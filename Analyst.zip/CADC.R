# CADC.R
# TODO: Add comment
# 
# Author: Mark Herzog
# Contact: mherzog@prbo.org
# Creation Date: May 31, 2009
###############################################################################

CADC<-function(ProtocolType, data.level="0", dsn="ravian_wh") {#Here we could pass the dsn or create on-the-fly as below, the dsn is provided by the wrapper
	## This file should not be part of public package.
	tmp<-new("DataStore")
	DataStructure(tmp)<- "RavianWarehouse"
	ConnectionType(tmp)<- "ODBC"
	if(dsn==""){
		dsn="DSN=ravian_wh"	#point to devel  'Try RavianWarehouse-Data
		driver="/usr/lib/x86_64-linux-gnu/odbc/libmyodbc.so"
		server="dwdb.pointblue.org"
		db.database="ravian_wh"
		db.user="ravian"
		db.password="zakufeme"
		DSN(tmp)<- createDSN(
				DSN=dsn,		#this may be required, so could use "tempConString" for example...
				driver=driver,
				server=server,
				database=db.database,
				user=db.user,
				password=db.password)
	}else{
		DSN(tmp)<-as.character(dsn)
	}
	tbl.name.pref<-switch(ProtocolType,
			PointCount = "RavianPointCount",
			Band = "RavianBanding",
			AreaSearch = "RavianAreaSearch",
			BBS = "RavianBBS",
			eBird = "RavianEBird",
			ShoreBird = "ShoreBird",
			ISBAdb = "ISBAdb",
			ShoreBirdGeo = "ShoreBird",
			eBird_SEADC = "RavianEBird_SEADC",
			BBS_SEADC = "RavianBBS_SEADC")
	if(is.null(tbl.name.pref))tbl.name.pref<-"RavianPointCount"
	tbl.name.suff<-switch(data.level,
			"0" = "Level0_v1",
			"1" = "Level1_v1",
			"2" = "Level2_v1",
			"3" = "Level3_v1",
			"4" = "Level4_v1",
			"5" = "Level5_v1",
			"b" = "Base_v1")
	if(ProtocolType=="ShoreBirdGeo"){tbl.name.suff<-"Base_v2"} #this is temporary
	if(is.null(tbl.name.suff))tbl.name.suff<-"Level0_v1"
	tbl.name<-paste(tbl.name.pref,tbl.name.suff,sep="")
	TableName(tmp)<-tbl.name
	return(tmp)
}