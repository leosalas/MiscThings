<?php
error_reporting(E_ALL);

$reqpath=$_SERVER['DOCUMENT_ROOT'];

require_once("$reqpath/lib/rserve-php/Connection.php");
require_once("$reqpath/Analyst/make_formData.php");
require_once("$reqpath/Analyst/loadRavianLibs.php");

ob_start(); 

try{

        $cnx = new Rserve_Connection('127.0.0.1',6311,array('debug'=>FALSE));

        //load the needed libraries into the R session - look in the file loadRavianLibs.php
        loadRavianLibs($cnx);

        //declare two R vairables in session
        $result=$cnx->evalString('results<-list()');
        $result=$cnx->evalString('results.out<-""');

        //create the R list object "formData"
        $cnarr = make_formData($_REQUEST);

        //write latest formData request
        if ($handle = fopen('/var/www/html/tmp/raviandata.txt','w')) {
           fwrite($handle, print_r($cnarr, true));
           fclose($handle);
         }

        //load formData to the R session and check its contents
        $result=$cnx->evalString($cnarr);
        $rwcheck=$cnx->evalString('rwerror<-checkRavianWebErrors(formData)');

        //HERE, if it is an empty string, continue, else echo it
        if($rwcheck!=""){
                // there are errors in the post
                echo $rwcheck;
        }else {
                //post is OK. Pass formData to the called process 
				//All wrappers return text or a list object. Need a Dispatch function that will generate the xml or just cat the error
				$rwresults=$cnx->evalString('results<-try(do.call("RavianWeb.Dispatch",args=list(formData)),silent=TRUE)');
				//Whatever dispatch receives, must convert to XML
		
				//Dispatch prints the xml, so must end with print(resultsOut); here passed as-is
				echo $rwresults;
        }
        //close
        $cnx->close();


}
catch (Exception $e) {
        echo $e->getMessage();
        if ($cnx) $cnx->close();
}

ob_end_flush();

//End of script
?>

