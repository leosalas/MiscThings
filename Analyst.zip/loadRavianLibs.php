<?php
function loadRavianLibs($conn) {
	try{

		$result=$conn->evalString('library(Ravian)');
		$result=$conn->evalString('library(RavianWeb)');
//		$result=$conn->evalString('source("/var/www/html/Analyst/CADC.R")');
	}
	catch (Exception $e){
		throw $e;
	}
}
// end of script
