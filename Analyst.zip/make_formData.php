<?php
function make_formData(){
	//mandatories
	if(empty($_REQUEST["Process"])){
		$proc='""';
	}else{
		$proc='"' . $_REQUEST["Process"] . '"';
	}
	if(empty($_REQUEST["DataType"])){
		$dtp='""';
	}else{
		$dtp='"' . $_REQUEST["DataType"] . '"';
	}
	if(empty($_REQUEST["eventSQL"])){
		$evs='""';
	}else{
		$evs='"' . $_REQUEST["eventSQL"] . '"';
	}
	
	//optionals
	if(empty($_REQUEST["OutputType"])){
		$outt='"XML"';
	}else{
		$outt='"' . $_REQUEST["OutputType"] . '"';
	}
	if(empty($_REQUEST["obsSQL"])){
		$ovs='""';
	}else{
		$ovs='"' . $_REQUEST["obsSQL"] . '"';
	}
	if(isset($_REQUEST["level"])){ // && (is_null($_REQUEST["level"]) || strlen($_REQUEST["level"])=0)){
		$lvl='"' . $_REQUEST["level"] . '"';
		//$lvl='"3"';
	}else{
		$lvl='"3"';
		//$lvl='"' . $_REQUEST["level"] . '"';
	}
	if(empty($_REQUEST["TaxonGroups"])){
		$tgr='""';
		$tgrn='""';
	}else{
		$tgr="'" . $_REQUEST["TaxonGroups"] . "'";
		if(empty($_REQUEST["TaxonGroupsName"])){
			$tgrn='"Taxon_Guilds"';
		}else{
			$tgrn='"' . $_REQUEST["TaxonGroupsName"] . '"';
		}
	}
	if(empty($_REQUEST["SpatialGroups"])){
		$sgr='""';
		$sgrn='""';
	}else{
		$sgr="'" . $_REQUEST["SpatialGroups"] . "'";
		if(empty($_REQUEST["SpatialGroupsName"])){
			$sgrn='"Spatial_Groups"';
		}else{
			$sgrn='"' . $_REQUEST["SpatialGroupsName"] . '"';
		}
	}
	if(empty($_REQUEST["ObservationGroups"])){
		$ogr='""';
		$ogrn='""';
	}else{
		$ogr="'" . $_REQUEST["ObservationGroups"] . "'";
		if(empty($_REQUEST["ObservationGroupsName"])){
			$ogrn='"Observation_Groups"';
		}else{
			$ogrn='"' . $_REQUEST["ObservationGroupsName"] . '"';
		}
	}
	if(empty($_REQUEST["spatialRez"]) and (strtolower($_REQUEST["DataType"])=="pointcount")){
		$sprz='"Transect"';
	}else{
		$sprz='"' . $_REQUEST["spatialRez"] . '"';
	}
	//add the other params
	//then add the rest of the callRavian code
	$cnarr = 'formData<-list(Process=' . $proc . ',OutputType=' . $outt . ',DataType=' . $dtp . 
			',eventSQL=' . $evs . ',obsSQL=' . $ovs . ',level=' . $lvl . ',TaxonGroups=' . $tgr .
			',TaxonGroupsName=' . $tgrn . ',SpatialGroups=' . $sgr . ',SpatialGroupsName=' . $sgrn .
			',ObservationGroups=' . $ogr . ',ObservationGroupsName=' . $ogrn . ',SpatialResolution=' . $sprz . ')';
	return($cnarr);
}
// end of script
