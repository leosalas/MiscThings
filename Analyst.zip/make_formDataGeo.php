<?php
function make_formDataGeo(){
	//Ravian mandatories
	if(empty($_REQUEST["Process"])){
		$proc='""';
	}else{
		$proc='"' . $_REQUEST["Process"] . '"';
	}
	if(empty($_REQUEST["DataType"])){
		$dtp='""';
	}else{
		$dtp='"' . $_REQUEST["DataType"] . '"';
	}
	if(empty($_REQUEST["eventSQL"])){
		$evs='""';
	}else{
		$evs='"' . $_REQUEST["eventSQL"] . '"';
	}
	
	//optionals
	if(empty($_REQUEST["OutputType"])){
		$outt='"XML"';
	}else{
		$outt='"' . $_REQUEST["OutputType"] . '"';
	}
	if(empty($_REQUEST["obsSQL"])){
		$ovs='""';
	}else{
		$ovs='"' . $_REQUEST["obsSQL"] . '"';
	}
	if(empty($_REQUEST["level"])){
		$lvl='"3"';
	}else{
		$lvl='"' . $_REQUEST["level"] . '"';
	}
	if(empty($_REQUEST["TaxonGroups"])){
		$tgr='""';
		$tgrn='""';
	}else{
		$tgr="'" . $_REQUEST["TaxonGroups"] . "'";
		if(empty($_REQUEST["TaxonGroupsName"])){
			$tgrn='"Taxon_Guilds"';
		}else{
			$tgrn='"' . $_REQUEST["TaxonGroupsName"] . '"';
		}
	}
	if(empty($_REQUEST["SpatialGroups"])){
		$sgr='""';
		$sgrn='""';
	}else{
		$sgr="'" . $_REQUEST["SpatialGroups"] . "'";
		if(empty($_REQUEST["SpatialGroupsName"])){
			$sgrn='"Spatial_Groups"';
		}else{
			$sgrn='"' . $_REQUEST["SpatialGroupsName"] . '"';
		}
	}
	if(empty($_REQUEST["ObservationGroups"])){
		$ogr='""';
		$ogrn='""';
	}else{
		$ogr="'" . $_REQUEST["ObservationGroups"] . "'";
		if(empty($_REQUEST["ObservationGroupsName"])){
			$ogrn='"Observation_Groups"';
		}else{
			$ogrn='"' . $_REQUEST["ObservationGroupsName"] . '"';
		}
	}
	//add the geo params
	if(empty($_REQUEST["GeoDataObsLink"])){
		$gdol='""';
	}else{
		$gdol="'" . $_REQUEST["GeoDataObsLink"] . "'";
	}
	if(empty($_REQUEST["GeoLinkParVals1"])){
		$glpv1='""';
	}else{
		$glpv1="'" . $_REQUEST["GeoLinkParVals1"] . "'";
	}
	if(empty($_REQUEST["GeoLinkParVals2"])){
		$glpv2='""';
	}else{
		$glpv2="'" . $_REQUEST["GeoLinkParVals2"] . "'";
	}
	if(empty($_REQUEST["QueryGeo"])){
		$qgeo='""';
	}else{
		$qgeo="'" . $_REQUEST["QueryGeo"] . "'";
	}
	if(empty($_REQUEST["geoDbName"])){
		$qgdbn='""';
	}else{
		$qgdbn="'" . $_REQUEST["geoDbName"] . "'";
	}
	if(empty($_REQUEST["wkt"])){
		$wkt='""';
	}else{
		$wkt="'" . $_REQUEST["wkt"] . "'";
	}
	if(empty($_REQUEST["collTables"])){
		$colltbls='""';
	}else{
		$colltbls="'" . $_REQUEST["collTables"] . "'";
	}
	if(empty($_REQUEST["geoType"])){
		$qgtype='""';
	}else{
		$qgtype="'" . $_REQUEST["geoType"] . "'";
	}
	if(empty($_REQUEST["queryType"])){
		$qgqtype='""';
	}else{
		$qgqtype="'" . $_REQUEST["queryType"] . "'";
	}
	
	
	//then add the rest of the callRavian code
	$cnarr = 'formData<-list(Process=' . $proc . ',OutputType=' . $outt . ',DataType=' . $dtp . 
			',eventSQL=' . $evs . ',obsSQL=' . $ovs . ',level=' . $lvl . ',TaxonGroups=' . $tgr .
			',TaxonGroupsName=' . $tgrn . ',SpatialGroups=' . $sgr . ',SpatialGroupsName=' . $sgrn .
			',ObservationGroups=' . $ogr . ',ObservationGroupsName=' . $ogrn . 
			',GeoDataObsLink=' . $gdol . ',GeoLinkParVals1=' . $glpv1 . ',GeoLinkParVals2=' . $glpv2 . 
			',QueryGeo=' . $qgeo . ',geoDbName=' . $qgdbn . ',wkt=' . $wkt . ',collTables=' . $colltbls .
			',geoType=' . $qgtype . ',queryType=' . $qgqtype . ')';
	return($cnarr);
}
// end of script