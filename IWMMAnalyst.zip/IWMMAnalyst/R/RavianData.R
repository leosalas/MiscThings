# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This class stores effort and observational data in different slots, and  
## provides methods to merge these (long, wide) and summarize these:
## numEvents, numObs, numSpecies, summarizeVar, totalObsBySpecies
## This will be a class available to the client app

################################## Object def
#' Abstract class for RavianData
#' 
#' Abstract class for RavianData
#' 
#' @param EffortData A data.frame with the effort data
#' @param ObsData A data.frame with the observational data
#' @param MergedData A data.frame with the merged effort and observation tables
#' @param ErrorReport A string with any execution errors
setClass("RavianData", representation(
				EffortData = "data.frame",
				ObsData = "data.frame",
				MergedData = "data.frame",
				ErrorReport = "character"
		)
)

############################### class operation methods ############################################################

############################## EffortData
#' Set generic to  method that sets the EffortData slot of RavianData object.
#' 
#' @name setEffortData
#' @param object A RavianData object
#' @param value A data.frame to put into the EffortData slot
setGeneric("EffortData<-", 
		function(object, value)	standardGeneric("EffortData<-"))

#' Set EffortData slot of RavianData object.
#' 
#' @name setEffortData
#' @param object A RavianData object
#' @param value A data.frame to put into the EffortData slot
setReplaceMethod("EffortData",signature(object="RavianData"),
		function(object,value) {
			slot(object,"EffortData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the EffortData slot of the RavianData object.
#' 
#' @name EffortData
#' @param object A RavianData object
setGeneric("EffortData", 
		function(object) standardGeneric("EffortData"))

#' Retrieve the contents of the EffortData slot of the RavianData object.
#' 
#' @name EffortData
#' @param object A RavianData object
setMethod("EffortData", signature(object="RavianData"),
		function(object) slot(object,"EffortData"))


############################## ObsData
#' Set generic to  method that sets the ObsData slot of RavianData object.
#' 
#' @name setObsData
#' @param object A RavianData object
#' @param value A data.frame to put into the ObsData slot
setGeneric("ObsData<-", 
		function(object, value)	standardGeneric("ObsData<-"))

#' Set ObsData slot of RavianData object.
#' 
#' @name setObsData
#' @param object A RavianData object
#' @param value A data.frame to put into the ObsData slot
setReplaceMethod("ObsData",signature(object="RavianData"),
		function(object,value) {
			slot(object,"ObsData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the ObsData slot of the RavianData object.
#' 
#' @name ObsData
#' @param object A RavianData object
setGeneric("ObsData", 
		function(object) standardGeneric("ObsData"))

#' Retrieve the contents of the EffortData slot of the RavianData object.
#' 
#' @name ObsData
#' @param object A RavianData object
setMethod("ObsData", signature(object="RavianData"),
		function(object) slot(object,"ObsData"))

############################## MergedData
#' Set generic to  method that sets the MergedData slot of RavianData object.
#' 
#' @name setEffortData
#' @param object A RavianData object
#' @param value A data.frame to put into the MergedData slot
setGeneric("MergedData<-", 
		function(object, value)	standardGeneric("MergedData<-"))

#' Set MergedData slot of RavianData object.
#' 
#' @name setEffortData
#' @param object A RavianData object
#' @param value A data.frame to put into the MergedData slot
setReplaceMethod("MergedData",signature(object="RavianData"),
		function(object,value) {
			slot(object,"MergedData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the MergedData slot of the RavianData object.
#' 
#' @name MergedData
#' @param object A RavianData object
setGeneric("MergedData", 
		function(object) standardGeneric("MergedData"))

#' Retrieve the contents of the MergedData slot of the RavianData object.
#' 
#' @name MergedData
#' @param object A RavianData object
setMethod("MergedData", signature(object="RavianData"),
		function(object) slot(object,"MergedData"))

############################## ErrorReport
#Generic set by validateRavianDomain.R

#' Set ErrorReport slot of RavianData object.
#' 
#' @name setErrorReport
#' @param object An RavianData object
#' @param value A string to put into the ErrorReport slot
setReplaceMethod("ErrorReport",signature(object="RavianData"),
		function(object,value) {
			slot(object,"ErrorReport")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ErrorReport slot of the RavianData object.
#' 
#' @name ErrorReport
#' @param object An RavianData object
setMethod("ErrorReport", signature(object="RavianData"),
		function(object) slot(object,"ErrorReport"))


############################## Initialize
#' Instantiate a new RavianData object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "RavianData"),
		function (.Object, ...) 
		{
			.Object@EffortData 	<- data.frame()
			.Object@ObsData 	<- data.frame()
			.Object@MergedData 	<- data.frame()
			.Object@ErrorReport	<- character()
			.Object
		}
)

############################################## Methods #####################################

##################################### mergeRavianData
#' Set generic to  method that merges effort and observation tables for a RavianData object
#' 
#' @name mergeRavianData
#' @param object A RavianData object. 
#' @param by A string specifying the type of merge, with the following possible values: long, and wide
#' 			The long format preserves all the information in both the effort and the observational data
#' 			The wide format preserves all the information in the effort data and adds a column per species, with the total detection for the species in each event
setGeneric("mergeRavianData",
		function(object, by, ...) standardGeneric("mergeRavianData"))

#' Merge effort and observation tables in a RavianData object
#' 
#' @param object A RavianData object.
#' @param by A string specifying the type of merge, with the following possible values: long, and wide
#' 			The long format preserves all the information in both the effort and the observational data
#' 			The wide format preserves all the information in the effort data and adds a column per species, with the total detection for the species in each event
setMethod("mergeRavianData", signature(object = "RavianData"),
		function(object, by="long", ...) {
			eff<-EffortData(object)
			obs<-ObsData(object)
			if(NROW(eff)==0){
				ErrorReport(object)<-"Error: no effort data to merge."
			}else if(NROW(obs)==0){
				ErrorReport(object)<-"Error: no effort data to merge."
			}else{
				nms<-names(eff);nms<-nms[which(nms %in% names(obs))]
				if(by=="long"){
					mrg<-try(merge(eff,obs,by=nms,all.x=TRUE),silent=TRUE)
					if(inherits(mrg,"try-error")){
						ErrorReport(object)<-"Error: failed to merge effort and observational data by long format."
					}else{
						mrg$ObservationCount<-ifelse(is.na(mrg$ObservationCount),0,mrg$ObservationCount)
						MergedData(object)<-mrg
					}
				}else if(by=="wide"){
					obsw<-obs[,c(nms,"SpeciesCode","ObservationCount")]
					obsr<-reshape(obsw,idvar=nms,v.names="ObservationCount",timevar="SpeciesCode",direction="wide")
					nmsspp<-names(obsr)[which(!names(obsr) %in% nms)]
					nmsspp<-substr(nmsspp,7,10)
					names(obsr)<-c(nms,nmsspp)
					for(sss in nmsspp){
						obsr[,sss]<-ifelse(is.na(obsr[,sss]),0,obsr[,sss])
					}
					mrg<-try(merge(eff,obsr,by=nms,all.x=TRUE),silent=TRUE)
					if(inherits(mrg,"try-error")){
						ErrorReport(object)<-"Error: failed to merge effort and observational data by wide format."
					}else{
						MergedData(object)<-mrg
					}
				}else{
					ErrorReport(object)<-"Error: Ravian does not know how to merge data as specified."
				}
			}
			return(object)
		}
)
