#' @include RavianData.R

# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This object takes the data (effort and observation tables), formData, and the file to source. 
## It loads the file, calls the function, passes the parameters and takes the results

################################## Object def
#' Abstract class for analysisResult
#' 
#' Abstract class for analysisResult
#' 
#' @param FormData A json string with the GET/POST request as it was passed to analysisResult
#' @param BirdData A RavianData object with the effort and observation tables
#' @param PluginName A string naming the file to source 
#' @param AnalysisResult A list storing the results, and any errors executing
#' @param ErrorReport A string with any execution errors
setClass("analysisResult", representation(
				FormData = "character",
				BirdData = "RavianData",
				PluginName = "character",
				AnalysisResult = "list",
				ErrorReport = "character"
		)
)

############################### class operation methods ############################################################

############################## FormData
#Generic set by speciesKeys.R

#' Set FormData slot of analysisResult object.
#' 
#' @name setFormData
#' @param object An analysisResult object
#' @param value A json string to put into the FormData slot, which includes the parameters of the POST.
setReplaceMethod("FormData",signature(object="analysisResult"),
		function(object,value) {
			slot(object,"FormData")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the FormData slot of the analysisResult object.
#' 
#' @name FormData
#' @param object An analysisResult object
setMethod("FormData", signature(object="analysisResult"),
		function(object) slot(object,"FormData"))

############################## BirdData
#' Set generic to  method that sets the BirdData slot of analysisResult object.
#' 
#' @name setBirdData
#' @param object An analysisResult object
#' @param value A RavianData object with the effort and observation tables
setGeneric("BirdData<-", 
		function(object, value)	standardGeneric("BirdData<-"))

#' Set BirdData slot of analysisResult object.
#' 
#' @name setBirdData
#' @param object An analysisResult object
#' @param value A RavianData object with the effort and observation tables
setReplaceMethod("BirdData",signature(object="analysisResult"),
		function(object,value) {
			slot(object,"BirdData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the BirdData slot of the analysisResult object.
#' 
#' @name BirdData
#' @param object An analysisResult object
setGeneric("BirdData", 
		function(object) standardGeneric("BirdData"))

#' Retrieve the contents of the BirdData slot of the analysisResult object.
#' 
#' @name BirdData
#' @param object An analysisResult object
setMethod("BirdData", signature(object="analysisResult"),
		function(object) slot(object,"BirdData"))

############################## PluginName
#Generic set by checkPlugin.R

#' Set PluginName slot of analysisResult object.
#' 
#' @name setPluginName
#' @param object An analysisResult object
#' @param value A string naming the file to source for the application requested
setReplaceMethod("PluginName",signature(object="analysisResult"),
		function(object,value) {
			slot(object,"PluginName")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the PluginName slot of the analysisResult object.
#' 
#' @name PluginName
#' @param object An analysisResult object
setMethod("PluginName", signature(object="analysisResult"),
		function(object) slot(object,"PluginName"))

############################## AnalysisResult
#' Set generic to  method that sets the AnalysisResult slot of analysisResult object.
#' 
#' @name setAnalysisResult
#' @param object An analysisResult object
#' @param value A list with the results of the execution of an analysis function
setGeneric("AnalysisResult<-", 
		function(object, value)	standardGeneric("AnalysisResult<-"))

#' Set AnalysisResult slot of analysisResult object.
#' 
#' @name setAnalysisResult
#' @param object An analysisResult object
#' @param value A list with the results of the execution of an analysis function
setReplaceMethod("AnalysisResult",signature(object="analysisResult"),
		function(object,value) {
			slot(object,"AnalysisResult")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the AnalysisResult slot of the analysisResult object.
#' 
#' @name AnalysisResult
#' @param object An analysisResult object
setGeneric("AnalysisResult", 
		function(object) standardGeneric("AnalysisResult"))

#' Retrieve the contents of the AnalysisResult slot of the analysisResult object.
#' 
#' @name AnalysisResult
#' @param object An analysisResult object
setMethod("AnalysisResult", signature(object="analysisResult"),
		function(object) slot(object,"AnalysisResult"))

############################## ErrorReport
#Generic set by validateRavianDomain.R

#' Set ErrorReport slot of analysisResult object.
#' 
#' @name setErrorReport
#' @param object An analysisResult object
#' @param value A string to put into the ErrorReport slot
setReplaceMethod("ErrorReport",signature(object="analysisResult"),
		function(object,value) {
			slot(object,"ErrorReport")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ErrorReport slot of the analysisResult object.
#' 
#' @name ErrorReport
#' @param object An analysisResult object
setMethod("ErrorReport", signature(object="analysisResult"),
		function(object) slot(object,"ErrorReport"))


############################## Initialize
#' Instantiate a new analysisResult object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "analysisResult"),
		function (.Object, ...) 
		{
			.Object@FormData 		<- character()
			.Object@BirdData 		<- new("RavianData")
			.Object@PluginName 		<- character()
			.Object@AnalysisResult	<- list()
			.Object@ErrorReport		<- character()
			.Object
		}
)


##################################### Methods ##################################
#requestApplicationResults(object)
#' Set generic to  method that requests the execution of an analysis on Ravian
#' 
#' @name requestApplicationResults
#' @param object An analysisResult object. 
setGeneric("requestApplicationResults",
		function(object) standardGeneric("requestApplicationResults"))

#' Request the analysis of some data in Ravian
#' 
#' @param object An analysisResult object.
setMethod("requestApplicationResults", signature(object = "analysisResult"),
		function(object) {
			fnct.name<-PluginName(object)
			regpath<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianPluginRegistry.yaml",sep="")),silent=TRUE)
			srcpth<-paste(regpath$sourcepath,fnct.name,sep="")	
			source(srcpth)
			
			#pass BirdData as is - a list
			data<-BirdData(object)
			
			
			#cycle through all names in fd, and exclude the obvious: project, protocol, species, guild, seasonal, sttdate, enddate, region, location, whname, appName
			#all other parameters will go in the args list as a list, and incorporated in the ... of the function
			fd<-fromJSON(FormData(object))
			fda<-fd[["analysisName"]]
			parnames<-names(fd)
			parnames<-parnames[which(!parnames %in% c("analysisName","warehouseName","region","samplingUnits","guilds",
									"species","obsgroup","seasonal","startDate","endDate","projects","protocols","accLevel","outputFormat"))]
			
			argslst<-list() 
			env<-new.env()
			assign(fda,as.name(fda),envir=env)
			argslst[["dataObj"]]<-data
			for(nn in parnames){
				argslst[[nn]]<-fd[[nn]]
				assign(nn,as.name(nn),envir=env)
			}
			
			results<-try(do.call(fda,args=argslst, envir=env),silent=TRUE)
			if(inherits(results,"try-error")){
				ErrorReport(object)<-as.character(results)
			}else if(class(results)!="list"){
				eo<-new("RavianResultError")
				ResultTitle(eo)<-"Error generating analysis results"
				ResultType(eo)<-"Error"
				ErrorDescription(eo)<-"Ravian submitted the request for analyses but the results are not a list object."
				SinkObjects(eo)<-list(object=object,results=results)
				ErrorDate(eo)<-as.character(Sys.time())
				AnalysisResult(object)<-list(ErrorObj=eo)
			}else if(NROW(results)==0){
				eo<-new("RavianResultWarning")
				ResultTitle(eo)<-"Warning - the request for analyses resulted in no results returned."
				ResultType(eo)<-"Warning"
				WarningDescription(eo)<-"Ravian sent the request for the appropriate analysis but it returned no results. Probably the data did not meet the minimal requirements for analysis?"
				results[[1]]<-eo
				AnalysisResult(object)<-results
			}else{
				AnalysisResult(object)<-results
			}
			return(object)
})

