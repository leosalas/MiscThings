# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This class uses information passed to it by other classes (fetchRavianData, speciesKeys, locationKeys, fetchGeospatialData) 
## to return a object of the class connectRavian with a connection handle

################################## Object def
#' Abstract class for connectRavian
#' 
#' Abstract class for connectRavian
#' 
#' @param ResultHandle A list whose first element is a connection handle, or an error in attempting to get a connection handle
#' @param HandleType A string specifying the type of handle requested: support, warehouse, geospatial
setClass("connectRavian", representation(
				ResultHandle = "list",
				HandleType = "character"
		)
)

############################### class operation methods ############################################################

############################## ResultHandle
#' Set generic to  method that sets the ResultHandle slot of connectRavian object.
#' 
#' @name setResultHandle
#' @param object A connectRavian object
#' @param value A list to put into the ResultHandle slot, whose first element is a connection handle, or an error in attempting to get a conection handle
setGeneric("ResultHandle<-", 
		function(object, value)	standardGeneric("ResultHandle<-"))

#' Set ResultHandle slot of connectRavian object.
#' 
#' @name setResultHandle
#' @param object A connectRavian object
#' @param value A list to put into the ResultHandle slot, whose first element is a connection handle, or an error in attempting to get a conection handle
setReplaceMethod("ResultHandle",signature(object="connectRavian"),
		function(object,value) {
			slot(object,"ResultHandle")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the ResultHandle slot of the connectRavian object.
#' 
#' @name ResultHandle
#' @param object A connectRavian object
setGeneric("ResultHandle", 
		function(object) standardGeneric("ResultHandle"))

#' Retrieve the contents of the ResultHandle slot of the connectRavian object.
#' 
#' @name ResultHandle
#' @param object A connectRavian object
setMethod("ResultHandle", signature(object="connectRavian"),
		function(object) slot(object,"ResultHandle"))


############################## HandleType
#' Set generic to  method that sets the HandleType slot of connectRavian object.
#' 
#' @name setHandleType
#' @param object A connectRavian object
#' @param value A string to put into the HandleType slot, valid values: support, warehouse, geospatial
setGeneric("HandleType<-", 
		function(object, value)	standardGeneric("HandleType<-"))

#' Set HandleType slot of connectRavian object.
#' 
#' @name setHandleType
#' @param object A connectRavian object
#' @param value A string to put into the HandleType slot, valid values: support, warehouse, geospatial
setReplaceMethod("HandleType",signature(object="connectRavian"),
		function(object,value) {
			slot(object,"HandleType")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the HandleType slot of the connectRavian object.
#' 
#' @name HandleType
#' @param object A connectRavian object
setGeneric("HandleType", 
		function(object) standardGeneric("HandleType"))

#' Retrieve the contents of the ResultHandle slot of the connectRavian object.
#' 
#' @name HandleType
#' @param object A connectRavian object
setMethod("HandleType", signature(object="connectRavian"),
		function(object) slot(object,"HandleType"))


############################## Initialize
#' Instantiate a new connectRavian object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "connectRavian"),
		function (.Object, ...) 
		{
			.Object@ResultHandle 	<- list()
			.Object@HandleType 		<- character()
			.Object
		}
)


##################################### getRavianHandle
#' Set generic to  method that gets a connection handle object for a connectRavian object
#' 
#' @name getRavianHandle
#' @param object A connectRavian object. 
setGeneric("getRavianHandle",
		function(object, ...) standardGeneric("getRavianHandle"))

#' get a connection handle object for a connectRavian object
#' 
#' @param object A connectRavian object.
setMethod("getRavianHandle", signature(object = "connectRavian"),
		function(object, ...) {
			connectType<-HandleType(object)
			if(connectType=="warehouse"){
				dsn="ravian_wh"
				conn<-try(odbcConnect(dsn),silent=TRUE)
			}else if(connectType=="support"){
				dsn="PRBOdb"
				conn<-odbcConnect(dsn)
			}else if(connectType=="geospatial"){
				conn<-"Error: this version of Ravian is not yet set to handle geospatial queries"
				class(conn)<-"try-error"
			}else{
				conn<-"Error: the requested connection handle type is unknown to Ravian"
				class(conn)<-"try-error"
			}
			ResultHandle(object)<-list(conn)
			return(object)
			
		}
)


