#' @include utilsRavian.R
#' @include fetchRavianData.R
#' @include connectRavian.R
#' @include encodeRavianResults.R
#' @include speciesKeys.R
#' @include locationKeys.R
#' @include checkPlugin.R
#' @include analysisResult.R
#' @include RavianData.R
#' @include RavianResults.R

# TODO: Add comment
# 
# Author: lsalas
# Contact: lsalas@pointblue.org
# Creation Date: February 2, 2016
###############################################################################

################################## Object def
#' Abstract class for dispatchRavian
#' 
#' Abstract class for dispatchRavian
#' 
#' @param FormData A json string with the GET/POST parameters
#' @param ConnectHandle A connectRavian object
#' @param FetchedData A fetchRavianData object
#' @param SpeciesData A speciesKeys object
#' @param LocationData A locationKeys object
#' @param AppResults A list that contains all the results prepared by the app: tables, and/or graphs, and/or errors
#' @param EncodedResults An encodeRavianResults object
setClass("dispatchRavian", representation(
				FormData = "character",
				ConnectHandle = "connectRavian",
				FetchedData = "fetchRavianData",
				SpeciesData = "speciesKeys",
				LocationData = "locationKeys",
				PluginName = "checkPlugin",
				AppResults = "analysisResult",
				EncodedResults = "encodeRavianResults"
		)
)

############################### class operation methods ############################################################

############################## FormData
#Generic set by speciesKeys.R

#' Set FormData slot of dispatchRavian object.
#' 
#' @name setFormData
#' @param object A dispatchRavian object
#' @param value A json string to put into the FormData slot, which includes the parameters of the POST.
setReplaceMethod("FormData",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"FormData")<-value
			validObject(object)
			object
		})


#' Retrieve the contents of the FormData slot of the dispatchRavian object.
#' 
#' @name FormData
#' @param object A dispatchRavian object
setMethod("FormData", signature(object="dispatchRavian"),
		function(object) slot(object,"FormData"))

############################## ConnectHandle
#Generic set by speciesKeys.R

#' Set ConnectHandle slot of dispatchRavian object.
#' 
#' @name setConnectHandle
#' @param object A dispatchRavian object
#' @param value A connectRavian object to put into the ConnectHandle slot.
setReplaceMethod("ConnectHandle",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"ConnectHandle")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ConnectHandle slot of the dispatchRavian object.
#' 
#' @name ConnectHandle
#' @param object A dispatchRavian object
setMethod("ConnectHandle", signature(object="dispatchRavian"),
		function(object) slot(object,"ConnectHandle"))


############################## FetchedData
#' Set generic to  method that sets the FetchedData slot of dispatchRavian object.
#' 
#' @name setFetchedData
#' @param object A dispatchRavian object
#' @param value A fetchRavianData object to put into the FetchedData slot, containing: support data data.frame, effort data data.frame, observation data data.frame, and (optional) geospatial data data.frame.
setGeneric("FetchedData<-", 
		function(object, value)	standardGeneric("FetchedData<-"))

#' Set FetchedData slot of dispatchRavian object.
#' 
#' @name setFetchedData
#' @param object A dispatchRavian object
#' @param value A fetchRavianData object to put into the FetchedData slot, containing: support data data.frame, effort data data.frame, observation data data.frame, and (optional) geospatial data data.frame.
setReplaceMethod("FetchedData",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"FetchedData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the FetchedData slot of the dispatchRavian object.
#' 
#' @name FetchedData
#' @param object A dispatchRavian object
setGeneric("FetchedData", 
		function(object) standardGeneric("FetchedData"))

#' Retrieve the contents of the FetchedData slot of the dispatchRavian object.
#' 
#' @name FetchedData
#' @param object A dispatchRavian object
setMethod("FetchedData", signature(object="dispatchRavian"),
		function(object) slot(object,"FetchedData"))


############################## SpeciesData
#Generic set by fetchRavianData.R

#' Set SpeciesData slot of dispatchRavian object.
#' 
#' @name setSpeciesData
#' @param object A dispatchRavian object
#' @param value A speciesKeys object to put into the SpeciesData slot.
setReplaceMethod("SpeciesData",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"SpeciesData")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the SpeciesData slot of the dispatchRavian object.
#' 
#' @name SpeciesData
#' @param object A dispatchRavian object
setMethod("SpeciesData", signature(object="dispatchRavian"),
		function(object) slot(object,"SpeciesData"))


############################## LocationData
#Generic set by fetchRavianData.R

#' Set LocationData slot of dispatchRavian object.
#' 
#' @name setLocationData
#' @param object A dispatchRavian object
#' @param value A locationKeys object to put into the LocationData slot.
setReplaceMethod("LocationData",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"LocationData")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the LocationData slot of the dispatchRavian object.
#' 
#' @name LocationData
#' @param object A dispatchRavian object
setMethod("LocationData", signature(object="dispatchRavian"),
		function(object) slot(object,"LocationData"))


############################## PluginName
#Generic set by checkPlugin.R

#' Set PluginName slot of dispatchRavian object.
#' 
#' @name setPluginName
#' @param object A dispatchRavian object
#' @param value A checkPlugin object to put into the PluginName slot.
setReplaceMethod("PluginName",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"PluginName")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the PluginName slot of the dispatchRavian object.
#' 
#' @name PluginName
#' @param object A dispatchRavian object
setMethod("PluginName", signature(object="dispatchRavian"),
		function(object) slot(object,"PluginName"))


############################## AppResults
#' Set generic to  method that sets the AppResults slot of dispatchRavian object.
#' 
#' @name setAppResults
#' @param object A dispatchRavian object
#' @param value An analysisResult object to put into the AppResults slot, which contains the results of the execution of a Ravian application: a list of tables and/or graphs.
setGeneric("AppResults<-", 
		function(object, value)	standardGeneric("AppResults<-"))

#' Set AppResults slot of dispatchRavian object.
#' 
#' @name setAppResults
#' @param object A dispatchRavian object
#' @param value An analysisResult object to put into the AppResults slot, which contains the results of the execution of a Ravian application: a list of tables and/or graphs.
setReplaceMethod("AppResults",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"AppResults")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the AppResults slot of the dispatchRavian object.
#' 
#' @name AppResults
#' @param object A dispatchRavian object
setGeneric("AppResults", 
		function(object) standardGeneric("AppResults"))

#' Retrieve the contents of the AppResults slot of the dispatchRavian object.
#' 
#' @name AppResults
#' @param object A dispatchRavian object
setMethod("AppResults", signature(object="dispatchRavian"),
		function(object) slot(object,"AppResults"))

############################## EncodedResults
#' Set generic to  method that sets the EncodedResults slot of dispatchRavian object.
#' 
#' @name setEncodedResults
#' @param object A dispatchRavian object
#' @param value An encodeRavianResults object to put into the EncodedResults slot.
setGeneric("EncodedResults<-", 
		function(object, value)	standardGeneric("EncodedResults<-"))

#' Set EncodedResults slot of dispatchRavian object.
#' 
#' @name setEncodedResults
#' @param object A dispatchRavian object
#' @param value An encodeRavianResults object to put into the EncodedResults slot.
setReplaceMethod("EncodedResults",signature(object="dispatchRavian"),
		function(object,value) {
			slot(object,"EncodedResults")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the EncodedResults slot of the dispatchRavian object.
#' 
#' @name EncodedResults
#' @param object A dispatchRavian object
setGeneric("EncodedResults", 
		function(object) standardGeneric("EncodedResults"))

#' Retrieve the contents of the EncodedResults slot of the dispatchRavian object.
#' 
#' @name EncodedResults
#' @param object A dispatchRavian object
setMethod("EncodedResults", signature(object="dispatchRavian"),
		function(object) slot(object,"EncodedResults"))


############################## Initialize
#' Instantiate a new dispatchRavian object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "dispatchRavian"),
		function (.Object, ...) 
		{
			.Object@FormData 		<- character()
			.Object@ConnectHandle 	<- new("connectRavian")
			.Object@FetchedData 	<- new("fetchRavianData")
			.Object@SpeciesData 	<- new("speciesKeys")
			.Object@LocationData 	<- new("locationKeys")
			.Object@PluginName		<- new("checkPlugin")
			.Object@AppResults 		<- new("analysisResult")
			.Object@EncodedResults 	<- new("encodeRavianResults")
			.Object
		}
)



################################# class execution methods ###############################################
#error as list:
	#element 1 is type="error"
	#element 2 is sink/cat
	#element 3 is the message
	#element 4 is the object to sink (e.g., the dispatch object)
##################################### requestRavianResults
#' Set generic to  method that requests analysis results for a dispatchRavian object. This is the main method of the class
#' 
#' @name requestRavianResults
#' @param object An dispatchRavian object. 
#' @param requestParameters A json string with the GET/POST contents 
setGeneric("requestRavianResults",
		function(object, requestParameters) standardGeneric("requestRavianResults"))

#' Requests analysis results for a dispatchRavian object.
#' 
#' @param object A dispatchRavian object.
#' @param requestParameters A json string with the GET/POST contents
setMethod("requestRavianResults", signature(object = "dispatchRavian",requestParameters = "character"),
		function(object, requestParameters) {
			options(warn=-1);reslst<-list();
			#populate object with the request
			FormData(object)<-requestParameters
			
			#first, validate the request
			vobj<-new("validateRavianDomain")
			RequestParameters(vobj)<-requestParameters
			ValidationType(vobj)<-"general"
			validRes<-ErrorReport(requestDomainValidation(vobj))
			if(validRes==""){
				
				#get config info -> should load a data frame called RavianConfig - put this in UTILS?
				#Also, each plugin will have its own yaml file, stored in its own dir
				ravian.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianWarehouseRegistry.yaml",sep="")),silent=TRUE)
				plugin.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianPluginRegistry.yaml",sep="")),silent=TRUE)
				if(inherits(ravian.registry,"try-error") || inherits(plugin.registry,"try-error")){ #config list OK?
					eo<-new("RavianResultError")
					ResultTitle(eo)<-"Error retrieving registry data"
					ResultType(eo)<-"Error"
					ErrorDescription(eo)<-ifelse(inherits(ravian.registry,"try-error"),as.character(ravian.registry),as.character(plugin.registry))
					SinkObjects(eo)<-list(envir=paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianWarehouseRegistry.yaml",sep=""),ravian.registry=ravian.registry,plugin.registry=plugin.registry)
					ErrorDate(eo)<-as.character(Sys.time())
					reslst<-list();reslst[[1]]<-eo
					AppResults(object)<-reslst
				}else{	#Have config list for warehouse registry and plugin registry
					
					#######################################################################################################################################################
					## From here on, this will be done by the client app, not by Ravian, when they are able to use APIs
					## It should all be done by a wrapper
					
					#evaluate for the need of support info for species, returning a list of species FieldBirdId keys, if guild parameter is present.
					#if the post contains no Guild or Species values, it returns an empty list
					spKeys<-SpeciesData(object)
					FormData(spKeys)<-requestParameters
					SpeciesData(object)<-evaluateSpeciesKeys(spKeys)	#returns a list whose first element should be the numeric list of keys
					
					#ditto for location keys...
					lcKeys<-LocationData(object)
					FormData(lcKeys)<-requestParameters
					LocationData(object)<-evaluateLocationKeys(lcKeys)	#returns a list whose first element should be the numeric list of keys
					
					#eval for errors
					sk<-ErrorReport(SpeciesData(object))
					lk<-ErrorReport(LocationData(object))
					if(NROW(sk)>0 || NROW(lk)>0){
						eo<-new("RavianResultError")
						ResultTitle(eo)<-"Error retrieving species or locations keys"
						ResultType(eo)<-"Error"
						ErrorDescription(eo)<-ifelse(NROW(sk)==0,lk,sk)
						SinkObjects(eo)<-list(lcKeys=lcKeys,spKeys=spKeys,requestParameters=requestParameters)
						ErrorDate(eo)<-as.character(Sys.time())
						reslst<-list();reslst[[1]]<-eo
						AnalysisResult(AppResults(object))<-reslst
					}else{	#Have support data: species and location keys
						
						## instantiates fetchRavianData, passes handle and args for observational data, retrieves data into list for FetchedData slot [requestRavianData method]
						dataObj<-FetchedData(object)
						FormData(dataObj)<-requestParameters
						LocationData(dataObj)<-ResultKeys(LocationData(object))
						SpeciesData(dataObj)<-ResultKeys(SpeciesData(object))
						FetchedData(object)<-getRavianData(dataObj,ravian.registry)
						
						## checks for error in query result 
						gd<-ErrorReport(FetchedData(object))
						if(NROW(gd)>0){
							err<-paste(gd,collapse=". ")
							if(grepl("Ravian Warning",gd)){
								eo<-new("RavianResultWarning")
								ResultTitle(eo)<-"Warning - failed to retrieve requested data"
								ResultType(eo)<-"Warning"
								WarningDescription(eo)<-gd
							}else{
								eo<-new("RavianResultError")
								ResultTitle(eo)<-"Error retrieving requested data"
								ResultType(eo)<-"Error"
								ErrorDescription(eo)<-as.character(gd)
								SinkObjects(eo)<-list(object=dataObj)
								ErrorDate(eo)<-as.character(Sys.time())
							}
							reslst<-list();reslst[[1]]<-eo
							AnalysisResult(AppResults(object))<-reslst
						}else{
							
							## OPTIONAL - not now: instantiates connectRavian, requests conn handle for geo data [getRavianHandle method]
							## OPTIONAL - not now: passes handle and args for geo data to fetchRavianData object, retrieves data into list for FetchedData slot (geospatial data table) [requestRavianData method]
							## OPTIONAL - checks for error in query result
							## OPTIONAL - merges support with effort with geospatial -> effort [mergeEffortInfo function]
							
							## Till here, the above will be done by the client app.
							##########################################################################################################################################
							## Below here: #check the pluggin registration; if valid:
							## 1) pass formData, retrieve results
							## 2) encode results
							## 3) cat encoded results
							
							## validate the app
							appCheck<-PluginName(object)
							RegistryData(appCheck)<-plugin.registry
							FormData(appCheck)<-requestParameters
							PluginName(object)<-getPluginName(appCheck)
							
							anerr<-ErrorReport(PluginName(object))
							if(NROW(anerr)>0){	#is app registered?
								eo<-new("RavianResultError")
								ResultTitle(eo)<-"Error retrieving requested plugin"
								ResultType(eo)<-"Error"
								ErrorDescription(eo)<-as.character(paste(anerr,collapse=", "))
								SinkObjects(eo)<-list(object=appCheck)
								ErrorDate(eo)<-as.character(Sys.time())
								reslst<-list();reslst[[1]]<-eo
								AnalysisResult(AppResults(object))<-reslst
								
							}else{	#app registered OK
								## sources app code, calls the app, passing the effort and obs tables [requestAppResult method]
								appRes<-AppResults(object)
								FormData(appRes)<-requestParameters
								bdat<-BirdData(appRes)
								EffortData(bdat)<-ResultData(FetchedData(object))$effdata
								ObsData(bdat)<-ResultData(FetchedData(object))$obsdata
								BirdData(appRes)<-bdat
								PluginName(appRes)<-PluginName(PluginName(object))
								AppResults(object)<-requestApplicationResults(appRes)
								
								apperr<-ErrorReport(AppResults(object))
								if(NROW(apperr)>0){	#error executing app?
									eo<-new("RavianResultError")
									ResultTitle(eo)<-"Error retrieving requested analyses"
									ResultType(eo)<-"Error"
									ErrorDescription(eo)<-as.character(paste(apperr,collapse=", "))
									SinkObjects(eo)<-list(object=appRes)
									ErrorDate(eo)<-as.character(Sys.time())
									reslst<-list();reslst[[1]]<-eo
									AnalysisResult(AppResults(object))<-reslst
								}
							}
						}
					}
				}
			}else{
				eo<-new("RavianResultError")
				ResultTitle(eo)<-"Error validating the request to Ravian"
				ResultType(eo)<-"Error"
				ErrorDescription(eo)<-paste(validRes, collapse=". ")
				SinkObjects(eo)<-list(object=object)
				ErrorDate(eo)<-as.character(Sys.time())
				reslst<-list();reslst[[1]]<-eo
				AnalysisResult(AppResults(object))<-reslst
			}
				
			fd<-fromJSON(requestParameters)
			outtype<-ifelse(is.null(fd$outputFormat),"html",fd$outputFormat)	#defaulting to html!!!
			#if there are plots, there may be wdt and hgt parameters in fd, but must submit both
			if(TRUE %in% grepl("/^plotwidth$/",names(fd),fixed=T) && TRUE %in% grepl("/^plotheight$/",names(fd),fixed=T)){
				wdt<-fd[["plotwidth"]]; hgt<-fd[["plotheight"]]
				encObj<-EncodedResults(object,wdt=wdt,hgt=hgt)
			}else{
				encObj<-EncodedResults(object)
			}
			AnalysisTitle(encObj)<-AnalysisTitle(PluginName(object))
			Results(encObj)<-AnalysisResult(AppResults(object))
			OutputType(encObj)<-outtype
			RequestParameters(encObj)<-fd
			EncodedResults(object)<-encodeResults(encObj) #here specify what to show in tool tip!!
			## cats out the encoded results
			#cat(TextResults(EncodedResults(object)))
			return(TextResults(EncodedResults(object)))

		}
)









