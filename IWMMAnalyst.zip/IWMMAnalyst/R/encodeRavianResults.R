# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This class uses a list object containing results:
##		tables as list, graphs as list, error as list 
## plus a specification to return html (html tables, printed plots), javascript (highchart plots, js tables), or json (json tables, printed plots)


################################## Object def
#' Abstract class for encodeRavianResults
#' 
#' Abstract class for encodeRavianResults
#' 
#' @param AnalysisTitle A string with the title for the analysis that generated the results. This should be described in the yaml entry for the plugin used.
#' @param RequestParameters A list containing the full request parameters
#' @param Results A list object containing RavianResult sub-class objects: RavianResultTable, RavianResultGraph RavianResultError
#' @param OutputType A string specifying the type of output requested: html, json, javascript
#' @param TextResults A character string with the results as a single simple-text output
setClass("encodeRavianResults", representation(
				AnalysisTitle = "character",
				RequestParameters = "list",
				Results = "list",
				OutputType = "character",
				TextResults = "character"
		)
)

############################### class operation methods ############################################################

############################## AnalysisTitle
#Generic is set in checkPlugin.R

#' Set AnalysisTitle slot of encodeRavianResults object.
#' 
#' @name setAnalysisTitle
#' @param object A encodeRavianResults object
#' @param value A string specifying the type of output requested: html, json, javascript
setReplaceMethod("AnalysisTitle",signature(object="encodeRavianResults"),
		function(object,value) {
			slot(object,"AnalysisTitle")<-value
			validObject(object)
			object
		})

# Generic is set in checkPlugin.R
#' Retrieve the contents of the ResultHandle slot of the encodeRavianResults object.
#' 
#' @name AnalysisTitle
#' @param object A encodeRavianResults object
setMethod("AnalysisTitle", signature(object="encodeRavianResults"),
		function(object) slot(object,"AnalysisTitle"))

############################## RequestParameters
#Generic set by validateRavianDomain.R

#' Set RequestParameters slot of encodeRavianResults object.
#' 
#' @name setRequestParameters
#' @param object A encodeRavianResults object
#' @param value A list to put into the RequestParameters slot, containing the request parameters
setReplaceMethod("RequestParameters",signature(object="encodeRavianResults"),
		function(object,value) {
			slot(object,"RequestParameters")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the RequestParameters slot of the encodeRavianResults object.
#' 
#' @name RequestParameters
#' @param object A encodeRavianResults object
setMethod("RequestParameters", signature(object="encodeRavianResults"),
		function(object) slot(object,"RequestParameters"))


############################## Results
#' Set generic to  method that sets the Results slot of encodeRavianResults object.
#' 
#' @name setResults
#' @param object A encodeRavianResults object
#' @param value A list to put into the Results slot, containing RavianResult sub-class objects: RavianResultTable, RavianResultGraph RavianResultError
setGeneric("Results<-", 
		function(object, value)	standardGeneric("Results<-"))

#' Set Results slot of encodeRavianResults object.
#' 
#' @name setResults
#' @param object A encodeRavianResults object
#' @param value A list to put into the Results slot, containing RavianResult sub-class objects: RavianResultTable, RavianResultGraph RavianResultError
setReplaceMethod("Results",signature(object="encodeRavianResults"),
		function(object,value) {
			slot(object,"Results")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the Results slot of the encodeRavianResults object.
#' 
#' @name Results
#' @param object A encodeRavianResults object
setGeneric("Results", 
		function(object) standardGeneric("Results"))

#' Retrieve the contents of the Results slot of the encodeRavianResults object.
#' 
#' @name Results
#' @param object A encodeRavianResults object
setMethod("Results", signature(object="encodeRavianResults"),
		function(object) slot(object,"Results"))

############################## OutputType
#' Set generic to  method that sets the OutputType slot of encodeRavianResults object.
#' 
#' @name setOutputType
#' @param object A encodeRavianResults object
#' @param value A string specifying the type of output requested: html, json, javascript
setGeneric("OutputType<-", 
		function(object, value)	standardGeneric("OutputType<-"))

#' Set OutputType slot of encodeRavianResults object.
#' 
#' @name setOutputType
#' @param object A encodeRavianResults object
#' @param value A string specifying the type of output requested: html, json, javascript
setReplaceMethod("OutputType",signature(object="encodeRavianResults"),
		function(object,value) {
			slot(object,"OutputType")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the OutputType slot of the encodeRavianResults object.
#' 
#' @name OutputType
#' @param object A encodeRavianResults object
setGeneric("OutputType", 
		function(object) standardGeneric("OutputType"))

#' Retrieve the contents of the ResultHandle slot of the encodeRavianResults object.
#' 
#' @name OutputType
#' @param object A encodeRavianResults object
setMethod("OutputType", signature(object="encodeRavianResults"),
		function(object) slot(object,"OutputType"))

############################## TextResults
#' Set generic to  method that sets the TextResults slot of encodeRavianResults object.
#' 
#' @name setTextResults
#' @param object A encodeRavianResults object
#' @param value A character string with the results as a single simple-text output
setGeneric("TextResults<-", 
		function(object, value)	standardGeneric("TextResults<-"))

#' Set TextResults slot of encodeRavianResults object.
#' 
#' @name setTextResults
#' @param object A encodeRavianResults object
#' @param value A character string with the results as a single simple-text output
setReplaceMethod("TextResults",signature(object="encodeRavianResults"),
		function(object,value) {
			slot(object,"TextResults")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the TextResults slot of the encodeRavianResults object.
#' 
#' @name TextResults
#' @param object A encodeRavianResults object
setGeneric("TextResults", 
		function(object) standardGeneric("TextResults"))

#' Retrieve the contents of the TextResults slot of the encodeRavianResults object.
#' 
#' @name TextResults
#' @param object A encodeRavianResults object
setMethod("TextResults", signature(object="encodeRavianResults"),
		function(object) slot(object,"TextResults"))


############################## Initialize
#' Instantiate a new encodeRavianResults object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "encodeRavianResults"),
		function (.Object, ...) 
		{
			.Object@AnalysisTitle	<- character()
			.Object@RequestParameters	<- list()
			.Object@Results 		<- list()
			.Object@OutputType 		<- character()
			.Object@TextResults 	<- character()
			.Object
		}
)


##################################### Methods ##################################
#encodeResults(object)
#' Set generic to  method that requests Ravian results be encoded as simple text
#' 
#' @name encodeResults
#' @param object An encodeRavianResults object. 
setGeneric("encodeResults",
		function(object, ...) standardGeneric("encodeResults"))

#' Request that Ravian results be encoded as simple text
#' 
#' @param object An encodeRavianResults object.
#' @param tooltip Only applicable for ggplotly outputs: the aesthetic to display in the tooltip. Defaults to all.
setMethod("encodeResults", signature(object = "encodeRavianResults"),
		function(object,tooltip="all",...) {
		#each entry in the list of results should be a RavianResult object.
			#determine the output format - one function for each format and output type
			#loop through the list
							
		res<-Results(object)
		outtype<-OutputType(object); if(NROW(outtype)==0 || outtype==""){outtype<-"html"}	#enforcing the default
		textResult<-character()
		analysisTitle<-AnalysisTitle(object); if(NROW(analysisTitle)==0 || analysisTitle==""){analysisTitle<-"Analysis Results"}	
		
		#process list of results
		if(outtype=="pdf"){
			req<-RequestParameters(object)
			#from the req obtain the name of the markdown template and the application warehouse?? the request should include the application name!!
			tmplte<-req$outputTemplate
			appName<-req$applicationName #this is MANDATORY??
			markdown.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianMarkdownRegistry.yaml",sep="")),silent=TRUE)
			mdpdf<-markdown.registry$format$pdf[[appName]]
			
			#validate the template by checking the yaml, and return the path = rmdtemplatepath
			if(TRUE %in% grepl(tmplte,names(mdpdf))){
				#convert results to a simple list: use a function that takes slot contents based on object type
					
					#This needs to be re-done
					#A chapter per type of result: tables, graphs, warnings & errors
					#http://stackoverflow.com/questions/25824795/how-to-combine-two-rmarkdown-rmd-files-into-a-single-output
					#in Windows...
				#fcon<-tempfile(pattern="RavianPDF", tmpdir="/tmp",fileext=".rmd")
				#write("--- \n title: 'IWMM Report' \n output: pdf_document \n toc: TRUE \n---",fcon)
				
				#now loop for tables, graphs, warns and errors, and create chapters as needed
					
				resAsList<-convertResultsToList(res)
				#create the outfile 
				if(grepl("Windows",Sys.info()["sysname"])){
					tpd<-tempdir()		#if locally
				}else{
					tpd<-markdown.registry$outputpath		
				}
				pdffilepath<-tempfile(pattern="RavianPDF", tmpdir=tpd,fileext=".pdf")
				rmdtemplatepath<-paste(Sys.getenv("R_SHARE_DIR"),markdown.registry$sourcepath,tmplte,sep="")
				reqdat<-list(request=req)
				Sys.unsetenv("HOME");Sys.setenv(HOME="/var/www/html/tmp")
				pdftry<-try(render(input=rmdtemplatepath,params=list(raviandata=resAsList,requestdata=reqdat),
								output_file=pdffilepath,intermediates_dir="/var/www/html/tmp",envir=new.env(),quiet=TRUE),silent=TRUE)
				if(inherits(pdftry,"try-error")){
					TextResults(object)<-paste("Ravian error: failed to generate pdf output file.",paste(pdftry,collapse=". "))
				}else{
					TextResults(object)<-pdftry
				}
			}else{
				TextResults(object)<-paste("Ravian error: Ravian could not find a reporting template with the name '",tmplte,"'.",
						"Please contact Point blue at: <feedback address here>")
			}
		}else{
			for(ss in 1:NROW(res)){ #there shall never be more than a few results, so no need to lapply here
				resObj<-res[[ss]]
				if(!inherits(resObj,"RavianResults")){
					eo<-new("RavianResultError")
					ResultTitle(eo)<-"Error completing requested analyses"
					ResultType(eo)<-"Error"
					ErrorDescription(eo)<-"Error: Ravian received an unrecognizable type of analysis result, and it cannot translate it into html."
					SinkObjects(eo)<-list(object=resObj)
					ErrorDate(eo)<-as.character(Sys.time())
					resObj<-encodeRavianResultObject(eo,outtype=outtype)
					textResult<-c(textResult,EncodedResult(resObj))
				}else if(class(resObj)=="RavianResultGraph" && outtype!="html"){
					graphttl<-ResultTitle(resObj)
					resObjj<-encodeRavianResultObject(resObj,outtype=outtype,tooltip=tooltip,...)
					textResult<-c(textResult,EncodedResult(resObjj))
					resObjh<-encodeRavianResultObject(resObj,outtype="png")
					resObjhe<-EncodedResult(resObjh)
					resObjhe<-gsub('"','\"',resObjhe)
					resObjhe<-gsub("/","\\/",resObjhe)
					resObjhe<-paste("{\"resultType\":\"Png\",\"resultTitle\":\"",graphttl,
							"\",\"resultContents\":\"",resObjhe,"\"}",sep="")
					textResult<-c(textResult,resObjhe)
				}else{ #tables
					resObj<-encodeRavianResultObject(resObj,outtype=outtype,...)
					textResult<-c(textResult,EncodedResult(resObj))
				}
			}		
			collapsedTextResults<-paste(textResult,collapse=",")
			if(outtype=="json"){
				TextResults(object)<-paste("{\"analysisTitle\":\"",analysisTitle,"\",\"analysisResults\":[",collapsedTextResults,"]}",sep="")
			}else{
				TextResults(object)<-collapsedTextResults
			}
		}
		
		
		return(object)
})



