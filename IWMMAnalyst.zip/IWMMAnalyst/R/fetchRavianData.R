#' @include connectRavian.R
#' @include speciesKeys.R
#' @include locationKeys.R

# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This class uses information passed to it by dispatchRavian to locate the SamplingUnitId keys identifying all sampling units in a region, or unit/study area
## to return the object of the class fetchRavianData with a list where each element is a vector of keys, and its name is the name of the region/unit/study area selected
## The request MUST contain either a region, a collection of units/study areas, or specific SamplingUnitIds from selected plots

################################## Object def
#' Abstract class for fetchRavianData
#' 
#' Abstract class for fetchRavianData
#' 
#' @param FormData A json string with the GET/POST request as it was passed to fetchRavianData
#' @param ConnectHandle A connectRavian object with the connection handle to resolve the request
#' @param SpeciesData A data.frame with the results of a speciesKeys object's fetch of species FieldBirdIds with information in the POST
#' @param LocationData A data.frame with the results of a fetchRavianData object's fetch of SamplingUnitIds with information in the POST
#' @param ResultData A list with two elements, the effort data frame, and the observation data frame
#' @param ErrorReport A string vector to store any error reports
setClass("fetchRavianData", representation(
				FormData = "character",
				ConnectHandle = "connectRavian",
				SpeciesData = "data.frame",
				LocationData = "data.frame",
				ResultData = "list",
				ErrorReport = "character"
		)
)

############################### class operation methods ############################################################

############################## FormData
#Generic set by speciesKeys.R

#' Set FormData slot of fetchRavianData object.
#' 
#' @name setFormData
#' @param object A fetchRavianData object
#' @param value A json string to put into the FormData slot, which includes the parameters of the POST.
setReplaceMethod("FormData",signature(object="fetchRavianData"),
		function(object,value) {
			slot(object,"FormData")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the FormData slot of the fetchRavianData object.
#' 
#' @name FormData
#' @param object A fetchRavianData object
setMethod("FormData", signature(object="fetchRavianData"),
		function(object) slot(object,"FormData"))

############################## ConnectHandle
#Generic set by speciesKeys.R

#' Set ConnectHandle slot of fetchRavianData object.
#' 
#' @name setConnectHandle
#' @param object A fetchRavianData object
#' @param value A connectRavian object to put into the ConnectHandle slot.
setReplaceMethod("ConnectHandle",signature(object="fetchRavianData"),
		function(object,value) {
			slot(object,"ConnectHandle")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ConnectHandle slot of the fetchRavianData object.
#' 
#' @name ConnectHandle
#' @param object A fetchRavianData object
setMethod("ConnectHandle", signature(object="fetchRavianData"),
		function(object) slot(object,"ConnectHandle"))

############################## SpeciesData
#' Set generic to  method that sets the SpeciesData slot of fetchRavianData object.
#' 
#' @name setSpeciesData
#' @param object A fetchRavianData object
#' @param value A data.frame to put into the SpeciesData slot
setGeneric("SpeciesData<-", 
		function(object, value)	standardGeneric("SpeciesData<-"))

#' Set SpeciesData slot of fetchRavianData object.
#' 
#' @name setSpeciesData
#' @param object A fetchRavianData object
#' @param value A data.frame to put into the SpeciesData slot
setReplaceMethod("SpeciesData",signature(object="fetchRavianData"),
		function(object,value) {
			slot(object,"SpeciesData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the SpeciesData slot of the fetchRavianData object.
#' 
#' @name SpeciesData
#' @param object A fetchRavianData object
setGeneric("SpeciesData", 
		function(object) standardGeneric("SpeciesData"))

#' Retrieve the contents of the SpeciesData slot of the fetchRavianData object.
#' 
#' @name SpeciesData
#' @param object A fetchRavianData object
setMethod("SpeciesData", signature(object="fetchRavianData"),
		function(object) slot(object,"SpeciesData"))


############################## LocationData
#' Set generic to  method that sets the LocationData slot of fetchRavianData object.
#' 
#' @name setLocationData
#' @param object A fetchRavianData object
#' @param value A data.frame to put into the LocationData slot
setGeneric("LocationData<-", 
		function(object, value)	standardGeneric("LocationData<-"))

#' Set LocationData slot of fetchRavianData object.
#' 
#' @name setLocationData
#' @param object A fetchRavianData object
#' @param value A data.frame to put into the LocationData slot
setReplaceMethod("LocationData",signature(object="fetchRavianData"),
		function(object,value) {
			slot(object,"LocationData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the LocationData slot of the fetchRavianData object.
#' 
#' @name LocationData
#' @param object A fetchRavianData object
setGeneric("LocationData", 
		function(object) standardGeneric("LocationData"))

#' Retrieve the contents of the LocationData slot of the fetchRavianData object.
#' 
#' @name LocationData
#' @param object A fetchRavianData object
setMethod("LocationData", signature(object="fetchRavianData"),
		function(object) slot(object,"LocationData"))

############################## ResultData
#' Set generic to  method that sets the ResultData slot of fetchRavianData object.
#' 
#' @name setResultData
#' @param object A fetchRavianData object
#' @param value A list to put into the ResultData slot, with two elements: a data frame of effort data, and a data frame with the observations for the species requested
setGeneric("ResultData<-", 
		function(object, value)	standardGeneric("ResultData<-"))

#' Set ResultData slot of fetchRavianData object.
#' 
#' @name setResultData
#' @param object A fetchRavianData object
#' @param value A list to put into the ResultData slot, with two elements: a data frame of effort data, and a data frame with the observations for the species requested
setReplaceMethod("ResultData",signature(object="fetchRavianData"),
		function(object,value) {
			slot(object,"ResultData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the ResultData slot of the fetchRavianData object.
#' 
#' @name ResultData
#' @param object A fetchRavianData object
setGeneric("ResultData", 
		function(object) standardGeneric("ResultData"))

#' Retrieve the contents of the ResultData slot of the fetchRavianData object.
#' 
#' @name ResultData
#' @param object A fetchRavianData object
setMethod("ResultData", signature(object="fetchRavianData"),
		function(object) slot(object,"ResultData"))

############################## ErrorReport
#Generic set by validateRavianDomain.R

#' Set ErrorReport slot of fetchRavianData object.
#' 
#' @name setErrorReport
#' @param object A fetchRavianData object
#' @param value A string to put into the ErrorReport slot
setReplaceMethod("ErrorReport",signature(object="fetchRavianData"),
		function(object,value) {
			slot(object,"ErrorReport")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ErrorReport slot of the fetchRavianData object.
#' 
#' @name ErrorReport
#' @param object A fetchRavianData object
setMethod("ErrorReport", signature(object="fetchRavianData"),
		function(object) slot(object,"ErrorReport"))


############################## Initialize
#' Instantiate a new fetchRavianData object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "fetchRavianData"),
		function (.Object, ...) 
		{
			.Object@FormData 		<- character()
			.Object@ConnectHandle 	<- new("connectRavian")
			.Object@SpeciesData 	<- data.frame()
			.Object@LocationData 	<- data.frame()
			.Object@ResultData 		<- list()
			.Object@ErrorReport		<- character()
			.Object
		}
)

##################################### getRavianData
#returns the effort and observation data frames
#' Set generic to  method that gets the effort and observation data from the FormData request, and stores results in the ResultData slot of the fetchRavianData object
#' 
#' @name getRavianData
#' @param object A fetchRavianData object. 
#' @param ravian.registry A list object provided by dispatchRavian from reading the RavianWarehouseRegistry.yaml file
#' @return Two data frames, with effort and observation data
setGeneric("getRavianData",
		function(object, ravian.registry) standardGeneric("getRavianData"))

#' Get the effort and observation data from the FormData request, and stores results in the ResultData slot of the fetchRavianData object
#' 
#' @param object A fetchRavianData object.
#' @param ravian.registry A list object provided by dispatchRavian from reading the RavianWarehouseRegistry.yaml file
#' @return Two data frames, with effort and observation data
setMethod("getRavianData", signature(object = "fetchRavianData",ravian.registry = "list"),
		function(object, ravian.registry) {
			#need information in the post for: project, protocol, startdate, enddate, seasonal, obsgroup

			fd<-fromJSON(FormData(object))
			acclevel<-fd$accLevel;if(is.null(acclevel)){acclevel<-3}
			spp<-SpeciesData(object)	#a data.frame: either named "species" (with a sublist of keys), or one/several names of guilds, or an empty list
			loc<-LocationData(object)	#a data frame with 0 rows if no location data provided (no region or samplingUnits), or a data frame with the name and SUids of region or sampling locations
			
			#need to validate the warehouse tablename and accLevel
			tblcheck<-validatedTableLevel(formData=fd,ravian.registry=ravian.registry)
			if(grepl("Error",tblcheck)){
				ErrorReport(object)<-paste(tblcheck,collapse=", ")
			}else{
				### construct the sql from the information in fd, and in the support data
				sqllst<-try(getRavianSQL(ravian.registry=ravian.registry,Species=spp,Locations=loc,formData=fd,acclevel=acclevel),silent=TRUE)
				if(inherits(sqllst,"try-error")){
					ErrorReport(object)<-paste(sqllst,collapse=", ")
				}else{
					### make connection and query effort and observation data
					connObj<-ConnectHandle(object)
					HandleType(connObj)<-"warehouse"
					conn<-ResultHandle(getRavianHandle(connObj))[[1]]
					
					#review connection for error...
					if(inherits(conn,"try-error")){
						ErrorReport(object)<-as.character(conn)
					}else{
						effsql<-sqllst$eff
						obssql<-sqllst$obs
						effdata<-try(sqlQuery(conn,as.character(effsql),rows_at_time=1),silent=TRUE)
						if(TRUE %in% grepl("ERROR", effdata)){
							ErrorReport(object)<-as.character(obsdata)
						}else if(inherits(effdata,"try-error")){
							ErrorReport(object)<-as.character(effdata)
						}else if(!is.null(nrow(effdata)) && nrow(effdata)>0){
							#if there is region data, then append to effdata
							if(nrow(loc)>0 && grepl("region",names(effdata))){
								effdata<-merge(effdata,loc,by="SamplingUnitId",all.x=TRUE)
							}
							
							obsdata<-try(sqlQuery(conn,as.character(obssql),rows_at_time=1),silent=TRUE)
							if(inherits(obsdata,"try-error")){
								ErrorReport(object)<-as.character(obsdata)
							}else if(TRUE %in% grepl("ERROR", obsdata)){
								ErrorReport(object)<-as.character(obsdata)
							}else if(!is.null(nrow(obsdata)) && nrow(obsdata)>0){
								#In case the warehouse is funky, remove all records with ObservationCount=0
								if(TRUE %in% grepl("ObservationCount",names(obsdata))){
									obsdata<-subset(obsdata,ObservationCount>0)
								}
								if(nrow(obsdata)==0){
									ErrorReport(object)<-"Ravian Warning: there is no data for the species/guilds selected."
								}else{
									#Add location metadata: the location metadata exist in the warehouse - it's just a matter for the pluggin app to group correctly for analyses.
									#Add guilds
									if(TRUE %in% grepl("Guild",names(spp))){
										sppdf<-as.data.frame(spp)		#a data frame with one column naming the guild and the other is the species key
										obsdataguild<-try(merge(obsdata,sppdf,by="TaxonId"),silent=TRUE) #
										###CAREFUL!!!!!
										###The above is a union join, so if a taxon belongs to more than one guild, its records will be duplicated.
										####################################################################################
										if(!inherits(obsdataguild,"try-error")){
											obsdata<-obsdataguild
											#add observation groups: again, just the metadata for the app plugin to analyze using it
											ogdef<-fd$obsgroup			
											if(NROW(ogdef)>0){
												obsGroupVar<-names(ogdef)
												obsgroupdefs<-data.frame()
												for(nn in names(ogdef[[1]])){
													ogd<-as.character(ogdef[[1]][[nn]])
													tdf<-data.frame(GroupName=nn,groupdef=ogd)
													obsgroupdefs<-rbind(obsgroupdefs,tdf)
												}
												names(obsgroupdefs)<-c("ObservationsGroup",obsGroupVar)
												
												obsdataobsgroups<-try(merge(obsdata,obsgroupdefs,all.x=TRUE)) #this is a left join
												if(!inherits(obsdataobsgroups,"try-error")){
													obsdata<-obsdataobsgroups
												}else{
													obsdata<-"Error: Ravian could not attribute observation group information"; class(obsdata)<-"try-error"
												}
											}
											
										}else{
											obsdata<-"Error: Ravian could not attribute guild information"; class(obsdata)<-"try-error"
										}
									}
									
									#effort data attributions...
									#add seasonal info: 1) assign season value; and 2) remove effort and obs data without a value	
									seasonal<-fd$seasonal;if(is.null(seasonal)){seasonal<-0}
									if(seasonal==1){
										#MUST have start and end dates
										if(is.null(fd$startDate) || is.null(fd$endDate)){
											ErrorReport(object)<-"Error: the request asks for treating the data as seasonal, but no definition of season was provided (no start and end dates)."
										}else{
											#create a data frame with startyear, startmonth, startday, endyear (=startyear or startyear+1), endmoth, endday, seasonvalue
											sttdat<-as.Date(fd$startDate);styr<-as.numeric(format(sttdat,"%Y"));stmo<-as.numeric(format(sttdat,"%m"));stdy<-as.numeric(format(sttdat,"%d"))
											if(leap_year(styr) && stmo==2 && stdy==29){ #conditions met for non-leap-year correction?
												stly<-1
											}else{
												stly<-0
											} 
											enddat<-as.Date(fd$endDate);edyr<-as.numeric(format(enddat,"%Y"));edmo<-as.numeric(format(enddat,"%m"));eddy<-as.numeric(format(enddat,"%d"))
											if(leap_year(edyr) && edmo==2 && eddy==29){ #conditions met for non-leap-year correction?
												edly<-1
											}else{
												edly<-0
											} 
											seasonal.df<-data.frame()
											yrs<-styr:edyr
											if(stmo<=edmo){
												for(yy in yrs){
													lystmo<-stmo;lystdy<-stdy;lyedmo<-edmo;lyeddy<-eddy
													if(!leap_year(yy) && stly==1){	#correct start date
														lystmo<-3;lystdy<-1
													}
													if(!leap_year(yy) && edly==1){	#correct end date
														lyedmo<-3;lyeddy<-1
														
													}
													seasonal.tmp<-data.frame(StartYear=yy,SeasonStartDate=paste(yy,"-",lystmo,"-",lystdy,sep=""),
															SeasonEndDate=paste(yy,"-",lyedmo,"-",lyeddy,sep=""))
													seasonal.df<-rbind(seasonal.df,seasonal.tmp)
												}
											}else{	#season goes over end-of-year mark
												for(yy in styr:(edyr-1)){
													lystmo<-stmo;lystdy<-stdy;lyedmo<-edmo;lyeddy<-eddy
													yrsst<-yy; yrsed<-yy+1
													if(!leap_year(yrsst) && stly==1){	#correct start date
														lystmo<-3;lystdy<-1
													}
													if(!leap_year(yrsed) && edly==1){	#correct end date
														lyedmo<-3;lyeddy<-1
													}
													seasonal.tmp<-data.frame(StartYear=yrsst,SeasonStartDate=paste(yrsst,"-",lystmo,"-",lystdy,sep=""),
															SeasonEndDate=paste(yrsed,"-",lyedmo,"-",lyeddy,sep=""))
													seasonal.df<-rbind(seasonal.df,seasonal.tmp)
												}
											}
											seasonal.df$Season<-1:(nrow(seasonal.df))
											#loop though the table and assign a seasonvalue to each event and obs record whose date is within the start and end dates of a season
											effdata$Season<-sapply(effdata$ObservationDate,FUN=function(x,seasonal.df){
														xd<-as.Date(x);recseason<-NA
														for(dd in 1:nrow(seasonal.df)){
															if(xd > as.Date(seasonal.df[dd,"SeasonStartDate"]) && xd < as.Date(seasonal.df[dd,"SeasonEndDate"])){recseason<-seasonal.df[dd,"Season"]}
														}
														return(recseason)
													},seasonal.df)
											#filter for those records and events with season values
											effdata<-subset(effdata,!is.na(Season))
											## Need to check again for effort data!
											if(nrow(effdata)==0){
												ErrorReport(object)<-"Ravian Warning: there is no data for the time period specified."
											}
										}
									}
									reslst<-list(effdata=effdata)
									reslst[["obsdata"]]<-obsdata
									ResultData(object)<-reslst
								}
							}else if(nrow(obsdata)==0){
								ErrorReport(object)<-"Ravian Warning: there is no data for the species/guilds selected."
							}else{
								ErrorReport(object)<-"Error: Ravian failed to retrieve observation data."
							}
						}else if(nrow(effdata)==0){
							ErrorReport(object)<-"Ravian Warning: there is no data for the locations and dates selected."
						}else{
							ErrorReport(object)<-"Error: Ravian failed to retrieve effort data."
						}
						ResultHandle(ConnectHandle(object))[[1]]<-odbcClose(conn)
					}
				}	
			}
			
			return(object)
})


#' Construct the effort and observation SQL statements from the registry, form data, and support info
#' 
#' @param ravian.registry A list containing the Ravian warehouse registry information
#' @param Species The contents of the SpeciesData slot of the fetchRavianData object (a data.frame)
#' @param Locations The contents of the LocationData slot of the fetchRavianData object (a data.frame)
#' @param formData A list including the parameters in the request
#' @param acclevel A numeric value between 0-5 indicating the access level to the warehouses. Defaults to 3.
#' @return Two strings, with effort and observation SQL statements
getRavianSQL<-function(ravian.registry,Species,Locations,formData,acclevel=3) {
	fd<-formData
	
	### Location data is the only mandatory information in the request
	########### check that there is at least one of: project, region, or samplingUnits
	if(TRUE %in% c(grepl("projects",names(fd)),grepl("region",names(fd)),grepl("samplingUnits",names(fd)))){
		whname<-fd$warehouseName
		
		tblname<-ravian.registry[[whname]]$tablename
		ver<-ravian.registry[[whname]]$tablesuffix
		effsql<-ravian.registry[[whname]]$querydefs$sqleffort
		obssql<-ravian.registry[[whname]]$querydefs$sqlobs
		
		#the basic...
		if(is.null(ver)){
			effsql<-paste(effsql," from ",tblname," where 1=1",sep="")
			obssql<-paste(obssql," from ",tblname," where 1=1",sep="")
		}else if(acclevel=="base"){
			effsql<-paste(effsql," from ",tblname,acclevel,ver," where 1=1",sep="")
			obssql<-paste(obssql," from ",tblname,acclevel,ver," where 1=1",sep="")
		}else{
			effsql<-paste(effsql," from ",tblname,"level",acclevel,ver," where 1=1",sep="")
			obssql<-paste(obssql," from ",tblname,"level",acclevel,ver," where 1=1",sep="")
		}
		
		#Now the location info...
		if(TRUE %in% grepl("projects",names(fd))){
			proj<-fd$projects
			effsql<-paste(effsql," and ProjectCode in ('",paste(proj,collapse="','"),"')",sep="")
			obssql<-paste(obssql," and ProjectCode in ('",paste(proj,collapse="','"),"')",sep="")
		}
		
		#Locations can be empty, if projects exist. But they can also be passed in addition to projects, so...
		#Locations, btw, are the samplingUnitIds from either region or samplingUnits
		####################################
		#Begin edits
		#Locations can also be an sql statement
		
		locsdf<-Locations
		
		#
		if(nrow(locsdf)>0){
			if(nrow(locsdf)==1 && names(locsdf)=="sqlt"){
				sqltxt<-as.character(locsdf$sqlt)
				effsql<-paste(effsql," and SamplingUnitId in (",sqltxt,")",sep="")
				obssql<-paste(obssql," and SamplingUnitId in (",sqltxt,")",sep="")
			}else{	#this else statement is all that used to be inside the parent if statement on line 467
				effsql<-paste(effsql," and SamplingUnitId in (",paste(as.numeric(locsdf$SamplingUnitId),collapse=","),")",sep="")
				obssql<-paste(obssql," and SamplingUnitId in (",paste(as.numeric(locsdf$SamplingUnitId),collapse=","),")",sep="")
			}
		}
		
		############ Up to here the basics. Now add new stuff
		if(TRUE %in% grepl("protocols",names(fd))){
			prot<-fd$protocols
			effsql<-paste(effsql," and ProtocolCode in ('",paste(prot,collapse="','"),"')",sep="")
			obssql<-paste(obssql," and ProtocolCode in ('",paste(prot,collapse="','"),"')",sep="")
		}
		
		#add dates
		if(TRUE %in% grepl("startDate",names(fd))){
			sttdat<-fd$startDate
			effsql<-paste(effsql," and ObservationDate >= '",as.character(sttdat),"'",sep="")
			obssql<-paste(obssql," and ObservationDate >= '",as.character(sttdat),"'",sep="")
		}
		if(TRUE %in% grepl("endDate",names(fd))){
			enddat<-fd$endDate
			effsql<-paste(effsql," and ObservationDate <= '",as.character(enddat),"'",sep="")
			obssql<-paste(obssql," and ObservationDate <= '",as.character(enddat),"'",sep="")
		}
		
		#add species codes to the observation sql
		speciesdf<-Species
		if(nrow(speciesdf)>0){
			if(tblname %in% c("ravianglc","ravianmarshbird")){
				#ugh! remove once Doug adds the TaxonId field
				obssql<-paste(obssql," and BirdCd in ('",paste(speciesdf$SpeciesCode,collapse="','"),"')",sep="")
			}else{
				obssql<-paste(obssql," and TaxonId in ('",paste(speciesdf$TaxonId,collapse="','"),"')",sep="")
			}
		}
		
		sqllst<-list(eff=effsql,obs=obssql)
	}else{
		sqllst<-"Error: no location information in the request. It must include at least one of the following arguments: projects, region, or samplingUnits"
		class(sqllst)<-"try-error"
	}
	
	return(sqllst)
}


#' @param formData A list object including the parameters in the request
#' @param ravian.registry A list object provided by dispatchRavian from reading the RavianWarehouseRegistry.yaml file
#' @return A string: either an error, or an empty string
validatedTableLevel<-function(formData,ravian.registry){
	fd<-formData
	valres<-""
	whname<-fd$warehouseName
	acclevel<-fd$accLevel
	if(is.null(acclevel)){
		acclevel<-3
	}
	tblname<-ravian.registry[[whname]]$tablename
	if(is.null(tblname)){
		valres<-"Error: no warehouse table name provided."
	}else{
		ver<-ravian.registry[[whname]]$tablesuffix
		if(is.null(ver)){
			fulltable<-tblname
		}else if(acclevel=="base"){
			fulltable<-paste(tblname,acclevel,ver,sep="")
		}else{
			fulltable<-paste(tblname,"level",acclevel,ver,sep="")
		}
		connObj<-new("connectRavian")
		HandleType(connObj)<-"warehouse"
		connObj<-getRavianHandle(connObj)
		conn<-ResultHandle(connObj)[[1]]
		if(grepl("Error",conn)){
			valres<-"Error: connection failed - Ravian could not validate the table named in the request."
		}else{
			sqlval<-paste("SELECT table_name FROM INFORMATION_SCHEMA.TABLES WHERE table_schema = 'ravian_wh' and table_name ='",fulltable,"'",sep="")
			valres<-try(sqlQuery(conn,sqlval,rows_at_time=1),silent=TRUE)
			ResultHandle(connObj)[[1]]<-odbcClose(conn)
			if(inherits(valres,"try-error") || (TRUE %in% grepl("ERROR",valres))){
				valres<-"Error: Ravian could not validate the data table named in the request."
			}else if(nrow(valres)!=1){
				valres<-paste("Error: more than one warehouse table located - ",paste(valres,collapse="; "),sep="")
			}else{}
		}
	}
	
	return(valres)
}

