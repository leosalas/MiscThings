#' @include connectRavian.R

# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This class uses information passed to it by dispatchRavian to locate the SamplingUnitId keys identifying all locations in a region, or unit/study area
## to return the object of the class locationKeys with a list where each element is a vector of keys, and its name is the name of the region/unit/study area selected
## The request MUST contain either a region, a collection of units/study areas, or specific SamplingUnitIds from selected plots

################################## Object def
#' Abstract class for locationKeys
#' 
#' Abstract class for locationKeys
#' 
#' @param FormData A json string with the GET/POST request as it was passed to locationKeys
#' @param ConnectHandle A connectRavian object with the connection handle to resolve the request
#' @param ResultKeys A data frame with SamplingUnitId keys and names identifying the locations to include in the analysis. 
#' 			If no location information is provided, an error is triggered. 
#' 			If transects or study areas, or other higher levels of location selection are provided, their names are
#' 			kept in the resulting data frame, describing which locations belong to each level.
#' 			If a region's name and domain name are provided, the region's name and all its sampling units are returned.
#' @param ErrorReport A string vector to store any error reports
setClass("locationKeys", representation(
				FormData = "character",
				ConnectHandle = "connectRavian",
				ResultKeys = "data.frame",
				ErrorReport = "character"
		)
)

############################### class operation methods ############################################################

############################## FormData
#Generic set by speciesKeys.R

#' Set FormData slot of locationKeys object.
#' 
#' @name setFormData
#' @param object A locationKeys object
#' @param value A json string to put into the FormData slot, which includes the parameters of the POST.
setReplaceMethod("FormData",signature(object="locationKeys"),
		function(object,value) {
			slot(object,"FormData")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the FormData slot of the locationKeys object.
#' 
#' @name FormData
#' @param object A locationKeys object
setMethod("FormData", signature(object="locationKeys"),
		function(object) slot(object,"FormData"))

############################## ConnectHandle
#Generic set by speciesKeys.R

#' Set ConnectHandle slot of locationKeys object.
#' 
#' @name setConnectHandle
#' @param object A locationKeys object
#' @param value A connectRavian object to put into the ConnectHandle slot.
setReplaceMethod("ConnectHandle",signature(object="locationKeys"),
		function(object,value) {
			slot(object,"ConnectHandle")<-value
			validObject(object)
			object
		})


#' Retrieve the contents of the ConnectHandle slot of the locationKeys object.
#' 
#' @name ConnectHandle
#' @param object A locationKeys object
setMethod("ConnectHandle", signature(object="locationKeys"),
		function(object) slot(object,"ConnectHandle"))

############################## ResultKeys
#Generic set by speciesKeys.R

#' Set ResultKeys slot of locationKeys object.
#' 
#' @name setResultKeys
#' @param object A locationKeys object
#' @param value Data.frame to put into the ResultKeys slot, describing each set of locations in the request
setReplaceMethod("ResultKeys",signature(object="locationKeys"),
		function(object,value) {
			slot(object,"ResultKeys")<-value
			validObject(object)
			object
		})


#' Retrieve the contents of the ResultKeys slot of the locationKeys object.
#' 
#' @name ResultKeys
#' @param object A locationKeys object
setMethod("ResultKeys", signature(object="locationKeys"),
		function(object) slot(object,"ResultKeys"))

############################## ErrorReport
#Generic set by validateRavianDomain.R

#' Set ErrorReport slot of locationKeys object.
#' 
#' @name setErrorReport
#' @param object A locationKeys object
#' @param value A string to put into the ErrorReport slot
setReplaceMethod("ErrorReport",signature(object="locationKeys"),
		function(object,value) {
			slot(object,"ErrorReport")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ErrorReport slot of the locationKeys object.
#' 
#' @name ErrorReport
#' @param object A locationKeys object
setMethod("ErrorReport", signature(object="locationKeys"),
		function(object) slot(object,"ErrorReport"))


############################## Initialize
#' Instantiate a new locationKeys object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "locationKeys"),
		function (.Object, ...) 
		{
			.Object@FormData 		<- character()
			.Object@ConnectHandle 	<- new("connectRavian")
			.Object@ResultKeys 		<- data.frame()
			.Object@ErrorReport		<- character()
			.Object
		}
)



##################################### evaluateLocationKeys
#returns a list of vectors with SamplingUnitId keys, one for each study area/unit key provided, or for the region named
#' Set generic to  method that gets SamplingUnitIdId keys from the FormData slot in the object
#' 
#' @name evaluateSpeciesKeys
#' @param object An speciesKeys object. 
setGeneric("evaluateLocationKeys",
		function(object) standardGeneric("evaluateLocationKeys"))


#' Get SamplingUnitId keys from the FormData slot in the object
#' 
#' @param object A locationKeys object.
setMethod("evaluateLocationKeys", signature(object = "locationKeys"),
		function(object) {
			#This method is for location information other than projects: region or samplingUnits.
			#decode and evaluate FormData
			fd<-fromJSON(FormData(object))
			whname<-fd$warehouseName
			
			if(!TRUE %in% grepl("region",names(fd))){	
				#no region info
				#check for SUid keys
				if(!TRUE %in% grepl("samplingUnits",names(fd))){	
					#no location info - requesting all sampling units in a project or projects - this will be checked in the function getRavianSQL of the fetchRavianData object
					#the object is returned unchanged, so ResultKeys is a data.frame with 0 rows
				}else{
					#sampling units are being passed
					#need to understand if study areas, transects/net collections, plots/points/nets were passed
					#then construct a list of values by region, or study area, or transect/net collection selected
					#Whatever it is, find all its children, and find the children of the chidlren
					locNames<-names(fd$samplingUnits)	#IMPORTANT: see the JSON specs document to understand how the data may be grouped
					
					if(is.null(locNames)){
						#no grouping
						locKeys<-as.numeric(fd$samplingUnits)
					}else{
						#there are groupings
						locKeys<-numeric()
						for(nn in locNames){
							locKeys<-c(locKeys,fd$samplingUnits[[nn]])
						}
					}
					#Also need the warehouse registry info to understand the event type and the type of sampling unit to sort the name categories of the sampling units
					#For example, did the user send plot names or study area names or transect names?
					ravian.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianWarehouseRegistry.yaml",sep="")),silent=TRUE)
					if(inherits(ravian.registry,"try-error")){ #config list OK?
						ErrorReport(object)<-as.character(ravian.registry)
					}else{
						eventtype<-ravian.registry[[whname]]$eventtype
						connObj<-ConnectHandle(object)
						HandleType(connObj)<-"support"
						conn<-ResultHandle(getRavianHandle(connObj))[[1]]
						
						#evaluate the handle for an error
						if(inherits(conn,"try-error")){
							ErrorReport(object)<-as.character(conn)
						}else{
							sqltxt<-paste("SELECT t1.SamplingUnitId AS lev1, t1.ShortName as name1, ",
									"t2.SamplingUnitId as lev2, t2.ShortName as name2, ",
									"t3.SamplingUnitId as lev3, t3.ShortName as name3 ",
									"FROM SamplingUnit AS t1 LEFT JOIN SamplingUnit AS t2 ON t2.ParentSamplingUnitId = t1.SamplingUnitId ",
									"LEFT JOIN SamplingUnit AS t3 ON t3.ParentSamplingUnitId = t2.SamplingUnitId ",
									"WHERE t1.SamplingUnitId in (",paste(locKeys,collapse=","),")",sep="")
							gdf<-try(sqlQuery(conn,sqltxt,rows_at_time=1),silent=TRUE)
############# THE FOLLOWING IS A NAMING STANDARD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
							if(inherits(gdf,"try-error") || (TRUE %in% grepl("ERROR",gdf))){
								ErrorReport(object)<-"Error: Ravian encountered an error when attempting to obtain information about the survey locations"
							}else{
								if(nrow(gdf)>0){
									if(is.null(gdf$lev3) || is.na(gdf$lev3)){
										#no keys at level 3
										if(is.null(gdf$lev2) || is.na(gdf$lev2)){
											#no keys at level 2, so must have keys at most atomic level
											kdf<-data.frame(unique(gdf[,c("name1","lev1")]))
											if(eventtype=="areasearch"){
												namstype<-"PlotName"
											}else if(eventtype=="pointcount"){
												namstype<-"Point"
											}else if(eventtype=="banding"){
												namstype<-"NetLocation"
											}else{
												namstype<-"LocationName"
											}
										}else{
											#have atomic keys at level 2, but potential grouping at level 1
											kdf<-data.frame(unique(gdf[,c("name1","name2","lev2")]))
											if(eventtype=="areasearch"){
												namstype<-c("StudyArea","PlotName")
											}else if(eventtype=="pointcount"){
												namstype<-c("Transect","Point")
											}else if(eventtype=="banding"){
												namstype<-c("StationName","NetLocation")
											}else{
												namstype<-c("StudyArea","LocationName")
											}
										}
									}else{
										#have atomic keys at level 3, but potential grouping at levels 2 and 1
										kdf<-data.frame(unique(gdf[,c("name1","name2","name3","lev3")]))
										if(eventtype=="pointcount"){
											namstype<-c("StudyArea","Transect","Point")
										}else if(eventtype=="banding"){
											namstype<-c("StudyArea","StationName","NetLocation")
										}else{
											namstype<-c("StudyArea","ParentLocationName","LocationName")
										}
									}
									names(kdf)<-c(namstype,"SamplingUnitId")
									##We KNOW that gdf has some data, so kdf will too. BUT there may be some NA's from invalid sampling unit ids. Martin may want this to be an error, so...
									if(sum(is.na(kdf$SamplingUnitId))>0){
										ErrorReport(object)<-"Error: Ravian could not locate the id key for some of the sampling units. Please make sure the correct sampling unit ids are being passed to Ravian."
									}else{
										ResultKeys(object)<-kdf
									}
								}else{
									ErrorReport(object)<-"Error: Ravian could not locate the id key for the sampling units. Please make sure the correct sampling unit ids are being passed to Ravian."
								}
							}
							ResultHandle(ConnectHandle(object))[[1]]<-odbcClose(conn)
						}
					}
				}
			}else{
				#A named region was passed - need to resolve...
				#Must include the type and name of region
				#retrieve the SUIds based on what is passed
	##NOOO!!! Pass back just the basic query "sqltxt"
				
				##############################################
				# Begin edits
				#connObj<-ConnectHandle(object)
				#HandleType(connObj)<-"support"
				#conn<-ResultHandle(getRavianHandle(connObj))[[1]]
				#
				##evaluate the handle for an error
				#if(inherits(conn,"try-error")){
				#	ErrorReport(object)<-as.character(conn)
				#}else{
				#	#got handle, will query...
					regionId<-as.numeric(fd$region)
					sqltxt<-paste("select SamplingUnitId from PRBOdb.samplingunitregionfeature_vw where RegionId = ",regionId,sep="")
					tdf<-data.frame(sqlt=sqltxt)
				#	gdf<-try(sqlQuery(conn,sqltxt,rows_at_time=1),silent=TRUE)
				#	if(inherits(gdf,"try-error") || (TRUE %in% grepl("ERROR",gdf))){
				#		ErrorReport(object)<-"Error: an error occurred when Ravian attempted to find region information"
				#	}else{
				#		if(nrow(gdf)==0){
				#			ErrorReport(object)<-"Error: A region was named in the request, but Ravian failed to find information about sampling locations in it."
				#		}else{
				#			res<-data.frame(Region=gdf$RegionName,SamplingUnitId=gdf$samplingunitid)
				#			#In theory only one region was passed. Do we want to check for NA's here too?
				#			ResultKeys(object)<-res
					ResultKeys(object)<-tdf
				#		}
				#	}
				#}
				#ResultHandle(ConnectHandle(object))[[1]]<-odbcClose(conn)
			}
			return(object)
		}
)


