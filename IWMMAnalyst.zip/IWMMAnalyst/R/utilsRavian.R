# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This is just a test function - DELETE
passToDispatch<-function(requestParameters){
	env <- new.env()
	robj<-do.call(what=new,args=list(Class="dispatchRavian"))
	assign("requestParameters", requestParameters, envir = env)
	assign("robj", robj, envir = env)
	w<-do.call(what="requestRavianResults",args=list(object=robj,requestParameters=requestParameters), envir=env)
	return(w)
}


#' Function to add log reports to the IWMMAnalyst
#' @param logobj The object to be logged
#' @param logdir The name of the Ravian log registry entry key indicating the path where to place the log file
#' @param idv A random string passed to the function that names the log file
#' @return The name of the temp file with the logged object
addRavianLog<-function(logobj, logdir="general",idv=""){
	if(idv==""){
		idv<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
	}
	tfn<-paste(idv,"_errorLog.Rdata",sep="")
	log.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianLogRegistry.yaml",sep="")),silent=TRUE)
	path<-log.registry[[logdir]][["path"]]
	filenam<-paste(path,tfn,sep="")
	save(logobj,file=filenam)
	return(idv)
}

#' Function to encode a plot object into a base64 stream.
#' @param plobj The plot object to convert
#' @param wdt the width of the plot
#' @param hgt the height of the plot
create.EncodeGraph<-function(plobj, wdt=9.5,hgt=3.5){
	if(grepl("Windows",Sys.info()["sysname"])){
		tpd<-tempdir()		#if locally
	}else{
		tpd<-"/var/www/html/tmp"		
	}
	tmpf<-tempfile(pattern="RavianWeb", tmpdir=tpd)
	
	png(filename=tmpf, width = wdt, height = hgt, units= "in", res=300)
	print(plobj)
	dev.off()
	img <- readBin(tmpf, "raw", file.info(tmpf)[1, "size"])
	enc <-  base64Encode(img, "character")
	return(enc[1])
}

#' Function to create the json content of a plotly object.
#' @param plobj The plot object to convert
#' @param tooltip The plotly parameter that specifies which aesthetics to show in the tool tip
createJSONforPlotly<-function(plobj, tooltip="all"){
	ppp<-plotly::gg2list(plobj,tooltip=tooltip)
	ddd<-plotly::as.widget(ppp)
	#then print_html that object
	pagepath<-htmltools::html_print(ddd,viewer=NULL)
	htfile <- file(pagepath, "r")
	resout<-readLines(htfile)
	close(htfile)
	for(ii in 1:NROW(resout)){
		if(grepl("application/json",resout[ii])){
			jsout<-resout[ii]
		}
	}
	jsoutt<-substr(jsout,regexpr("\\{",jsout),regexpr("</script>",jsout)-1)
	return(jsoutt)
}

#' Function to pass the plotly full html plotly code to the browser
createHTMLforPlotly<-function(plobj,plotlyLibPth, tooltip="all"){
	ppp<-plotly::gg2list(plobj)
	ddd<-plotly::as.widget(ppp)
	#then print_html that object
	pagepath<-htmltools::html_print(ddd,viewer=NULL)
	htfile <- file(pagepath, "r")
	resout<-readLines(htfile)
	close(htfile)
	plotly.cfg<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianPlotlyConfig.yaml",sep="")),silent=TRUE)
	if(!inherits(plotly.cfg,"try-error")){
		plylbpath<-as.character(plotly.cfg$plotlylibsloc)
		plylbpath<-paste("src=\"",plylbpath,sep="")
		resout<-gsub("src=\"lib/",plylbpath,resout)
	}else{	#failed to find the plotly config file, so send "as is"
		resout<-paste(resout,collapse=" ")
	}
	resout<-paste(resout,collapse=" ")
	return(resout)
}

#' Function to convert a list of RavianResult objects to a generic R list
convertResultsToList<-function(ravianList){
	reslist<-list()
	for(ii in 1:(NROW(ravianList))){
		obj<-ravianList[[ii]]
		lobj<-list(ResultType=ResultType(obj),ResultTitle=ResultTitle(obj),ResultNotes=ResultNotes(obj))
		if(ResultType(obj)=="Table"){
			lobj$ResultTable<-ResultTable(obj)
		}else if(ResultType(obj)=="Graph"){
			lobj$ResultGraphPltFunction<-ResultGraphPltFunction(obj)
			lobj$ResultGraphArgs<-ResultGraphArgs(obj)
		}else if(ResultType(obj)=="Error"){
			lobj$ErrorDescription<-ErrorDescription(obj)
		}else if(ResultType(obj)=="Warning"){
			lobj$WarningDescription<-WarningDescription(obj)
		}else{
			#extend here
		}
		reslist[[ii]]<-lobj
	}
	return(reslist)
}


