# TODO: Add comment
# 
# Author: lsalas
###############################################################################


#This is a class of objects that at the very minimum validates the following domains in NodeDb: project, protocol, samplingUnit, species, guild, and region
#It will be extended to subclasses that narrow down these domains and may extend to include other domains
#The validation method takes as input the json of the post and looks within it for requests within these domains.
#The class knows how to query for each domain and thus, will check any content to belong to the domain

################################## Object def validateRavianDomain
#' Abstract class for validateRavianDomain
#' 
#' Abstract class for validateRavianDomain
#' 
#' @param RequestParameters A json string with the content of the POST/GET
#' @param ValidationType A text string that serves to define prototypes for subclasses. The superclass has type "General"
#' @param ErrorReport A string with any execution errors
setClass("validateRavianDomain", prototype=prototype(ValidationType="general"),
		representation(
				RequestParameters = "character",
				ValidationType = "character",
				ErrorReport = "character"
		)
)

############################### class operation methods ############################################################

############################## RequestParameters
#' Set generic to  method that sets the RequestParameters slot of validateRavianDomain object.
#' 
#' @name setRequestParameters
#' @param object A validateRavianDomain object
#' @param value A json string with the content of the POST/GET
setGeneric("RequestParameters<-", 
		function(object, value)	standardGeneric("RequestParameters<-"))

#' Set RequestParameters slot of validateRavianDomain object.
#' 
#' @name setRequestParameters
#' @param object A validateRavianDomain object
#' @param value A json string with the content of the POST/GET
setReplaceMethod("RequestParameters",signature(object="validateRavianDomain"),
		function(object,value) {
			slot(object,"RequestParameters")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the RequestParameters slot of the validateRavianDomain object.
#' 
#' @name RequestParameters
#' @param object A validateRavianDomain object
setGeneric("RequestParameters", 
		function(object) standardGeneric("RequestParameters"))

#' Retrieve the contents of the RequestParameters slot of the validateRavianDomain object.
#' 
#' @name RequestParameters
#' @param object A validateRavianDomain object
setMethod("RequestParameters", signature(object="validateRavianDomain"),
		function(object) slot(object,"RequestParameters"))


############################## ValidationType
#' Set generic to  method that sets the ValidationType slot of validateRavianDomain object.
#' 
#' @name setValidationType
#' @param object A text string that serves to define prototypes for subclasses
#' @param value A data.frame to put into the ValidationType slot
setGeneric("ValidationType<-", 
		function(object, value)	standardGeneric("ValidationType<-"))

#' Set ValidationType slot of validateRavianDomain object.
#' 
#' @name setValidationType
#' @param object A text string that serves to define prototypes for subclasses
#' @param value A data.frame to put into the ValidationType slot
setReplaceMethod("ValidationType",signature(object="validateRavianDomain"),
		function(object,value) {
			slot(object,"ValidationType")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the ValidationType slot of the validateRavianDomain object.
#' 
#' @name ValidationType
#' @param object A validateRavianDomain object
setGeneric("ValidationType", 
		function(object) standardGeneric("ValidationType"))

#' Retrieve the contents of the RequestParameters slot of the validateRavianDomain object.
#' 
#' @name ValidationType
#' @param object A validateRavianDomain object
setMethod("ValidationType", signature(object="validateRavianDomain"),
		function(object) slot(object,"ValidationType"))

############################## ErrorReport
#' Set generic to  method that sets the ErrorReport slot of speciesKeys object.
#' 
#' @name setErrorReport
#' @param object A speciesKeys object
#' @param value A string to put into the ErrorReport slot
setGeneric("ErrorReport<-", 
		function(object, value)	standardGeneric("ErrorReport<-"))

#' Set ErrorReport slot of validateRavianDomain object.
#' 
#' @name setErrorReport
#' @param object An validateRavianDomain object
#' @param value A string to put into the ErrorReport slot
setReplaceMethod("ErrorReport",signature(object="validateRavianDomain"),
		function(object,value) {
			slot(object,"ErrorReport")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the ErrorReport slot of the speciesKeys object.
#' 
#' @name ErrorReport
#' @param object A speciesKeys object
setGeneric("ErrorReport", 
		function(object) standardGeneric("ErrorReport"))

#' Retrieve the contents of the ErrorReport slot of the validateRavianDomain object.
#' 
#' @name ErrorReport
#' @param object An validateRavianDomain object
setMethod("ErrorReport", signature(object="validateRavianDomain"),
		function(object) slot(object,"ErrorReport"))


############################## Initialize
#' Instantiate a new validateRavianDomain object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "validateRavianDomain"),
		function (.Object, ...) 
		{
			.Object@RequestParameters 	<- character()
			.Object@ValidationType 	<- character()
			.Object@ErrorReport	<- character()
			.Object
		}
)

######################################################################################################################

####################### domain validation method

#' Set generic to  method that requests the validation of a request for Ravian
#' 
#' @name requestDomainValidation
#' @param object A validateRavianDomain object. 
setGeneric("requestDomainValidation",
		function(object) standardGeneric("requestDomainValidation"))

#' Request the analysis of some data in Ravian
#' 
#' @param object An analysisResult object.
setMethod("requestDomainValidation", signature(object = "validateRavianDomain"),
		function(object) {
			req<-fromJSON(RequestParameters(object))
			#get a connection
			connObj<-new("connectRavian")
			HandleType(connObj)<-"support"
			connObj<-getRavianHandle(connObj)
			connlst<-ResultHandle(connObj);conn<-connlst[[1]]
			#check that the connection is up
			if(inherits(conn,"try-error") || conn==-1){
				ErrorReport(object)<-"Error: Ravian could not establish a connection with the database to validate the request."
			}else{
				errormessages<-character()
				if(TRUE %in% grepl("projects",names(req))){
					domdef<-req$projects
					errorrep<-getDomainCheck(conn=conn,domdef=domdef,domname="projects",tblField="ProjectId",tblName="PRBOdb.Project",txtfld=TRUE)
					if(errorrep!=""){errormessages<-c(errormessages,errorrep)}
				}
				if(TRUE %in% grepl("protocols",names(req))){
					domdef<-req$protocols
					errorrep<-getDomainCheck(conn=conn,domdef=domdef,domname="protocols",tblField="ProtocolId",tblName="PRBOdb.Protocol",txtfld=TRUE)
					if(errorrep!=""){errormessages<-c(errormessages,errorrep)}
				}
				if(TRUE %in% grepl("species",names(req))){
					domdef<-req$species
					errorrep<-getDomainCheck(conn=conn,domdef=domdef,domname="species",tblField="BirdCd",tblName="PRBOdb.FieldBird_v2",txtfld=TRUE)
					if(errorrep!=""){errormessages<-c(errormessages,errorrep)}
				}
				if(TRUE %in% grepl("guilds",names(req))){	
					domdef<-req$guilds
					errorrep<-getDomainCheck(conn=conn,domdef=domdef,domname="guilds",tblField="GuildName",tblName="PRBOdb.FieldBirdGuild",txtfld=TRUE)
					if(errorrep!=""){errormessages<-c(errormessages,errorrep)}
				}
				if(TRUE %in% grepl("samplingUnits",names(req))){
					domdef<-req$samplingUnits
					errorrep<-getDomainCheck(conn=conn,domdef=domdef,domname="samplingUnits",tblField="SamplingUnitID",tblName="PRBOdb.SamplingUnit",txtfld=FALSE)
					if(errorrep!=""){errormessages<-c(errormessages,errorrep)}
				}
				if(TRUE %in% grepl("region",names(req))){
					domdef<-req$region
					errorrep<-getDomainCheck(conn=conn,domdef=domdef,domname="region",tblField="regionid",tblName="PRBOdb.samplingunitregionfeature_vw",txtfld=FALSE)
					if(errorrep!=""){errormessages<-c(errormessages,errorrep)}
				}
				ErrorReport(object)<-paste(errormessages,collapse=" ")
				odbcClose(conn)
			}
			
			return(object)
		}
)

#' Function to check for domain validation in a parameter in the request
#' @param conn The connection object to use for the check
#' @param domdef The domain of values in the request being validated
#' @param domname The name of the domain being validated. This is usually the same as the name of the parameter in the request. Eg., projects or protocols
#' @param tblField The name of the field in a table in NodeDb that validates the domain
#' @param tblName The name of the table in NodeDb that contains the field that validates the domain
#' @param txtfld A boolean: is the field a text field? Default: TRUE
getDomainCheck<-function(conn,domdef,domname,tblField,tblName,txtfld=TRUE){
	errmsg<-""
	if(domname=="guilds"){
		#domdef is a list for guilds... so...
		domdef<-domdef[[1]]
	}
	if(txtfld==TRUE){
		sqltxt<-paste("select distinct ",tblField," from ",tblName," where ",tblField," in ('",paste(domdef,collapse="','"),"')",sep="")
	}else{
		sqltxt<-paste("select distinct ",tblField," from ",tblName," where ",tblField," in (",paste(domdef,collapse=","),")",sep="")
	}
	
	chk<-try(sqlQuery(conn,sqltxt,rows_at_time=1), silent = TRUE)
	if(inherits(chk,"try-error")){
		errmsg<-paste("Error: Ravian could not validate the list of ",domname,".",sep="")
	}else if(NROW(chk)==0){
		errmsg<-paste("Error: all ",domname," requested are not known to Ravian.",sep="")
	}else if(TRUE %in% grepl("ERROR",paste(chk,collapse=". "))){
		errmsg<-paste("Error: Ravian encountered a querying error when attempting to validate the list of ",domname,". Please make sure that the values you provided are adequate: '",paste(domdef, collapse=','),"'.",sep="")
	}else if(nrow(chk)>0){
		rdf<-domdef[which(!casefold(domdef) %in% casefold(as.character(chk[,tblField])))]
		if(NROW(rdf)>0){
			errmsg<-paste("Error: the list of ",domname," requested includes values not known to Ravian: ",paste(rdf,collapse=", "),".",sep="")
		}else{
			errmsg<-""
		}
	}else{
		#can't validate - error
		errmsg<-paste("Error: Ravian could not validate the list of ",domname,".",sep="")
	}
	return(errmsg)
}
