pkgname <- "Ravian"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('Ravian')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("createDSN")
### * createDSN

flush(stderr()); flush(stdout())

### Name: createDSN
### Title: Create a DSN connection string for an ODBC connector driver...
### Aliases: createDSN
### Keywords: database

### ** Examples
## Not run: createDSN("{MySQL ODBC 5.1 Driver}","192.168.2.102","bmde.data","genericUser","Pa55w0rd",3306,2049)


### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
