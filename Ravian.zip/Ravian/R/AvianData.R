#' @include DataStore.R

###############################################################################
# AvianData.R
# TODO: Add comment
# 
# Author: Leo Salas & Mark Herzog
# Contact: lsalas@prbo.org
# Creation Date: May 30, 2009
###############################################################################
#' Abstract class for AvianData
#' 
#' Abstract class for AvianData
#' 
#' @param ObsData dataframe that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType character string that defines the type of data.  Each subclass of AvianData has a unique ProtocolType
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @exportClass AvianData
setClass("AvianData", representation(
				ObsData = "data.frame",
				EffortData = "data.frame", 
				ProtocolType = "character",
				Fields = "list",
				FilterList = "list",
				DataDefn = "DataStore",
				Metadata="list"))

#' Set generic to  method that sets ObsData slot of AvianData object.
#' 
#' @name setObsData
#' @param object An AvianData object
#' @param value Dataframe to put into ObsData slot.
setGeneric("ObsData<-", 
		function(object, value)	standardGeneric("ObsData<-"))

#' Set ObsData slot of AvianData object.
#' 
#' @name setObsData
#' @param object An AvianData object
#' @param value Dataframe to put into ObsData slot.
setReplaceMethod("ObsData",signature(object="AvianData"),
		function(object,value) {
			slot(object,"ObsData")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ObsData slot value of AvianData object.
#' 
#' @name ObsData
#' @param object An AvianData object
setGeneric("ObsData", 
		function(object) standardGeneric("ObsData"))

#' Retrieve ObsData slot value of AvianData object.
#' 
#' @name ObsData
#' @param object An AvianData object
setMethod("ObsData", signature(object="AvianData"),
		function(object) slot(object,"ObsData"))

#' Set generic to  method that sets EffortData slot of AvianData object.
#' 
#' @name setEffortData
#' @param object An AvianData object
#' @param value Dataframe to put into EffortData slot.
setGeneric("EffortData<-", 
		function(object, value)	standardGeneric("EffortData<-"))

#' Set EffortData slot of AvianData object.
#' 
#' @name setEffortData
#' @param object An AvianData object
#' @param value Dataframe to put into EffortData slot.
setReplaceMethod("EffortData", signature(object="AvianData"),
		function(object,value){
			slot(object,"EffortData")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves EffortData slot value of AvianData object.
#' 
#' @name EffortData
#' @param object An AvianData object
setGeneric("EffortData",
		function(object)	standardGeneric("EffortData"))

#' Retrieve EffortData slot value of AvianData object.
#' 
#' @name EffortData
#' @param object An AvianData object
setMethod("EffortData", signature(object="AvianData"),
		function(object) slot(object,"EffortData"))

#' Set generic to  method that retrieves ProtocolType slot value of AvianData object
#' 
#' @name ProtocolType
#' @param object An AvianData object
setGeneric("ProtocolType",
		function(object) standardGeneric("ProtocolType"))

#' Retrieve ProtocolType slot value of AvianData object
#' 
#' @name ProtocolType
#' @param object An AvianData object
setMethod("ProtocolType", signature(object="AvianData"),
		function(object) slot(object,"ProtocolType"))
#Note no setProtocolType method - the slot is instantiated by the subclass defaut

#' Set generic to  method that sets Fields slot of an AvianData object.
#' 
#' @name setFields
#' @param object An AvianData object
#' @param value list to put into Fields slot.
setGeneric("Fields<-", 
		function(object, value)	standardGeneric("Fields<-"))

#' Set Fields slot of an AvianData object.
#' 
#' @name setFields
#' @param object An AvianData object
#' @param value list to put into Fields slot.
setReplaceMethod("Fields",signature(object="AvianData"),
		function(object,value) {
			slot(object,"Fields")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves Fields slot value of AvianData object
#' 
#' @name Fields
#' @param object An AvianData object
setGeneric("Fields", 
		function(object)	standardGeneric("Fields"))

#' Retrieve Fields slot value of AvianData object
#' 
#' @name Fields
#' @param object An AvianData object
setMethod("Fields", signature(object="AvianData"),
		function(object) slot(object,"Fields"))

#' Set generic to  method that sets FilterList slot of AvianData object .
#' 
#' @name FilterList
#' @param object An AvianData object
#' @param value list to put into FilterList slot, or list to build FilterList from.
setGeneric("FilterList<-",
		function(object, value) standardGeneric("FilterList<-"))

#' Set FilterList slot of AvianData object .
#' 
#' Create a FilterList for a data object.  This will primarily
#' 		be used to develop the WHERE segment of the SQL
#' 		SELECT statement.  User may actually provide a WHERE
#' 		clause, or set specific arguments through a list of key:value pairs,
#' 		where each key is a field name and the value are filtering conditions for the field
#' 		Fieldnames are defined within the Ravian warehouse fieldname schema.
#' 
#' @name FilterList
#' @param object An AvianData object
#' @param value list to put into FilterList slot, or list to build FilterList from.
setReplaceMethod("FilterList", signature(object="AvianData"),
		function(object, value){
			if (is.null(value) == TRUE) 
				return("Unable to perform operation. value for FilterList cannot be blank.")
			else 
			if ((!("eventSQL" %in% names(value)) & ("obsSQL" %in% names(value))) | (("eventSQL" %in% names(value)) & !("obsSQL" %in% names(value)))) 
				return("Unable to perform operation.  'eventSQL' and 'obsSQL' must both be supplied, or neither supplied and instead a list of key,value provided, where key is a field name.")
			else   
			#TODO: this line below seems to imply that eventSQL is optional.  If so, the evaluation above needs revision...
			if ("eventSQL" %in% names(value)) {
				## we could do regex search through each query to confirm that the correct
				## fields are within each part of the list. 
				where.list<-value
			}
			else {  ## it must be a paired list of variables, which means we need to build the eventSQL and obsSQL				
				tmp<-value[names(value) %in% Fields(object)$event]
				
				## while this is pretty cool (if I say so, myself)... it might be
				## inefficient to build a SQL statement full of 'IN' phrases.
				## It may be worth just looping through the list and building 
				## something a little more complex.
				
				## REVISED - Below needs to be revised to create a FilterList
				##  (i.e. list with obsSQL and eventSQL)
				where.event<-paste(
						paste(
								paste(names(tmp),
										lapply(tmp,
												function(x) ifelse(is.character(x),
															paste("'",x,"'",sep="",collapse=","),
															paste(x,collapse=","))),
										sep=" IN ("),
								collapse=") AND "),
						")",
						sep="")
				tmp<-value[names(value) %in% Fields(object)$obs]
				where.obs<-paste(
						paste(
								paste(names(tmp),
										lapply(tmp,
												function(x) ifelse(is.character(x),
															paste("'",x,"'",sep="",collapse=","),
															paste(x,collapse=","))),
										sep=" IN ("),
								collapse=") AND "),
						")",
						sep="")
				where.list <- list(eventSQL = where.event,
						obsSQL = where.obs)
			}
			slot(object,"FilterList")<-where.list
			validObject(object)
			object
		})

#' Set generic to  method that retrieves FilterList slot value of AvianData object
#' 
#' @name FilterList
#' @param object An AvianData object
setGeneric("FilterList", 
		function(object) standardGeneric("FilterList"))

#' Retrieve FilterList slot value of AvianData object
#' 
#' @name FilterList
#' @param object An AvianData object
setMethod("FilterList", signature(object="AvianData"),
		function(object) slot(object,"FilterList"))

#' Set generic to  method that sets DataDefn slot of AvianData object
#' 
#' @name DataDefn
#' @param object An AvianData object
#' @param value DataStore-type object to be put into DataDefn slot.
setGeneric("DataDefn<-", 
		function(object, value)	standardGeneric("DataDefn<-"))

#' Set DataDefn slot of AvianData object
#' 
#' @name DataDefn
#' @param object An AvianData object
#' @param value DataStore-type object to be put into DataDefn slot.
setReplaceMethod("DataDefn",signature(object="AvianData"),
		function(object,value) {
			slot(object,"DataDefn")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves DataDefn slot value of AvianData object
#' 
#' @name DataDefn
#' @param object An AvianData object
setGeneric("DataDefn", 
		function(object)	standardGeneric("DataDefn"))

#' Retrieve DataDefn slot value of AvianData object
#' 
#' @name DataDefn
#' @param object An AvianData object
setMethod("DataDefn", signature(object="AvianData"),
		function(object) slot(object,"DataDefn"))

#' Set generic to  method that sets Metadata slot of AvianData object
#' 
#' @name setMetadata
#' @param object An AvianData object
#' @param value list to insert into Metadata slot
setGeneric("Metadata<-", 
		function(object, value) standardGeneric("Metadata<-"))

#' Set Metadata slot of AvianData object
#' 
#' @name setMetadata
#' @param object An AvianData object
#' @param value list to insert into Metadata slot
setReplaceMethod("Metadata", signature(object="AvianData"),
		function(object,value){
			slot(object,"Metadata")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves Metadata slot value of AvianData object
#' 
#' @name Metadata
#' @param object An AvianData object
setGeneric("Metadata", 
		function(object)	standardGeneric("Metadata"))

#' Retrieve Metadata slot value of AvianData object
#' 
#' @name Metadata
#' @param object An AvianData object
setMethod("Metadata", signature(object="AvianData"),
		function(object) slot(object,"Metadata"))

#' Set generic to  method that summarizes AvianData object
#' 
#' Provide simple core summary information on an AvianData object.
#' @name summary
#' @param object An AvianData object.
if (!isGeneric("summary")) {
	if (is.function("summary"))
		fun <- summary
	else fun <- function(object, ...) standardGeneric("summary")

	setGeneric("summary", fun)
}


#' Summarize AvianData object
#' 
#' Provide simple core summary information on an AvianData object.
#' @param object An AvianData object.
setMethod("summary", "AvianData",
		function(object) {
			##TODO We should format nicely, include options for Metadata export, etc.
			cat(
					"Summary information for ", class(object), " object:",
					"ObsData data frame \n",
					"Number of rows:", nrow(ObsData(object)),"\n",
					"EffortData data frame \n",
					"Number of rows:", nrow(EffortData(object)),"\n",
					if(nrow(ObsData(object))==1){
						"First row of ObsData frame:"
						ObsData(object)
					},
					if(nrow(EffortData(object))==1){
						"First row of EffortData frame:"
						EffortData(object)
					}
			)
		})

#' Instantiate a new AvianData object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "AvianData"),
		function (.Object, ...) 
		{
			## TODO is there a way to only allow this initialize to happen if the object is a subclass of AvianData... in other words keep people from initializing an actual AvianData object? 
			
			.Object@ObsData <- data.frame()
			.Object@EffortData <- data.frame()
			.Object@Metadata <- list()
			.Object@ProtocolType <- ""
			.Object@DataDefn <- new("DataStore")
			.Object@Fields<-list()
			.Object@FilterList<-list()
			.Object
		}
)


#' Set generic to  method that produces a unique species list
#' 
#' Produce a list of unique species observed within AvianData object
#' 
#' @param object An AvianData object.
setGeneric("listSpecies", 
		function(object, display, ...) standardGeneric("listSpecies"))

#' Unique species list
#' 
#' Produce a list of unique species observed within AvianData object
#' @param object An AvianData object.
#' @param display String naming the variable to list, defaults to CommonName
setMethod("listSpecies",signature(object="AvianData"), 
		function(object, display="") {
			tmp<-ObsData(object)
			if(display=="")display<-"CommonName"
			tmp<-unique(tmp[,names(tmp) == display])
			return(tmp)
		})

#' Set generic to  method that estimates Abundance or Density from AvianData object
#' 
#' @name estimateAbundance
#' @param object An AvianData object.  See specific Ravian objects for details
setGeneric("estimateAbundance",
		function(object,  ...) standardGeneric("estimateAbundance"))
 
#' Set generic to  method that estimates Occupancy from AvianData object
#' 
#' @name estimateOccupancy
#' @param object An AvianData object. See specific Ravian objects for details
setGeneric("estimateOccupancy",
		function(object,  ...) standardGeneric("estimateOccupancy"))

#' Set generic to  method that estimates Simple Species Richness from AvianData object
#' 
#' @name estimateRichness
#' @param object An AvianData object. See specific Ravian objects for details
setGeneric("estimateRichness",
		function(object, ...) standardGeneric("estimateRichness"))

#' Extracts the effort or observation dataframe from an AvianData
#' 
#' @name as.data.frame
#' @param x An AvianData object.
#' @param source.table character string, either ObsData for Observation data.frame, 
#'		EffortData for the Effort data.frame, or merged, which will result in a different column per species
#' @param selected.fields character vector to inform the function to only retrieve a subset
#' 		of all the possible fields.  If blank (default) all fields will be retrieved.
#This method is not being exported - to be used only within Ravian methods.
setMethod("as.data.frame",
		signature(x="AvianData", row.names="missing", optional="missing"),
		function(x, source.table = "ObsData", selected.fields=NULL, ...) {
			if(source.table=="EffortData"){
				res.df<-EffortData(x)
			}else if(source.table=="merged"){
				effd<-EffortData(x)
				obsd<-ObsData(x)
				res.df<-merge(effd,obsd,all.x=TRUE)
				res.df$ObservationCount<-ifelse(is.na(res.df$ObservationCount),0,res.df$ObservationCount)
			}else if(source.table=="byspecies"){
				wided<-EffortData(x)
				obsd<-ObsData(x)
				spp<-unique(obsd$SpeciesCode)
				for(sss in spp){
					obs.sp<-subset(obsd,SpeciesCode==sss)
					obs.sp<-obs.sp[,c("ProjectCode", "ProjectName", "LocalityID","SamplingUnitId",
									"ProtocolCode","Visit","YearCollected","MonthCollected","JulianDay","ObservationCount")]
					names(obs.sp)<-c("ProjectCode", "ProjectName", "LocalityID","SamplingUnitId",
							"ProtocolCode","Visit","YearCollected","MonthCollected","JulianDay",sss)
					wided<-merge(wided,obs.sp,by=c("ProjectCode", "ProjectName", "LocalityID","SamplingUnitId",
									"ProtocolCode","Visit","YearCollected","MonthCollected","JulianDay"),all.x=TRUE)
					wided[,sss]<-ifelse(is.na(wided[,sss]),0,wided[,sss])
				}
				res.df<-wided
			}else{
				res.df<-ObsData(x)
			}
			if(!is.null(selected.fields)){res.df<-res.df[selected.fields]}
			return(res.df)
		})

#' Set generic to  method that creates a populated QueryList object of DataStore object (of AvianData object)
#' 
#' This method will retrieve information from FilterList and DataStore slots in an AvianData object 
#' 		to instantiate the QueryList object in the DataStore object in the AvianData object.
#' @name buildQueryList
#' @param data.obj An AvianData object
#' @param data.type Either "obs" (default) or "event" string thus specifying what fields and filters to
#' 		retrieve to build the QueryList object
#' @param more.filters String with any additional filter arguments
#' @param more.obs.filters String with additional observation filter arguments
#This method is not exported - to be used within Ravian methods only
setGeneric("buildQueryList", 
		function(data.obj, data.type, more.filters, more.obs.filters, ...) standardGeneric("buildQueryList"))

#' Creates a populated QueryList object of DataStore object (of AvianData object)
#' 
#' This method will retrieve information from FilterList and DataStore slots in an AvianData object 
#' to instantiate the QueryList object in the DataStore object in the AvianData object.
#' @name buildQueryList
#' @param data.obj An AvianData object
#' @param data.type Either "obs" (default) or "event" string thus specifying what fields and filters to
#' 		retrieve to build the QueryList object
#' @param more.filters String with any additional filter arguments
#' @param more.obs.filters String with additional observation filter arguments
setMethod("buildQueryList",
		signature(data.obj = "AvianData", data.type="character"),
		function(data.obj, data.type="obs", more.filters="", more.obs.filters="", ...){
			if (is.null(data.obj)==TRUE) stop("An AvianData class of object is required.")
			if (!class(data.obj) %in% c("BandData","PointCountData","AreaSearchData","ShoreBirdData","ISBAdbData","ShoreBirdGeoData")) stop("An AvianData class of object is required.")
			m.flt<-more.filters
			m.o.flt<-more.obs.filters
			if(length(m.flt)<0 | is.null(m.flt) | is.na(m.flt)) m.flt<-""
			if(length(m.o.flt)<0 | is.null(m.o.flt) | is.na(m.o.flt)) m.o.flt<-""
			#Instantiate a new QueryList object
			tmp<-new("QueryList")
			if(!length(FilterList(data.obj)$obsSQL)) FilterList(data.obj)$obsSQL<-""
			## First, the observation data
			if(data.type=="obs" | data.type==""){
				Select(tmp) <- paste(Fields(data.obj)$obs,collapse=", ")
				From(tmp) <- TableName(DataDefn(data.obj))
				if (FilterList(data.obj)$obsSQL != "" & FilterList(data.obj)$eventSQL != "") {
					where.tmp <- paste(FilterList(data.obj)$eventSQL,FilterList(data.obj)$obsSQL,sep=" AND ")
				} else {
					if (FilterList(data.obj)$obsSQL =="") where.tmp <- FilterList(data.obj)$eventSQL
					else where.tmp <- FilterList(data.obj)$obsSQL
				}
				Where(tmp) <- where.tmp
				if(m.flt!="") {
					where.tmp <- paste(where.tmp,"AND",m.flt)
					Where(tmp) <- where.tmp
				}
				if(m.o.flt!="") {
					where.tmp <- paste(where.tmp,"AND",m.o.flt)
					Where(tmp) <- where.tmp
				}
				
				## TODO Would an OrderBy() help?
			}else{	#event data type
				Select(tmp)<-paste(Fields(data.obj)$event, collapse=', ')
				Distinct(tmp) <- TRUE
				From(tmp) <- TableName(DataDefn(data.obj))
				Where(tmp) <- FilterList(data.obj)$eventSQL
				if(m.flt!="") {
					Where(tmp) <- paste(FilterList(data.obj)$eventSQL,"AND",m.flt)
				}
			}
			return(tmp)
		}
)

#' Set generic to  method that populates AvianData object using the query information in it
#' 
#' @name getAvianData
#' @param object An AvianData object
#' @param more.filters A string providing more filter criteria, in a form readily
#' 		incorporable as part of a Where sql clause, applicable to the sampling effort
#' @param more.obs.filters A string providing more filter criteria, in a form readily
#' 		incorporable as part of a Where sql clause, applicable only to the observational data
#' @param taxon.groups A json string of a list object, where each entry is a character vector
#' 		of species codes that conform a taxon group (i.e., a guild) and the name of the list
#' 		entry provides the name of the group.
#' @param spatial.groups Analogous to taxon.groups, but the contents are the SamplingUnitIds
#' 		of the locations that become a group.
#' @param obs.groups Analogous to taxon.groups, but the name of the list entry provides the 
#' 		name of a covariate in the data table, and the items in the entry define the values
#' 		of the covariate that become a group.
setGeneric("getAvianData", 
		function(object, more.filters, more.obs.filters, taxon.groups, spatial.groups, obs.groups, ...)	standardGeneric("getAvianData"))

#' Populates AvianData object using the query information in it
#' 
#' @name getAvianData
#' @param object An AvianData object
#' @param more.filters A string providing more filter criteria, in a form readily
#' 		incorporable as part of a Where sql clause, applicable to the sampling effort
#' @param more.obs.filters A string providing more filter criteria, in a form readily
#' 		incorporable as part of a Where sql clause, applicable only to the observational data
#' @param taxon.groups A json string of a list object, where each entry is a character vector
#' 		of species codes that conform a taxon group (i.e., a guild) and the name of the list
#' 		entry provides the name of the group.
#' @param spatial.groups Analogous to taxon.groups, but the contents are the SamplingUnitIds
#' 		of the locations that become a group.
#' @param obs.groups Analogous to taxon.groups, but the name of the list entry provides the 
#' 		name of a covariate in the data table, and the items in the entry define the values
#' 		of the covariate that become a group.
setMethod("getAvianData", signature(object="AvianData"),
		function(object, more.filters=NULL, more.obs.filters=NULL, taxon.groups="", spatial.groups="", obs.groups="", ...){
			filt<-more.filters
			if(!length(filt)) filt<-""
			o.filt<-more.obs.filters
			if(!length(o.filt)) o.filt<-""
			if (is.null(object)==TRUE) stop("An AvianData object is required.")
			if (!class(object) %in% c("BandData","PointCountData","AreaSearchData","ShoreBirdData","ISBAdbData","ShoreBirdGeoData")) stop("An AvianData class of object is required.")
			eff.data.query<-try(buildQueryList(data.obj=object, data.type="event", more.filters=filt, more.obs.filters=""), silent=TRUE)
			#check for proper SQL
			if(inherits(eff.data.query,"try-error")){
				res<-paste(eff.data.query, collapse=" ")
				class(res)<-"try-error"
				return(res)
			}else{
				Query(DataDefn(object))<-eff.data.query
				effort.data<-try(getDataRavian(DataDefn(object)),silent=TRUE)
				if(inherits(effort.data,"try-error")){
					res<-paste(effort.data, collapse=" ")
					class(res)<-"try-error"
					return(res)
				}else{
					#check for no data harvested
					if (nrow(effort.data$result.data)==0) {
						res<-paste("Ravian Message: No survey events are available for selection submitted.")
						class(res)<-"try-error"
						return(res)
					}
					eff.dat<- effort.data$result.data
					#Now attach the spatial.groups info
					if(spatial.groups!="") {	#links by SamplingUnitID
						spatial.groups.l<-fromJSON(spatial.groups)
						onsg<-names(spatial.groups.l)
						sg<-as.data.frame(unlist(spatial.groups.l,recursive=FALSE))
						sgn<-rownames(sg)
						ssnn<-array()
						for(ii in 1:NROW(sgn)){
							for(jj in 1:NROW(onsg)){
								if(grepl(onsg[jj],sgn[ii])==TRUE)ssnn[ii]<-onsg[jj]
							}
						}
						sgf<-as.data.frame(cbind(sg,ssnn),row.names=NULL)
						colnames(sgf)<-c("SamplingUnitId","SpatialGroup")
						sggf<-merge(eff.dat,sgf,by=intersect(names(eff.dat),names(sgf)),all.x=TRUE)
						sggf$SpatialGroup<-ifelse(is.na(sggf$SpatialGroup),"unassigned",as.character(sggf$SpatialGroup))
						eff.dat<-sggf
						Metadata(object)[["spatial.groups"]]=spatial.groups
					}
					EffortData(object)<-eff.dat
				}
			}
			#get observation data
			obs.data.query<-try(buildQueryList(data.obj=object, data.type="obs", more.filters=filt, more.obs.filters=o.filt), silent=TRUE)
			#check for proper SQL
			if(inherits(obs.data.query,"try-error")){
				res<-paste(obs.data.query, collapse=" ")
				class(res)<-"try-error"
				return(res)
			}else{
				Query(DataDefn(object))<-obs.data.query
				obs.data<-try(getDataRavian(DataDefn(object)),silent=TRUE)
				if(inherits(obs.data,"try-error")){
					res<-paste(obs.data, collapse=" ")
					class(res)<-"try-error"
					return(res)
				}else{
					#check for no data harvested
					if (nrow(obs.data$result.data)==0) {
						res<-paste("Ravian Message: There are no records available for analyses.")
						class(res)<-"try-error"
						return(res)
					}
					obs.dat<- obs.data$result.data
					
					#First attach the spatial.groups info
					if(spatial.groups!="") {	#links by SamplingUnitID
						spatial.groups.l<-fromJSON(spatial.groups)
						onsg<-names(spatial.groups.l)
						sg<-as.data.frame(unlist(spatial.groups.l,recursive=FALSE))
						sgn<-rownames(sg)
						ssnn<-array()
						for(ii in 1:NROW(sgn)){
							for(jj in 1:NROW(onsg)){
								if(grepl(onsg[jj],sgn[ii])==TRUE)ssnn[ii]<-onsg[jj]
							}
						}
						sgf<-as.data.frame(cbind(sg,ssnn),row.names=NULL)
						colnames(sgf)<-c("SamplingUnitId","SpatialGroup")
						sggf<-merge(obs.dat,sgf,by=intersect(names(obs.dat),names(sgf)),all.x=TRUE)
						sggf$SpatialGroup<-ifelse(is.na(sggf$SpatialGroup),"unassigned",as.character(sggf$SpatialGroup))
						obs.dat<-sggf
					}
					
					#Now attach the taxon.groups info
					if(taxon.groups!="") {	#links by SpeciesCode
						taxon.groups<-fromJSON(taxon.groups)
						ontg<-names(taxon.groups)
						tg<-as.data.frame(unlist(taxon.groups,recursive=FALSE))
						tgn<-rownames(tg)
						ttnn<-array()
						for(ii in 1:NROW(tgn)){
							for(jj in 1:NROW(ontg)){
								if(grepl(ontg[jj],tgn[ii])==TRUE)ttnn[ii]<-ontg[jj]
							}
						}
						tgf<-as.data.frame(cbind(tg,ttnn),row.names=NULL)
						colnames(tgf)<-c("SpeciesCode","TaxonGroup")
						tggf<-merge(obs.dat,tgf,by=intersect(names(obs.dat),names(tgf)),all.x=TRUE)
						tggf$TaxonGroup<-ifelse(is.na(tggf$TaxonGroup),"unassigned",as.character(tggf$TaxonGroup))
						obs.dat<-tggf
						Metadata(object)[["taxon.groups"]]=taxon.groups
					}
					
					#Now attach the obs.groups info
					if(obs.groups!="") {	#links by variable specified in json string
						o.groups<-fromJSON(obs.groups)
						onog<-names(o.groups)
						#get group names and group membership, then assign values of group membership to the data
						#this should be with a merge, so we need a table of group codes and their group member values...
						#then merge by code value
						og.table<-vector()
						for(kk in 1:NROW(o.groups[[1]])){	#here is a point of extension, where the numeral 1 can be a loop numeral
							togt<-cbind(as.data.frame(o.groups[[1]][kk]),names(o.groups[[1]][kk]))
							names(togt)<-c(onog,"ObservationsGroup")
							og.table<-rbind(og.table,togt)
						}
						og.df<-as.data.frame(og.table)
						#merge now...
						oggf<-merge(obs.dat,og.df,by=intersect(names(obs.dat),names(og.df)),all.x=TRUE)
						oggf$ObservationsGroup<-ifelse(is.na(oggf$ObservationsGroup),"unassigned",as.character(oggf$ObservationsGroup))
						obs.dat<-oggf
						Metadata(object)[["observation.groups"]]=o.groups
					}

					ObsData(object)<-obs.dat
				}
			}
			return(object)
		})