#' @include RavianUtils.R
#' @include AvianData.R
#' @include RavianSampleSummaryTable.R


###############################################################################
# BandData.R
# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Creation Date: May 30, 2009
###############################################################################

#' BandData class - subclass of AvianData Class
#' 
#' BandData class - subclass of AvianData Class
#' @param ObsData dataframe that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType always "Band"
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @exportClass BandData
#Note to Leo: missing ProjectName, Effort is now NetHours, Age is back to LifeStage, "StationCode","StationName",
setClass("BandData",contains=c("AvianData"),
		prototype=prototype(ProtocolType="Band",
				Fields = list(obs = c("ProjectCode", "ProjectName", "ProtocolCode","StationCode","StationName","SamplingUnitId",
								"YearCollected", "MonthCollected", "DayCollected", "JulianDay","ObservationDate", 
								"NetHours", "ObservationCount","ScientificName", "CommonName", "SpeciesCode","PhylogenOrder", 
								"BandCode", "LifeStage", "Sex", "Wing", "Weight", "CloacalProtuberance",
								"BroodPatch", "BodyMolt", "WingMolt", "WingWear", "JuvenalPlumage",
								"Skull", "Fat"),
						event = c("ProjectCode", "ProjectName", "ProtocolCode","SamplingUnitId","StationCode","StationName",
								"YearCollected", "MonthCollected", "DayCollected", "JulianDay", "ObservationDate", "NetHours"))))

#' Instantiate a new BandData object
#' @return The BandData object
setMethod("initialize",
		signature(.Object = "BandData"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)

#' Estimate Abundance from BandData object
#' 
#' @param object A BandData object.
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param units String with the numeric exponent for the base-10 number to use to report the capture rate (e.g., "2" = x100 net-hours)
#' @param guild String giving a general name for the group of taxa, if provided (must not have blank spaces)
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
#' @param obs.group String naming the observation groups the data must be divided into - e.g., HabitatType, or Sex (must not have blank spaces). 
setMethod("estimateAbundance", signature(object = "BandData"),
		function(object, summarize.by="StationName", time.var = "YearCollected", units="2", 
				guild = "", spatial.units="", obs.group="",...) {
			#guild=taxon.groups.name,spatial.units=spatial.groups.name,obs.group=obs.groups.name
			ea.call<-match.call()
			if (is.null(object)) {stop("A data object is required.")}
			sb.name<-ifelse(spatial.units=="","StationName",spatial.units)
			
			support.site.fields<-c("ProtocolCode",time.var,"JulianDay","StationName","StationCode","NetHours")	#"ProjectCode","ProjectName",
			id.vars=c(time.var,"StationName","JulianDay")
			cast.eq<-paste(time.var,"StationName","JulianDay",sep="+")
			by.list<-c("ProtocolCode","StationName",time.var)	#"ProjectName","ProjectCode",
			field.sort.order<-c("ProtocolCode",sb.name,time.var)	#"ProjectName",
			if(summarize.by!="StationName"){
				support.site.fields<-c(support.site.fields,summarize.by)
				id.vars<-c(id.vars,summarize.by)
				cast.eq<-paste(cast.eq,summarize.by,sep="+")
				by.list<-c(by.list,summarize.by)
			}
			if(obs.group!=""){
				support.site.fields<-c(support.site.fields,"ObservationsGroup")
				id.vars<-c(id.vars,"ObservationsGroup")
				cast.eq<-paste(cast.eq,"ObservationsGroup",sep="+")
				by.list<-c(by.list,"ObservationsGroup")
				field.sort.order<-c(field.sort.order,obs.group)
			}
			support.effort<-unique(EffortData(object)[,support.site.fields])
			if(guild==""){	#treat data as independent species, do not group
				id.vars<-c(id.vars,"ScientificName")
				cast.eq<-paste(cast.eq,"+ScientificName~ObservationCount",sep="")
				support.species<-unique(ObsData(object)[,c("ScientificName","CommonName","SpeciesCode")])
				field.sort.order<-c(field.sort.order,"ScientificName")
				by.list<-c(by.list,"ScientificName")
				guild.t<-"Species";guild.n<-"ScientificName"
			}else{
				id.vars<-c(id.vars,"TaxonGroup")
				cast.eq<-paste(cast.eq,"+TaxonGroup~ObservationCount",sep="")
				support.species<-unique(ObsData(object)[,c("TaxonGroup")])
				field.sort.order<-c(field.sort.order,guild)
				by.list<-c(by.list,"TaxonGroup")
				guild.t<-guild;guild.n<-guild
			}
			support.effort<-merge(support.effort,support.species)
			#Now melt and cast to get the set of base observations
			melt.data <- melt(ObsData(object),id.vars,measure.vars="ObservationCount",variable_name="ObservationCount")
			base.table <- data.frame(cast(melt.data,cast.eq,fun.aggregate="sum"))
			base.data<-merge(support.effort,base.table, all.x=TRUE)
			full.N<-nrow(base.data)	#total number of observations
			base.data$ObservationCount<-ifelse(is.na(base.data$ObservationCount)==TRUE,0,base.data$ObservationCount)
			na.obs.count<-sum(base.data$ObservationCount==0)
			## Should now estimate counts per desired unit effort
			expval<-10^type.convert(units)
			base.data$BirdsPerNetHour<-expval*(base.data$ObservationCount/base.data$NetHours)
			## Data are now "grouped by" each sampling event (Station and JulianDate) and species/guild and observations group (if applicable)
			
			##Now summarize by time.var and Station (most atomic)
			support.site.fields<-support.site.fields[!(support.site.fields) %in% c("JulianDay","NetHours")]
			bird.abund<-calcCompress(by.list=by.list,comp.field="BirdsPerNetHour",calc.fun=c("mean","var","NROW"),
					data.table=base.data,support.site.fields=support.site.fields,effort.base=support.effort,new.name="Abund")
			
			##Then summarize by summarize.by if not Station
			if(summarize.by!="StationName"){
				support.site.fields<-support.site.fields[!(support.site.fields) %in% c("StationName")]
				by.list<-by.list[!(by.list) %in% c("StationName")]
				bird.abund<-calcCompress(by.list=by.list,comp.field="meanAbund",calc.fun=c("mean","var","NROW"),
						data.table=base.data,support.site.fields=support.site.fields,effort.base=support.effort,new.name="Abund")
			}
			##Can do no more...
			bird.abund$StandardError<-sqrt(bird.abund$varAbund/bird.abund$SampleSize)
			names(bird.abund)[names(bird.abund)=="meanAbund"]<-"Abundance"
			names(bird.abund)[names(bird.abund)=="varAbund"]<-"Variance"
			if(guild!="")names(bird.abund)[names(bird.abund)=="TaxonGroup"]<-guild	
			names(bird.abund)[names(bird.abund)=="SpatialGroup"]<-sb.name	
			if(obs.group!="")names(bird.abund)[names(bird.abund)=="ObservationsGroupGroup"]<-obs.group
			
			## Prepare results for RavianResultsAnalysisTable object
			#sorting and arranging fields in order...
			field.order<-c(field.sort.order,"Abundance","Variance","StandardError","SampleSize")
			bird.abund<-bird.abund[,c(field.order,names(bird.abund)[!names(bird.abund) %in% field.order])]
			
			bird.abund<-bird.abund[order(bird.abund[,guild.n],bird.abund[,time.var],bird.abund[,summarize.by]),]	#bird.abund[,"ProjectName"],
			
			res.table<-bird.abund[,c(field.sort.order,"Abundance","Variance","StandardError","SampleSize")]
			units.val="(birds per net/hour)"
			if (expval!=0) units.val<-paste("(birds/",expval, "Net-Hours)",sep="")
			
			table.title<-paste("Station-level Estimates of Abundance ",units.val," from Banding Data Summarized by", guild.t, sep="")
			if(summarize.by!="StationName") table.title<-paste(table.title,"and",sb.name,sep="")
			if(obs.group!="") table.title<-paste(table.title,"and",obs.group)
			
			support <- bird.abund[,!(names(bird.abund) %in% c("Abundance","Variance","StandardError","SampleSize"))]
			if(!is.null(support.species))support <- merge(support,support.species,all.x=TRUE)
			table.notes<-paste("Total records retrieved:",full.N)
			if(na.obs.count>0) table.notes<-paste(table.notes,". Number of sampling events with 0 captures: ",na.obs.count,sep="")
			#CAreful... here should use summarize.by rather than StationName for g.var
			plot.params<-list()
			plot.params$y.var<-"Abundance"
			plot.params$y.label<-"Abundance"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year","Month")
			plot.params$g.var<-c(sb.name)
			plot.params$g.label<-c(sb.name)
			if(guild==""){
				plot.params$g.var<-c(sb.name,"ScientificName")
				plot.params$g.label<-c(sb.name,"Species")
			}else{
				plot.params$g.var<-c(sb.name,guild)
				plot.params$g.label<-c(sb.name,guild)
			}
						
			## now we have to create the results object
			res<-new("RavianSampleSummaryTable")
				ResultsTable(res)<- res.table
				SupportData(res)<- support
				Process(res)<- "Abundance"
				TableTitle(res)<-table.title
				Notes(res)<-table.notes
				ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,
						guild=guild,spatial.units=spatial.units,obs.group=obs.group)
				PlotParameters(res)<-plot.params
				DataStoreData(res)<-DataDefn(object)
				SupportData(res)<-support
				Call(res)<- ea.call
			return(res)
		}
)


#' Estimate Simple Species Richness from BandData object
#' 
#' @param object A BandData object.
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces) 
#' @param obs.group String naming the observation groups the data must be divided into - e.g., HabitatType, or Sex (must not have blank spaces). 
setMethod("estimateRichness", signature(object = "BandData"),
		function(object, summarize.by="StationName", time.var="YearCollected", 
				spatial.units="", obs.group="",...) {
			##Note to Leo: the variable guild, in estimation of richness, plays only a cosmetic value
			##That is, it is to be used for the title of the resulting table, as it affects nothing else
			ea.call<-match.call()
			if (is.null(object)) {stop("A data object is required.")}
			sb.name<-ifelse(spatial.units!="",spatial.units,"StationName")
			support.site.fields<-c("ProtocolCode",time.var,"JulianDay",summarize.by,"StationCode")		#"ProjectCode","ProjectName",
			by.list<-c("ProtocolCode",time.var,summarize.by,"JulianDay")	#"ProjectName","ProjectCode",
			base.fields.list<-c(support.site.fields,"ScientificName")
			if(obs.group!=""){
				by.list<-c(by.list,"ObservationsGroup")
				base.fields.list<-c(base.fields.list,"ObservationsGroup")
			}
			
			support.effort<-unique(EffortData(object)[,support.site.fields])
			total.E<-NROW(support.effort)
			data.temp<-unique(ObsData(object)[,names(ObsData(object)) %in% base.fields.list])
			total.N<-nrow(data.temp)
			#remove noObs records from Obs data... (needed for data from warehouse)
			data.temp<-subset(data.temp,!is.na(ScientificName))
			total.S<-NROW(unique(ObsData(object)$ScientificName))
			#First compression: to summarize.by and banding event (== visit)
			full.data<-calcCompress(by.list=by.list,comp.field="ScientificName",calc.fun="NROW",data.table=data.temp,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="SampleSize")
			full.data$SpeciesCount<-full.data$SampleSize
			#any events with no observation will have SampleSize=0, soo
			total.NoObs=sum(full.data$SpeciesCount==0)
			
			##Second compression: to summarize.by and time.var (i.e., combining visits data). 
			support.site.fields<-support.site.fields[!(support.site.fields) %in% c("JulianDay")]
			by.list<-by.list[!(by.list) %in% c("JulianDay")]
			bird.rich<-calcCompress(by.list=by.list,comp.field="SpeciesCount",calc.fun=c("mean","var","NROW"),data.table=full.data,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="Rich")
			
			##If an obs.group was submitted, data will be, at this point, summarized by obs.group and summarize.by
			##Can go no further
			
			bird.rich$StandardError<-sqrt(bird.rich$varRich/bird.rich$SampleSize)
			names(bird.rich)[names(bird.rich)=="meanRich"]<-"Richness"
			names(bird.rich)[names(bird.rich)=="varRich"]<-"Variance"
			
			#Now sort and arrange fields and prepare to populate object...
			bird.richness<-bird.rich[order(bird.rich[,"ProtocolCode"],bird.rich[,time.var],bird.rich[,summarize.by]),]	#bird.rich[,"ProjectName"],
			field.order<-c("ProtocolCode",summarize.by,time.var,"Richness","Variance","StandardError","SampleSize")	#"ProjectName","ProjectCode",
			res.table.fields<-c(time.var,sb.name,"Richness","Variance","StandardError","SampleSize")	#"ProjectCode",
			and.ttl<-""
			if(obs.group!=""){
				field.order<-c("ProtocolCode","ObservationsGroup",summarize.by,time.var,"Richness","Variance","StandardError","SampleSize")		#"ProjectName","ProjectCode",
				res.table.fields<-c(obs.group,time.var,sb.name,"Richness","Variance","StandardError","SampleSize")	#"ProjectCode",
				and.ttl<-paste(" and",obs.group)
			}
			bird.richness<-bird.richness[,c(field.order,names(bird.richness)[!names(bird.richness) %in% field.order])]
			names(bird.richness)[names(bird.richness)==summarize.by]<-sb.name	
			if(obs.group!="")names(bird.richness)[names(bird.richness)=="ObservationsGroup"]<-obs.group
			res.table<-bird.richness[,c(res.table.fields)]
			support<-bird.richness[,!(names(bird.richness) %in% c("Richness","Variance","StandardError","SampleSize"))]
			table.title<-paste("Estimates of Mean Species Richness from Banding Data Summarized by ",sb.name,and.ttl,sep="")
						
			table.notes<-paste("Total number of sampling events: ",total.E,". Total number of species: ",total.S,
					". Total number of observations: ",total.N,". Total number of sampling events with 0 species: ",total.NoObs,sep="")
			plot.params<-list()
			plot.params$y.var<-"Richness"
			plot.params$y.label <- "Richness (Species per Station)"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year","Month")
			plot.params$g.var<-sb.name
			plot.params$g.label<-sb.name
			if(obs.group!="") {
				plot.params$g.var<-c(sb.name,obs.group)
				plot.params$g.label<-c(sb.name,obs.group)
			}
			
			#Finally, populate the RavianResults object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.table
			SupportData(res)<- support
			Process(res)<- "Richness"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,spatial.units=spatial.units,obs.group=obs.group)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			Call(res)<- ea.call
			return(res)
		}
)