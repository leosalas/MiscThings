#' @include RavianUtils.R
#' @include QueryList.R


###############################################################################
# DataStore.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org
# Creation Date: May 30, 2009
###############################################################################


#' DataStore Class
#' 
#' Data Store Class
#' @param DataStructure character string that defines the type of database the data will be retrieved from.
#' @param ConnectionType character string the defines the type of connection that will be used to
#' 		communicate with the database.
#' @param DSN character string that contains a properly formatted DSN string.
#' @param TableName character string that informs the object which table will need to be queried to retrieve the data
#' @param Query A QueryList object that defines all components of the query.
#' @exportClass DataStore
setClass("DataStore", 
		representation (
				DataStructure = "character",
				ConnectionType = "character",
				DSN = "character",
				TableName = "character",
				Query = "QueryList"
		)
)

#' Set generic to Retrieve value of DataStructure slot of DataStore object
#' 
#' @param object A DataStore object
setGeneric("DataStructure",
		function(object) standardGeneric("DataStructure"))

#' Retrieve value of DataStructure slot of DataStore object
#' 
#' @param object A DataStore object
setMethod("DataStructure",signature(object="DataStore"),
		function(object) slot(object,"DataStructure"))

#' Set generic to Set DataStructure slot of DataStore object
#' 
#' @name setDataStructure
#' @param object A DataStore object
#' @param value character string to insert into slot
setGeneric("DataStructure<-",
		function(object,value) standardGeneric("DataStructure<-"))

#' Set DataStructure slot of DataStore object
#' 
#' @name setDataStructure
#' @param object A DataStore object
#' @param value character string to insert into slot
setReplaceMethod("DataStructure",
		signature(object="DataStore"),
		function(object,value) {
			slot(object,"DataStructure")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of ConnectionType slot of DataStore object
#' 
#' @param object A DataStore object
setGeneric("ConnectionType",
		function(object) standardGeneric("ConnectionType"))

#' Retrieve value of ConnectionType slot of DataStore object
#' 
#' @param object A DataStore object
setMethod("ConnectionType",signature(object="DataStore"),
		function(object) slot(object,"ConnectionType"))

#' Set generic to Set ConnectionType slot of DataStore object
#' 
#' @name setConnectionType
#' @param object A DataStore object
#' @param value character string to insert into slot
setGeneric("ConnectionType<-",
		function(object,value) standardGeneric("ConnectionType<-"))

#' Set ConnectionType slot of DataStore object
#' 
#' @name setConnectionType
#' @param object A DataStore object
#' @param value character string to insert into slot
setReplaceMethod("ConnectionType",
		signature(object="DataStore"),
		function(object,value) {
			slot(object,"ConnectionType")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of DSN slot of DataStore object
#' 
#' @param object A DataStore object
setGeneric("DSN",
		function(object) standardGeneric("DSN"))

#' Retrieve value of DSN slot of DataStore object
#' 
#' @param object A DataStore object
setMethod("DSN",signature(object="DataStore"),
		function(object) slot(object,"DSN"))

#' Set generic to Set DSN slot of DataStore object
#' 
#' @name setDSN
#' @param object A DataStore object
#' @param value character string to insert into slot
setGeneric("DSN<-",
		function(object,value) standardGeneric("DSN<-"))

#' Set DSN slot of DataStore object
#' 
#' @name setDSN
#' @param object A DataStore object
#' @param value character string to insert into slot
setReplaceMethod("DSN",
		signature(object="DataStore"),
		function(object,value) {
			slot(object,"DSN")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of TableName slot of DataStore object
#' 
#' @param object A DataStore object
setGeneric("TableName",
		function(object) standardGeneric("TableName"))

#' Retrieve value of TableName slot of DataStore object
#' 
#' @param object A DataStore object
setMethod("TableName",signature(object="DataStore"),
		function(object) slot(object,"TableName"))

#' Set generic to Set TableName slot of DataStore object
#' 
#' @name setTableName
#' @param object A DataStore object
#' @param value character string to insert into slot
setGeneric("TableName<-",
		function(object,value) standardGeneric("TableName<-"))

#' Set TableName slot of DataStore object
#' 
#' @name setTableName
#' @param object A DataStore object
#' @param value character string to insert into slot
setReplaceMethod("TableName",
		signature(object="DataStore"),
		function(object,value) {
			slot(object,"TableName")<-value
			validObject(object)
			object
		})


#' Set generic to Retrieve value of Query slot of DataStore object
#' 
#' @param object A DataStore object
setGeneric("Query",
		function(object) standardGeneric("Query"))

#' Retrieve value of Query slot of DataStore object
#' 
#' @param object A DataStore object
setMethod("Query",signature(object="DataStore"),
		function(object) slot(object,"Query"))

#' Set generic to Set Query slot of DataStore object
#' 
#' @name setQuery
#' @param object A DataStore object
#' @param value A QueryList object to insert into slot
setGeneric("Query<-",
		function(object,value) standardGeneric("Query<-"))

#' Set Query slot of DataStore object
#' 
#' @name setQuery
#' @param object A DataStore object
#' @param value A QueryList object to insert into slot
setReplaceMethod("Query",
		signature(object="DataStore"),
		function(object,value) {
			slot(object,"Query")<-value
			validObject(object)
			object
		})

#' Instantiate a new DataStore object
#' @return The DataStore object
setMethod("initialize",
		signature(.Object = "DataStore"),
		function (.Object, ...) 
		{
			.Object@DataStructure <- ""
			.Object@ConnectionType <-  ""
			.Object@DSN <-  ""
			.Object@TableName <- ""
			.Object@Query <- new("QueryList")
			.Object
		}
)


#' Set generic to Retrieve data from DataStore object with specific FilterList.
#' 
#' This method harvests data using the parameters in the DataStore object
#' and returns the dataset as a data.frame object and the query statement used
#' Reading from a data warehouse, or directly from a .dbf or .csv file are supported
#' @param data.store A DataStore object
setGeneric("getDataRavian", 
		function(data.store) standardGeneric("getDataRavian"))

#' Retrieve data from DataStore object with specific FilterList.
#' 
#' This method harvests data using the parameters in the DataStore object
#' and returns the dataset as a data.frame object and the query statement used
#' Reading from a data warehouse, or directly from a .dbf or .csv file are supported
#' Reading from .dbf or .csv is temporarily disbaled, as it requires R_2.10
#' @param data.store A DataStore object
setMethod("getDataRavian",
		signature(data.store = "DataStore"),
		function (data.store) {
			query.sql<-try(as.character(buildQuery(Query(data.store))), silent=TRUE)
			if(inherits(query.sql,"try-error")){
				return(query.sql)
			}else{
				if (ConnectionType(data.store)=="ODBC") {
					conn<-try(connectDatabase(dsn=DSN(data.store)),silent=TRUE)
					if(inherits(conn,"try-error")){
						return(conn)
					}else{
						result.data<-try(sqlQuery(conn, query.sql), silent=TRUE)
						closeDatabase(conn)
						if(inherits(result.data,"try-error")) {
							return(result.data)
						}
						bbb<-paste(result.data,collapse="")
						if(grepl("ERROR:",bbb)){
							sql.err<-bbb
							class(sql.err)<-"try-error"
							return(sql.err)
						}
					}
				}else{
					sql.err<-"Not an ODBC connection, so cannot connect. Reading of .dbf and .csv files temporarily disabled."
					class(sql.err)<-"try-error"
					return(sql.err)
				}
#				else{
#					strtsql<-regexpr(" WHERE ", query.sql)
#					ddd<-data.frame()
#					if (ConnectionType(data.store)=="csv") {
#						ddd<-read.csv(TableName(data.store),header=TRUE)
#						data.table<-paste("select * from ddd",substring(query.sql,strtsql,nchar(query.sql)),sep="")
#						result.data<-sqldf(data.table)
#					}else if(ConnectionType(data.store)=="dbf"){
#						ddd<-read.csv(TableName(data.store),header=TRUE)
#						data.table<-paste("select * from ddd",substring(query.sql,strtsql,nchar(query.sql)),sep="")
#						result.data<-sqldf(data.table)
#					}else{
						#Placeholder
#					}
#				}
			}			
			
			results<-list(result.data=result.data, query.sql=query.sql)
			return(results)
		}
)