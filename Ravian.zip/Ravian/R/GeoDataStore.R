#' @include RavianUtils.R
#' @include QueryList.R

###############################################################################
# GeoDataStore.R
# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Creation Date: April 6, 2012
###############################################################################


#' GeoDataStore Class
#' 
#' Geographic Data Store Class
#' @param DataStructure Character string that defines the type of database the data will be retrieved from.
#' @param ConnectionType Character string that defines the type of connection that will be used to
#' 		communicate with the database.
#' @param ConnectionParameters List of parameters to generate a connection to a geo-database; paired values "name"="value", typically "dsn"="name of dsn".
#' @param LinkParameterValues A character array with unique values of entries in the GoeDataObsDataLink field
#' @param Query List of character arrays. Each list element is a 2-element character array: a prefix query and a suffix query so that
#' 		Ravian will loop through each list element and construct a query for each element of the LinkParameterValues array with it
#' @exportClass GeoDataStore
setClass("GeoDataStore", 
		representation (
				DataStructure = "character",
				ConnectionType = "character",
				ConnectionParameters = "list",
				LinkParameterValues = "character",
				Query = "list"
		),prototype=prototype(
				DataStructure="PostgreSQL",
				ConnectionType="DBI"
		)
)

##Below, some generics set by DataSore.R

#' Retrieve value of DataStructure slot of GeoDataStore object
#' 
#' @param object A GeoDataStore object
setMethod("DataStructure",signature(object="GeoDataStore"),
		function(object) slot(object,"DataStructure"))

#' Set DataStructure slot of GeoDataStore object
#' 
#' @name setDataStructure
#' @param object A GeoDataStore object
#' @param value character string to insert into slot
setReplaceMethod("DataStructure",
		signature(object="GeoDataStore"),
		function(object,value) {
			slot(object,"DataStructure")<-value
			validObject(object)
			object
		})

#' Retrieve value of ConnectionType slot of GeoDataStore object
#' 
#' @param object A GeoDataStore object
setMethod("ConnectionType",signature(object="GeoDataStore"),
		function(object) slot(object,"ConnectionType"))

#' Set ConnectionType slot of GeoDataStore object
#' 
#' @name setConnectionType
#' @param object A GeoDataStore object
#' @param value character string to insert into slot
setReplaceMethod("ConnectionType",
		signature(object="GeoDataStore"),
		function(object,value) {
			slot(object,"ConnectionType")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of the ConnectionParameters slot of GeoDataStore object
#' 
#' @param object A GeoDataStore object
setGeneric("ConnectionParameters",
		function(object) standardGeneric("ConnectionParameters"))

#' Retrieve value of ConnectionParameters slot of GeoDataStore object
#' 
#' @param object A GeoDataStore object
setMethod("ConnectionParameters",signature(object="GeoDataStore"),
		function(object) slot(object,"ConnectionParameters"))

#' Set generic to Set ConnectionParameters slot of GeoDataStore object
#' 
#' @name setConnectionParameters
#' @param object A GeoDataStore object
#' @param value List to insert into slot
setGeneric("ConnectionParameters<-",
		function(object,value) standardGeneric("ConnectionParameters<-"))

#' Set ConnectionParameters slot of GeoDataStore object
#' 
#' @name setConnectionParameters
#' @param object A GeoDataStore object
#' @param value List to insert into slot
setReplaceMethod("ConnectionParameters",
		signature(object="GeoDataStore"),
		function(object,value) {
			slot(object,"ConnectionParameters")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of LinkParameterValues slot of GeoDataStore object
#' 
#' @param object A GeoDataStore object
setGeneric("LinkParameterValues",
		function(object) standardGeneric("LinkParameterValues"))

#' Retrieve value of LinkParameterValues slot of GeoDataStore object
#' 
#' @param object A GeoDataStore object
setMethod("LinkParameterValues",signature(object="GeoDataStore"),
		function(object) slot(object,"LinkParameterValues"))

#' Set generic to set LinkParameterValues slot of GeoDataStore object
#' 
#' @name setLinkParameterValues
#' @param object A GeoDataStore object
#' @param value character array to insert into slot
setGeneric("LinkParameterValues<-",
		function(object,value) standardGeneric("LinkParameterValues<-"))

#' Set LinkParameterValues slot of GeoDataStore object
#' 
#' @name setLinkParameterValues
#' @param object A GeoDataStore object
#' @param value character array to insert into slot
setReplaceMethod("LinkParameterValues",
		signature(object="GeoDataStore"),
		function(object,value) {
			slot(object,"LinkParameterValues")<-value
			validObject(object)
			object
		})

#' Retrieve value of Query slot of GeoDataStore object
#' 
#' @param object A GeoDataStore object
setMethod("Query",signature(object="GeoDataStore"),
		function(object) slot(object,"Query"))


#' Set Query slot of GeoDataStore object
#' 
#' @name setQuery
#' @param object A GeoDataStore object
#' @param value A list object to insert into slot
setReplaceMethod("Query",
		signature(object="GeoDataStore"),
		function(object,value) {
			slot(object,"Query")<-value
			validObject(object)
			object
		})

#' Instantiate a new GeoDataStore object
#' @return The GeoDataStore object
setMethod("initialize",
		signature(.Object = "GeoDataStore"),
		function (.Object, ...) 
		{
			.Object@DataStructure <- ""
			.Object@ConnectionType <-  ""
			.Object@ConnectionParameters <-  list()
			.Object@LinkParameterValues <- ""
			.Object@Query <- list()
			.Object
		}
)

#' Set generic to Retrieve data from GeoDataStore object.
#' 
#' This method harvests data using the parameters in the GeoDataStore object
#' and returns the dataset as a data.frame object
#' @param geo.data.store A GeoDataStore object
setGeneric("getGeoDataRavian", 
		function(geo.data.store, ...) standardGeneric("getGeoDataRavian"))

#' Retrieve data from GeoDataStore object.
#' 
#' This method harvests data using the parameters in the GeoDataStore object
#' and returns the dataset as a data.frame object
#' @param geo.data.store A GeoDataStore object
setMethod("getGeoDataRavian",
		signature(geo.data.store = "GeoDataStore"),
		function (geo.data.store, aqp="") {
			
			ds<-DataStructure(geo.data.store)
			ct<-ConnectionType(geo.data.store)
			if(ds=="PostgreSQL" & ct=="DBI"){
				drv.v<-"PostgreSQL"
				host.v<-ConnectionParameters(geo.data.store)[["host"]]
				dbname.v<-ConnectionParameters(geo.data.store)[["dbname"]]
				port.v<-ConnectionParameters(geo.data.store)[["port"]]
				user.v<-ConnectionParameters(geo.data.store)[["user"]]
				#passw.v<-ConnectionParameters(geo.data.store)[["passw"]]
				lpv<-LinkParameterValues(geo.data.store)
				qlv<-Query(geo.data.store)
				
				#create connection
				drv <- dbDriver(drv.v)
				con <- dbConnect(drv,host=host.v,dbname=dbname.v,port=port.v,user=user.v)
				#loop query
				res.df<-data.frame()
				for(qqq in 1:length(qlv)){
					pref.q<-qlv[[qqq]][1]
					midd.q<-qlv[[qqq]][2]
					suff.q<-qlv[[qqq]][3]
					q.df<-data.frame()
					for(ppp in 1:length(lpv)){
						for(vvv in 1:length(aqp)){
							qsql<-paste(pref.q,lpv[ppp],midd.q,aqp[vvv],suff.q,sep='')
							rs <- dbSendQuery(con, statement = qsql)
							rdf<-fetch(rs, n= -1)
							if(NROW(rdf)>0){
								rdf$linkpar<-lpv[ppp]
								rdf$addparvalue<-aqp[vvv]
								if(NROW(q.df)==0){
									q.df<-rdf
								}else{
									q.df<-rbind(q.df,rdf)  
								}
							} #else fail gracefully
						}
					}
					if(NROW(res.df)==0){
						res.df<-q.df
					}else{	#assuming each query retrieves a different set of data...
						res.df<-merge(res.df,q.df,by=c("linkpar"))
					}
				}	#if queries returned no data, sending back empty df
				dbDisconnect(con)
				return(res.df)
			}else{
				err.msg<-"Ravian Message: data structure or connection type not supported"
				class(err.msg)<-"try-error"
				return(err.msg)
			}
			
		}
)
