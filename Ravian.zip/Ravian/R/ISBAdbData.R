#' @include RavianUtils.R
#' @include AvianData.R
#' @include RavianSampleSummaryTable.R


###############################################################################
# AreaSearchData.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org
# Creation Date: May 30, 2009
###############################################################################

#' ISBAdbData class - subclass of AvianData Class
#' 
#' ISBAdbData class - subclass of AvianData Class
#' @param ObsData dataframe that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType always "AreaSearch"
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @exportClass ISBAdbData
setClass("ISBAdbData", contains=c("AvianData"),
		prototype=prototype(ProtocolType="AreaSearch",
				Fields = list(obs=c("ProjectCode", "ProjectName", "LocalityID","SamplingUnitId","StudyArea", 
								"Plot", "PlotName", "ProtocolCode",	"YearCollected", "MonthCollected", 
								"DayCollected", "JulianDay", "Visit", "Salinity", "Temperature", "DepthMin", 
								"BehaviorCd", "CoverCd", "OxygenMgl", "HabitatCd", "phLevel","TideLevel", 
								"ScientificName", "CommonName", "SpeciesCode", "PhylogenOrder", "FlyOver", "ObservationCount"),
						event=c("ProjectCode", "ProjectName", "LocalityID", "SamplingUnitId", "StudyArea", 
								"Plot", "PlotName", "ProtocolCode","YearCollected", "MonthCollected", 
								"DayCollected", "JulianDay", "Visit", "AreaSurveyed", "SurveyDuration",
								"TideLevel")
				)))

#' Instantiate a new ISBAdbData object
#' @return The ISBAdbData object
setMethod("initialize",
		signature(.Object = "ISBAdbData"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)

###########################################
# So here's how this is going to change
# we need a method to estimate total counts (sum) "estimateTotals"
# by Plot or SpatialGroup, Year, Month, day, tide, visit and Species or Guild, as well as number of ponds in the estimate (1 if Plot, n if SpatialGroup)
# must include all sampling events and put 0's where they belong
# then we make it wide format (a column per taxon or guild) and add other covariates.
# then remove DayCollected and time surveyed and return

#' Set generic to  method that estimates Total Counts from ISBAdbData object
#' 
#' @name estimateTotals
#' @param object An ISBAdbData object.  
setGeneric("estimateTotals",
		function(object,  ...) standardGeneric("estimateTotals"))

#' Estimate Total Counts from ISBAdbData object
#' 
#' @param object An ISBAdbData object
#' @param summarize.by String that denotes the field to summarize the data by: either PlotName or SpatialGroup
#' @param guild String naming the taxon to aggregate by: either SpeciesCode or Guild
setMethod("estimateTotals", signature(object = "ISBAdbData"),  
		function(object, summarize.by="PlotName", guild="CommonName",...) {
			ea.call<-match.call()
			lnk<-c(summarize.by, "ProjectCode", "ProjectName", "ProtocolCode","YearCollected", "MonthCollected", "DayCollected", "TideLevel") 
			 #"JulianDay","SamplingUnitId", "LocalityID", "StudyArea", "Plot", "PlotName",
			ref<-EffortData(object)
			# BUT... if summarize.by=="SpatialGroup", collapse ref by it and check that the sums of covariates and max of covariates match, else nullify them
			nrf<-names(ref)[which(!names(ref) %in% c(lnk,summarize.by,guild,"SurveyDuration","BehaviorCd","CoverCd","HabitatCd",
									"JulianDay","SamplingUnitId", "LocalityID", "StudyArea", "Plot", "PlotName","Visit"))]
			if(summarize.by=="PlotName"){
				lnk<-c(lnk,"Visit")
			}
			ref.df<-data.frame()
			if(summarize.by=="SpatialGroup"){
				for(rrr in nrf){
					fml<-paste(rrr,"~",paste(lnk,collapse=" + "))
					if(sum(!is.na(ref[,rrr])>0)){
						tmpmean<-aggregate(as.formula(fml),data=ref,FUN=mean)
						if(rrr=="AreaSurveyed")tmpmean<-aggregate(as.formula(fml),data=ref,FUN=sum)
						tmpmean[,rrr]<-round(tmpmean[,rrr],2)
					}else{
						tmpmean<-unique(ref[,lnk])
						tmpmean[,rrr]<-NA
					}
					if(NROW(ref.df)==0){
						ref.df<-tmpmean
					}else{
						ref.df<-merge(ref.df,tmpmean,by=lnk,all=TRUE)
					}
				}
			}else{
				ref.df<-unique(ref[,c(lnk,nrf)])
			}
			
			#need number of ponds surveyed...
			npn.df<-unique(ref[,c(lnk)])
			npn.df$NumPondsSurveyed<-1
			if(summarize.by=="SpatialGroup"){
				ref.npn<-unique(ref[,c(lnk,"PlotName")])
				npnt<-aggregate(as.formula(paste("PlotName ~",paste(lnk,collapse=" + "))),data=ref.npn,FUN=NROW)
				npn.df<-merge(npn.df,npnt,by=lnk,all.x=TRUE)
				npn.df<-npn.df[,c(lnk,"PlotName")]
				names(npn.df)<-c(lnk,"NumPondsSurveyed")
			}
			
			obs<-ObsData(object)
			eff<-unique(ref[,lnk])
			fml<-paste("ObservationCount ~ ",paste(lnk,collapse=" + "),"+ ",guild,sep="") #[which(lnk != "TideLevel")]
			obs<-aggregate(as.formula(fml),data=obs,FUN=sum)
			mrg<-merge(eff,obs,by=lnk,all.x=TRUE) #[which(lnk != "TideLevel")]
			#remove na's
			mrg<-subset(mrg,!is.na(mrg$ObservationCount))
			#aggregate by guild, summarize.by and lnk
			fml<-paste("ObservationCount ~",paste(lnk,collapse=" + "),"+ ",guild,sep="")
			agg<-aggregate(as.formula(fml),data=mrg,FUN=sum)
			#then reshape to wide
			wid<-reshape(agg,v.names="ObservationCount",idvar=c(lnk,summarize.by),timevar=guild,direction="wide")
			#rename
			guildnams<-names(wid)[which(grepl("ObservationCount",names(wid),fixed=T))]
			guildnams<-substr(guildnams,18,nchar(guildnams))
			names(wid)<-c(lnk,guildnams)
			#then merge back with eff and add 0's
			wideff<-merge(eff,wid,by=lnk,all.x=TRUE)
			for(ggg in guildnams){
				wideff[,ggg]<-ifelse(is.na(wideff[,ggg])==TRUE,0,wideff[,ggg])
			}
			#then merge with ref and npn.df
			widref<-merge(wideff,ref.df,by=lnk,all.x=TRUE)
			widrefn<-merge(widref,npn.df,by=lnk,all.x=TRUE)
			widrefn<-widrefn[,which(!names(widrefn) %in% c("JulianDay"))]
			
			#and return
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- widrefn
			SupportData(res)<- ref.df
			Process(res)<- "Totals"
			guildname<-ifelse(guild=="TaxonGroup","guild","species")
			TableTitle(res)<-paste("Total number of counts of birds by",guildname,"in each sampling event")
			Notes(res)<-""
			ProcessParameters(res)<-list(summarize.by=summarize.by,guild=guild)
			PlotParameters(res)<-list()
			DataStoreData(res)<-DataDefn(object)
			Call(res)<- ea.call
			return(res)
		})

##################################################################################

#' Estimate Abundance from ISBAdbData object
#' 
#' @param object An ISBAdbData object
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param guild String giving a general name for the group of taxa, if provided (must not have blank spaces)
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
setMethod("estimateAbundance", signature(object = "ISBAdbData"),  
		function(object, summarize.by="Plot", time.var="YearCollected", guild="", spatial.units="",...) {
			## if we are not summarizing by plot, then we must assume that the sampling unit will be the plot
			## it's possible this need not be the case, but we'll make it that way for now.
			ea.call<-match.call()
			if (is.null(object)) {stop("A data object is required.")}
			sb.name<-ifelse(spatial.units=="","Plot",spatial.units)
			#First thing is to get plot-level estimates
			# The following are the starting set of parameters...
			support.site.fields<-c(time.var,"Visit","Plot")	#"ProjectCode","ProjectName",
			id.vars=c(time.var,"Visit","Plot")
			cast.eq<-paste(time.var,"+Plot+Visit",sep="")
			by.list<-c("Plot",time.var)	#"ProjectName","ProjectCode",
			if(summarize.by!="Plot"){
				support.site.fields<-c(support.site.fields,summarize.by)
				id.vars<-c(id.vars,summarize.by)
				cast.eq<-paste(cast.eq,"+",summarize.by,sep="")
				by.list<-c(by.list,summarize.by)
			}
			support.effort<-unique(EffortData(object)[,support.site.fields])
			if(guild==""){	#treat data as independent species, do not group
				id.vars<-c(id.vars,"ScientificName")
				cast.eq<-paste(cast.eq,"+ScientificName~ObservationCount",sep="")
				support.species<-unique(ObsData(object)[,c("ScientificName","CommonName","PhylogenOrder")])
				field.sort.order<-c(sb.name,time.var,"ScientificName")	#"ProjectName","ProjectCode",
				by.list<-c(by.list,"ScientificName")
				guild.t<-" by Species";guild.n<-"ScientificName"
			}else{
				id.vars<-c(id.vars,"TaxonGroup")
				cast.eq<-paste(cast.eq,"+TaxonGroup~ObservationCount",sep="")
				support.species<-unique(ObsData(object)[,c("TaxonGroup")])
				field.sort.order<-c(sb.name,time.var,guild)		#"ProjectName","ProjectCode",
				by.list<-c(by.list,"TaxonGroup")
				guild.t<-paste(" by",guild);guild.n<-guild
			}

			support.effort<-merge(support.effort,support.species)
			#Now melt and cast to get the set of base observations
			melt.data <- melt(ObsData(object),id.vars,measure.vars="ObservationCount",variable_name="ObservationCount")
			base.table <- data.frame(cast(melt.data,cast.eq,fun.aggregate="sum")) #CAREFUL: this assumes ObsCount=0 when no observations (warehouse only).
			base.data<-merge(support.effort,base.table, all.x=TRUE)
			full.N<-nrow(base.data)	#total number of observations
			base.data$ObservationCount<-ifelse(is.na(base.data$ObservationCount)==TRUE,0,base.data$ObservationCount)
			na.obs.count<-sum(base.data$ObservationCount==0)
			
			#compress to plot (i.e., average to plot)
			support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Visit")]
			bird.abund<-calcCompress(by.list=by.list,comp.field="ObservationCount",calc.fun=c("mean","var","NROW"),
					data.table=base.data,support.site.fields=support.site.fields,effort.base=support.effort,new.name="Abund")
			
			#Now summarizing at summarize.by if it is not Plot
			if(summarize.by!="Plot"){
				support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Plot")]
				by.list<-by.list[!(by.list) %in% c("Plot")]
				bird.abund<-calcCompress(by.list=by.list,comp.field="meanAbund",calc.fun=c("mean","var","NROW"),
						data.table=bird.abund,support.site.fields=support.site.fields,effort.base=support.effort,new.name="Abund")
				#TODO: Here function to calculate F-test for validity of lumping
				#Variance among = 1/(g-1) x SUM[1 to g](gp.mean - gl.mean)^2  | g is number of groups, gp.mean is group mean and gl.mean is mean of means
				#Variance within = SUM[1 to g](1/ni-1) x gp.var | ni is the group's sample size, and gp.var its variance
				#F-test = Var.among/Var.within, with (g-1),(N-g) df | N is the total number of obs.
			}
			#Can do no more...
			bird.abund$StandardError<-sqrt(bird.abund$varAbund/bird.abund$SampleSize)
			names(bird.abund)[names(bird.abund)=="meanAbund"]<-"Abundance"
			names(bird.abund)[names(bird.abund)=="varAbund"]<-"Variance"
			if(guild!="")names(bird.abund)[names(bird.abund)=="TaxonGroup"]<-guild	
			names(bird.abund)[names(bird.abund)=="SpatialGroup"]<-sb.name	
			
			## Prepare bird.abund to be ready for RavianResults object
			field.order<-c(field.sort.order,"Abundance","Variance","StandardError","SampleSize")
			bird.abund<-bird.abund[,c(field.order,names(bird.abund)[!names(bird.abund) %in% field.order])]
			
			bird.abund<-bird.abund[order(bird.abund[,guild.n],bird.abund[,time.var],bird.abund[,sb.name]),]	#bird.abund[,"ProjectName"],
			
			res.table<-bird.abund[,names(bird.abund) %in% field.order]
			y.label <- "Abundance (Birds per Plot)"
			
			## Prepare results for RavianResultsAnalysisTable object 
			table.title<-paste("Plot-level Estimates of Abundance (Birds per Plot) from Area Search Data", guild.t,sep="")
			if(summarize.by!="Plot") table.title<-paste(table.title," Summarized by ",sb.name,sep="")
			
			support <- bird.abund[,!(names(bird.abund) %in% c("Abundance","Density","Variance","StandardError","SampleSize"))]
			if(guild=="")support <- merge(support,support.species,all.x=TRUE)
			table.notes<-paste("Total sampling events:",full.N)
			if(na.obs.count>0) table.notes<-paste(table.notes,". Number of sampling events with 0 observations: ",na.obs.count,sep="")
			
			plot.params<-list()
			plot.params$y.var<-"Abundance"
			plot.params$y.label<-"Abundance (Birds per Plot)"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year","Month")
			plot.params$g.var<-c(sb.name)
			plot.params$g.label<-c(sb.name)
			if(guild=="") {
				plot.params$g.var<-c(sb.name,"ScientificName")
				plot.params$g.label<-c(sb.name,"Species")
			}else{
				plot.params$g.var<-c(sb.name,guild)
				plot.params$g.label<-c(sb.name,guild)
			}
						
			## now we have to create the results object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.table
			SupportData(res)<- support
			Process(res)<- "Abundance"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,
					guild=guild,spatial.units=spatial.units)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			SupportData(res)<-support
			Call(res)<- ea.call
			return(res)
		}
)
#' Estimate Simple Species Richness from ISBAdbData object
#' 
#' @param object An ISBAdbData object.
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
setMethod("estimateRichness", signature(object = "ISBAdbData"),
		function(object, summarize.by="Plot", time.var = "YearCollected", 
				spatial.units="", ...) {
			##Note to Leo: the variable guild, in estimation of richness, plays only a cosmetic value
			##That is, it is to be used for the title of the resulting table, as it affects nothing else
			ea.call<-match.call()
			if (is.null(object)) {stop("A data object is required.")}
			sb.name<-ifelse(spatial.units!="",spatial.units,"Plot")
			#get Plot-level list of species
			# The following are the starting set of parameters...
			support.site.fields<-c(time.var,summarize.by,"Visit")	#"ProjectCode","ProjectName",
			by.list<-c(time.var,summarize.by,"Visit")	#"ProjectName","ProjectCode",
			
			if(summarize.by!="Plot"){
				support.site.fields<-c(time.var,summarize.by,"Plot","Visit")	#"ProjectCode","ProjectName",
				by.list<-c(time.var,summarize.by,"Plot","Visit")	#"ProjectName","ProjectCode",
			}
			
			base.fields.list<-c(support.site.fields,"ScientificName")
			support.effort<-unique(EffortData(object)[,support.site.fields])
			total.E<-NROW(support.effort)
			data.temp<-unique(ObsData(object)[,names(ObsData(object)) %in% base.fields.list])
			total.N<-nrow(data.temp)
			#remove noObs records...
			data.temp<-subset(data.temp,!is.na(ScientificName))
			total.S<-NROW(unique(ObsData(object)$ScientificName))
			full.data<-calcCompress(by.list=by.list,comp.field="ScientificName",calc.fun="NROW",data.table=data.temp,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="SampleSize")
			full.data$SpeciesCount<-full.data$SampleSize
			#We now have a table with number of species per visit to Plot - counting those with 0 species...
			total.O<-sum(full.data$SpeciesCount==0)
			
			##Second compression: to Plot and time.var (i.e., combining visits data). 
			support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Visit")]
			by.list<-by.list[!(by.list) %in% c("Visit")]
			bird.rich<-calcCompress(by.list=by.list,comp.field="SpeciesCount",calc.fun=c("mean","var","NROW"),data.table=full.data,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="Rich")
			
			##Third compression: if summarize.by is not Plot... (so, summarizing by plot and then by summarize.by)
			if(summarize.by!="Plot"){
				support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Plot")]
				by.list<-by.list[!(by.list) %in% c("Plot")]
				bird.rich<-calcCompress(by.list=by.list,comp.field="meanRich",calc.fun=c("mean","var","NROW"),data.table=bird.rich,
						support.site.fields=support.site.fields,effort.base=support.effort,new.name="Rich")
			}
			
			##Extend here if ever wanting to summarize by obs.group
			
			bird.rich$StandardError<-sqrt(bird.rich$varRich/bird.rich$SampleSize)
			names(bird.rich)[names(bird.rich)=="meanRich"]<-"Richness"
			names(bird.rich)[names(bird.rich)=="varRich"]<-"Variance"
			
			#Now sort and arrange fields and prepare to populate object...
			bird.richness<-bird.rich[order(bird.rich[,time.var],bird.rich[,summarize.by]),]		#bird.rich[,"ProjectName"],
			field.order<-c(summarize.by,time.var,"Richness","Variance","StandardError","SampleSize")	#"ProjectName","ProjectCode",
			bird.richness<-bird.richness[,c(field.order,names(bird.richness)[!names(bird.richness) %in% field.order])]
			
			names(bird.richness)[names(bird.richness)==summarize.by]<-sb.name
			
			res.table<-bird.richness[,c(time.var,sb.name,"Richness","Variance","StandardError","SampleSize")]	#"ProjectCode",
			support<-bird.richness[,!(names(bird.richness) %in% c("Richness","Variance","StandardError","SampleSize"))]
			table.title<-paste("Plot-level Estimates of Mean Species Richness from Area Search Data Summarized by ",sb.name,sep="")
			table.notes<-paste("Total number of sampling events: ",total.E,". Total number of species: ",total.S,
					". Total number of observations: ",total.N,". Total number of sampling events with 0 species: ",total.O,sep="")
			plot.params<-list()
			plot.params$y.var<-"Richness"
			plot.params$y.label <- "Richness (Species per Plot)"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year","Month")
			plot.params$g.var<-sb.name
			plot.params$g.label<-sb.name
			
			#Finally, populate the RavianResults object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.table
			SupportData(res)<- support
			Process(res)<- "Richness"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,spatial.units=spatial.units)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			Call(res)<- ea.call
			return(res)
		}
)