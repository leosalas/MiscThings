#' @include AvianData.R


###############################################################################
# NestData.R
# TODO: Add comment
# 
# Author: Mark Herzog
# Contact: mherzog@prbo.org
# Creation Date: May 30, 2009
###############################################################################

#' NestData class - subclass of AvianData Class
#' 
#' NestData class - subclass of AvianData Class
#' @param ObsData dataframe that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType always "Nest"
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @exportClass NestData
setClass("NestData", contains=c("AvianData"),
		prototype=prototype(ProtocolType="Nest"))

#' Instantiate a new NestData object
#' @return The NestData object 
setMethod("initialize",
		signature(.Object = "NestData"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)