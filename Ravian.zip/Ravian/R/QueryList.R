# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Feb 15, 2010
###############################################################################

#' QueryList class
#' 
#' QueryList class
#' @param Select character string used for SELECT portion of SQL query
#' @param Distinct logical field to inform function if DISTINCT should be used in SQL query
#' @param From character string used for FROM portion of SQL query
#' @param Where character string used for WHERE portion of SQL query
#' @param GroupBy character string used for GROUP BY portion of SQL query
#' @param Having character string used for HAVING portion of SQL query
#' @param OrderBy character string used for ORDER BY portion of SQL query
#' @exportClass QueryList
setClass("QueryList", 
		representation (
				Select = "character",
				Distinct = "logical",
				From = "character",
				Where = "character",
				GroupBy = "character",
				Having = "character",
				OrderBy = "character"
		),
		validity=function(object){
			error<-""
			if (is.null(Select(object))==TRUE) error<-"No fields defined in SELECT portion of query."
			if (is.null(From(object))==TRUE) paste(error,"No table defined in FROM portion of query.")
			if (error =="") TRUE
			else
				paste("buildQuery failed due to the following errors:",error)
		}
)

#' Instantiate a new QueryList object
#' @return The QueryList object
#' 
#' @exportMethod  initialize
setMethod("initialize",
		signature(.Object = "QueryList"),
		function (.Object, ...) 
		{
			.Object@Select <- "*"
			.Object@Distinct <- FALSE
			.Object@From <- ""
			.Object@Where <- ""
			.Object@GroupBy <- ""
			.Object@Having <- ""
			.Object@OrderBy <- ""
			.Object
		}
)

#' Set generic to Retrieve value of Select slot of DataStore object
#' 
#' @param object A QueryList object
setGeneric("Select",
		function(object) standardGeneric("Select"))

#' Retrieve value of Select slot of DataStore object
#' 
#' @param object A QueryList object
setMethod("Select",signature(object="QueryList"),
		function(object) slot(object,"Select"))

#' Set generic to Set Select slot within QueryList
#' 
#' @name setSelect
#' @param object A QueryList object
#' @param value character string to insert into Select slot
setGeneric("Select<-",
		function(object,value) standardGeneric("Select<-"))

#' Set Select slot within QueryList
#' 
#' @name setSelect
#' @param object A QueryList object
#' @param value character string to insert into Select slot
setReplaceMethod("Select",
		signature(object="QueryList"),
		function(object,value) {
			slot(object,"Select")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of Distinct slot of QueryList object
#' 
#' @param object A QueryList object
setGeneric("Distinct",
		function(object) standardGeneric("Distinct"))

#' Retrieve value of Distinct slot of QueryList object
#' 
#' @param object A QueryList object
setMethod("Distinct",signature(object="QueryList"),
		function(object) slot(object,"Distinct"))

#' Set generic to Set Distinct slot of QueryList object
#' 
#' @name setDistinct
#' @param object A QueryList object
#' @param value TRUE/FALSE to insert into slot
setGeneric("Distinct<-",
		function(object,value) standardGeneric("Distinct<-"))

#' Set Distinct slot of QueryList object
#' 
#' @name setDistinct
#' @param object A QueryList object
#' @param value TRUE/FALSE to insert into slot
setReplaceMethod("Distinct",
		signature(object="QueryList"),
		function(object,value) {
			slot(object,"Distinct")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of From slot of QueryList object
#' 
#' @param object A QueryList object
setGeneric("From",
		function(object) standardGeneric("From"))

#' Retrieve value of From slot of QueryList object
#' 
#' @param object A QueryList object
setMethod("From",signature(object="QueryList"),
		function(object) slot(object,"From"))

#' Set generic to Set From slot of QueryList object
#' 
#' @name setFrom
#' @param object A QueryList object
#' @param value character string to insert into slot
setGeneric("From<-",
		function(object,value) standardGeneric("From<-"))

#' Set From slot of QueryList object
#' 
#' @name setFrom
#' @param object A QueryList object
#' @param value character string to insert into slot
setReplaceMethod("From",
		signature(object="QueryList"),
		function(object,value) {
			slot(object,"From")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of Where slot of QueryList object
#' 
#' @param object A QueryList object
setGeneric("Where",
		function(object) standardGeneric("Where"))

#' Retrieve value of Where slot of QueryList object
#' 
#' @param object A QueryList object
setMethod("Where",signature(object="QueryList"),
		function(object) slot(object,"Where"))

#' Set generic to Set Where slot of QueryList object
#' 
#' @name setWhere
#' @param object A QueryList object
#' @param value character string to insert into slot
setGeneric("Where<-",
		function(object,value) standardGeneric("Where<-"))

#' Set Where slot of QueryList object
#' 
#' @name setWhere
#' @param object A QueryList object
#' @param value character string to insert into slot
setReplaceMethod("Where",
		signature(object="QueryList"),
		function(object,value) {
			slot(object,"Where")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of GroupBy slot of QueryList object
#' 
#' @param object A QueryList object
setGeneric("GroupBy",
		function(object) standardGeneric("GroupBy"))

#' Retrieve value of GroupBy slot of QueryList object
#' 
#' @param object A QueryList object
setMethod("GroupBy",signature(object="QueryList"),
		function(object) slot(object,"GroupBy"))

#' Set generic to Set GroupBy slot of QueryList object
#' 
#' @name setGroupBy
#' @param object A QueryList object
#' @param value character string to insert into slot
setGeneric("GroupBy<-",
		function(object,value) standardGeneric("GroupBy<-"))

#' Set GroupBy slot of QueryList object
#' 
#' @name setGroupBy
#' @param object A QueryList object
#' @param value character string to insert into slot
setReplaceMethod("GroupBy",
		signature(object="QueryList"),
		function(object,value) {
			slot(object,"GroupBy")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of Having slot of QueryList object
#' 
#' @param object A QueryList object
setGeneric("Having",
		function(object) standardGeneric("Having"))

#' Retrieve value of Having slot of QueryList object
#' 
#' @param object A QueryList object
setMethod("Having",signature(object="QueryList"),
		function(object) slot(object,"Having"))

#' Set generic to Set Having slot of QueryList object
#' 
#' @name setHaving
#' @param object A QueryList object
#' @param value character string to insert into slot
setGeneric("Having<-",
		function(object,value) standardGeneric("Having<-"))

#' Set Having slot of QueryList object
#' 
#' @name setHaving
#' @param object A QueryList object
#' @param value character string to insert into slot
setReplaceMethod("Having",
		signature(object="QueryList"),
		function(object,value) {
			slot(object,"Having")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of OrderBy slot of QueryList object
#' 
#' @param object A QueryList object
setGeneric("OrderBy",
		function(object) standardGeneric("OrderBy"))

#' Retrieve value of OrderBy slot of QueryList object
#' 
#' @param object A QueryList object
setMethod("OrderBy",signature(object="QueryList"),
		function(object) slot(object,"OrderBy"))

#' Set generic to Set OrderBy slot of QueryList object
#' 
#' @name setOrderBy
#' @param object A QueryList object
#' @param value character string to insert into slot
setGeneric("OrderBy<-",
		function(object,value) standardGeneric("OrderBy<-"))

#' Set OrderBy slot of QueryList object
#' 
#' @name setOrderBy
#' @param object A QueryList object
#' @param value character string to insert into slot
setReplaceMethod("OrderBy",
		signature(object="QueryList"),
		function(object,value) {
			slot(object,"OrderBy")<-value
			validObject(object)
			object
		})


#' Set generic to Create a query from a QueryList
#' 
#' This method builds a properly formatted SQL statement from 
#' the contents of a QueryList object
#' @name buildQuery
#' @param object A QueryList object
setGeneric("buildQuery",
		function(object,value) standardGeneric("buildQuery"))


#' Create a query from a QueryList
#' 
#' This method builds a properly formatted SQL statement from 
#' the contents of a QueryList object
#' @param object A QueryList object
setMethod("buildQuery",signature(object = "QueryList"),
		function (object) {
			if (validObject(object)) {
				query<-paste("SELECT",Select(object))
				if (Distinct(object) == TRUE) query<-paste("SELECT DISTINCT", Select(object))
				query<-paste(query,"FROM",From(object))
				if (Where(object) != "") query<-paste(query,"WHERE",Where(object)) 
				if (GroupBy(object) != "") query<-paste(query,"GROUP BY",GroupBy(object))
				if (Having(object) != "") query<-paste(query,"HAVING",Having(object))
				if (OrderBy(object) != "") query<-paste(query,"ORDER BY", OrderBy(object))
			}
			else {
				## I don't think you'd ever get here.  Just in case.
				query<-"Invalid Query"
				## TODO make it a "try-error" class
			}
			return(query)
		}
)			


