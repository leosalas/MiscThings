# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Feb 12, 2010
###############################################################################


#' ggplot class
#' 			
setClass("ggplot") #make the class visible to S4

#' RavianResultsGraph class
#' 
#' RavianResultsGraph class is a general results graph used to store results of plots on the data.
#' 			
#' @param ResultsGraph A ggplot2-type object containing the resulting graph
#' @param PlotTitle The title of the plot
#' @param GraphParameters List of parameters passed to the method that produced the graph
#' @param Notes Any notes (string), such as number of null observations
#' @param Call  this is the call used to perform the analysis (may not be needed).
#' @exportClass RavianResultsGraph
setClass("RavianResultsGraph", 
		representation(
				ResultsGraph = "ggplot", 	 				
				GraphTitle = "character",			
				Notes = "character",			
				GraphParameters = "list",		 		
				Call="call"
		)
)

#' Instantiate a new RavianResultsGraph object
#' @name initialize
#' @return The RavianResultsGraph object 
setMethod("initialize",
		signature(.Object = "RavianResultsGraph"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)

#' Set generic to  method that sets ResultsGraph slot of RavianResultsGraph object
#' 
#' @name setResultsGraph
#' @param object A RavianResultsGraph object
#' @param value ggplot to insert into slot
if (!isGeneric("ResultsGraph<-")) {
	if (is.function("ResultsGraph<-"))
		fun <- ResultsGraph
	else fun <- function(object, value) standardGeneric("ResultsGraph<-")
	
	setGeneric("ResultsGraph<-", fun)
}

#' Set ResultsGraph slot of RavianResultsGraph object
#' 
#' @name setResultsGraph
#' @param object A RavianResultsGraph object
#' @param value ggplot to insert into slot
setReplaceMethod("ResultsGraph",signature(object="RavianResultsGraph"),
		function(object,value) {
			slot(object,"ResultsGraph")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ResultsGraph slot of RavianResultsGraph object
#' 
#' @name ResultsGraph
#' @param object A ggplot object
if (!isGeneric("ResultsGraph")) {
	if (is.function("ResultsGraph"))
		fun <- ResultsGraph
	else fun <- function(object) standardGeneric("ResultsGraph")
	
	setGeneric("ResultsGraph", fun)
}

#' Retrieve ResultsGraph slot of RavianResultsGraph object
#' 
#' @name ResultsGraph
#' @param object A ggplot object
setMethod("ResultsGraph",signature(object="RavianResultsGraph"),
		function(object) slot(object,"ResultsGraph"))

#' Set generic to  method that sets GraphTitle slot of RavianResultsGraph object
#' 
#' @name setGraphTitle
#' @param object A RavianResultsGraph object
#' @param value string to insert into slot
if (!isGeneric("GraphTitle<-")) {
	if (is.function("GraphTitle<-"))
		fun <- GraphTitle
	else fun <- function(object, value) standardGeneric("GraphTitle<-")
	
	setGeneric("GraphTitle<-", fun)
}

#' Set GraphTitle slot of RavianResultsGraph object
#' 
#' @name setGraphTitle
#' @param object A RavianResultsGraph object
#' @param value string to insert into slot
setReplaceMethod("GraphTitle",signature(object="RavianResultsGraph"),
		function(object,value) {
			slot(object,"GraphTitle")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves GraphTitle slot of RavianResultsGraph object
#' 
#' @name GraphTitle
#' @param object A RavianResultsGraph object
if (!isGeneric("GraphTitle")) {
	if (is.function("GraphTitle"))
		fun <- GraphTitle
	else fun <- function(object) standardGeneric("GraphTitle")
	
	setGeneric("GraphTitle", fun)
}

#' Retrieve GraphTitle slot of RavianResultsGraph object
#' 
#' @name GraphTitle
#' @param object A RavianResultsGraph object
setMethod("GraphTitle",signature(object="RavianResultsGraph"),
		function(object) slot(object,"GraphTitle"))

#' Set generic to  method that sets Notes slot of RavianResultsGraph object
#' 
#' @name setNotes
#' @param object A RavianResultsGraph object
#' @param value string to insert into slot
if (!isGeneric("Notes<-")) {
	if (is.function("Notes<-"))
		fun <- Notes
	else fun <- function(object, value) standardGeneric("Notes<-")
	
	setGeneric("Notes<-", fun)
}

#' Set Notes slot of RavianResultsGraph object
#' 
#' @name setNotes
#' @param object A RavianResultsGraph object
#' @param value string to insert into slot
setReplaceMethod("Notes",signature(object="RavianResultsGraph"),
		function(object,value) {
			slot(object,"Notes")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves Notes slot of RavianResultsGraph object
#' 
#' @name Notes
#' @param object A RavianResultsGraph object
if (!isGeneric("Notes")) {
	if (is.function("Notes"))
		fun <- Notes
	else fun <- function(object) standardGeneric("Notes")
	
	setGeneric("Notes", fun)
}

#' Retrieve Notes slot of RavianResultsGraph object
#' 
#' @name Notes
#' @param object A RavianResultsGraph object
setMethod("Notes",signature(object="RavianResultsGraph"),
		function(object) slot(object,"Notes"))

#' Set generic to  method that sets GraphParameters slot of RavianResultsGraph object
#' 
#' @name setGraphParameters
#' @param object A RavianResultsGraph object
#' @param value list object to insert into slot
if (!isGeneric("GraphParameters<-")) {
	if (is.function("GraphParameters<-"))
		fun <- GraphParameters
	else fun <- function(object, value) standardGeneric("GraphParameters<-")
	
	setGeneric("GraphParameters<-", fun)
}

#' Set GraphParameters slot of RavianResultsGraph object
#' 
#' @name setGraphParameters
#' @param object A RavianResultsGraph object
#' @param value list object to insert into slot
setReplaceMethod("GraphParameters",signature(object="RavianResultsGraph"),
		function(object,value) {
			slot(object,"GraphParameters")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves GraphParameters slot of RavianResultsGraph object
#' 
#' @name GraphParameters
#' @param object A RavianResultsGraph object
if (!isGeneric("GraphParameters")) {
	if (is.function("GraphParameters"))
		fun <- GraphParameters
	else fun <- function(object) standardGeneric("GraphParameters")
	
	setGeneric("GraphParameters", fun)
}

#' Retrieve GraphParameters slot of RavianResultsGraph object
#' 
#' @name GraphParameters
#' @param object A RavianResultsGraph object
setMethod("GraphParameters",signature(object="RavianResultsGraph"),
		function(object) slot(object,"GraphParameters"))

#' Set generic to  method that sets Call slot of RavianResultsGraph object
#' 
#' @name setCall
#' @param object A RavianResultsGraph object
#' @param value a call object to insert into slot
if (!isGeneric("Call<-")) {
	if (is.function("Call<-"))
		fun <- Call
	else fun <- function(object, value) standardGeneric("Call<-")
	
	setGeneric("Call<-", fun)
}

#' Set Call slot of RavianResultsGraph object
#' 
#' @name setCall
#' @param object A RavianResultsGraph object
#' @param value a call object to insert into slot
setReplaceMethod("Call",signature(object="RavianResultsGraph"),
		function(object,value) {
			slot(object,"Call")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves Call slot of RavianResultsGraph object
#' 
#' @name Call
#' @param object A RavianResultsGraph object
if (!isGeneric("Call")) {
	if (is.function("Call"))
		fun <- Call
	else fun <- function(object) standardGeneric("Call")
	
	setGeneric("Call", fun)
}

#' Retrieve Call slot of RavianResultsGraph object
#' 
#' @name Call
#' @param object A RavianResultsGraph object
setMethod("Call",signature(object="RavianResultsGraph"),
		function(object) slot(object,"Call"))


