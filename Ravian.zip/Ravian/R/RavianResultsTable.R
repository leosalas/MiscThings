# Results.R
# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Creation Date: May 30, 2009
###############################################################################

#' RavianResultsTable class
#' 
#' RavianResultsTable class is a general results table used to store results of statistical analyses on the data, 
#' 			such as results from a linear regression analysis. So, a RavianResultsTable typically holds the the 
#' 			following columns (it varies): ParamaterName, ParameterValue, SE, t-statistic, p-value.
#' 			
#' @param ResultsTable data.frame containing results performed in an analysis
#' @param Process character string that defines the method that generated the table
#' @param TableTitle The title of the resulting table
#' @param Notes Any notes (string), such as number of null observations
#' @param ProcessParameters List of parameters (other than the AvianData object) passed to the method that produced the table
#' @param Call  this is the call used to perform the analysis (may not be needed).
#' @exportClass RavianResultsTable
setClass("RavianResultsTable", 
		representation(
				ResultsTable = "data.frame", 	 	
				Process = "character",			
				TableTitle = "character",			
				Notes = "character",			
				ProcessParameters = "list",		 		
				Call="call"
		)
)

#' Instantiate a new RavianResultsTable object
#' @name initialize
#' @return The RavianResultsTable object
setMethod("initialize",
		signature(.Object = "RavianResultsTable"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)

#' Set generic to  method that sets ResultsTable slot of RavianResultsTable object
#' 
#' @name setResultsTable
#' @method setResultsTable
#' @param object A RavianResultsTable object
#' @param value data.frame to insert into slot
#' @export
if (!isGeneric("ResultsTable<-")) {
	if (is.function("ResultsTable<-"))
		fun <- ResultsTable
	else fun <- function(object, value) standardGeneric("ResultsTable<-")
	
	setGeneric("ResultsTable<-", fun)
}

#' Set ResultsTable slot of RavianResultsTable object
#' 
#' @name setResultsTable
#' @method setResultsTable
#' @param object A RavianResultsTable object
#' @param value data.frame to insert into slot
#' @export
setReplaceMethod("ResultsTable",signature(object="RavianResultsTable"),
		function(object,value) {
			slot(object,"ResultsTable")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ResultsTable slot of RavianResultsTable object
#' 
#' @name ResultsTable
#' @param object A data frame object
if (!isGeneric("ResultsTable")) {
	if (is.function("ResultsTable"))
		fun <- ResultsTable
	else fun <- function(object) standardGeneric("ResultsTable")
	
	setGeneric("ResultsTable", fun)
}

#' Retrieve ResultsTable slot of RavianResultsTable object
#' 
#' @name ResultsTable
#' @param object A data frame object
setMethod("ResultsTable",signature(object="RavianResultsTable"),
		function(object) slot(object,"ResultsTable"))

#' Set generic to  method that sets Process slot of RavianResultsTable object
#' 
#' @name setProcess
#' @param object A RavianResultsTable object
#' @param value character string to insert into slot
if (!isGeneric("Process<-")) {
	if (is.function("Process<-"))
		fun <- Process
	else fun <- function(object, value) standardGeneric("Process<-")
	
	setGeneric("Process<-", fun)
}

#' Set Process slot of RavianResultsTable object
#' 
#' @name setProcess
#' @param object A RavianResultsTable object
#' @param value character string to insert into slot
setReplaceMethod("Process",signature(object="RavianResultsTable"),
		function(object,value) {
			slot(object,"Process")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves Process slot of RavianResultsTable object
#' 
#' @name Process
#' @param object RavianResultsTable object
if (!isGeneric("Process")) {
	if (is.function("Process"))
		fun <- Process
	else fun <- function(object) standardGeneric("Process")
	
	setGeneric("Process", fun)
}

#' Retrieve Process slot of RavianResultsTable object
#' 
#' @name Process
#' @param object RavianResultsTable object
setMethod("Process",signature(object="RavianResultsTable"),
		function(object) slot(object,"Process"))

#' Set generic to  method that sets TableTitle slot of RavianResultsTable object
#' 
#' @name setTableTitle
#' @param object A RavianResultsTable object
#' @param value string to insert into slot
if (!isGeneric("TableTitle<-")) {
	if (is.function("TableTitle<-"))
		fun <- TableTitle
	else fun <- function(object, value) standardGeneric("TableTitle<-")
	
	setGeneric("TableTitle<-", fun)
}

#' Set TableTitle slot of RavianResultsTable object
#' 
#' @name setTableTitle
#' @param object A RavianResultsTable object
#' @param value string to insert into slot
setReplaceMethod("TableTitle",signature(object="RavianResultsTable"),
		function(object,value) {
			slot(object,"TableTitle")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves TableTitle slot of RavianResultsTable object
#' 
#' @name TableTitle
#' @param object A RavianResultsTable object
if (!isGeneric("TableTitle")) {
	if (is.function("TableTitle"))
		fun <- TableTitle
	else fun <- function(object) standardGeneric("TableTitle")
	
	setGeneric("TableTitle", fun)
}

#' Retrieve TableTitle slot of RavianResultsTable object
#' 
#' @name TableTitle
#' @param object A RavianResultsTable object
setMethod("TableTitle",signature(object="RavianResultsTable"),
		function(object) slot(object,"TableTitle"))

#' Set generic to  method that sets Notes slot of RavianResultsTable object
#' 
#' @name setNotes
#' @param object A RavianResultsTable object
#' @param value string to insert into slot
if (!isGeneric("Notes<-")) {
	if (is.function("Notes<-"))
		fun <- Notes
	else fun <- function(object, value) standardGeneric("Notes<-")
	
	setGeneric("Notes<-", fun)
}

#' Set Notes slot of RavianResultsTable object
#' 
#' @name setNotes
#' @param object A RavianResultsTable object
#' @param value string to insert into slot
setReplaceMethod("Notes",signature(object="RavianResultsTable"),
		function(object,value) {
			slot(object,"Notes")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves Notes slot of RavianResultsTable object
#' 
#' @name Notes
#' @param object A RavianResultsTable object
if (!isGeneric("Notes")) {
	if (is.function("Notes"))
		fun <- Notes
	else fun <- function(object) standardGeneric("Notes")
	
	setGeneric("Notes", fun)
}

#' Retrieve Notes slot of RavianResultsTable object
#' 
#' @name Notes
#' @param object A RavianResultsTable object
setMethod("Notes",signature(object="RavianResultsTable"),
		function(object) slot(object,"Notes"))

#' Set generic to  method that sets ProcessParameters slot of RavianResultsTable object
#' 
#' @name setProcessParameters
#' @param object A RavianResultsTable object
#' @param value list object to insert into slot
if (!isGeneric("ProcessParameters<-")) {
	if (is.function("ProcessParameters<-"))
		fun <- ProcessParameters
	else fun <- function(object, value) standardGeneric("ProcessParameters<-")
	
	setGeneric("ProcessParameters<-", fun)
}

#' Set ProcessParameters slot of RavianResultsTable object
#' 
#' @name setProcessParameters
#' @param object A RavianResultsTable object
#' @param value list object to insert into slot
setReplaceMethod("ProcessParameters",signature(object="RavianResultsTable"),
		function(object,value) {
			slot(object,"ProcessParameters")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ProcessParameters slot of RavianResultsTable object
#' 
#' @name ProcessParameters
#' @param object A RavianResultsTable object
if (!isGeneric("ProcessParameters")) {
	if (is.function("ProcessParameters"))
		fun <- ProcessParameters
	else fun <- function(object) standardGeneric("ProcessParameters")
	
	setGeneric("ProcessParameters", fun)
}

#' Retrieve ProcessParameters slot of RavianResultsTable object
#' 
#' @name ProcessParameters
#' @param object A RavianResultsTable object
setMethod("ProcessParameters",signature(object="RavianResultsTable"),
		function(object) slot(object,"ProcessParameters"))

#' Set generic to  method that sets Call slot of RavianResultsTable object
#' 
#' @name setCall
#' @param object A RavianResultsTable object
#' @param value a call object to insert into slot
if (!isGeneric("Call<-")) {
	if (is.function("Call<-"))
		fun <- Call
	else fun <- function(object, value) standardGeneric("Call<-")
	
	setGeneric("Call<-", fun)
}

#' Set Call slot of RavianResultsTable object
#' 
#' @name setCall
#' @param object A RavianResultsTable object
#' @param value a call object to insert into slot
setReplaceMethod("Call",signature(object="RavianResultsTable"),
		function(object,value) {
			slot(object,"Call")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves Call slot of RavianResultsTable object
#' 
#' @name Call
#' @param object A RavianResultsTable object
if (!isGeneric("Call")) {
	if (is.function("Call"))
		fun <- Call
	else fun <- function(object) standardGeneric("Call")
	
	setGeneric("Call", fun)
}

#' Retrieve Call slot of RavianResultsTable object
#' 
#' @name Call
#' @param object A RavianResultsTable object
setMethod("Call",signature(object="RavianResultsTable"),
		function(object) slot(object,"Call"))

###################################################################################
# Methods
###################################################################################

####### as.data.frame for the general RavianResultsTable
#' Set generic to  method that exports a RavianResultsTable Object into a data.frame
#'
#' @name as.data.frame
#' @param x a RavianResultsTable object
if (!isGeneric("as.data.frame")) {
	if (is.function("as.data.frame"))
		fun <- as.data.frame
	else fun <- function(x,row.names,optional, ...) standardGeneric("as.data.frame")
	
	setGeneric("as.data.frame", fun)
}

#' Export a RavianResultsTable Object into a data.frame
#'
#' @param x a RavianResultsTable object
setMethod("as.data.frame",
		signature(x="RavianResultsTable",row.names="missing",optional="missing"),
		function(x, ...) {
			res.df<-ResultsTable(x)
			return(res.df)
		})

#' Set generic to  method that converts BMDE field names to more amenable values in a RavianResultsTable object
#' 
#' @name checkRowColumnNames
#' @param object A RavianResultsTable object
#' @param guild.type A string with the general name of the guilds (e.g., "Foraging guilds")
#' @param su.type A string with the general name of the spatial units (e.g., "Habitat types")
if (!isGeneric("checkRowColumnNames")) {
	if (is.function("checkRowColumnNames"))
		fun <- checkRowColumnNames
	else fun <- function(object, ...) standardGeneric("checkRowColumnNames")
	
	setGeneric("checkRowColumnNames", fun)
}

#' Converts BMDE field names to more amenable values in a RavianResultsTable object
#' 
#' Converts BMDE field names to more amenable values in a RavianResultsTable object
#' 
#' @param object A RavianResultsTable object
#' @param guild.type A string with the general name of the guilds (e.g., "Foraging guilds")
#' @param su.type A string with the general name of the spatial units (e.g., "Habitat types")
setMethod("checkRowColumnNames",
		signature(object = "RavianResultsTable"),
		function (object, ...) {
			#Get the res.table from the object
			qqq<-as.data.frame(ResultsTable(object))
			table.obj.new<-replaceFieldNames(table.obj=qqq)
			ResultsTable(object)<-table.obj.new
			#Get the support.table from the object
			if (class(object)=="RavianSampleSummaryTable"){
				qqq<-SupportData(object)
				table.obj.new<-replaceFieldNames(table.obj=qqq)
				SupportData(object)<-table.obj.new
			}
			return(object)
		})

#' Replaces the names in a table by those specified in function changeFieldName
#' 
#' @param table.obj A table (data frame)
replaceFieldNames<-function(table.obj){
	col.names<-as.vector(colnames(table.obj))
	#First the rows
	first.col<-as.vector(table.obj[,1])
	for(bb in 1:NROW(first.col)){
		row.cv<-first.col[bb]
		new.row.cv<-changeFieldName(row.cv)
		if(is.null(new.row.cv)) new.row.cv<-row.cv
		first.col[bb]<-new.row.cv
	}
	table.obj<-cbind(as.data.frame(first.col),table.obj[,c(-1)])
	
	#now the colnames
	for(cc in 1:NROW(col.names)){
		col.cv<-col.names[cc]
		new.col.cv<-changeFieldName(col.cv)
		if(is.null(new.col.cv)) new.col.cv<-col.cv
		col.names[cc]<-new.col.cv
	}
	colnames(table.obj)<-col.names
	#return the table
	return(table.obj)
}

#' Replaces a provided name by another one more amenable for public use
#'
#' Replaces a provided name by another one more amenable for public use if found in switch function, otherwise returns name as is 
#' @param orig.val A string with the name to replace
#' @return The replaced name if found in replacement list, or the name originally provided
changeFieldName<-function(orig.val){
	new.val<-switch(orig.val,
			sum = "TOTAL",
			NROW = "Count",
			max = "Maximum",
			min = "Minimum",
			mean = "Mean",
			se = "Standard Error",
			sd = "Standard Deviation",
			SampleSize = "Sample Size",
			ProjectName = "Project Name",
			StudyArea = "Study Area",
			PlotName = "Plot Name",
			YearCollected = "Year",
			MonthCollected = "Month",
			DayCollected = "Day",
			JulianDay = "Julian Day",
			AreaSurveyed = "Area Surveyed",
			SurveyDuration = "Survey Duration",
			ScientificName = "Scientific Name",
			CommonName = "Common Name",
			PhylogenOrder = "Taxon Id",
			SpeciesCode = "Species Code",
			ObservationCount = "Observation Count",
			NoObservations = "Zero Observations",
			StationCode = "Station Code",
			StationName = "Station Name",
			ObservationDate = "Observation Date",
			NetHours = "Net Hours",
			BandCode = "Band Code",
			LifeStage = "Age",
			Wing = "Wing Length",
			CloacalProtuberance = "Cloacal Protuberance",
			BroodPatch = "Brood Patch",
			BodyMolt = "Body Molt",
			WingMolt = "Wing Molt",
			WingWear = "Wing Wear",
			JuvenalPlumage = "Juvenal Plumage",
			Skull = "Skull Ossification",
			Fal = "Fat Level",
			TransectName = "Transect Name",
			DistanceFromObserver = "Dist. From Observer",
			InFocalHabitat = "In Focal Habitat",
			ProportionAreaSurveyed = "Proportion of Area Surveyed",
			AgeRatio = "Age Ratio (Hy/A)",
			SexRatio = "Sex Ratio (M/F)",
			StandardError = "Standard Error",
			ProjectCode = "Project Code",
			SUgroup = "Sampling Unit",
			SpatialGroup = "Spatial Group"
	)
	return(new.val)
}
