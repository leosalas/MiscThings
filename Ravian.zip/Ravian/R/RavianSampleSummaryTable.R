#' @include RavianResultsTable.R
#' @include RavianSummaryTable.R

# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Feb 12, 2010
###############################################################################

#' RavianSampleSummaryTable class
#' 
#' RavianSampleSummaryTable sub-class of RavianSummaryTable; this class of objects is intended to hold values that 
#' 		were obtained from summarizations of data in the AvianData object to show replicates from sampling units,
#' 		or summarizations of sampling units at larger spatial or temporal levels.  Data in these tables are ready for
#' 		model analyses, such as regressions. This means the object's table has the following structure typical:
#' 		Yvar, seY, N, Xvars
#' 		Yvar contains the dependent variable values, each being the value of a parameter for a replicate, or the summary
#' 		(mean, sum, etc.) of the replicates at a larger temporal level.  For example, Yvar may contain the total counts of
#' 		species X at each point, or the average of counts for each year, or the average of counts per transect per year.
#' 		Xvars are the explanatory (here called "support") variables' values at the same scale as Yvar values
#' 
#' @param SupportData data.frame containing additional fields that can be used as model explanatory variables or factors
#' @exportClass  RavianSampleSummaryTable
setClass("RavianSampleSummaryTable",contains=c("RavianSummaryTable"),
		representation(
				SupportData = "data.frame"
		)
)

#' Set generic to  method that sets SupportData slot of RavianSampleSummaryTable object
#' 
#' @name setSupportData
#' @param object A RavianSampleSummaryTable object
#' @param value data.frame to insert into slot
if (!isGeneric("SupportData<-")) {
	if (is.function("SupportData<-"))
		fun <- SupportData
	else fun <- function(object, value) standardGeneric("SupportData<-")
	
	setGeneric("SupportData<-", fun)
}

#' Set SupportData slot of RavianSampleSummaryTable object
#' 
#' @name setSupportData
#' @param object A RavianSampleSummaryTable object
#' @param value data.frame to insert into slot
setReplaceMethod("SupportData",signature(object="RavianSampleSummaryTable"),
		function(object,value) {
			slot(object,"SupportData")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves SupportData slot of RavianSampleSummaryTable object
#' 
#' @name SupportData
#' @param object A RavianSampleSummaryTable object
if (!isGeneric("SupportData")) {
	if (is.function("SupportData"))
		fun <- SupportData
	else fun <- function(object) standardGeneric("SupportData")
	
	setGeneric("SupportData", fun)
}

#' Retrieve SupportData slot of RavianSampleSummaryTable object
#' 
#' @name SupportData
#' @param object A RavianSampleSummaryTable object
setMethod("SupportData",signature(object="RavianSampleSummaryTable"),
		function(object) slot(object,"SupportData"))

##### as.data.frame for RavianSampleSummaryTable
#' Export a RavianResultsTable Object into a data.frame
#'
#' @name as.data.frame
#' @param x a RavianSampleSummaryTable object
setMethod("as.data.frame",
		signature(x="RavianSampleSummaryTable",row.names="missing",optional="missing"),
		function(x, ...) {
			res.df<-ResultsTable(x)
			supp.df<-SupportData(x)
			full.df<-merge(supp.df,res.df,all.y=TRUE,sort=FALSE)
			return(full.df)
		})

##### trend estimation method
#Returns a RavianResultsTable
#' Set generic to  method that estimates simple trend on a RavianSampleSummaryTable object
#' 
#' @name trend
#' @param object RavianSampleSummaryTable object
#' @param do.log logical value to determine if log transformation will happen prior to trend estimation
#' @param weighted logical value to determine if trend analysis will be weighted by the variance of the estimates
#' @param reg.type String indicating what type of trend to calculate: simple = simple linear, cubic = cubic spline, loess = loess
if (!isGeneric("trend")) {
	if (is.function("trend"))
		fun <- trend
	else fun <- function(object, do.log, weighted, reg.type, ...) standardGeneric("trend")
	
	setGeneric("trend", fun)
}

#' Estimate simple trend on a RavianSampleSummaryTable object
#' 
#' @param object RavianSampleSummaryTable object
#' @param do.log Boolean value to determine if log transformation will happen prior to trend estimation
#' @param weighted Boolean value to determine if trend analysis will be weighted by the variance of the estimates
#' @param reg.type String indicating what type of trend to calculate: simple = simple linear, cubic = cubic spline, loess = loess
#' @param group String naming the grouping factor for the trend. If NA (default), then all data within a year are considered replicates.
setMethod("trend",
		signature(object = "RavianSampleSummaryTable"),
		function (object, do.log=FALSE, weighted=TRUE, reg.type="simple",group=NA,...) 
		{
			ea.call<-match.call()
			res.df<-as.data.frame(object)
			x.var<-PlotParameters(object)$x.var; xvar<-x.var
			y.var<-PlotParameters(object)$y.var
			x.label<-PlotParameters(object)$x.label
			y.label<-PlotParameters(object)$y.label
			regvars<-na.omit(c(y.var,x.var,group,"StandardError","SampleSize"))
			res.df<-res.df[,regvars]
			if(class(res.df[,x.var])=="character"){
				tst<-as.numeric(res.df[,x.var])
				if(!is.na(tst)){
					res.df[,x.var]<-tst
				}else{
					tst<-as.numeric(as.factor(res.df[,x.var]))
					res.df$x.var.val<-res.df[,x.var]
					res.df[,x.var]<-tst
				}
			}
			if(class(res.df[,y.var])=="character")res.df[,y.var]<-as.numeric(res.df[,y.var])
			if(class(res.df$StandardError)=="character")res.df$StandardError<-as.numeric(res.df$StandardError)
			if(class(res.df$SampleSize)=="character")res.df$SampleSize<-as.numeric(res.df$SampleSize)
			#res.df<-as.data.frame(apply(res.df,2,as.numeric),stringsAsFactors=FALSE,row.names=NULL)
			#checks
			if ((!x.var %in% names(res.df)) | (is.na(group)==FALSE & !(group %in% names(res.df)))) {
				trend.err<-paste("Error:",x.label,"is not an available variable to trend against, or", group,"is not an available factor to group by.")
				class(trend.err)<-"try-error"
				return(trend.err)
			}else{
				if(reg.type=="cubic" | reg.type=="loess"){
					if(nrow(res.df)<4)reg.type<-"simple"
				}
				#more than one x.var check
				chk.x<-checkXVarTrend(dat.df=res.df,xvar=x.var,xlab=x.label)
				if(!is.null(chk.x)){
					trend.err<-paste(chk.x)
					class(trend.err)<-"try-error"
					return(trend.err)
				}else{
					#check for NA's and "NA"s in the data...(if found, remove and warn)
					notes.warn<-""
					if(sum(is.na(res.df[,c(y.var)]))>0){
						nna.v<-sum(is.na(res.df[,c(y.var)]))
						res.df<-na.omit(res.df)
						notes.warn<-paste("WARNING:",y.var,"estimates have",nna.v,"record(s) with no values.  These were excluded from trend calculations.")
					}
					if(sum(res.df[,c(y.var)]=="NA")>0){
						nna.v<-sum(res.df[,c(y.var)]=="NA")
						res.df<-subset(res.df,res.df[,c(y.var)]!="NA")
						notes.warn<-paste("WARNING:",y.var,"estimates have",nna.v,"record(s) with no values.  These were excluded from trend calculations.")
					}
					trend.notes<-""
					if (((min(res.df$StandardError, na.rm=TRUE)<=0) | ("TRUE" %in% is.na(res.df$StandardError))) & weighted==TRUE){
						trend.notes<-"Ravian Message: Dataset contains at least one standard error value = 0.  Weighted regression cannot be performed."
						weighted<-FALSE
					} 
					table.title<-paste("Simple linear trend estimate of",y.label,"by",x.label)
					if(reg.type=="cubic"){
						x.var<-paste("s(",x.var,")",sep="")
						table.title<-paste("Generalized additive trend estimate of",y.label,"by",x.label,"with cubic spline smoother")
					}
					if(reg.type=="loess"){
						x.var<-paste("lo(",x.var,")",sep="")
						table.title<-paste("Generalized additive trend estimate of",y.label,"by",x.label,"with locally weighed (loess) smoother")
					}
					if(is.na(group)){
						reg.rs<-try(doRegr(dat.df=res.df,xvar=x.var,yvar=y.var,do.log=do.log,weighted=weighted,reg.type=reg.type),silent=TRUE)  #try-catch
						if(inherits(reg.rs,"try-error")){
							trend.err<-paste("Ravian Message: Attempt to produce trend estimate failed.")
							class(trend.err)<-"try-error"
							return(trend.err)
						}
					}else{
						reg.rs<-data.frame()
						for(ggg in as.character(unique(res.df[,group]))){
							t.res.df<-subset(res.df,res.df[,group]==ggg)
							if(length(unique(t.res.df[,xvar]))>1){
								tmp.rs<-try(doRegr(dat.df=t.res.df,xvar=x.var,yvar=y.var,do.log=do.log,weighted=weighted,reg.type=reg.type),silent=TRUE)  #try-catch
								if(inherits(tmp.rs,"try-error")){
									trend.err<-paste("Ravian Message: Attempt to produce trend estimate failed.")
									class(trend.err)<-"try-error"
									return(trend.err)
								}else{
									tmp.rs$GroupVar<-ggg
									reg.rs<-rbind(reg.rs,tmp.rs)
								}
							}
						}
					}
					trend.notes<-paste(trend.notes,notes.warn)
				}
			}
			#populate results object
			res<-new("RavianResultsTable")
			ResultsTable(res)<- reg.rs
			Process(res)<- "Trend estimation"
			TableTitle(res)<-table.title
			Notes(res)<-trend.notes
			ProcessParameters(res)<-list(data=res.df,xvar=x.var,yvar=y.var,x.label=x.label,y.label=y.label,do.log=do.log,weight=weighted,reg.type=reg.type)
			Call(res)<- ea.call
			return(res)
		}
)

#' Checks that the dataset provided for trend estimation has more than one value in the x-axis
#' 
#' @name checkXVarTrend
#' @param dat.df A data frame to inspect
#' @param xvar The name of the x variable in the data frame
#' @param xlab The label of the x variable
checkXVarTrend<-function(dat.df,xvar,xlab){
	if(NROW(unique(dat.df[,which(names(dat.df)==xvar)]))<2){
		xv.check<-paste("Ravian Message: Dataset contains only one value for the x-axis variable ",xlab,". Trend analysis cannot be performed.",sep="")
	}else{
		xv.check<-NULL
	}
	return(xv.check)
}

#' Estimates regression parameters for a simple linear fit on data in a data frame
#' 
#' @name doRegr
#' @param dat.df A data frame with data to regress
#' @param xvar The name of the x variable in the data frame
#' @param yvar The name of the y variable in the data frame
#' @param do.log A boolean determining whether to log values before regressing - not currently used
#' @param weighted A boolean determining wheter to weigh x values by inverse of variance - CAREFUL: Variance variable is assumed to be named "Variance"
#' @param reg.type A string specifying whether to perform a "simple" linear regression, or a "cubic" or "loess" gam
doRegr<-function(dat.df,xvar,yvar,do.log,weighted,reg.type="simple"){
	fml<-as.formula(paste(yvar,"~",xvar))
	if (weighted==TRUE){
		dat.df$Variance<-(((as.numeric(dat.df$StandardError))^2)*as.numeric(dat.df$SampleSize))
		if(reg.type=="simple")trend.est<-lm(fml, weights=(1/Variance), data=dat.df)
		if(reg.type=="cubic")trend.est<-gam(fml, weights=(1/Variance), data=dat.df)
		if(reg.type=="loess")trend.est<-gam(fml, weights=(1/Variance), data=dat.df)
		#if(reg.type=="simple")trend.est<-eval(substitute(lm(yv~xv, weights=(1/Variance), data=dat.df),list(yv=as.name(yvar), xv=as.name(xvar))))
		#if(reg.type=="cubic")trend.est<-eval(substitute(gam(yv~xv, weights=(1/Variance), data=dat.df),list(yv=as.name(yvar), xv=as.name(xvar))))
		#if(reg.type=="loess")trend.est<-eval(substitute(gam(yv~xv, weights=(1/Variance), data=dat.df),list(yv=as.name(yvar), xv=as.name(xvar))))
	} else {
		if(reg.type=="simple")trend.est<-lm(fml, data=dat.df)
		if(reg.type=="cubic")trend.est<-gam(fml, data=dat.df)
		if(reg.type=="loess")trend.est<-gam(fml, data=dat.df)
		#trend.lm<-eval(substitute(lm(yv~xv, data=dat.df),list(yv=as.name(yvar), xv=as.name(xvar))))
	}
	#make the results a table
	#rrs<-summary(trend.est)
	rrr<-as.data.frame(coef(trend.est))
	f.col<-rownames(rrr)
	se.arr<-numeric()
	for(ppp in 1:length(f.col)){
		se.arr<-c(se.arr,vcov(trend.est)[ppp,ppp])
	}
	trnd.t<-cbind(f.col,rrr,se.arr)
	trnd.table<-data.frame(trnd.t, row.names=NULL)
	colnames(trnd.table)<-c("Parameter","Value","SE_value")
	return(trnd.table)
}


