# RavianUtils.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org
# Creation Date: May 31, 2009
# Also note: I removed the merging of all old fields... too cumbersome. Need to edit Rd.
# None of these functions are being exported.  To be used within Ravian methods only.

#' Enhanced aggregation function 
#' 
#' Enhanced aggregation function to support multiple aggregations at once, and also supports nicer naming options
#' 
#' @param data data.frame
#' @param by list to determine which fields to aggregate by
#' @param field character string that defines the fields that operations will be performed on during the aggregation
#' @param new.name character string to define new names for the newly created aggregated fields, if desired
#' @param FUN vector of appropriate functions
#' @return data.frame of aggredated data
#' @author Mark Herzog \email{mherzog@@prbo.org}
compressData<-function(data=NULL,by,field=NULL,new.name=NULL,FUN) {
	if (is.null(data)==TRUE) stop ("A data file is required.")
	if (is.null(field)==TRUE) stop ("Field to operate on is required.")
	for (Field in as.character(field)) {
		if (is.null(new.name)==TRUE) new.name<-Field
		temp2<-data.frame()
		for (Function in as.character(FUN)) {
			FUNC<-match.fun(Function)
			temp1<-aggregate(data[,names(data)==Field],by,FUNC)
			names(temp1)[names(temp1)=="x"]<-ifelse(Function=="NROW","SampleSize",paste(casefold(Function),new.name,sep=""))
			if (nrow(temp2)==0) {
				temp2<-temp1
			} else {
				temp2<-merge(temp2,temp1,all=TRUE)
			}
		}
	}
	return(temp2)
}

#' Create a DSN connection string for an ODBC connector driver
#' 
#' Creates a DSN connection string for any available ODBC connector driver.
#' 
#'	This function is made available to allow connections to databases where a DSN has not been created on the machine
#' 	currently in use.  This can provide a security measure to keep usernames and passwords from remaining on computers.
#' 
#' @param DSN a character string naming the data source name
#' @param driver character string. Exact name of the ODBC driver. 
#' @param server character string. IP address (or dns name) of the server where database is located.  
#' @param database character string.  Name of the database that a connection is to be made 
#' @param user character string.  Username, if needed, for connection to database 
#' @param password character string.  Password, if needed, for connection to database
#' @param port integer.  Port to communicate on.
#' @param option integer.  Option value(s) for the DSN connection string 
#' @return	A character string, that represents a properly formatted DSN string to be used in \code{\link{connectDatabase}}.
#' @author Mark Herzog \email{mherzog@@prbo.org}
#' @seealso 
#' \code{\link{connectDatabase}}
#' \code{\link{closeDatabase}}
#' @examples 
#' 	\dontrun{createDSN("{MySQL ODBC 5.1 Driver}","192.168.2.102","bmde.data","genericUser","Pa55w0rd",3306,2049)}
#' @keywords database
createDSN<-function(DSN,driver="{MySQL ODBC 5.1 Driver}",server,database,user,password,port=3306,option=2049) {
	error<-""
	if (is.null(DSN)==TRUE) paste(error,"DSN argument cannot be NULL")
	if (is.null(driver)==TRUE) paste(error,"driver argument cannot be NULL")
	if (is.null(server)==TRUE) paste(error,"server argument cannot be NULL")
	if (is.null(database)==TRUE) paste(error,"database argument cannot be NULL")
	if (is.null(user)==TRUE) paste(error,"user argument cannot be NULL")
	if (is.null(password)==TRUE) paste(error,"password argument cannot be NULL")
	if (is.null(port)==TRUE) paste(error, "port argument cannot be NULL")
	if (is.null(option)==TRUE) paste(error, "option argument cannot be NULL")
	if (error != "") stop(paste("createDSN failed due to the following errors:",error,sep="\n"))
	dsnsuff<-paste(
			paste("Driver=",driver,sep=""),
			paste("Server=",server,sep=""),
			paste("Database=",database,sep=""),
			paste("User=",user,sep=""),
			paste("Password=",password,sep=""),
			paste("Port=",port,sep=""),
			paste("Option=",option,sep=""),
			sep=";")
	dsnpref<-""
	if(grepl("Linux",Sys.info()[1])==TRUE) dsnpref<-paste(DSN,";",sep="")
	dsn<-paste(dsnpref,dsnsuff,sep="")
	return(dsn)
}

#' Connect to Database
#' 
#' Set up the connection to a database
#' 
#' @param dsn character string that defines the saved dsn or is a properly formatted dsn string.
#' 		If the latter, then all other fields are optional.
#' @return A standard R database connection object
#' @author Mark Herzog \email{mherzog@@prbo.org}
connectDatabase<-function(dsn="DataWarehouses_Devel") {#RavianWarehouse-Redhat must provide a registered DSN or a string with connection info that has a DSN...
	if(dsn==""){
		error<-"Connection string or DSN is empty"
		return(error)
	}
	options(warn=2)
	if(!grepl("DATABASE",dsn,ignore.case=TRUE)){ #try connection using DSN
		PRBOdb.con<-try(odbcConnect(dsn, rows_at_time = 1), silent=TRUE)
	}else if(grepl("DATABASE",dsn,ignore.case=TRUE)){ #try flexible connection with string, but must have DSN=... in Linux
		PRBOdb.con<-try(odbcDriverConnect(connection=dsn, rows_at_time = 1), silent=TRUE)
	} else {
		#       dbname<-ifelse(substr(group,1,5)=="digir","digir",dbname)
		#       MySQL.driver<-dbDriver(driver)
		#       PRBOdb.con<-dbConnect(MySQL.driver, group=group, dbname=dbname, ...)
	}
	options(warn=-1)
	return(PRBOdb.con)
}

#' Close connection to a Database
#' 
#' Close the connection to a database
#' 
#' @param con the R database connection object to be closed 
#' @param ODBC logical to define whether the connection is an ODBC connection
#' @return returns invisibly a logical indicating if it succeeded.
#' @author Mark Herzog \email{mherzog@@prbo.org}
closeDatabase<-function(con, ODBC=TRUE) {
	if (ODBC==TRUE) {
		odbcClose(con)
	} else {
		#      dbDisconnect(con)
	}
}

#' Wrapper function around compressData for methods estimating Abundance or Richness
#' 
#' Wrapper function around compressData for methods estimating Abundance or Richness
#' This function makes the "by" list used by the compressData function form 
#' input arguments; it also creates a support data table from input arguments (typically
#' additional effort and location information for estimating Abundance or Richness) 
#' Then calls compressData, merges the support data table to the resulting table and
#' 
#' @param by.list A string vector with the names of the variables to include in the "by" list of compressData
#' @param comp.field The field on which compression will be carried (on which aggregation functions will be carried - see compressData for details) 
#' @param calc.fun A string vector naming the functions to apply to comp.field (see compressData for details) 
#' @param data.table The data table
#' @param support.site.fields A string vector with the names of the variables to use to build the support table
#' @param effort.base The base table with effort data. Unique values of the support.site.fields in this table become the support data table
#' @param new.name The new name suffix to apply to any new fields generated by the aggregation (see compressData for details)
#' @return data.frame of aggregated data merged with effort data
#' @author Leo Salas \email{lsalas@@prbo.org}
calcCompress<-function(by.list,comp.field,calc.fun,data.table,support.site.fields,effort.base,new.name){
	#first make the by
	by<-list()
	for(by.name in by.list){
		eval(substitute(by$x<-data.table$x,list(x=by.name)))
	}
	#then make the support.data table
	support.site<-unique(effort.base[,support.site.fields])
	#then compress the data
	bird.compr<-compressData(data=data.table,by=by,field=comp.field,new.name=new.name,FUN=calc.fun)  
	bird.compr<-merge(support.site,bird.compr, all.x=T) #This may produce NAs in the new.name variable, soo...
	#Also, Mark's function sets the new variable to be SampleSize if func=NROW
	for(Function in calc.fun){
		nv.name<-ifelse(Function=="NROW","SampleSize",paste(casefold(Function),new.name,sep=""))
		bird.compr[,which(names(bird.compr)==nv.name)]<-ifelse(is.na(bird.compr[,which(names(bird.compr)==nv.name)])==TRUE,0,bird.compr[,which(names(bird.compr)==nv.name)])
	}
	return(bird.compr)
}
