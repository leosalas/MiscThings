#' @include RavianUtils.R
#' @include AvianData.R
#' @include RavianSampleSummaryTable.R
#' @include AreaSearchData.R
#' @include GeoDataStore.R

###############################################################################
# AreaSearchGeoData.R
# TODO: Need a function that creates and populates a GeoDataStore object.  In Ravian that is done by the CADC function.  CADCgeo function?
# 
# Author: lsalas
# Contact: lsalas@prbo.org
# Creation Date: April 6, 2012
###############################################################################


#' ShoreBirdGeoData class - subclass of AreaSearchData Class
#' 
#' ShoreBirdGeoData class - subclass of AreaSearchData Class
#' @param ObsData data frame that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType always "AreaSearch"
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @param GeoDataDefn A GeoDataStore object to manage connection information for geographic data sources
#' @param GeoData A data frame that contains the geographic data harvested to attribute the observation data
#' @param GeoDataObsDataLink A string vector naming the single variable by which to link the geographic data and the observational data
#' @exportClass ShoreBirdGeoData
setClass("ShoreBirdGeoData", 
			representation(
				GeoDataDefn = "GeoDataStore",
				GeoData = "data.frame",
				GeoDataObsDataLink = "character"
			),
			contains=c("AvianData","ShoreBirdData"),
			prototype=prototype(
				ProtocolType="AreaSearch",
				Fields = list(obs=c("ApplicationCode","SUgroup","Geopolitical","HabRegion","Habitat","Site",
								"ProjectCode", "ProjectName", "LocalityID","SamplingUnitId","Plot","PlotName",
								"ProtocolCode","Visit","YearCollected","MonthCollected","JulianDay",
								"ScientificName","CommonName","SpeciesCode","PhylogenOrder","FlyOver",
								"ObservationCount"),
						event=c("ApplicationCode","SUgroup","Geopolitical","HabRegion","Habitat","Site",
								"ProjectCode", "ProjectName", "LocalityID","SamplingUnitId","Plot","PlotName",
								"ProtocolCode","Visit","YearCollected","MonthCollected","JulianDay","NoObservations","Salinity","Temperature","DepthMin",
								"Wind","Precipitation","PercentCloudCover","DominantCoverType","SecondaryCoverType",
								"TidalConditions","VisibleArea","PercentFlood","PercentBare","PercentVegetated",
								"VegetationHeight","Acres","AcresAgricultural","AcresAlkaliMeadow","AcresCW",
								"AcresDTCH","AcresFAC","AcresFW","AcresIP","AcresMRF","AcresPermanentPond","AcresPG",
								"AcresRIP","AcresRWS","AcresSummerWater","AcresUnmanagedFloodedWetland","AcresUPL",
								"AcresVAG","AcresVernalPool","AcresVernalPoolAlkaliMeadows","AcresVORF","AcresVOS",
								"AcresWaterGrass","FloodableAcres","PercentEntireUnitFlooded","PrimaryHabitatObjective",
								"SecondayHabitatObjective","SFMAcres","HuntDayInd","WindSpeed")),
				GeoDataObsDataLink="SamplingUnitID"
			))

#New slots: GeoDataDefn, GeoData, GeoDataObsDataLink
#' Set generic to Retrieve value of GeoDataDefn slot of ShoreBirdGeoData object
#' 
#' @param object A ShoreBirdGeoData object
setGeneric("GeoDataDefn",
			function(object) standardGeneric("GeoDataDefn"))
	
#' Retrieve value of GeoDataDefn slot of ShoreBirdGeoData object
#' 
#' @param object A ShoreBirdGeoData object
setMethod("GeoDataDefn",signature(object="ShoreBirdGeoData"),
			function(object) slot(object,"GeoDataDefn"))
	
#' Set generic to Set GeoDataDefn slot of ShoreBirdGeoData object
#' 
#' @name setGeoDataDefn
#' @param object A ShoreBirdGeoData object
#' @param value A GeoDataStore object to insert into slot
setGeneric("GeoDataDefn<-",
			function(object,value) standardGeneric("GeoDataDefn<-"))
	
#' Set GeoDataDefn slot of ShoreBirdGeoData object
#' 
#' @name setGeoDataDefn
#' @param object A ShoreBirdGeoData object
#' @param value A GeoDataStore object to insert into slot
setReplaceMethod("GeoDataDefn",
			signature(object="ShoreBirdGeoData"),
			function(object,value) {
				slot(object,"GeoDataDefn")<-value
				validObject(object)
				object
		})
	
#' Set generic to Retrieve value of GeoData slot of ShoreBirdGeoData object
#' 
#' @param object A ShoreBirdGeoData object
setGeneric("GeoData",
		function(object) standardGeneric("GeoData"))

#' Retrieve value of GeoData slot of ShoreBirdGeoData object
#' 
#' @param object A ShoreBirdGeoData object
setMethod("GeoData",signature(object="ShoreBirdGeoData"),
		function(object) slot(object,"GeoData"))

#' Set generic to Set GeoData slot of ShoreBirdGeoData object
#' 
#' @name setGeoData
#' @param object A ShoreBirdGeoData object
#' @param value A data frame object to insert into slot
setGeneric("GeoData<-",
		function(object,value) standardGeneric("GeoData<-"))

#' Set GeoData slot of ShoreBirdGeoData object
#' 
#' @name setGeoData
#' @param object A ShoreBirdGeoData object
#' @param value A data frame object to insert into slot
setReplaceMethod("GeoData",
		signature(object="ShoreBirdGeoData"),
		function(object,value) {
			slot(object,"GeoData")<-value
			validObject(object)
			object
		})

#' Set generic to Retrieve value of GeoDataObsDataLink slot of ShoreBirdGeoData object
#' 
#' @param object A ShoreBirdGeoData object
setGeneric("GeoDataObsDataLink",
		function(object) standardGeneric("GeoDataObsDataLink"))

#' Retrieve value of GeoDataObsDataLink slot of ShoreBirdGeoData object
#' 
#' @param object A ShoreBirdGeoData object
setMethod("GeoDataObsDataLink",signature(object="ShoreBirdGeoData"),
		function(object) slot(object,"GeoDataObsDataLink"))

#' Set generic to Set GeoDataObsDataLink slot of ShoreBirdGeoData object
#' 
#' @name setGeoDataObsDataLink
#' @param object A ShoreBirdGeoData object
#' @param value A character vector object to insert into slot
setGeneric("GeoDataObsDataLink<-",
		function(object,value) standardGeneric("GeoDataObsDataLink<-"))

#' Set GeoDataObsDataLink slot of ShoreBirdGeoData object
#' 
#' @name setGeoDataObsDataLink
#' @param object A ShoreBirdGeoData object
#' @param value A character vector object to insert into slot
setReplaceMethod("GeoDataObsDataLink",
		signature(object="ShoreBirdGeoData"),
		function(object,value) {
			slot(object,"GeoDataObsDataLink")<-value
			validObject(object)
			object
		})

	
#' Instantiate a new ShoreBirdGeoData object
#' @return The ShoreBirdGeoData object
setMethod("initialize",
		signature(.Object = "ShoreBirdGeoData"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object@GeoDataDefn <- new("GeoDataStore")
			.Object@GeoData<-data.frame()
			.Object@GeoDataObsDataLink<-""
			.Object
		}
)


#Generic exists in base, just extending it...
#' Links geo data and observation data in an ShoreBirdGeoData object
#' 
#' @name as.data.frame
#' @param x A ShoreBirdGeoData object
#' @param row.names A string naming the rows, ignored here - see ?as.data.frame for details
#' @param optional A string providing further details to the base function, ignored here - see ?as.data.frame for details
setMethod("as.data.frame", signature(x="ShoreBirdGeoData",row.names="missing", optional="character"),
		function(x,row.names = NULL, optional = FALSE, ..., stringsAsFactors = default.stringsAsFactors()){
			gd.df<-GeoData(x)
			od.df<-ObsData(x)
			ed.df<-EffortData(x)
			linkparam<-GeoDataObsDataLink(x)
			if(length(gd.df)==0 | length(od.df)==0 | length(ed.df)==0){
				err.msg<-"Ravian Message: Missing geographic attribute data or observation data.  Cannot create data frame."
				class(err.msg)<-"try-error"
				return(err.msg)
			}else if(linkparam==""){
				err.msg<-"Ravian Message: Missing variable name to link geographic attribution data and observation data.  Cannot create data frame."
				class(err.msg)<-"try-error"
				return(err.msg)
			}else{
				data.df<-merge(ed.df,gd.df,all.x=TRUE)
				data.df<-merge(data.df,od.df, by=c("ApplicationCode","SUgroup","Geopolitical","HabRegion","Habitat","Site",
						"ProjectCode", "ProjectName", "LocalityID","SamplingUnitId","Plot","PlotName",
						"ProtocolCode","Visit","YearCollected","MonthCollected","JulianDay"), 
						all.x=TRUE)
				data.df$ObservationCount<-ifelse(is.na(data.df$ObservationCount),0,data.df$ObservationCount)
				return(data.df)				
			}
		})
