#' @include AvianData.R
#' @include RavianSummaryTable.R

# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Aug 5, 2009
###############################################################################

###DEPENDENCIES: stats

##This method would take an AvianData object and creates a crosstab table based on a named row variable, 
##column variable and cell variable.
##User prvides the names of the variables in a character vector; this will result in a crosstab table.  
##A fourth entry in the vector specifies the function to apply to the cell variable for tabulation.
##The four entries in the vector are, in this order: row variable, column variable, cell variable, and function.
##The method returns a RavianSummaryTable object

##Two possible types of tables may be returned:
##1) Full cross-tabulation (e.g., mean weight by age and sex categories): t.vars<-c("Age","Sex","Weight","mean")
##2) Single-variable tabulation (e.g., mean weight by age categories): t.vars<-c("Age","Age","Weight","mean")
##	Note that single and double-variable frequencies can be obtained:
##      Single-variable frequencies: t.vars<-c("Age","Age",NA,"NROW")
##     (NOTE: this is the only case for which cell.var is NA, and FUN will be forced to NROW)
##      Double-variable frequencies: t.vars<-c("Month","Year","CommonName","NROW")

##Example t.vars
##t.vars1<-c("Point","YearCollected","Visit","sum")
##t.vars2<-c("Point","Point","Visit","sum")
##t.vars3<-c("CommonName","CommonName",NA,"NROW") 
##t.vars<-c("Point","Year","CommonName","NROW")

##NOTE: numeric row and/or column variables will be treated as discrete
 
#' Create crosstab tables on an AvianData object
#' 
#' Creates one to many crosstab tables on an AvianData object
#' @name crossTabulate
#' @param object An AvianData object
#' @param t.vars A 5-elements vector of variables to crosstabulate and function to apply
if (!isGeneric("crossTabulate")) {
	if (is.function("crossTabulate"))
		fun <- crossTabulate
	else fun <- function(object, t.vars) standardGeneric("crossTabulate")
	setGeneric("crossTabulate", fun)
}


#' Create crosstab tables on an AvianData object
#' 
#' Creates one to many crosstab tables on an AvianData object
#' 
#' @param object An AvianData object
#' @param t.vars A 4-elements vector of variables to crosstabulate and function to apply
setMethod("crossTabulate", signature(object="AvianData",t.vars = "character"),
		function(object, t.vars) {
			ea.call<-match.call()
			error<-""
			if (is.null(object)==TRUE) {error<-"An AvianData object is required."}
			if (is.null(t.vars)==TRUE) {error<-"A table of variables to crosstabulate is required."}
			if(is.na(t.vars[1]) | is.na(t.vars[2]) | is.na(t.vars[4]) | is.null(t.vars[1]) | is.null(t.vars[2]) | is.null(t.vars[4]) |
				t.vars[1]=="" | t.vars[2]=="" | t.vars[4]=="") {
				error<-"Either row or column variable of table is null, or function to apply is null."
			}
			if(error!=""){
				class(error)<-"try-error"
				return(error)
			}
			#If object is a ShoreBirdData object and t.vars[3] == "CommonName" and t.vars[4] == "NROW"
			tn.add<-""
			if(class(object)=="ShoreBirdData" & t.vars[3]=="SpeciesCode" & t.vars[4]=="NROW"){
				obs.dat<-ObsData(object)
				obs.dat<-try(correctSpeciesForFlocks(obs.dat),silent=TRUE)
				if (inherits(obs.dat,"try-error")) return(obs.dat)
				ObsData(object)<-obs.dat
				tn.add<-". Number of records may have been inflated because of splitting of mixed flock codes"
			}
			full.data<-merge(EffortData(object),ObsData(object), all.x=T)
			table.note<-paste(countRecordsNulls(full.data,t.vars),tn.add,sep="")
			full.data$ObservationCount<-ifelse(is.na(full.data$ObservationCount)==TRUE,0,full.data$ObservationCount)
			#Some band data may have no net hours.  Must handle this... Other cases??? If so, consider changing signature.
			if(ProtocolType(object)=="Band"){full.data$NetHours<-ifelse(is.na(full.data$NetHours)==TRUE,0,full.data$NetHours)}
			#retrieve the actors...
			c.var<-NA
			if(!is.na(t.vars[3]) & t.vars[3]!="AgeRatio" & t.vars[3]!="SexRatio") c.var<-full.data[,c(t.vars[3])]	
			x.var<-as.data.frame(full.data[,c(t.vars[2])],row.names=NULL,stringsAsFactors=F)
			y.var<-as.data.frame(full.data[,c(t.vars[1])],row.names=NULL,stringsAsFactors=F)
			tab.data<-as.data.frame(cbind(y.var,x.var,c.var),row.names=NULL,stringsAsFactors=F)
			tab.data<-subset(tab.data,!is.na(tab.data[,1]) & !is.na(tab.data[,2]))
			#must do the following in case of removal of c.var NAs for NROW calls results in complete deletion of groups where samples were taken
			fs.tab.data<-as.data.frame(unique(tab.data[,1]))
			if(t.vars[1]!=t.vars[2]){fs.tab.data<-as.data.frame(merge(unique(tab.data[,1]),unique(tab.data[,2])))}
			nfstd<-t.vars[1]
			if(t.vars[1]!=t.vars[2]){nfstd<-c(t.vars[1],t.vars[2])}
			names(fs.tab.data)<-nfstd
			#check for special cases
			tab.data<-checkSpecialCases(full.data,tab.data,t.vars) 
			#Now, aggregate by FUN...
			app.fun<-t.vars[4]
			if(is.na(t.vars[3]) | !is.na(t.vars[3]) & (t.vars[3]=="CommonName" | t.vars[3]=="ScientificName" | t.vars[3]=="Transect" | t.vars[3]=="Point")) app.fun<-"NROW"
			#now build the table
			tabledata<-try(aggregate(tab.data[,3],list(tab.data[,1],tab.data[,2]),app.fun),silent=TRUE)
				if (inherits(tabledata,"try-error")) {
					err.table<-list(paste(tabledata,collapse=" "))
					class(err.table)<-"try-error"
					return(err.table)
				} else {
					names(tabledata)<-as.character(c(t.vars[1],t.vars[2],t.vars[3]))
					tabledata[,3]<-round(tabledata[,3], digits=2)
					#then to check for deleted groups where samples happened but no obs...
					mg.tabledata<-as.data.frame(join(fs.tab.data,tabledata,type="left",match="all")) 
					if((ncol(mg.tabledata)==2) & (t.vars[1]==t.vars[2])){
						mg.tabledata[,3]<-mg.tabledata[,2]
						mg.tabledata[,2]<-mg.tabledata[,1]
						names(mg.tabledata)<-names(tabledata)
					}
					mg.tabledata[,3]<-ifelse(is.na(mg.tabledata[,3])==TRUE,0,mg.tabledata[,3])
					cross.table<-eval(substitute(xtabs(z ~ x + y, mg.tabledata),
							list(z=as.name(t.vars[3]),x=as.name(t.vars[2]),y=as.name(t.vars[1]))))
					tmp.table<-as.matrix(cross.table)
					fc<-rownames(tmp.table)
					c.names<-c(t.vars[2],colnames(tmp.table))
					if(t.vars[1]==t.vars[2]){
						if(!is.na(t.vars[3])){
							if(app.fun!="NROW"){
								c.names<-c(t.vars[1],t.vars[3])
							}else{
								c.names<-c(t.vars[1],"Count")
							}
						}else{
							c.names<-c(t.vars[1],"Count")
						}
					}
					final.table<-as.data.frame(cbind(fc,tmp.table),row.names=NULL,stringsAsFactors=F)
					names(final.table)<-c.names
					title<-makeTitle(app.fun,t.vars[1],t.vars[2],t.vars[3])
					plot.params<-list()
					if(ncol(final.table)==2){
						plot.params$y.var<-names(final.table)[2]
						plot.params$y.label<-substr(title,1,regexpr(" by ",title)-1)
						plot.params$x.var<-names(final.table)[1]
						plot.params$x.label<-names(final.table)[1]
					}
					#Now populate the RavianResults object
					res<-new("RavianSummaryTable")
					ResultsTable(res) <- final.table 	 	
					Process(res) <- "crossTabulate"			
					TableTitle(res) <- title			
					Notes(res) <- table.note			
					ProcessParameters(res) <- list(table.vars=t.vars)
					PlotParameters(res) <- plot.params		
					DataStoreData(res) <- DataDefn(object)
					Call(res) <- ea.call
					return(res)
				}
})

#' Re-build the data table for cross-tabulation for special cases
#' 
#' Re-build the data table for cross-tabulation based on two special cases: a request for summary NetHours
#' and a request for number of species
#' 
#' @param full.data A data.frame with the entire data contents of the AvianData object being cross-tabulated
#' @param tab.data The current data table considered for cross-tabulation
#' @param t.vars A vector of variables to crosstabulate
checkSpecialCases<-function(full.data,tab.data,t.vars){
	###############
	# In case a table where c.var=nethours is requested, 
	# Use unique dates, x.var, y.var, g.var and nethours and use this table for crosstabbing instead			
	# So, just need to append date and get uniques as table to return...
	###############
	if(!is.na(t.vars[3]) & t.vars[3]=="NetHours"){
		od<-as.array(full.data[,names(full.data)=="ObservationDate"])
		new.tab.data<-unique(cbind(tab.data,od))
		return(new.tab.data[,1:3])
	}
	###############
	#If user requested to know the number of visits/sampling events, it is here interpreted as number of unique values in c.var			
	#Append variables to ensure unique dates (so append year)
	#Then just get the uniques of this table as the harvest table on which to crosstabulate
	#app.fun MUST be "NROW"
	###############
	if(!is.na(t.vars[3]) & (t.vars[3]=="Visit" | t.vars[3]=="JulianDay")){
		od<-as.data.frame(full.data[,which(names(full.data) %in% c("YearCollected"))])	#No ObservationDate in AS, PC warehouse
		new.tab.data<-unique(cbind(tab.data,od))
		return(new.tab.data[,1:3])
	}
	#########################
	# If the request is to return number of species?
	# c.var MUST be "CommonName" or "ScientificName" NOT "SpeciesCode" (excepting PFSS)
	# and the only operation... app.fun must be NROW
	# Easier than above: the table of data to crosstabulate is the uniques of x.var, y.var, c.var (,g.var)
	##########################
	if(!is.na(t.vars[3]) & (t.vars[3]=="CommonName" | t.vars[3]=="ScientificName" | t.vars[3]=="SpeciesCode")){
		sub.tab.data<-subset(tab.data, !is.na(tab.data[,3]))
		new.tab.data<-unique(sub.tab.data)
		return(new.tab.data)
	}
	###############
	#If user requested to know the number of transects (unique transects visited) or points			
	#Then just get the uniques of this table as the harvest table on which to crosstabulate
	#app.fun MUST be NROW
	###############
	if(!is.na(t.vars[3]) & (t.vars[3]=="Transect" | t.vars[3]=="Point")){
		new.tab.data<-unique(tab.data)
		return(new.tab.data[,1:3])
	}
	#########################
	# If the request is to return AgeRatio by x,y,z variables
	# c.var MUST be "AgeRatio"
	# so, all that is needed is to generate c.var with age ratio values
	# for each subset of x.var & y.var in tab.data
	# The only problem may be some subsets with full nulls
	##########################
	if(!is.na(t.vars[3]) & t.vars[3]=="AgeRatio"){
		age.data<-full.data$LifeStage
		age.data<-cbind(tab.data,age.data)
		new.tab.data<-unique(tab.data)
		age.ratio<-array()
		for(aa in 1:nrow(new.tab.data)){
			#note that below any missing age (and thus CommonName, etc) data won't be counted
			tmphy<-age.data[which(age.data[,1]==new.tab.data[aa,1] & age.data[,2]==new.tab.data[aa,2] & age.data[,4] %in% c("1","2")),]
			tmpad<-age.data[which(age.data[,1]==new.tab.data[aa,1] & age.data[,2]==new.tab.data[aa,2] & age.data[,4] %in% c("3","4","5","6","7")),]
			if(nrow(tmphy)==0) age.ratio[aa]<-0
			else if(nrow(tmpad)==0) age.ratio[aa]<-0
			else age.ratio[aa]<-nrow(tmphy)/nrow(tmpad)
		}
		new.tab.data<-cbind(new.tab.data[,c(1,2)],age.ratio)
		colnames(new.tab.data)<-c(t.vars[1],t.vars[2],"AgeRatio(H/A)")
		return(new.tab.data)
	}
	#########################
	# If the request is to return SexRatio by x,y,z variables... same as above
	#########################
	if(!is.na(t.vars[3]) & t.vars[3]=="SexRatio"){
		sex.data<-full.data$Sex
		sex.data<-cbind(tab.data,sex.data)
		new.tab.data<-unique(tab.data)
		sex.ratio<-array()
		for(aa in 1:nrow(new.tab.data)){
			tmpm<-sex.data[which(sex.data[,1]==new.tab.data[aa,1] & sex.data[,2]==new.tab.data[aa,2] & sex.data[,4]=="M"),]
			tmpf<-sex.data[which(sex.data[,1]==new.tab.data[aa,1] & sex.data[,2]==new.tab.data[aa,2] & sex.data[,4]=="F"),]
			if(nrow(tmpm)==0) sex.ratio[aa]<-0
			else if(nrow(tmpf)==0) sex.ratio[aa]<-0
			else sex.ratio[aa]<-nrow(tmpm)/nrow(tmpf)
		}
		new.tab.data<-cbind(new.tab.data[,c(1,2)],sex.ratio)
		colnames(new.tab.data)<-c(t.vars[1],t.vars[2],"SexRatio(M/F)")
		return(new.tab.data)
	}
	return(tab.data)
}

#' Make the title for the table produced by cross-tabulation
#' 
#' Makes the title for the table produced by cross-tabulation
#' 
#' @param app.fun The name of the function to apply to the "cell" variable in cross-table
#' @param var1 The name of the "row" variable to crosstabulate
#' @param var2 The name of the "column" variable to crosstabulate
#' @param var3 The name of the "cell" variable to crosstabulate. The function app.fun is applied to values of this variable
makeTitle<-function(app.fun,var1,var2,var3){
	if(!is.na(var3) & (var3=="AgeRatio" | var3=="SexRatio")) {
		title.pref<-""
	}else{
		title.pref<-switch(EXPR=app.fun,
			sum = "Total ",
			NROW = "Count of ",
			max = "Maximum of ",
			min = "Minimum of ",
			mean = "Mean of ",
			se = "Standard Error of ",
			var = "Variance of ")
	}
	if(!is.na(var3)) {
		new.title<-paste(title.pref,var3," by ",var1, sep="")
		#the only edit here was to replace var2 by paste(var2, collapse...)
		if(var1!=var2)new.title<-paste(new.title,"and",paste(var2,collapse=" and "))
	}else{
		new.title<-paste("Frequency of categories of",var1)
		if(var1!=var2)new.title<-paste(new.title,"by",paste(var2,collapse=" and "))
	}
	return(new.title)
}


#' Creates a note for the table produced by cross-tabulation
#' 
#' Creates a note for the table produced by cross-tabulation by counting total number of records and how many have NAs in each field
#' 
#' @param full.data The data table being cross-tabulated
#' @param t.vars A vector of variables to crosstabulate
countRecordsNulls<-function(full.data,t.vars){
	table.note<-paste("Total records = ",nrow(full.data))
	if(sum(is.na(full.data[,which(names(full.data)==t.vars[1])]))>0) table.note<-paste(table.note,"; sampling events with no ",t.vars[1]," = ",sum(is.na(full.data[,which(names(full.data)==t.vars[1])])),sep="")
	if(t.vars[1]!=t.vars[2] & sum(is.na(full.data[,which(names(full.data)==t.vars[2])]))>0) table.note<-paste(table.note,"; sampling events with no ",t.vars[2]," = ",sum(is.na(full.data[,which(names(full.data)==t.vars[2])])),sep="")
	if(!is.na(t.vars[3]) & t.vars[3]!="AgeRatio" & t.vars[3]!="SexRatio" & sum(is.na(full.data[,which(names(full.data)==t.vars[3])]))>0) table.note<-paste(table.note,"; sampling events with no ",t.vars[3]," = ",sum(is.na(full.data[,which(names(full.data)==t.vars[3])])),sep="")
	return(table.note)
}



##NOTE: numeric row and/or column variables will be treated as discrete

#' Create crosstab tables on an AvianData object, version 2
#' 
#' Creates one to many crosstab tables on an AvianData object
#' @name crossTabulate2
#' @param object An AvianData object
#' @param cellVar The string naming the variable "aggregated" and displayed in each cell of the table
#' @param colsVar The string naming the variable that defines the columns of the table 
#' @param groupVars The vector string naming one or more grouping variables, thus defining the rows of the table
#' @param FUN The string naming the function to use to aggregate and create the table, defaulting to NROW
if (!isGeneric("crossTabulate2")) {
	if (is.function("crosstabTable"))
		fun <- crosstabTable
	else fun <- function(object, cellVar, colsVar, groupVars, FUN) standardGeneric("crossTabulate2")
	setGeneric("crossTabulate2", fun)
}


#' Create crosstab tables on an AvianData object, version 2
#' 
#' Creates one to many crosstab tables on an AvianData object
#' 
#' @param object An AvianData object
#' @param cellVar The string naming the variable "aggregated" and displayed in each cell of the table
#' @param colsVar The string naming the variable that defines the columns of the table 
#' @param groupVars The vector string naming one or more grouping variables, thus defining the rows of the table
#' @param FUN The string naming the function to use to aggregate and create the table, defaulting to NROW
setMethod("crossTabulate2", signature(object="AvianData",cellVar = "character", colsVar = "character", groupVars = "character", FUN = "character"),
		function(object, cellVar, colsVar, groupVars, FUN = "NROW") {
			ea.call<-match.call()
			error<-""
			if (is.null(object)==TRUE) {error<-"An AvianData object is required."}
			if (is.null(cellVar)==TRUE) {error<-"A variable to aggregate to crosstabulate is required."}
			if (is.null(colsVar)==TRUE) {error<-"A variable for the columns of the table is required."}
			if (is.null(groupVars)==TRUE) {error<-"One or more variables for the rows of the table is required."}
			if(error!=""){
				class(error)<-"try-error"
				return(error)
			}
			dat<-try(do.call("as.data.frame",args=list(x=object,by="merged"),envir=.GlobalEnv),silent=TRUE)
			if(inherits(dat,"try-error")){
				return(dat)
			}
			n.zeroes<-sum(dat$ObservationCount==0)
			table.note<-""; if(n.zeroes>0)table.note<-paste("Number of events with no detections:",n.zeroes)
			if(grepl("SpatialGroup",paste(names(dat),collapse="::"))){
				dat<-subset(dat,SpatialGroup!="unassigned")
			}
			fml<-paste(cellVar,"~",colsVar,"+",paste(groupVars,collapse="+"))
			if(FUN %in% c("sum","mean","sd","max","min")){
				tmptbl<-aggregate(as.formula(fml),data=dat,FUN=FUN,na.rm=TRUE)
			}else if(FUN=="NROW"){
				dat<-unique(dat[,c(cellVar,colsVar,groupVars)])
				tmptbl<-aggregate(as.formula(fml),data=dat,FUN=FUN)
			}else{
				tmptbl<-aggregate(as.formula(fml),data=dat,FUN=FUN)
			}
			
			tbl<-reshape(data=tmptbl,timevar=colsVar,idvar=groupVars,direction="wide")
			ncv<-names(tbl)[grep(cellVar,names(tbl))]
			ncvn<-substr(ncv,nchar(cellVar)+2,nchar(ncv))
			names(tbl)<-c(groupVars,ncvn)
			for(ccc in ncvn){
				tbl[,ccc]<-ifelse(is.na(tbl[,ccc]),0,tbl[,ccc])
			}
			tbl<-tbl[,c(groupVars,sort(ncvn))]
			
			title<-makeTitle(app.fun=FUN,var1=colsVar,var2=groupVars,var3=cellVar)
			plot.params<-list()
			if(ncol(tbl)==2){
				plot.params$y.var<-names(tbl)[2]
				plot.params$y.label<-substr(title,1,regexpr(" by ",title)-1)
				plot.params$x.var<-names(tbl)[1]
				plot.params$x.label<-names(tbl)[1]
			}
			
			#Now populate the RavianResults object
			res<-new("RavianSummaryTable")
			ResultsTable(res) <- tbl 	 	
			Process(res) <- "crossTabulate"			
			TableTitle(res) <- title			
			Notes(res) <- table.note			
			ProcessParameters(res) <- list(cellVar=cellVar,colsVar=colsVar,groupVars=groupVars,FUN=FUN)
			PlotParameters(res) <- plot.params		
			DataStoreData(res) <- DataDefn(object)
			Call(res) <- ea.call
			return(res)
			
		})
