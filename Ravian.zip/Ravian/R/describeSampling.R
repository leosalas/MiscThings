#' @include AvianData.R
#' @include RavianSummaryTable.R

# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Oct 28, 2009
###############################################################################

###DEPENDENCIES######
#base

#This is a method for an AvianData object, describing the sampling events in the table of effort data
#Each sampling unit described results in a table of descriptive information as follows:
#TransectName|PlotName|StationName, MaxNumber_PointsPerVisit (PC data only), Visit_n,MaxNumPointsVisit_n(PC data only),Visit_m,Max... 
#
#Inputs: the AvianData object to describe
##Example call: (ddd<-describeSampling(data.obj)

#' Describe sampling events in an AvianData object
#' 
#' Describes the sampling events in an AvianData object
#' 
#' @name describeSampling
#' @param object An AvianData object
if (!isGeneric("describeSampling")) {
	if (is.function("describeSampling"))
		fun <- describeSampling
	else fun <- function(object) standardGeneric("describeSampling")
	setGeneric("describeSampling", fun)
}

#' Describe sampling events in an AvianData object
#' 
#' Describes the sampling events in an AvianData object
#' 
#' @name describeSampling
#' @param object An AvianData object
setMethod("describeSampling", signature(object="AvianData"),
		function(object){
			ea.call<-match.call()
			error<-""
			if (is.null(object)) error<-"An AvianData object is required."
			if (error!=""){
				class(error)<-"try-error"
				return(error)
			}
			samp.dat<-try(do.call("as.data.frame",args=list(x=object,source.table="EffortData"),envir=.GlobalEnv),silent=TRUE)
			if(inherits(samp.dat,"try-error")){
				return(samp.dat)
			}
			res.list<-list()	#this is a list of desc.su lists
			max.allyears.nv<-0
			for(yyy in unique(samp.dat$YearCollected)){
				samp.dat.y<-subset(samp.dat,YearCollected == yyy)
				
				obj.t<-as.character(class(object))
				suFld<-switch(obj.t,
						"PointCountData" = "TransectName",
						"BandData" = "StationName",
						"AreaSearchData" = "PlotName")
				
				ssamp.dat<-samp.dat.y[,c(suFld,"Visit","MonthCollected","DayCollected")]
				
				EventMonth<-character()
				for(mmm in ssamp.dat$MonthCollected){
					mnam<-makeMonth(mmm)
					EventMonth<-c(EventMonth,mnam)
				}
				ssamp.dat$EventDate<-paste(EventMonth,ssamp.dat$DayCollected)
				if(obj.t=="PointCountData") ssamp.dat$Point<-samp.dat.y$Point
				ssord<-order(ssamp.dat$Visit,ssamp.dat$MonthCollected,ssamp.dat$DayCollected)
				ssamp.dat<-ssamp.dat[ssord,]
				suN<-switch(obj.t,
						"AreaSearchData" = "PlotName",
						"BandData" = "StationName",
						"PointCountData" = "TransectName"
				)
				
				desc.su<-list()
				if(obj.t=="PointCountData"){
					
					dst.names<-c("Year","TransectName","Max_PointsPerVisit")
					
					for(ttt in unique(ssamp.dat$TransectName)){

						tmp.dt<-subset(ssamp.dat,TransectName == ttt)
						
						arr.nv<-NROW(unique(tmp.dt$Visit)) #max visits for the su=ttt
						if(arr.nv>max.allyears.nv) max.allyears.nv<-arr.nv
						
						#agg.df<-aggregate(tmp.dt$Point,by=list(tmp.dt$Visit),FUN="unique")
						agg.mx<-0
						tmp.v.arr<-vector()
						for(vvv in unique(tmp.dt$Visit)){
							tmp.dv<-subset(tmp.dt,Visit == vvv)
							evd<-paste(unique(tmp.dv$EventDate),collapse=", ")
							agg.dv<-aggregate(tmp.dv$Point,by=list(tmp.dv$EventDate),FUN="unique")
							if(nrow(agg.dv)==1){
								agg.dv.t<-agg.dv[,2]
								nvp<-ifelse(is.null(nrow(agg.dv.t)),1,nrow(agg.dv.t))
								agg.mxdv<-length(agg.dv[,2])*nvp
								if(agg.mxdv>agg.mx)agg.mx<-agg.mxdv
							}else{
								mnpv<-numeric()
								for(ppp in agg.dv[,2]) {
									mnpv<-c(mnpv,length(ppp))
									if(length(ppp)>agg.mx)agg.mx<-length(ppp)
								}
								#agg.mxdv<-max(mnpv)
								agg.mxdv<-paste(mnpv,collapse=", ")
							}
							tmp.v.arr<-as.data.frame(cbind(tmp.v.arr,evd,agg.mxdv),stringsAsFactors=FALSE,row.names=NULL)
						}#su loop
						desc.su.tmp<-as.data.frame(cbind(yyy,ttt,agg.mx,tmp.v.arr),stringsAsFactors=FALSE,row.names=NULL)
						desc.su[[ttt]]<-desc.su.tmp
					}
					res.list[[as.character(yyy)]]<-desc.su
				}else{	#i.e.AreaSearchData and perhaps BandData?
					
					dst.names<-c("Year",suN)
					
					for(ttt in unique(ssamp.dat[,suN])){
						tmp.dt<-subset(ssamp.dat,ssamp.dat[,suN] == ttt)
						
						arr.nv<-NROW(unique(tmp.dt$Visit)) #max visits for the su=ttt
						if(arr.nv>max.allyears.nv) max.allyears.nv<-arr.nv
						
						tmp.v.arr<-character()
						for(vvv in unique(tmp.dt$Visit)){
							tmp.dv<-subset(tmp.dt,Visit == vvv)
							evd<-paste(unique(tmp.dv$EventDate),collapse=",")
							tmp.v.arr<-c(tmp.v.arr,evd)
						}
						desc.su.tmp<-as.data.frame(cbind(yyy,ttt,tmp.v.arr),stringsAsFactors=FALSE,row.names=NULL)
						desc.su[[ttt]]<-desc.su.tmp
					} #su loop
					res.list[[as.character(yyy)]]<-desc.su
				}
			} #year loop
			
			#now combining all years and su's in a matrix - padding to make same number of columns, then collapsing
			final.df<-vector()
			#setting the names...
			if(obj.t=="PointCountData"){#pc
				for(vvv in 1:max.allyears.nv)dst.names<-c(dst.names,paste(c("Visit","MaxPoints"),vvv,sep="_"))
			}else{
				for(vvv in 1:max.allyears.nv)dst.names<-c(dst.names,paste("Visit",vvv,sep="_"))
			}

			#padding the year*su matrices...BUG HERE!!!
			for(yyy in unique(samp.dat$YearCollected)){
				samp.dat.y<-subset(samp.dat,YearCollected == yyy)
				for(ttt in unique(samp.dat.y[,suN])){
					desc.df<-res.list[[as.character(yyy)]][[ttt]]
					if(obj.t=="PointCountData"){#pc
						if(ncol(desc.df)<((2*max.allyears.nv) + 3)){
							ncadd<-((2*max.allyears.nv)+3)-ncol(desc.df)
							for(ppp in 1:ncadd) desc.df<-cbind(desc.df,"NA")
						}
						names(desc.df)<-dst.names
					}else{
						if(ncol(desc.df)<(max.allyears.nv + 2)){
							ncadd<-(max.allyears.nv + 2)-ncol(desc.df)
							for(ppp in 1:ncadd) desc.df<-cbind(desc.df,"NA")
						}
						names(desc.df)<-dst.names
					}
					final.df<-rbind(final.df,desc.df)
				}
			}
			
			#order by Transect, then Year
			ordv<-order(final.df[,suN],final.df$Year)
			final.df<-final.df[ordv,]
			
			#prepare output object...
			res<-new("RavianSummaryTable")
			ResultsTable(res) <- final.df 	 	
			Process(res) <- "describeSampling"			
			TableTitle(res) <- paste("Description of Sampling Events")			
			PlotParameters(res) <- list()		
			DataStoreData(res) <- DataDefn(object)
			Call(res) <- ea.call
			return(res)
		})
		

#' Function that returns the abbreviated name of the month
#' 
#' Function that returns the abbreviated name of the month
#' @param mv A numeric value between 1 and 12 indicating the month
makeMonth<-function(mv){
		monthName<-switch(as.character(mv),
					"1" = "Jan",
					"2" = "Feb",
					"3" = "Mar",
					"4" = "Apr",
					"5" = "May",
					"6" = "Jun",
					"7" = "Jul",
					"8" = "Aug",
					"9" = "Sep",
					"10" = "Oct",
					"11" = "Nov",
					"12" = "Dec")
}
		
