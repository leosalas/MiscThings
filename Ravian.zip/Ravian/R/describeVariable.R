#' @include AvianData.R
#' @include RavianSummaryTable.R

# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Oct 28, 2009
###############################################################################

###DEPENDENCIES######
#base

#This is a method for an AvianData object, describing a variable in the table of data
#(i.e., merged sampling and observation tables) in the object.  Each variable described results in
#a table of descriptive statistics or a table of frequencies 
#
#The following output will be produced in the descriptive statistics table for continuous variables: 
#N, mean, median, standard deviation, minimum and maximum values
#
#For discrete variables (including numeric specified to be treated as discrete, see below), the following 
#output will be produced in the descriptive statistics table: Richness, Shannon H, Simpson and Evenness indices
#Note: continuous variables will be forced to discrete categories via factoring
#
#Inputs: the AvianData object to populate and describe, the name of the variable to describe, and how to treat it:
#whether as discrete or as continuous.
##Example call: (ddd<-describeVariable(data.obj,"Age","d")

#' Describe variable in an AvianData object
#' 
#' Describes a variable in an AvianData object
#' 
#' @name describeVariable
#' @param object An AvianData object
#' @param var A string naming a variable to describe; must be a variable in the data object 
#' @param type A string indicating whether to treat as factor ("d" as in discrete), ("c") continuous
if (!isGeneric("describeVariable")) {
	if (is.function("describeVariable"))
		fun <- describeVariable
	else fun <- function(object, var, type) standardGeneric("describeVariable")
	setGeneric("describeVariable", fun)
}

#' Describe variable in an AvianData object
#' 
#' Describes a variable in an AvianData object, returns a RavianSummaryTable object
#' 
#' @param object An AvianData object
#' @param var A string naming a variable to describe; must be a variable in the data object 
#' @param type A string indicating whether to treat as factor ("d" as in discrete), ("c") continuous
setMethod("describeVariable", signature(object="AvianData"),
		function(object, var, type) {
			ea.call<-match.call()
			error<-""
			if (is.null(object)) error<-"An AvianData object is required."
			if(is.null(var) | is.na(var) | var=="") error<-"The name of a variable to describe is required."
			if(is.null(type) | is.na(type) | type=="") error<-"The type (discrete or continuous - c or d) of a variable to describe is required."
			if (error!=""){
				class(error)<-"try-error"
				return(error)
			}
			full.data<-merge(EffortData(object),ObsData(object), all.x=T)
			na.recs<-sum(is.na(full.data$ObservationCount))
			full.data$ObservationCount<-ifelse(is.na(full.data$ObservationCount)==TRUE,0,full.data$ObservationCount)
			#Some band data may have no net hours.  Must handle this... Other cases??? If so, consider changing signature.
			if(ProtocolType(object)=="Band"){full.data$NetHours<-ifelse(is.na(full.data$NetHours)==TRUE,0,full.data$NetHours)}
			#retrieve the actor...
			d.var<-if(var=="CommonName"){
				full.data[,c("CommonName","ObservationCount")]
			}else{
				full.data[,which(names(full.data)==var)]
			}
			t.recs<-NROW(d.var)
			table.note<-paste("Total number of records summarized:",t.recs)
			
			if(t.recs>0 & t.recs>na.recs){
				#describe now...
				if(type == "c"){
					#N, mean, median, standard deviation, minimum and maximum values
					tbl.res<-getContinuousDescription(d.var)
				}else{
					#Richness, Shannon H, Simpson and Evenness indices
					table.note<-paste(table.note,"; number of records with null value: ",na.recs,".",sep="")
					tbl.res<-try(getSHE(d.var))	
				}	
				if(inherits(tbl.res,"try-error")) { #could not create the description table
					tbl.err<-paste(tbl.res,collapse="")
					class(tbl.err)<-"try-error"
					return(tbl.err)
				} else {
					#Store results in RavianSummaryTable object
					res<-new("RavianSummaryTable")
					ResultsTable(res) <- tbl.res 	 	
					Process(res) <- "describeVariable"			
					TableTitle(res) <- paste("Description of variable",var)			
					Notes(res) <- table.note			
					ProcessParameters(res) <- list(variable=var,type=type)
					PlotParameters(res) <- list()		
					DataStoreData(res) <- DataDefn(object)
					Call(res) <- ea.call
					return(res)
				}
			}else{
				tbl.err<-paste("Ravian Message: The field",var,"has no describable data.")
				class(tbl.err)<-"try-error"
				return(tbl.err)
			}
			
		})


#' Function that returns the description of a continuous variable
#' 
#' Function that returns the description of a continuous variable, reporting N, mean, median, standard deviation, minimum and maximum values
#' 
#' @param c.var A data.frame with one column - the column holds the data for the variable being described
getContinuousDescription<-function(c.var){
	tbl.res<-c(NROW(c.var),round(mean(c.var,na.rm=TRUE),2),round(median(c.var,na.rm=TRUE),2),
			round(sd(c.var,na.rm=TRUE),2),min(c.var,na.rm=TRUE),max(c.var,na.rm=TRUE))
	fc<-c("N","Mean","Median","Standard Deviation","Minimum","Maximum")
	tbl.res<-as.data.frame(cbind(fc,tbl.res))
	colnames(tbl.res)<-c("Parameter","Value")
	return(tbl.res)
}
		
#' Function that returns the description of a discrete variable
#' 
#' Function that returns the description of a discrete variable, reporting N, richness, diversity (Shannon), dominance (Simpson) and evenness
#' 
#' @param dat.obj A data.frame with one column - the column holds the data for the variable being described
getSHE<-function(dat.obj){
	#removing na's and nulls first
	dat.obj<-na.omit(dat.obj)
	tot.rec<-sum(dat.obj$ObservationCount)
	r.val<-NROW(unique(dat.obj$CommonName))
	freq.df<-aggregate(as.formula("ObservationCount~CommonName"),data=dat.obj,FUN="sum")
	freq.df<-subset(freq.df,ObservationCount>0)	#Should always be, but just in case...
	freq.df$p_i<-freq.df$ObservationCount/tot.rec
	freq.df$logp_i<-log(freq.df$p_i)
	freq.df$p_i_logp_i<-freq.df$p_i*freq.df$logp_i
	freq.df$p_i2<-freq.df$p_i*freq.df$p_i
	#H' = -1*sum(p_i * log(p_i))
	h.val= -1 * (sum(freq.df$p_i_logp_i))
	#S=1/sum(p_i^2)
	s.val=1/(sum(freq.df$p_i2))
	#Evenness = H'/H'max, with H'max = log(r.val)
	e.val=h.val/log(r.val)
	ret.she<-as.data.frame(c(r.val,round(h.val,3),round(s.val,3),round(e.val,3)))
	fc<-c("Richness","Shannon (H')","Simpson (1/S)","Evenness (H'/H'max)")
	ret.she<-cbind(fc,ret.she)
	colnames(ret.she)<-c("Index","Value")
	return(ret.she)
}

