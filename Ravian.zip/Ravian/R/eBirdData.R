#' @include AvianData.R

################################################################################
## eBirdData.R
## TODO: Add comment
## 
## Author: Mark Herzog
## Contact: mherzog@prbo.org
## Creation Date: May 30, 2009
################################################################################

#' eBirdData subclass of AvianData Class
#' 
#' @title eBirdData subclass of AvianData Class
#' @param ObsData dataframe that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType always "AreaSearch"
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @exportClass eBirdData
setClass("eBirdData", contains=c("AvianData"),
		prototype=prototype(ProtocolType="eBird"))

#' Instantiate a new eBirdData object
#' @return The eBirdData object 
setMethod("initialize",
		signature(.Object = "eBirdData"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)