#' @include AvianData.R
#' @include RavianResultsGraph.R

# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Apr 6, 2010
###############################################################################


## The intent is that this file will contain a collection of methods on AvianData class
## to generate bar and circular plots of abundance, or of any other counts/numeric parameter
## as well as other phenology methods, such as DOFA plots and estimates
## We start with the circular plots

#' Set generic to  method pheno.plot of AvianData object
#' 
#' @name pheno.plot
#' @param object A AvianData object
#' @param fields A string vector naming up to 5 fields to plot in a single plot, or in 5x1 facet
#' @param bin.size A numeric value specifying the bin size in Julian days for sum of values of fields (across days and years)
#' @param type A string specifying the type of plot.  Possible values: "bar", "polar", "circular" ("barpolar" not available)
if (!isGeneric("pheno.plot")) {
	if (is.function("pheno.plot"))
		fun <- pheno.plot
	else fun <- function(object, fields, bin.size, type, ...) standardGeneric("pheno.plot")
	
	setGeneric("pheno.plot", fun)
}

#' Make phenology plot for an AvianData object
#' 
#' @name pheno.plot
#' @param object A AvianData object
#' @param fields A string vector naming up to 5 fields to plot in a single plot, or in 5x1 facet
#' @param bin.size A numeric value specifying the bin size in Julian days for sum of values of fields (across days and years)
#' @param type A string specifying the type of plot.  Possible values: "bar", "polar", "circular" ("barpolar" not available)
setMethod("pheno.plot",
		signature(object = "AvianData"),
		function(object, fields=c("ObservationCount"), bin.size = 7, type="bar", ...) 
		{
			ea.call<-match.call()
			bz=bin.size
			if(is.null(bz)) bz<-7
			assign("bz",bz,envir=.GlobalEnv)
			fv<-fields
			if(is.null(fv))fv<-"ObservationCount"
			assign("fv",fv,envir=.GlobalEnv)
			#here check that numerics and factor levels do not add up to > 5!
			obs.df<-ObsData(object)
				#get the number of numerics and levels of factors, building title...
				k<-0	#The count variable k is very important below...
				titl.n<-array()
				for(i in 1:NROW(fv)){
					#if(is.numeric(obs.df[,which(names(obs.df)==fv[i])])){
					if(fv[i]=="ObservationCount"){
						k<-k+1
						titl.n[k]<-fv[i]
					}else{
						u<-k+1
						titl.n[u]<-paste("levels of",fv[i])
						k<-k+NROW(levels(as.factor(obs.df[,which(names(obs.df)==fv[i])])))
					}
				}
				if(k>4){
					error<-"User error: fields to plot are, combining levels of factor fields, more than 4, which exceeds the limit of this method."
					return(error)
				}
				assign("k",k,envir=.GlobalEnv)
			#Need to summarize by date 
			#NOTE: we don't use effort here...
			lbv<-ceiling(366/bz)
			if((366/bz)<(floor(366/bz)+ 0.5)) lbv<-floor(366/bz)
			ref.df<-as.data.frame(c(1:lbv))
			names(ref.df)<-c("bin.v")
			obs.df2<-make.bins(obs.df,bz,lbv)
			##Here subsetting by covariates
			for(i in 1:NROW(fv)){
				melt.data <- melt(obs.df2,id.vars="bin.v",measure.vars=fv[i])
				#treat ObservationCount as numeric, everything else as factor
				#if(is.factor(obs.df[,which(names(obs.df)==fv[i])])){
				if(fv[i]!="ObservationCount"){
					temp.table <- data.frame(cast(melt.data,bin.v~value,fun.aggregate=NROW))
				}else{
					temp.table <- data.frame(cast(melt.data,bin.v~.,fun.aggregate=sum))
				}
				full.table<-merge(ref.df,temp.table, all.x=TRUE)
				##Now need to build list of column names!
				#if(is.factor(obs.df[,which(names(obs.df)==fields[i])])){
				if(fv[i]!="ObservationCount"){
					nft<-levels(as.factor(obs.df[,which(names(obs.df)==fv[i])]))
					names(full.table)<-c("bin",nft)
				}else{
					names(full.table)<-c("bin",fv[i])
				}
				#Now making NAs into 0s
				for(j in 2:NROW(names(full.table))){
					full.table[,j]<-ifelse(is.na(full.table[,j])==TRUE,0,full.table[,j])
				}
				#then sort ascendingly by bin
				ft.ind <- order(full.table$bin, decreasing=FALSE)
				full.tst <- full.table[ft.ind,]
				#now append to cummulative table
				if(i==1){
					full.ts<-full.tst
				}else{
					nmts<-names(full.ts)
					full.ts<-cbind(full.ts,full.tst[,c(-1)])
					names(full.ts)<-c(nmts,names(full.tst)[c(-1)])
				}
			}
			
			
			##############################################################################################################
			#Data are ready to plot
			#Now sort this mess and create the graph object, populate it, add title, etc.
			#then plot the data in the bins using geom_bar.  Facetgrid 5x1 if more than 1 var...
			xlv<-paste("Julian Date (",bz,"-day bins)",sep="")
			tp<-data.frame(c(10,40,70,100,130,160,190,220,250,280,310,340),c(20),c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"))
			colnames(tp)<-c("xpos","ypos","mo")
			assign("tp",tp,envir=.GlobalEnv)
			assign("xlv",xlv,envir=.GlobalEnv)
			#Do we need to distinguish between 1 and n below??
			if(type=="bar"){ #this works beautifully, need to scale y-axes to be the same across.
				nk=k+1
				full.ts.w<-reshape(data=full.ts, idvar="bin", varying=list(2:nk), times=names(full.ts[2:nk]), timevar="PlotVar", v.names="count.val", direction="long")
				n.bin<-(full.ts.w$bin*bz)+5
				full.ts.w<-cbind(full.ts.w,n.bin)
				assign("full.ts.w",full.ts.w,envir=.GlobalEnv)
				bbb<-ggplot(full.ts.w, aes(x=n.bin, y=count.val), height=2) + ggplot2::geom_bar(stat="identity") + ggplot2::xlab(xlv) + ggplot2::ylab("Counts") + ggplot2::theme_bw() 
				if(k>1)bbb<-bbb + ggplot2::facet_grid(PlotVar ~ .)  #facet_wrap(~ PlotVar, ncol=2)
			}
			
			if(type=="polar"){ #this works beautifully too
				nk=k+1
				full.ts$bin<-full.ts$bin*bz
				full.ts.w<-reshape(data=full.ts, idvar="bin", varying=list(2:nk), times=names(full.ts[2:nk]), timevar="PlotVar", v.names="count.val", direction="long")
				assign("full.ts.w",full.ts.w,envir=.GlobalEnv)
				#mxb<-max(full.ts.w$count.val)
				bbb<-ggplot(full.ts.w, aes(x=bin, y=count.val), height=2) + ggplot2::geom_bar(stat="identity") + ggplot2::coord_polar() + 	#, height=2
						#ggplot2::scale_y_continuous(limits=c(0,mxb)) +
						ggplot2::xlab(NULL) + ggplot2::ylab("Counts") + ggplot2::theme_bw() + ggplot2::theme(axis.text.x = element_blank()) +
						ggplot2::geom_text(data = tp, aes(x=xpos, y=ypos, label=mo), size =4)
				if(k>1)bbb<-bbb + ggplot2::facet_grid(. ~ PlotVar)  #facet_wrap(~ PlotVar, ncol=2) 
			}

			if(type=="barpolar"){ #can't do this and store as ggplot object...
				#make sure there is only one variable to plot by forcing it to use the first one!
				assign("full.ts",full.ts,envir=.GlobalEnv)
				bb1<-ggplot(full.ts, aes(x=bin, y=full.ts[,2]), height=2) + ggplot2::geom_bar(stat="identity") + ggplot2::xlab(xlv) + ggplot2::ylab("Counts") + ggplot2::theme_bw()
				bb2<-ggplot(full.ts, aes(x=bin*bz, y=full.ts[,2]), height=2) + ggplot2::geom_bar(stat="identity") + ggplot2::coord_polar() + 
						ggplot2::xlab(NULL) + ggplot2::ylab("Counts") + ggplot2::theme_bw() + ggplot2::theme(axis.text.x = element_blank()) +
						ggplot2::geom_text(aes(x, y, label = tp$mo), data = data.frame( x = tp$xpos, y = tp$ypos), size =4)
				grid.newpage()
				pushViewport(viewport(layout = grid.layout(3,2)))
				print(bb2, vp = vplayout(1:2,1:2))
				print(bb1, vp = vplayout(3,1:2))
			} 
			
			if(type=="circular"){
				#set the canvas for polar plots like so:
				#Main circles...
				mcdf<-data.frame()
					t=seq(0,2*pi,by=0.01)
				mcdf<-makeCircleDf(cdf=mcdf,tseq=t,crad=5.4,lw=1)
				mcdf<-makeCircleDf(cdf=mcdf,tseq=t,crad=4.6,lw=1)
				assign("mcdf",mcdf,envir=.GlobalEnv)
				p<-ggplot(mcdf, aes(xv,yv)) + ggplot2::xlab(NULL) + ggplot2::ylab(NULL) + ggplot2::theme_bw() + ggplot2::scale_x_continuous(limits = c(-7,9)) + ggplot2::scale_y_continuous(limits = c(-7,7)) +
						ggplot2::theme(axis.text.x = element_blank()) + ggplot2::theme(axis.text.y = element_blank()) + ggplot2::theme(axis.ticks = element_blank()) + ggplot2::theme(panel.grid.major = element_blank())
				plc<-p+geom_point(size = 1, colour="lightgray") 
				#Main segments
				msdf<-data.frame()
				tst<-(-3*pi)/2
				for(u in 1:6){
					t=seq(tst,tst-(pi/6),by=-0.01)
					msdf<-makeSegmentDf(sdf=msdf,tseq=t,str=4.6,edr=5.4)
					tst<-tst-(pi/3)
				}
				assign("msdf",msdf,envir=.GlobalEnv)
				pf<-plc + ggplot2::geom_segment(data = msdf, aes(x = sxv, y = syv, xend = exv, yend = eyv), size = 2, colour = "lightgray")
				#add month letters...
				trad<-5
				tdf<-data.frame()
				for(i in 1:12){
					av<-(-19*pi/12)-((i-1)*pi/6)
					txv<-trad*cos(av)
					tyv<-trad*sin(av)
					ttf<-c(txv,tyv)
					tdf<-rbind(tdf,ttf)
				}
				tdf<-cbind(tdf,c("j","f","m","a","m","j","j","a","s","o","n","d"))
				names(tdf)<-c("mtx","mty","mo")
				assign("tdf",tdf,envir=.GlobalEnv)
				pfm<-pf + ggplot2::geom_text(data = tdf, aes(x=mtx, y=mty, label=mo))
				#add the center circle in light gray...
				mccdf<-data.frame()
					t=seq(0,2*pi,by=0.01)
				mccdf<-makeCircleDf(cdf=mccdf,tseq=t,crad=4.6,lw=1)
				assign("mccdf",mccdf,envir=.GlobalEnv)
				pfmc<-pfm + ggplot2::geom_polygon(data=mccdf, aes(x = xv, y= yv), fill="lightgray", colour = "white", size = 1)
				#add the guide lines also as geom_segments
				mgdf<-data.frame()
				stang<-0
				for(u in 1:6){
					mgdf<-makeGuidesDf(mgdf,sang=stang,eang=stang+pi)
					stang<-stang+(pi/6)
				}
				assign("mgdf",mgdf,envir=.GlobalEnv)
				pfms<-pfmc + ggplot2::geom_segment(data = mgdf, aes(x = gxv, y = gyv, xend = gexv, yend = geyv), size = 1, colour = "white")
				#now add the segments for the observations as follows
				mdcfd<-data.frame()	#segments data frame
				mdbcd<-data.frame()	#guide circles data frame
				br<-4.5
				py<-7
				mxmprad<-max(full.ts[,2:(k+1)])	#max value to map counts to
				mxmr<-ceiling(mxmprad/3) 	#this tells the size of the segments: if max count is 28, each segment is of size 10
				if(mxmprad<4)mxmr<-mxmprad
				assign("mxmr",mxmr,envir=.GlobalEnv)
				assign("mxmprad",mxmprad,envir=.GlobalEnv)
				for(g in 1:k){ 
					vbr<-br-(g*0.8)  #for each variable, set the base radius...(here's where segments begin)
					t=seq(0,2*pi,by=0.01)	#making the guide circle for each var
					mdbcd<-makeCircleDf(cdf=mdbcd,tseq=t,crad=vbr,lw=1) #guide circle
					py<-c(py,(7-(0.7*g)))	#y-pos of legend for each var
					for(i in 1:nrow(full.ts)){
						if(full.ts[i,(g+1)]!=0){
							tst<-((-1)*((full.ts[i,1])-1)*2*pi/lbv)+(pi/2)
							ted<-((-1)*(full.ts[i,1])*2*pi/lbv)+(pi/2)
							t=seq(tst,ted,by=-0.01)
							sgnd<-(ceiling((full.ts[i,(g+1)])/mxmr))*0.2 #map the count value to the segment length scale...
							#now make the segment
							mdcfd<-makeSegmentDf(sdf=mdcfd,tseq=t,str=vbr,edr=vbr+sgnd)
						}
					}
				}
				#plotting the data segments...
				assign("mdcfd",mdcfd,envir=.GlobalEnv)
				pma<-pfms + ggplot2::geom_segment(data = mdcfd, aes(x = sxv, y = syv, xend = exv, yend = eyv), size = 2, colour = "black")
				#adding the guide circles...
				assign("mdbcd",mdbcd,envir=.GlobalEnv)
				pmb<-pma+geom_point(data=mdbcd, size = 1, colour="white")
				#adding the legend
				nts<-names(full.ts)[c(-1)]
				vtd<-as.data.frame(cbind(c(7),py,c("Variables plotted:",nts)))
				names(vtd)<-c("mtx","mty","mo")
				assign("vtd",vtd,envir=.GlobalEnv)
				pmc<-pmb + ggplot2::geom_text(data=vtd,aes(x=as.numeric(as.character(mtx)), y=as.numeric(as.character(mty)), label=mo), size = 4, hjust=1)
				#add the reference slice...
				ssdf<-data.frame()
				t=seq(-3*pi/2,-19*pi/12,by=-0.01)
				ssdf<-makeSegmentDf(sdf=ssdf,tseq=t,str=4.6,edr=5.2)
				if(k>1)ssdf<-makeSegmentDf(sdf=ssdf,tseq=t,str=3.9,edr=4.5)
				if(k>2)ssdf<-makeSegmentDf(sdf=ssdf,tseq=t,str=3.2,edr=3.8)
				if(k>3)ssdf<-makeSegmentDf(sdf=ssdf,tseq=t,str=2.5,edr=3.1)
				nsxv<-ssdf$sxv + 7.2
				nexv<-ssdf$exv + 7.2
				nsyv<-ssdf$syv + 1.4
				neyv<-ssdf$eyv + 1.4
				ssdf<-cbind(ssdf,nsxv,nexv,nsyv,neyv)
				assign("ssdf",ssdf,envir=.GlobalEnv)
				pmd<-pmc + ggplot2::geom_segment(data = ssdf, aes(x = nsxv, y = nsyv, xend = nexv, yend = neyv), size = 2, colour = "lightgray")
				#last, add the scale
				bbb<-pmd + ggplot2::geom_text(aes(x=7, y=-4.3, label="Counts:"), size = 4, hjust=1) +
						ggplot2::geom_rect(xmin = 7.2, xmax = 7.5, ymin = -5.1, ymax = -4.9, colour="black", fill="black") +
						ggplot2::geom_text(aes(x=7, y=-4.9, label=paste("1 -",mxmr)), size = 4, hjust=1)
				if(mxmprad>3)bbb<-bbb +
						ggplot2::geom_rect(xmin = 7.2, xmax = 7.5, ymin = -6.4, ymax = -5.8, colour="black", fill="black") +
						ggplot2::geom_text(aes(x=7, y=-5.5, label=paste(mxmr+1,"-",mxmr*2)), size = 4, hjust=1)
				if(mxmprad>6)bbb<-bbb +
						ggplot2::geom_rect(xmin = 7.2, xmax = 7.5, ymin = -5.7, ymax = -5.3, colour="black", fill="black") +
						ggplot2::geom_text(aes(x=7, y=-6.2, label=paste((mxmr*2)+1,"-",mxmprad)), size = 4, hjust=1)
				
			}
			#Now here create the RR object and populate it...
			if(class(bbb)=="try-error"){
				return(bbb)
			}else if(!inherits(bbb,"ggplot")){
				class(bbb)<-"try-error"
				return(bbb)
			}else{
				class(bbb)<-"ggplot"
				res.graph<-new("RavianResultsGraph")
				ResultsGraph(res.graph)<-bbb
				var.list<-paste(titl.n,collapse=" and ")
				GraphTitle(res.graph)<-paste("Phenology plot of", var.list,"from",ProtocolType(object),"data")
				Notes(res.graph)<-"testing too"
				GraphParameters(res.graph)<-list(fields=fields,bin.size=bin.size,type=type)
				Call(res.graph)<- ea.call
				return(res.graph)
		}
	})

#' make.bins: function to make bins from a table provided by method pheno.plot
#' 
#' This function assings values to bins based on the number of bins and JulianDay
#' @param data.table A data.frame provided by method pheno.plot.  See method for details
#' @param bin.size A number indicating the number of bins in the table
#' @param lbv A number indicating the cutoff JulianDay value of members of the highest bin 
#' 		(i.e., anything above this JulianDay value belongs to this bin)
make.bins<-function(data.table, bin.size=7, lbv=52){
	#adding the bins field to the table...
	bin.v<-ceiling(data.table$JulianDay/bin.size)
	if(bin.v>lbv)bin.v<-lbv
	data.table2<-cbind(data.table,bin.v)
	return(data.table2)
}

#' makeCircleDf: function to make a data.frame of xy values to make a circular plot
#' 
#' This function calculates the x and y coordinates (vector value) of a point given an angle (tseq) and magnitude of vector (crad)
#' @param cdf A data.frame provided by method pheno.plot, to which calculated coordinates are added.  See method for details
#' @param tseq A number indicating the angle of the vector of the point
#' @param crad A number indicating the magnitude of the vector of the point 
#' @param lw A number for the plotting function - indicates line width
makeCircleDf<-function(cdf,tseq,crad,lw){
	#NOTE:cdf must have 3 columns, named xv,yv and wv
	xv<-cos(tseq)*crad
	yv<-sin(tseq)*crad
	wv<-lw
	clv<-1
	if(lw==0)clv<-2
	dd<-as.data.frame(cbind(xv,yv,wv,clv))
	cdf<-rbind(cdf,dd)
	return(cdf)
}

#' makeSegmentDf: function to make a data.frame of xy values to draw an arc in a circular plot
#' 
#' This function calculates the x and y coordinates (vector value) of the start and end points of an arc
#'  	given an angle (tseq) and magnitude of vector (str, edr)
#' @param sdf A data.frame provided by method pheno.plot, to which calculated coordinates are added.  See method for details
#' @param tseq A number indicating the angle of the vector of the points
#' @param str A number indicating the magnitude of the vector of the starting point 
#' @param edr A number indicating the magnitude of the vector of the ending point 
makeSegmentDf<-function(sdf,tseq,str,edr){
	#Note: sdf must have 4 columns named sxv,syv,exv,eyv
	sxv<-cos(tseq)*str
	syv<-sin(tseq)*str
	exv<-cos(tseq)*edr
	eyv<-sin(tseq)*edr
	dd<-as.data.frame(cbind(sxv,syv,exv,eyv))
	sdf<-rbind(sdf,dd)
	return(sdf)
}

#' makeGuidesDf: function to make a data.frame of xy values to draw an arc in a circular plot whose role is to act as plot guides 
#' 
#' This function calculates the x and y coordinates (vector value) of the start and end points of an arc
#'  	given an angle (sang, eang) and magnitude of vector (constant = 5.4)
#' @param gdf A data.frame provided by method pheno.plot, to which calculated coordinates are added.  See method for details
#' @param sang A number indicating the starting angle of the vector of the points
#' @param eang A number indicating the ending angle of the vector of the points 
makeGuidesDf<-function(gdf,sang,eang){
	#Note: gdf must have 4 columns: gxv,gyv,gexv,geyv
	gxv<-cos(sang)*5.4
	gyv<-sin(sang)*5.4
	gexv<-cos(eang)*5.4
	geyv<-sin(eang)*5.4
	dd<-as.data.frame(cbind(gxv,gyv,gexv,geyv))
	gdf<-rbind(gdf,dd)
}

