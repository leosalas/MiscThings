#' @include RavianUtils.R
#' @include AvianData.R
#' @include RavianSampleSummaryTable.R

###############################################################################
# PointCountData.R
# TODO: Add comment
# 
## Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org
# Creation Date: May 30, 2009
###############################################################################

#' PointCountData class - subclass of AvianData Class
#' 
#' PointCountData class - subclass of AvianData Class
#' 
#' @param ObsData dataframe that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType always "PointCount"
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @exportClass PointCountData
setClass("PointCountData", contains=c("AvianData"), 
		prototype=prototype(ProtocolType="PointCount",
				Fields = list(obs=c("ProjectCode", "ProjectName", "LocalityID", "SamplingUnitId",
								"StudyArea", "Transect", "TransectName", "Point","DecimalLatitude","DecimalLongitude",
								"Visit", "YearCollected", "MonthCollected", 
								"JulianDay", "Time", "Collector",
								"ScientificName", "CommonName", "SpeciesCode", 
								"PhylogenOrder", "DistanceFromObserver", "FlyOver", 
								"InFocalHabitat", "HabitatType", "ObservationCount", "NoObservations"),
						event=c("ProjectCode", "ProjectName", "LocalityID", "SamplingUnitId", "StudyArea", 
								"Transect", "TransectName", "Point", "DecimalLatitude","DecimalLongitude","Visit", "ProtocolCode",
								"YearCollected", "MonthCollected", "DayCollected", "JulianDay",
								"ProportionAreaSurveyed")
				)))

#' Instantiate a new PointCountData object
#' 
#' @return The PointCountData object
setMethod("initialize",
		signature(.Object = "PointCountData"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)

#' Estimate Abundance from PointCountData object
#' 
#' @param object A PointCountData object.
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param guild String giving a general name for the group of taxa, if provided (must not have blank spaces)
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
#' @param obs.group String naming the observation groups the data must be divided into - e.g., HabitatType, or Sex (must not have blank spaces). 
#' @param siteCovs A characgter vector naming the site covariates of an imperfect detection model
#' @param obsCovs A list containing data frames, each naming an observation covariate of an imperfect detection model
setMethod("estimateAbundance", signature(object = "PointCountData"),  
		function(object, summarize.by="Transect", time.var="YearCollected",  
				guild="",spatial.units="",obs.group="",siteCovs="",obsCovs="",...) {
			#OJO - must change the wrapper!
			ea.call<-match.call()
			if (is.null(object)) stop("A data object is required.")
			guild.n<-ifelse(guild=="","ScientificName","TaxonGroup")
			guild.t<-ifelse(guild=="","ScientificName",guild)
			sb.name<-ifelse(spatial.units=="",summarize.by,spatial.units)
			support.obs<-""
			id.vars<-unique(c(time.var,summarize.by,guild.n,"Visit","Point"))	#"ProjectCode",
			cast.eq<-paste(paste(id.vars,sep=""),collapse="+")	#"ProjectCode",
			cast.eq<-paste(cast.eq,"~ObservationCount",sep="")
			sort.vars<-c(time.var,guild.n,summarize.by) #sort in this order "ProjectCode",
			if(obs.group!=""){
				id.vars<-c("ObservationsGroup",id.vars)
				cast.eq<-paste("ObservationsGroup",cast.eq,sep="+")
				support.obs<-unique(ObsData(object)[,c("ObservationsGroup")])
				sort.vars<-c(sort.vars,"ObservationsGroup")
			}
			support.site.fields<-c(time.var,summarize.by,"Point","Visit")	#"ProjectCode",
			support.effort<-unique(EffortData(object)[,support.site.fields])
			evt.N<-NROW(support.effort)
			if(length(support.obs)>1){
				support.effort<-merge(support.effort,as.data.frame(support.obs))
				support.site.fields<-c(support.site.fields,"ObservationsGroup")
				names(support.effort)<-support.site.fields
			}
			support.guild<-unique(ObsData(object)[,c("ScientificName","CommonName","SpeciesCode","PhylogenOrder")])
			support.guild.names<-c("ScientificName","CommonName","SpeciesCode","PhylogenOrder")
			if(guild!=""){
				support.guild<-unique(ObsData(object)[,"TaxonGroup"])
				support.guild.names<-c("TaxonGroup")
			}
			support.effort<-merge(support.effort,as.data.frame(support.guild))
			support.site.fields<-c(support.site.fields,support.guild.names)
			names(support.effort)<-support.site.fields
			#First collapse by guild, if not SpeciesCode
			melt.data <- melt(ObsData(object),id.vars,measure.vars="ObservationCount",variable_name="ObservationCount")
			base.table <- data.frame(cast(melt.data,cast.eq,fun.aggregate="sum"))
			base.data<-merge(support.effort,base.table, all.x=TRUE)
			obs.N<-nrow(base.table)	#total number of observation records
			base.data$ObservationCount<-ifelse(is.na(base.data$ObservationCount)==TRUE,0,base.data$ObservationCount)
			if(grepl("PhylogenOrder",paste(names(base.data),collapse=":"))==TRUE) base.data$PhylogenOrder<-ifelse(is.na(base.data$PhylogenOrder)==TRUE,0,base.data$PhylogenOrder)
			
			res.ab.df<-array()
			rr<-0
			#pgl<-unique(base.data$ProjectCode)
			#for(ppp in pgl){
				ggl<-unique(base.data[,guild.n])
				for(ggg in ggl){
					tgl<-unique(base.data[,time.var])
					for(ttt in tgl){
						sgl<-unique(base.data[,summarize.by])
						for(sss in sgl){
							if(obs.group!=""){
								ogl<-unique(base.data$ObservationsGroup)
								for(ooo in ogl){
									tdt<-subset(base.data,base.data$ObservationsGroup==ooo & base.data[,time.var]==ttt & base.data[,summarize.by]==sss & base.data[,guild.n]==ggg)	#base.data$ProjectCode==ppp & 
									if(nrow(tdt)>0){
										rr<-rr+1
										if(rr==1){
											res.ab.df<-c(ggg,ttt,sss,ooo,estAbundOccup(pc.dat=tdt,func="avg"))	#ppp,
										}else{
											res.ab.df<-rbind(res.ab.df,c(ggg,ttt,sss,ooo,estAbundOccup(pc.dat=tdt,func="avg")))	#ppp,
										} 
									}
								}
							}else{
								tdt<-subset(base.data,base.data[,time.var]==ttt & base.data[,summarize.by]==sss & base.data[,guild.n]==ggg)		#base.data$ProjectCode==ppp & 
								if(nrow(tdt)>0){
									rr<-rr+1
									if(rr==1){
										res.ab.df<-c(ggg,ttt,sss,estAbundOccup(pc.dat=tdt,func="avg"))  #ppp,
									}else{
										res.ab.df<-rbind(res.ab.df,c(ggg,ttt,sss,estAbundOccup(pc.dat=tdt,func="avg")))	#ppp,
									}
								}
							}
						}
					}
				}
			#}
			if(is.null(dim(res.ab.df)))res.ab.df<-t(data.frame(res.ab.df)) #need this in case result is one-dimensional and R converst to character vector
			n.res.ab.df<-c(guild.t,time.var,sb.name)	#"ProjectCode",
			if(obs.group!="")n.res.ab.df<-c(n.res.ab.df,obs.group)
				n.res.ab.df<-c(n.res.ab.df,"Abundance","StandardError","ConfidenceInterval","SampleSize")
			row.names(res.ab.df)<-c(1:NROW(res.ab.df))
			res.ab.df<-as.data.frame(res.ab.df,stringsAsFactors=FALSE,row.names=NULL)
			names(res.ab.df)<-n.res.ab.df
			
			y.label <- "Abundance (Birds per Point)"
						
			## Prepare results for RavianResultsAnalysisTable object 
			#No need to sort, because loop above sorts the results already
			table.title<-paste("Point-level Estimates of Abundance (Birds per Point) from Point Count Data Summarized by", guild.t)
			if(obs.group!="") table.title<-paste(table.title,", ",obs.group, sep="")
			table.title<-paste(table.title,"and",sb.name)
			
			support.t.fields<-c("YearCollected",summarize.by)	#"ProjectCode","ProjectName",
			support.t.names<-c("YearCollected",sb.name,support.guild.names)	#"ProjectCode","ProjectName",
			if(guild!="") support.t.names<-c("YearCollected",sb.name,guild)	#"ProjectCode","ProjectName",
			support<-unique(EffortData(object)[,c(support.t.fields)])
			support <- merge(support,support.guild,all.x=TRUE)
			
			names(support)<-support.t.names
			table.notes<-paste("Total number of observations:",obs.N,"- Total number of sampling events:",evt.N)
						
			plot.params<-list()
			plot.params$y.var<-"Abundance"
			plot.params$y.label<-"Abundance"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year","Month")
			plot.params$g.var<-c(sb.name)
			plot.params$g.label<-c(sb.name)
			if(guild=="") {
				plot.params$g.var<-c(sb.name,"ScientificName")
				plot.params$g.label<-c(sb.name,"Species")
			}else{
				plot.params$g.var<-c(sb.name,guild.t)
				plot.params$g.label<-c(sb.name,guild.t)
			}
			
			
			## now we have to create the results object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.ab.df
			SupportData(res)<- support
			Process(res)<- "Abundance"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,guild=guild,
					spatial.units=spatial.units,obs.group=obs.group,siteCovs=siteCovs,obsCovs=obsCovs)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			Call(res)<- ea.call
			return(res)
		}
)


#' Estimate Occupancy from PointCountData object
#' 
#' @param object A PointCountData object.
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param guild String giving a general name for the group of taxa, if provided (must not have blank spaces)
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
#' @param obs.group String naming the observation groups the data must be divided into - e.g., HabitatType, or Sex (must not have blank spaces). 
#' @param siteCovs Character array naming the variables to use as site covariates for occupancy models
#' @param obsCovs Character array naming the variables to use as detection covariates for occupancy models
setMethod("estimateOccupancy", signature(object = "PointCountData"),  
		function(object, summarize.by="Transect", time.var="YearCollected",  
				guild="",spatial.units="",obs.group="",siteCovs="",obsCovs="",...) {
			#OJO - must change the wrapper!
			ea.call<-match.call()
			if (is.null(object)) stop("A data object is required.")
			guild.n<-ifelse(guild=="","ScientificName","TaxonGroup")
			guild.t<-ifelse(guild=="","ScientificName",guild)
			sb.name<-ifelse(spatial.units=="",summarize.by,spatial.units)
			support.obs<-""
			id.vars<-c(time.var,summarize.by,guild.n,"Visit","Point")
			cast.eq<-paste(time.var,summarize.by,guild.n,"Visit+Point~ObservationCount",sep="+")
			sort.vars<-c(time.var,guild.n,summarize.by) #sort in this order
			if(obs.group!=""){
				id.vars<-c("ObservationsGroup",id.vars)
				cast.eq<-paste("ObservationsGroup",cast.eq,sep="+")
				support.obs<-unique(ObsData(object)[,c("ObservationsGroup")])
				sort.vars<-c(sort.vars,"ObservationsGroup")
			}
			support.site.fields<-c(time.var,summarize.by,"Point","Visit")
			support.effort<-unique(EffortData(object)[,support.site.fields])
			evt.N<-NROW(support.effort)
			if(length(support.obs)>1){
				support.effort<-merge(support.effort,as.data.frame(support.obs))
				support.site.fields<-c(support.site.fields,"ObservationsGroup")
				names(support.effort)<-support.site.fields
			}
			support.guild<-unique(ObsData(object)[,c("ScientificName","CommonName","SpeciesCode","PhylogenOrder")])
			support.guild.names<-c("ScientificName","CommonName","SpeciesCode","PhylogenOrder")
			if(guild!=""){
				support.guild<-unique(ObsData(object)[,"TaxonGroup"])
				support.guild.names<-c("TaxonGroup")
			}
			support.effort<-merge(support.effort,as.data.frame(support.guild))
			support.site.fields<-c(support.site.fields,support.guild.names)
			names(support.effort)<-support.site.fields
			#First collapse by guild, if not SpeciesCode
			melt.data <- melt(ObsData(object),id.vars,measure.vars="ObservationCount",variable_name="ObservationCount")
			base.table <- data.frame(cast(melt.data,cast.eq,fun.aggregate="sum"))
			base.data<-merge(support.effort,base.table, all.x=TRUE)
			obs.N<-nrow(base.table)	#total number of observation records
			base.data$ObservationCount<-ifelse(is.na(base.data$ObservationCount)==TRUE,0,base.data$ObservationCount)
			
			
			res.ab.df<-array()
			rr<-0
			#pgl<-unique(base.data$ProjectCode)
			#for(ppp in pgl){
				ggl<-unique(base.data[,guild.n])
				for(ggg in ggl){
					tgl<-unique(base.data[,time.var])
					for(ttt in tgl){
						sgl<-unique(base.data[,summarize.by])
						for(sss in sgl){
							if(obs.group!=""){
								ogl<-unique(base.data$ObservationsGroup)
								for(ooo in ogl){
									tdt<-subset(base.data,base.data$ObservationsGroup==ooo & base.data[,time.var]==ttt & base.data[,summarize.by]==sss & base.data[,guild.n]==ggg) #base.data$ProjectCode==ppp & 
									if(nrow(tdt)>0){
										rr<-rr+1
										if(rr==1) res.ab.df<-c(ggg,ttt,sss,ooo,estAbundOccup(pc.dat=tdt,func="occ"))	#ppp,
										else res.ab.df<-rbind(res.ab.df,c(ggg,ttt,sss,ooo,estAbundOccup(pc.dat=tdt,func="occ"))) #ppp,
									}
								}
							}else{
								tdt<-subset(base.data,base.data[,time.var]==ttt & base.data[,summarize.by]==sss & base.data[,guild.n]==ggg)	#base.data$ProjectCode==ppp & 
								if(nrow(tdt)>0){
									rr<-rr+1
									if(rr==1) res.ab.df<-c(ggg,ttt,sss,estAbundOccup(pc.dat=tdt,func="occ"))	#ppp,
									else res.ab.df<-rbind(res.ab.df,c(ggg,ttt,sss,estAbundOccup(pc.dat=tdt,func="occ")))	#ppp,
								}
							}
						}
					}
				}
			#}
			if(is.null(dim(res.ab.df)))res.ab.df<-t(data.frame(res.ab.df)) #need this in case result is one-dimensional and R converst to character vector
			n.res.ab.df<-c(guild.t,time.var,sb.name)	#"ProjectCode",
			if(obs.group!="")n.res.ab.df<-c(n.res.ab.df,obs.group)
			n.res.ab.df<-c(n.res.ab.df,"Occupancy","StandardError","ConfidenceInterval",
						"P(detection)","StErr_P(detection)","CI_P(detection)","SampleSize")

			row.names(res.ab.df)<-c(1:NROW(res.ab.df))
			res.ab.df<-as.data.frame(res.ab.df,stringsAsFactors=FALSE,row.names=NULL)
			names(res.ab.df)<-n.res.ab.df
			
			y.label <- "Occupancy (Proportion of Points With Detections)"
			
			## Prepare results for RavianResultsAnalysisTable object 
			#No need to sort, because loop above sorts the results already
			table.title<-paste("Point-level Estimates of Occupancy from Point Count Data Summarized by", guild.t)
			if(obs.group!="") table.title<-paste(table.title,", ",obs.group, sep="")
			table.title<-paste(table.title,"and",sb.name)
			
			support.t.fields<-c("YearCollected",summarize.by)	#"ProjectCode","ProjectName",
			support.t.names<-c("YearCollected",sb.name,support.guild.names)	#"ProjectCode","ProjectName",
			if(guild!="") support.t.names<-c("YearCollected",sb.name,guild)	#"ProjectCode","ProjectName",
			support<-unique(EffortData(object)[,c(support.t.fields)])
			support <- merge(support,support.guild,all.x=TRUE)
			
			names(support)<-support.t.names
			table.notes<-paste("Total number of observations:",obs.N,"- Total number of sampling events:",evt.N)
			
			plot.params<-list()
			plot.params$y.var<-"Occupancy"
			plot.params$y.label<-"Occupancy"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year","Month")
			plot.params$g.var<-c(sb.name)
			plot.params$g.label<-c(sb.name)
			if(guild=="") {
				plot.params$g.var<-c(sb.name,"ScientificName")
				plot.params$g.label<-c(sb.name,"Species")
			}else{
				plot.params$g.var<-c(sb.name,guild.t)
				plot.params$g.label<-c(sb.name,guild.t)
			}
			
			
			## now we have to create the results object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.ab.df
			SupportData(res)<- support
			Process(res)<- "Occupancy"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,guild=guild,
					spatial.units=spatial.units,obs.group=obs.group,siteCovs=siteCovs,obsCovs=obsCovs)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			Call(res)<- ea.call
			return(res)
		}
)



#' Function to summarize point count data
#' 
#' Function to summarize point count data based on a named method and optional site and detection covariates
#' #
#' @param pc.dat The point count data frame.  Each record reports the count of individuals of a taxon during a visit to a point.
#' @param func String naming the method used to summarize the data: avg = averaging, occ = occupancy, nmx = n-mixture
#' @param oCovs Character array naming the variables to use as detection covariates for occupancy or n-mixture models
#' @param sCovs Character array naming the variables to use as site covariates for occupancy or n-mixture models
#' @param ... Other parameters to be passed to the function (yet to be determined)
#' @return A string or numeric array of a single estimate for all the points provided.  The array contains the estimate, SE, CI, etc.
#' @author Leo Salas
estAbundOccup<-function(pc.dat,func,oCovs="",sCovs="",...){
	
	if(func=="nmx" | func=="occ"){
		pc.dat.sub<-pc.dat[,c("Point","Visit","ObservationCount")]
		n.pt<-length(unique(pc.dat.sub$Point))
		wdat<-cast(pc.dat.sub, Point ~ Visit, value = "ObservationCount", fun.aggregate="sum")
		y=as.data.frame(wdat[,c(2:ncol(wdat))],stringsAsFactors=FALSE,row.names=NULL)
		stfml<-"~1";dtfml<-"~1"
		if(func=="nmx"){
			vAb<-"NA"; sevAb<-"NA";	civAb<-"NA"; distAb<-"NA"
			pDta<-"NA";	seDta<-"NA"; ciDta<-"NA"; nPts<-"NA"
			res.out<-c(vAb,sevAb,civAb,distAb,pDta,seDta,ciDta,nPts)
			ufpc<-try(unmarkedFramePCount(y = y),silent=TRUE) #try
			if(inherits(ufpc,"try-error")){
				return(res.out)
			}else{
				if(sCovs!=""){ # this works
					siteCovs<-as.data.frame(unique(pc.dat[,c(scv)]),stringsAsFactors=FALSE,row.names=NULL)
					names(siteCovs)<-scv
					ufpc.t<-try(unmarkedFramePCount(y = y, siteCovs = siteCovs), silent=TRUE) #try
					if(inherits(ufpc.t,"try-error")){
						sCovs<-""
					}else{
						stfml<-paste("~",paste(collapse(sCovs),sep="+"))
						ufpc<-ufpc.t
					}
				}
				if(oCovs!=""){ #NEED TO CHECK THIS SEGMENT!
					obsCovs<-list()
					for(vvv in oCovs){
						obsCovs[[vvv]]<-pc.dat[,c(vvv)]
					}
					if(sCovs!=""){
						ufpc.t<-try(unmarkedFramePCount(y = y, siteCovs = siteCovs, obsCovs = obsCovs),silent=TRUE) #try
						if(inherits(ufpc.t,"try-error")){
							oCovs<-""
						}else{
							ufpc<-ufpc.t
							dtfml<-paste("~",paste(collapse(oCovs),sep="+"))
							obsCovs(ufpc)<-scale(obsCovs(ufpc))
						}
					}else{
						ufpc.t<-try(unmarkedFramePCount(y = y, obsCovs = obsCovs),silent=TRUE) #try
						if(inherits(ufpc.t,"try-error")){
							oCovs<-""
						}else{
							ufpc<-ufpc.t
							dtfml<-paste("~",paste(collapse(oCovs),sep="+"))
							obsCovs(ufpc)<-scale(obsCovs(ufpc))
						}
					}
				}
				fml<-as.formula(paste(dtfml,stfml))
				pcm1<-try(pcount(fml, ufpc, mixture="P"),silent=TRUE) #try
				pcm2<-try(pcount(fml, ufpc, mixture="NB"),silent=TRUE) #try
				fmList=""
				if(!inherits(pcm1,"try-error")){
					fmList<-fitList(modelP = pcm1)
					if(!inherits(pcm2,"try-error"))fmList<-fitList(modelP = pcm1, modelNB = pcm2)
				}else{
					if(!inherits(pcm2,"try-error"))fmList<-fitList(modelNB = pcm2)
				}
				if(class(fmList)!="character"){
					msr<-modSel(fmList)
					abro<-switch(msr@Full[1,1],modelP = pcm1,modelNB = pcm2)
					if(sCovs==""){
						res.ab<-backTransform(abro,"state")
					}else{ #Read vignette - use confint, then back-transform as appropriate
						res.ab<-backTransform(linearComb(abro,coefficients = c(1, rep(0,length(sCovs)))),"state") #Haven't tested this!
					}
					vAb<-ifelse(!is.nan(coef(res.ab)),round(coef(res.ab),digits=3),0)
					sevAb<-ifelse(!is.nan(SE(res.ab)),round(SE(res.ab),digits=3),0)
					civAb<-ifelse(sevAb!=0,paste("(",paste(round(confint(res.ab),digits=2),collapse=","),")",sep=""),"NA")
					distAb<-ifelse(msr@Full[1,1]=="modelP","Poisson","NegBinomial")
					if(oCovs==""){
						res.dta<-backTransform(abro,"det")
					}else{
						res.dta<-backTransform(linearComb(abro,coefficients = c(1, rep(0,length(oCovs)))),"det") #Read vignette! Use confint! Haven't tested this!
					}
					pDta<-ifelse(!is.nan(coef(res.dta)),round(coef(res.dta),digits=3),0)
					seDta<-ifelse(!is.nan(SE(res.dta)),round(SE(res.dta),digits=3),0)
					ciDta<-ifelse(seDta!=0,paste("(",paste(round(confint(res.dta),digits=3),collapse=","),")",sep=""),"NA")
					res.out<-c(vAb,sevAb,civAb,distAb,pDta,seDta,ciDta,nPts=n.pt)
					return(res.out)
				}else{#could not fit either model
					return(res.out)
				}
			}
		}else{	#occ
			vOc<-"NA"; sevOc<-"NA";	civOc<-"NA"
			pDto<-"NA";	seDto<-"NA"; ciDto<-"NA"; nPts<-"NA"
			res.out<-c(vOc,sevOc,civOc,pDto,seDto,ciDto,nPts)
			ufoc<-try(unmarkedFrameOccu(y = y),silent=TRUE) #try
			if(inherits(ufoc,"try-error")){
				return(res.out)
			}else{
				if(sCovs!=""){ # this works
					siteCovs<-as.data.frame(unique(pc.dat[,c(scv)]),stringsAsFactors=FALSE,row.names=NULL)
					names(siteCovs)<-scv
					ufoc.t<-try(unmarkedFrameOccu(y = y, siteCovs = siteCovs),silent=TRUE) #try
					if(inherits(ufoc,"try-error")){
						sCovs<-""
					}else{
						stfml<-paste("~",paste(collapse(sCovs),sep="+"))
						ufoc<-ufoc.t
					}
				}
				if(oCovs!=""){ #NEED TO CHECK THIS SEGMENT!
					obsCovs<-list()
					for(vvv in oCovs){
						obsCovs[[vvv]]<-pc.dat[,c(vvv)]
					}
					if(sCovs!=""){
						ufoc.t<-try(unmarkedFrameOccu(y = y, siteCovs = siteCovs, obsCovs = obsCovs),silent=TRUE) #try
						if(inherits(ufoc.t,"try-error")){
							oCovs<-""
						}else{
							ufoc<-ufoc.t
							dtfml<-paste("~",paste(collapse(oCovs),sep="+"))
							obsCovs(ufoc)<-scale(obsCovs(ufoc))
						}
					}else{
						ufoc.t<-try(unmarkedFrameOccu(y = y, obsCovs = obsCovs),silent=TRUE) #try
						if(inherits(ufoc.t,"try-error")){
							oCovs<-""
						}else{
							ufoc<-ufoc.t
							dtfml<-paste("~",paste(collapse(oCovs),sep="+"))
							obsCovs(ufoc)<-scale(obsCovs(ufoc))
						}
					}
					if(mfa==0)obsCovs(ufpc)<-scale(obsCovs(ufpc))
					if(mfo==0)obsCovs(ufoc)<-scale(obsCovs(ufoc))
					dtfml<-paste("~",paste(collapse(sCovs),sep="+"))
				}
				fml<-as.formula(paste(dtfml,stfml))
				ocm1<-try(occu(fml,ufoc),silent=TRUE) #try
				if(!inherits(ocm1,"try-error")){
					if(sCovs==""){
						res.oc<-backTransform(ocm1,"state")
					}else{
						res.oc<-backTransform(linearComb(ocm1,coefficients = c(1, rep(0,length(sCovs)))),"state") #Read vignette! Use confint! Haven't tested this!
					}
					vOc<-ifelse(!is.nan(coef(res.oc)),round(coef(res.oc),digits=3),0)
					sevOc<-ifelse(!is.nan(SE(res.oc)),round(SE(res.oc),digits=3),0)
					civv<-round(confint(res.oc),digits=3)
					civv[1]<-ifelse(civv[1]<0,0,civv[1])
					civv[2]<-ifelse(civv[2]>1,1,civv[2])
					civOc<-ifelse(sevOc!=0,paste("(",paste(civv,collapse=","),")",sep=""),"NA")
					if(oCovs==""){
						res.dto<-backTransform(ocm1,"det")
					}else{#Read vignette - use confint, then back-transform as appropriate
						res.dto<-backTransform(linearComb(ocm1,coefficients = c(1, rep(length(oCovs)))),"det") #Haven't tested this!
					}
					pDto<-ifelse(!is.nan(coef(res.dto)),round(coef(res.dto),digits=3),0)
					seDto<-ifelse(!is.nan(SE(res.dto)),round(SE(res.dto),digits=3),0)
					civd<-round(confint(res.dto),digits=3)
					civd[1]<-ifelse(civd[1]<0,0,civd[1])
					civd[2]<-ifelse(civd[2]>1,1,civd[2])
					ciDto<-ifelse(seDto!=0,paste("(",paste(civd,collapse=","),")",sep=""),"NA")
					res.out<-c(vOc,sevOc,civOc,pDto,seDto,ciDto,nPts=n.pt)
					return(res.out)
				}else{
					return(res.out)
				}
			}
		}
	}else{#Averaging method
		#step 1: compress by visit to point
		by.vars<-as.list(pc.dat[,which(!names(pc.dat) %in% c("Visit","ObservationCount"))])
		av.res1<-compressData(data=pc.dat,by=by.vars,field="ObservationCount",new.name="Abund",FUN=c("mean","var"))
		#step 2: compress across points
		by.vars2<-as.list(av.res1[,which(!names(av.res1) %in% c("Point","meanAbund","varAbund"))])
		av.res2<-compressData(data=av.res1,by=by.vars2,field="meanAbund",new.name="Abund",FUN=c("mean","var","NROW"))
		if(!is.na(av.res2$varAbund)){
			st.err<-sqrt(av.res2$varAbund/av.res2$SampleSize)
			ciumAb<-round((av.res2$meanAbund+(1.96*st.err)),digits=3)
			cilmAb<-round((av.res2$meanAbund-(1.96*st.err)),digits=3)
			if(cilmAb<0)cilmAb<-0
			cimeanAb<-paste("(",cilmAb,",",ciumAb,")",sep="")
			res.out<-c(round(av.res2$meanAbund,digits=3),round(st.err,digits=3),cimeanAb,av.res2$SampleSize)
		}else{
			st.err<-"NA"
			cimeanAb<-"NA"
			res.out<-c(round(av.res2$meanAbund,digits=3),st.err,cimeanAb,av.res2$SampleSize)
		}
		return(res.out)
	}
}



#' Estimate Simple Species Richness from PointCountData object
#' 
#' Estimate Simple Species Richness from PointCountData object
#' @param object A PointCountData object.
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
#' @param obs.group String naming the observation groups the data must be divided into - e.g., HabitatType, or Sex (must not have blank spaces)  
setMethod("estimateRichness", signature(object = "PointCountData"),
		function(object, summarize.by="Transect", time.var="YearCollected", 
				spatial.units="",obs.group="",...) {
			##Note to Leo: the variable guild, in estimation of richness, plays only a cosmetic value
			##That is, it is to be used for the title of the resulting table, as it affects nothing else (see line 264)
			ea.call<-match.call()
			
			if (is.null(object)) {stop("A data object is required.")}
			
			sb.name<-ifelse(spatial.units!="",spatial.units,summarize.by)
			#get point-level list of species
			# The following are the starting set of parameters...
			support.site.fields<-unique(c(time.var,summarize.by,"Point","Visit"))	#"ProjectCode","ProjectName",
			support.effort<-unique(EffortData(object)[,support.site.fields])
			by.list<-unique(c(time.var,summarize.by,"Visit","Point"))	#"ProjectName","ProjectCode",
			field.order<-c(summarize.by,time.var,"Richness","Variance","StandardError","SampleSize")	#"ProjectName","ProjectCode",
			res.table.fields<-c(time.var,sb.name,"Richness","Variance","StandardError","SampleSize")	#"ProjectCode",
			base.fields.list<-c(support.site.fields,"ScientificName")
			support.obsg<-""
			if(obs.group!=""){
				support.obsg<-unique(ObsData(object)[,c("ObservationsGroup")])
				if(length(support.obsg)>1){
					by.list<-c(by.list,"ObservationsGroup")
					base.fields.list<-c(base.fields.list,"ObservationsGroup")
					field.order<-c("ObservationsGroup",summarize.by,time.var,"Richness","Variance","StandardError","SampleSize")	#"ProjectName","ProjectCode",
					res.table.fields<-c(time.var,obs.group,sb.name,"Richness","Variance","StandardError","SampleSize")		#"ProjectCode",
					support.effort<-merge(support.effort,as.data.frame(support.obsg))
				}
			}
			
			total.E<-NROW(support.effort)
			data.temp<-unique(ObsData(object)[,names(ObsData(object)) %in% base.fields.list])
			total.N<-nrow(data.temp)
			#remove noObs records...
			data.temp<-subset(data.temp,!is.na(ScientificName))
			total.S<-NROW(unique(ObsData(object)$ScientificName))
			full.data<-calcCompress(by.list=by.list,comp.field="ScientificName",calc.fun="NROW",data.table=data.temp,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="SampleSize")  #NROW defaults to new.name=SampleSize in Mark's compressData!
			full.data$SpeciesCount<-full.data$SampleSize
			#We now have a table with number of species per visit to point and observation.group - counting those with 0 species...
			total.O<-sum(full.data$SpeciesCount==0)
			
			##Second compression: to point-level, obs.group and time.var (i.e., combining visits data). 
			support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Visit")]
			by.list<-by.list[!(by.list) %in% c("Visit")]
			bird.rich<-calcCompress(by.list=by.list,comp.field="SpeciesCount",calc.fun=c("mean","var","NROW"),data.table=full.data,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="Rich")
			
			##Third compression: to summarize.by, obs.group and timve var... (i.e., combining point data IF summarize.by is not Point)
			if(summarize.by!="Point"){
				support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Point")]
				by.list<-by.list[!(by.list) %in% c("Point")]
				bird.rich<-calcCompress(by.list=by.list,comp.field="meanRich",calc.fun=c("mean","var","NROW"),data.table=bird.rich,
						support.site.fields=support.site.fields,effort.base=support.effort,new.name="Rich")
				bird.rich<-unique(bird.rich)
			}
			
			
			##This is as good as it gets.  Cannot compress any further (because we want estimates within obs.groups, if any)
						
			bird.rich$StandardError<-sqrt(bird.rich$varRich/bird.rich$SampleSize)
			names(bird.rich)[names(bird.rich)=="meanRich"]<-"Richness"
			names(bird.rich)[names(bird.rich)=="varRich"]<-"Variance"
			
			#Now sort and arrange fields and prepare to populate object...
			bird.richness<-bird.rich[order(bird.rich[,time.var],bird.rich[,summarize.by]),]	#bird.rich[,"ProjectName"],
			bird.richness<-bird.richness[,c(field.order,names(bird.richness)[!names(bird.richness) %in% field.order])]
			
			
			if(summarize.by!="Transect")names(bird.richness)[names(bird.richness)=="SpatialGroup"]<-sb.name	#Assuming that if there is a group, it comes with a name!
			if(obs.group!="")names(bird.richness)[names(bird.richness)=="ObservationsGroup"]<-obs.group
			
			res.table<-bird.richness[,c(res.table.fields)]
			support<-bird.richness[,!(names(bird.richness) %in% c("Richness","Variance","StandardError","SampleSize"))]
			table.title<-paste("Point-level Estimates of Mean Species Richness from Point Count Data Summarized by ",sb.name,sep="")
			if(obs.group!="") table.title<-paste(table.title,"and",obs.group)
			
			table.notes<-paste("Total number of sampling events: ",total.E,". Total number of species: ",total.S,
					". Total number of observations: ",total.N,". Total number of sampling events with 0 species: ",total.O,sep="")
			plot.params<-list()
			plot.params$y.var<-"Richness"
			plot.params$y.label <- "Richness (Species per Point)"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year","Month")
			plot.params$g.var<-sb.name
			plot.params$g.label<-sb.name
			if(obs.group!="") {
				plot.params$g.var<-c(sb.name,obs.group)
				plot.params$g.label<-c(sb.name,obs.group)
			}
			
						
			#Finally, populate the RavianResults object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.table
			SupportData(res)<- support
			Process(res)<- "Richness"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(obs.group=obs.group,summarize.by=summarize.by,time.var=time.var,spatial.units=spatial.units)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			Call(res)<- ea.call
			return(res)	
		}
)

