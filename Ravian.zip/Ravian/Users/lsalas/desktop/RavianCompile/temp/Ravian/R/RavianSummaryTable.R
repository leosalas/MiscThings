#' @include DataStore.R
#' @include RavianResultsTable.R
#' @include RavianResultsGraph.R

# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Date created: Feb 12, 2010
###############################################################################

#' RavianSummaryTable class
#' 
#' RavianSummaryTable sub-class of RavianResultsTable; this class of objects is intended to hold values that were obtained
#' 		from summarizations of data in the AvianData object, for example: frequency tabulations or cross-tabulations.
#' 		Any table that is not an analysis result table, or a summarization based on replicates, is a RavianSummaryTable.
#' 
#' @param PlotParameters List of parameters useful for plotting: x.var name, x.label, etc.
#' @param DataStore A DataStore object, literally the DataStore object in the AvianData object that provided the data being summarized
#' @exportClass  RavianSummaryTable
setClass("RavianSummaryTable",contains=c("RavianResultsTable"),
		representation(
				PlotParameters = "list",		
				DataStoreData = "DataStore"
		)
)

#' Set generic to  method that sets PlotParameters slot of RavianSummaryTable object
#' 
#' @name setPlotParameters
#' @param object A RavianSummaryTable object
#' @param value list object to insert into slot
if (!isGeneric("PlotParameters<-")) {
	if (is.function("PlotParameters<-"))
		fun <- PlotParameters
	else fun <- function(object, value) standardGeneric("PlotParameters<-")
	
	setGeneric("PlotParameters<-", fun)
}

#' Set PlotParameters slot of RavianSummaryTable object
#' 
#' @name setPlotParameters
#' @param object A RavianSummaryTable object
#' @param value list object to insert into slot
setReplaceMethod("PlotParameters",signature(object="RavianSummaryTable"),
		function(object,value) {
			slot(object,"PlotParameters")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves PlotParameters slot of RavianSummaryTable object
#' 
#' @name PlotParameters
#' @param object A RavianResultsTable object
if (!isGeneric("PlotParameters")) {
	if (is.function("PlotParameters"))
		fun <- PlotParameters
	else fun <- function(object) standardGeneric("PlotParameters")
	
	setGeneric("PlotParameters", fun)
}

#' Retrieve PlotParameters slot of RavianSummaryTable object
#' 
#' @name PlotParameters
#' @param object A RavianResultsTable object
setMethod("PlotParameters",signature(object="RavianSummaryTable"),
		function(object) slot(object,"PlotParameters"))

#' Set generic to  method that sets DataStoreData slot of RavianSummaryTable object
#' 
#' @name setDataStoreData
#' @param object A RavianSummaryTable object
#' @param value DataStore object to insert into slot
if (!isGeneric("DataStoreData<-")) {
	if (is.function("DataStoreData<-"))
		fun <- DataStoreData
	else fun <- function(object, value) standardGeneric("DataStoreData<-")
	
	setGeneric("DataStoreData<-", fun)
}

#' Set DataStoreData slot of RavianSummaryTable object
#' 
#' @name setDataStoreData
#' @param object A RavianSummaryTable object
#' @param value DataStore object to insert into slot
setReplaceMethod("DataStoreData",signature(object="RavianSummaryTable"),
		function(object,value) {
			slot(object,"DataStoreData")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves DataStoreData slot of RavianSummaryTable object
#' 
#' @name DataStoreData
#' @param object A RavianSummaryTable object
if (!isGeneric("DataStoreData")) {
	if (is.function("DataStoreData"))
		fun <- DataStoreData
	else fun <- function(object) standardGeneric("DataStoreData")
	
	setGeneric("DataStoreData", fun)
}

#' Retrieve DataStoreData slot of RavianSummaryTable object
#' 
#' @name DataStoreData
#' @param object A RavianSummaryTable object
setMethod("DataStoreData",signature(object="RavianSummaryTable"),
		function(object) slot(object,"DataStoreData"))


##### plot method
#' Plot a RavianSummaryTable object
#' 
#' Plots a RavianSummaryTable object.  The object must have a list of parameters in the PlotParameters slot, specifying
#' 		x.var and y.var. If plotting point geoms, g.var can be provided as a vector of one or two grouping
#' 		variables - typically a spatial grouping variable and a taxon grouping variable that results in a graph or line per spatial unit,
#' 		and a type of symbol per species or guild. There are limits to levels in grouping variables: a maximum of 5 species (or guilds) 
#' 		per plot, and a maximum of 5 spatial groups if non-faceted plot (the default) or 12 groups if faceted.  All other geoms
#' 		must not include g.var. The PlotParameters slot must also have x.label, y.label and g.label, where applicable.  
#' 
#' @param x RavianSummaryTable object
#' @param plot.type A required string that can take values "point", "histogram", "density" or "bar"
#' @param facet.wrap A boolean variable, defaulting to FALSE, which renders a single plot.  TRUE would produce a facet 
#' 		wrap of 3 columns (see package ggplot for details)
#' @param reg.type String indicating the type of regression line to fit into the plot. An empty string means no line, 
#' 		simple = simple linear, cubic = cubic spline, loess = loess
setGeneric("plot", function(x,y,...){standardGeneric("plot")})

#' Plot a RavianSummaryTable object
#' 
#' Plots a RavianSummaryTable object.  The object must have a list of parameters in the PlotParameters slot, specifying
#' 		x.var and y.var. If plotting point geoms, g.var can be provided as a vector of one or two grouping
#' 		variables - typically a spatial grouping variable and a taxon grouping variable that results in a graph or line per spatial unit,
#' 		and a type of symbol per species or guild. There are limits to levels in grouping variables: a maximum of 5 species (or guilds) 
#' 		per plot, and a maximum of 5 spatial groups if non-faceted plot (the default) or 12 groups if faceted.  All other geoms
#' 		must not include g.var. The PlotParameters slot must also have x.label, y.label and g.label, where applicable.  
#' 
#' @param x RavianSummaryTable object
#' @param plot.type A required string that can take values "point", "histogram", "density" or "bar"
#' @param facet.wrap A boolean variable, defaulting to FALSE, which renders a single plot.  TRUE would produce a facet 
#' 		wrap of 3 columns (see package ggplot for details)
#' @param reg.type String indicating the type of regression line to fit into the plot. An empty string means no line, 
#' 		simple = simple linear, cubic = cubic spline, loess = loess
setMethod("plot",
		signature(x = "RavianSummaryTable", y="missing"),
		function(x, plot.type="point", facet.wrap=FALSE, reg.type="",...) 
		{
			ea.call<-match.call()
			if(is.null(plot.type))plot.type="point"
			res.df<-as.data.frame(x)
			x.var=PlotParameters(x)$x.var
			assign("x.var",x.var,envir=.GlobalEnv)
			x.lab=PlotParameters(x)$x.label
			assign("x.lab",x.lab,envir=.GlobalEnv)
			y.var=PlotParameters(x)$y.var
			assign("y.var",y.var,envir=.GlobalEnv)
			y.lab=PlotParameters(x)$y.label
			assign("y.lab",y.lab,envir=.GlobalEnv)
			group.var=PlotParameters(x)$g.var
			if(is.null(group.var))group.var<-""
			group.lab=PlotParameters(x)$g.label
			#group.var has either one or two values - there is always a spatial group and if results are abundance estimates, a taxon group
			#if two, map one to line and the other to shape. else, make both the same
			#assign("group.var",group.var,envir=.GlobalEnv)
			if (plot.type=="") plot.type<-"point"
			#See if x-var is numeric, if so, convert it
			if(sum(is.na(as.numeric(res.df[,x.var])))==0){
				res.tmp<-as.data.frame(cbind(as.numeric(res.df[,x.var]),as.numeric(res.df[,y.var]),res.df[,which(!names(res.df) %in% c(x.var,y.var))]),row.names=NULL,stringsAsFactors=F)
				nrdf<-names(res.df)
				ntdf<-nrdf[which(!names(res.df) %in% c(x.var,y.var))]
				names(res.tmp)<-c(x.var,y.var,ntdf)
				res.df<-res.tmp
			}
			if(class(x)=="RavianSampleSummaryTable"){
				res.df$StandardError<-ifelse(is.na(res.df$StandardError),0,res.df$StandardError)
				res.df$ymax<-res.df[,which(names(res.df)==y.var)]+as.numeric(res.df$StandardError)
				res.df$ymin<-res.df[,which(names(res.df)==y.var)]-as.numeric(res.df$StandardError)
				if(y.lab=="Occupancy"){
					res.df$ymax<-ifelse(res.df$ymax>1,1,res.df$ymax)
					res.df$ymin<-ifelse(res.df$ymin<0,0,res.df$ymin)
				}
			}
			assign("res.df",res.df,envir=.GlobalEnv)
			
			#geom type?
			plgeompt<-switch(plot.type,
					"point"=ggplot2::geom_point(size=4),
					#"point"=ggplot2::geom_point(size=4,position="dodge"),
					"histogram"=ggplot2::geom_histogram(stat="identity"),
					"density"=ggplot2::geom_density(),
					"bar"=ggplot2::geom_bar(stat="identity"))
			
			#theme settings
			pltxtfnty<-ggplot2::opts(axis.title.y=theme_text(angle=90,size=16),
					axis.text.y=theme_text(size=14))
			pltheme<-ggplot2::theme_bw()
			
			#faceting default
			wrpq<-FALSE
			
			if(group.var[1] != "" & !is.null(group.var[1]) & !is.na(group.var[1])){ 
				#Only one group.var submitted if Richness plot (spatial group), otherwise it's always spatial group and taxon
				gv1<-group.var[1]	#spatial group
				gv2<-group.var[2]	#taxon group (abundance estimates only) or NA
				#assign("gv1",gv1,envir=.GlobalEnv)
				#assign("gv2",gv2,envir=.GlobalEnv)
				gv1lab<-group.lab[1]
				#assign("gv1lab",gv1lab,envir=.GlobalEnv)
				gv2lab<-group.lab[2]
				#assign("gv2lab",gv2lab,envir=.GlobalEnv)
				
				#for faceting, must determine which one is supernumerary - if both, return an error
				#one MUST be of length 1
				lv1<-length(unique(res.df[,c(gv1)]))
				lv2<-ifelse(is.na(gv2),0,length(unique(res.df[,c(gv2)])))
				if(lv1>1 & lv2>1){
					qqq<-paste("Ravian Message: Selected data contains more than one level of",gv1lab,"and more than one level of",gv2lab,"- Suggest evaluate one spatial unit at the time.")
					class(qqq)<-"try-error"
					return(qqq)
				}else if(lv1==1 & lv2==1){
					qqq<-ggplot2::ggplot(res.df,aes(y=as.numeric(as.vector(res.df[,which(names(res.df)==y.var)])),x=res.df[,which(names(res.df)==x.var)])) + plgeompt + pltheme +  pltxtfnty 
					qqq<-qqq+ggplot2::labs(y=PlotParameters(x)$y.label, x=PlotParameters(x)$x.label)
				}else{	#at least one of them is length == 1, but do we need to wrap?
					#first check if the supernumerary has more than 9 levels - also a limit
					supern<-ifelse(lv1>1,gv1,ifelse(lv2>1,gv2,NA)) #either one of lv1, lv2 or NA (when lv1=1 and lv2=0 or 1)
					if(is.na(supern)) supern<-gv1	#default in case supern==NA
					supern.l<-ifelse(supern==gv1,lv1,lv2)
					supern.n<-ifelse(supern==gv1,gv1lab,gv2lab)
					
					#must assign supern, supern.n and supern.l
		
					if(supern.l>9){
						qqq<-paste("Ravian Message: Selected data contains more than nine levels of",supern.n,"- Please make a smaller selection.")
						class(qqq)<-"try-error"
						return(qqq)
					}else{	#less than 9 levels, do we wrap?
						if(supern.l>4){
							wrpq<-TRUE
							supern.l<-1	#because we are wrapping, one line per plot...
						}
					}
					assign("supern",supern,envir=.GlobalEnv)
					assign("supern.n",supern.n,envir=.GlobalEnv)
					
					##############
					
					#############
					
					ltypes<-c("solid","dotted","dotdash","twodash","longdash")[1:supern.l]
					shapes<-c(0,20,2,18,6)[1:supern.l] #4 is the limit
					plscalln<-ggplot2::scale_linetype_manual(values=ltypes)
					plscalshp<-ggplot2::scale_shape_manual(values=shapes)
					
					if(plot.type!="density"){
						if(wrpq==TRUE){
							qqq<-ggplot2::ggplot(res.df,aes(y=res.df[,which(names(res.df)==y.var)],x=res.df[,which(names(res.df)==x.var)]))
							pllabs<-ggplot2::labs(y=PlotParameters(x)$y.label, x=PlotParameters(x)$x.label)
							pltfct<-eval(substitute(ggplot2::facet_wrap(~ tst, ncol=3),list(tst=as.name(supern))))
							qqq<-qqq + pltheme +  pltxtfnty + plgeompt + pllabs + pltfct 
						}else{
							qqq<-ggplot2::ggplot(res.df,aes(y=res.df[,which(names(res.df)==y.var)],x=res.df[,which(names(res.df)==x.var)], linetype=res.df[,which(names(res.df)==supern)], shape=res.df[,which(names(res.df)==supern)]))
							pllabs<-ggplot2::labs(y=PlotParameters(x)$y.label, x=PlotParameters(x)$x.label, linetype=supern.n, shape=supern.n)
							qqq<-qqq + pltheme +  pltxtfnty + plgeompt + pllabs
						}
					}else{#density without facet.wrap
						qqq<-ggplot2::ggplot(res.df,aes(res.df[,which(names(res.df)==x.var)], linetype=res.df[,which(names(res.df)==supern)], shape=res.df[,which(names(res.df)==supern)]))
						pllabs<-ggplot2::labs(x=PlotParameters(x)$x.label, y="Density", linetype=supern.n, shape=supern.n)
						qqq<-qqq + pltheme +  pltxtfnty + plgeompt + pllabs
					}
					if(supern.l>1)qqq<-qqq + plscalln + plscalshp
				}
			}else{	#group var is null, nothing to group by
				qqq<-ggplot2::ggplot(res.df,aes(y=as.numeric(as.vector(res.df[,which(names(res.df)==y.var)])),x=res.df[,which(names(res.df)==x.var)])) + plgeompt + pltheme +  pltxtfnty 
				qqq<-qqq+ggplot2::labs(y=PlotParameters(x)$y.label, x=PlotParameters(x)$x.label)
			}
			
			#If res.df has StandardError...
			if((class(x)=="RavianSampleSummaryTable") & (!identical(res.df$ymin,res.df$ymax))){
				#plerrbar<-ggplot2::geom_errorbar(data=res.df,stat="identity",aes(ymin=ymin,ymax=ymax),width=0.2,position="dodge")
				plerrbar<-ggplot2::geom_errorbar(data=res.df,stat="identity",aes(ymin=ymin,ymax=ymax),width=0.2)
				qqq<-qqq+plerrbar
			}
			
			#if trend line requested - no lines among points!
			if(reg.type!=""){
				x.sm<-switch(reg.type,"simple"="x","gam"="s(x)","loess"="lo(x)")
				reg.meth<-ifelse(reg.type=="simple","lm","gam")
				fml<-as.formula(paste("y ~",x.sm))
				assign("fml",fml,envir=.GlobalEnv)
				assign("reg.meth",reg.meth,envir=.GlobalEnv)
				stsmth<-ggplot2::geom_smooth(method=reg.meth,formula=fml,se=FALSE)
				qqq<-qqq+stsmth
			}else{
				if(plot.type=="point") {
					plgeomln<-ggplot2::geom_line(size=1,colour="black")	#
					qqq<-qqq+plgeomln
				}
			}
			
			
			#X-axis settings
			##TODO: if x-axis is discrete with >20 levels, flip axes? For this, y-axis must have <20 levels too... Or set limits?
			x.vals<-res.df[,which(names(res.df)==x.var)]
			x.nrw<-NROW(unique(x.vals))
			assign("x.vals",x.vals,envir=.GlobalEnv)
			assign("x.nrw",x.nrw,envir=.GlobalEnv)
			if(!is.numeric(x.vals)){	#assuming here this is a histogram or bar plot, so cannot assign size to x-axis labels...
				if(x.nrw<21){
					pltxtfntx<-ggplot2::opts(axis.title.x=theme_text(size=16),
							axis.text.x=theme_text(angle=45, hjust=1, vjust=0))
					plgeombrk<-ggplot2::scale_x_discrete()
				} else {
					#error
					qqq<-"Ravian Message: The x-axis variable is discrete and contains more than 20 unique values, which exceeds the plotting limits of the Analyst. Please make a smaller selection (e.g., fewer species or fewer sites)."
					class(qqq)<-"try-error"
					return(qqq)
				}
			} else {	#numeric
				#change this if faceting...
				tsv<-14; mnbrx<-7
				if(wrpq==TRUE){
					tsv<-10; mnbrx<-4
				}
				assign("tsv",tsv,envir=.GlobalEnv)
				assign("mnbrx",mnbrx,envir=.GlobalEnv)
				pltxtfntx<-ggplot2::opts(axis.title.x=theme_text(size=16),
						axis.text.x=theme_text(size=tsv))
				qqq<-qqq+pltxtfntx
				if(x.nrw<mnbrx) {
					plgeombrk<-ggplot2::scale_x_continuous(breaks = min(x.vals):max(x.vals))
				} else {
					# construct only 6 labels
					mv<-min(x.vals)
					ic<-ceiling((max(x.vals)-mv)/(mnbrx-1))
					zz<-array()
					for(z in 1:(mnbrx-1)){zz[z] <-mv+(ic*(z-1))}
					plgeombrk<-ggplot2::scale_x_continuous(breaks = zz)
				}
				qqq<-qqq+plgeombrk
			}
						
			#if reg.type!=""
			#subset the res.df by one or both groups and determine if each level has at least 4 x-axis values
			if(reg.type!="" & reg.type!="simple"){
				if(group.var[1] != "" & !is.null(group.var[1]) & !is.na(group.var[1])){
					ug1<-unique(res.df[,gv1])
					for(sss in ug1){
						rdf1<-subset(res.df,gv1==sss)
						if(gv2!=""){
							ug2<-unique(rdf1[,gv2])
							for(ttt in ug2){
								rdf2<-subset(rdf1,gv2==ttt)
								if(length(unique(rdf2[,x.var]))<4){
									qqq<-paste("Ravian Message: There are fewer than 4 values for",x.var,"in one of the data subsets.  Smoother could not be plotted.")
									class(qqq)<-"try-error"
								}
							}
						}else{
							if(length(unique(rdf1[,x.var]))<4){
								qqq<-paste("Ravian Message: There are fewer than 4 values for",x.var,"in one of the data subsets.  Smoother could not be plotted.")
								class(qqq)<-"try-error"
							}
						}
					}
				}else{
					if(length(unique(res.df[,x.var]))<4){
						qqq<-paste("Ravian Message: There are fewer than 4 values for",x.var,"in the dataset.  Smoother could not be plotted.")
						class(qqq)<-"try-error"
					}
				}	
			}
			if(class(qqq)=="try-error"){
				return(qqq)
			}else if(!inherits(qqq,"ggplot")){
				class(qqq)<-"try-error"
				return(qqq)
			}else{
				class(qqq)<-"ggplot"
				#Now populating the RavianResultsGraph object...
				res.graph<-new("RavianResultsGraph")
				ResultsGraph(res.graph)<-qqq
				GraphTitle(res.graph)<-TableTitle(x)
				Notes(res.graph)<-Notes(x)
				GraphParameters(res.graph)<-list(data.table=res.df,plot.type=plot.type)
				Call(res.graph)<- ea.call
				return(res.graph)
			}
		}
)

########Methods that beautify labels
#' Set generic to  method that converts BMDE field names to more amenable values in the PlotParameters slot of a RavianSummaryTable object
#' 
#' @name checkPlotLabels
#' @param object A RavianSummaryTable object
if (!isGeneric("checkPlotLabels")) {
	if (is.function("checkPlotLabels"))
		fun <- checkPlotLabels
	else fun <- function(object, ...) standardGeneric("checkPlotLabels")
	
	setGeneric("checkPlotLabels", fun)
}

#' Converts BMDE field names to more amenable values in the PlotParameters slot of a RavianSummaryTable object
#' 
#' @name checkPlotLabels
#' @param object A RavianSummaryTable object
setMethod("checkPlotLabels",
		signature(object = "RavianSummaryTable"),
		function (object, ...) {
			#Get the res.table from the object
			yyy<-PlotParameters(object)$y.label
			yyy.new<-changeFieldName(orig.val=yyy)
			if(is.null(yyy.new)) yyy.new<-yyy
			PlotParameters(object)$y.label<-yyy.new
			
			xxx<-PlotParameters(object)$x.label
			xxx.new<-changeFieldName(orig.val=xxx)
			if(is.null(xxx.new)) xxx.new<-xxx
			PlotParameters(object)$x.label<-xxx.new
			return(object)
			
			#If you are wondering, group labels need not be modified here
		})
