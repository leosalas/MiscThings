#' @include RavianUtils.R
#' @include AvianData.R
#' @include RavianSampleSummaryTable.R


###############################################################################
# ShoreBirdData.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org
# Creation Date: May 30, 2009
###############################################################################

#' ShoreBirdData class - subclass of AvianData Class
#' 
#' ShoreBirdData class - subclass of AvianData Class
#' @param ObsData dataframe that contains all the observations within current object
#' @param EffortData dataframe that contains all the effort related to observations
#' @param ProtocolType always "ShoreBird"
#' @param Fields list of size 2.  Containing information on the warehouse fields available for observations and effort.
#' @param FilterList a list of 2 sql queries. obsSQL is for observation filtering, and effortSQL is used for the effort filter.
#' @param DataDefn A DataStore object to manage all connection information fo the data object.
#' @param Metadata list containing information on how data were obtained, FilterLists performed, etc.
#' @exportClass ShoreBirdData
setClass("ShoreBirdData", contains=c("AvianData"),
		prototype=prototype(ProtocolType="ShoreBird",
				Fields = list(obs=c("ProjectCode", "ProjectName", "SamplingUnitId", "SUgroup","Geopolitical",
								"HabRegion","Habitat","Site","Plot","PlotName","ProtocolCode","Visit",
								"YearCollected","MonthCollected","JulianDay", "ScientificName","CommonName",
								"SpeciesCode","PhylogenOrder","FlyOver","ObservationCount"),
						event=c("ProjectCode", "ProjectName", "SamplingUnitId", "SUgroup","Geopolitical",
								"HabRegion","Habitat","Site","Plot","PlotName","ProtocolCode",
								"Visit","YearCollected","MonthCollected","JulianDay")
				)))

#' Instantiate a new ShoreBirdData object
#' @return The ShoreBirdData object
setMethod("initialize",
		signature(.Object = "ShoreBirdData"),
		function (.Object, ...) 
		{
			callNextMethod(.Object)
			.Object
		}
)






#' Estimate Abundance from ShoreBirdData object
#' 
#' @param object A ShoreBirdData object
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param guild String giving a general name for the group of taxa, if provided (must not have blank spaces)
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
#### REDO
setMethod("estimateAbundance", signature(object = "ShoreBirdData"),  
		function(object, summarize.by="Plot", time.var="YearCollected", guild="", spatial.units="",...) {
			## if we are not summarizing by plot, then we must assume that the sampling unit will be the plot
			## it's possible this need not be the case, but we'll make it that way for now.
			ea.call<-match.call()
			if (is.null(object)) {stop("A data object is required.")}
			sb.name<-ifelse(spatial.units=="","SUgroup",spatial.units)
			#First thing is to get plot-level estimates
			# The following are the starting set of parameters...
			support.site.fields<-c(time.var,"Visit","SUgroup")	#"ProjectCode","ProjectName",
			id.vars=c(time.var,"Visit","SUgroup")
			cast.eq<-paste(time.var,"+SUgroup+Visit",sep="")
			by.list<-c("SUgroup",time.var)	#"ProjectName","ProjectCode",
			if(summarize.by!="SUgroup"){
				support.site.fields<-c(support.site.fields,summarize.by)
				id.vars<-c(id.vars,summarize.by)
				cast.eq<-paste(cast.eq,"+",summarize.by,sep="")
				by.list<-c(by.list,summarize.by)
			}
			support.effort<-unique(EffortData(object)[,support.site.fields])
			if(guild==""){	#treat data as independent species, do not group
				id.vars<-c(id.vars,"CommonName")
				#cast.eq<-paste(cast.eq,"+CommonName~ObservationCount",sep="")
				cast.eq<-paste(cast.eq,"+CommonName",sep="")
				support.species<-unique(ObsData(object)[,c("ScientificName","CommonName","SpeciesCode","PhylogenOrder")])
				field.sort.order<-c(sb.name,time.var,"CommonName")	#"ProjectName","ProjectCode",
				by.list<-c(by.list,"CommonName")
				guild.t<-" by Species";guild.n<-"CommonName"
			}else{
				id.vars<-c(id.vars,"TaxonGroup")
				#cast.eq<-paste(cast.eq,"+TaxonGroup~ObservationCount",sep="")
				cast.eq<-paste(cast.eq,"+TaxonGroup",sep="")
				support.species<-unique(ObsData(object)[,c("TaxonGroup")])
				field.sort.order<-c(sb.name,time.var,guild)	#"ProjectName","ProjectCode",
				by.list<-c(by.list,"TaxonGroup")
				guild.t<-paste(" by",guild);guild.n<-guild
			}

			support.effort<-merge(support.effort,support.species)
			obs.df<-ObsData(object)
			##start edits
			eff.df<-EffortData(object)
			base.table<-merge(eff.df,obs.df, all.x=TRUE)
			base.table$ObservationCount<-ifelse(is.na(base.table$ObservationCount)==TRUE,0,base.table$ObservationCount)
			cast.eq<-paste("ObservationCount~",cast.eq,sep="")
			base.data<-aggregate(as.formula(cast.eq),data=base.table,FUN="sum",na.rm=TRUE)
			#Now melt and cast to get the set of base observations
			#melt.data <- melt(obs.df,id.vars,measure.vars="ObservationCount",variable_name="ObservationCount")
			#base.table <- data.frame(cast(melt.data,cast.eq,fun.aggregate="sum")) #CAREFUL: this assumes ObsCount=0 when no observations (warehouse only).
			##EDIT NOTE: In a ntushell: merge effort with obs at the base grouping level, then aggregate at the appropriate spatio-temporal level,
			##			then expand to the appropriate effort - which is the aggregate of spatial unit/group, time.var level and taxon = support.effort
			base.data<-merge(support.effort,base.table, all.x=TRUE)
			full.N<-nrow(base.data)	#total number of observations
			base.data$ObservationCount<-ifelse(is.na(base.data$ObservationCount)==TRUE,0,base.data$ObservationCount)
			na.obs.count<-sum(base.data$ObservationCount==0)
			
			#compress to SUgroup (i.e., average across visits to SUgroup)
			support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Visit")]
			if(summarize.by!="SUgroup"){	#remove SUgroup
				support.site.fields<-support.site.fields[!(support.site.fields) %in% c("SUgroup")]
				by.list<-by.list[!(by.list) %in% c("SUgroup")]
				bird.abund<-calcCompress(by.list=by.list,comp.field="ObservationCount",calc.fun=c("mean","var","NROW"),
					data.table=base.data,support.site.fields=support.site.fields,effort.base=support.effort,new.name="Abund")
				
					#TODO: Here function to calculate F-test for validity of lumping
					#Variance among = 1/(g-1) x SUM[1 to g](gp.mean - gl.mean)^2  | g is number of groups, gp.mean is group mean and gl.mean is mean of means
					#Variance within = SUM[1 to g](1/ni-1) x gp.var | ni is the group's sample size, and gp.var its variance
					#F-test = Var.among/Var.within, with (g-1),(N-g) df | N is the total number of obs.
	
			}else{ #this also happens to be summarize.by==SUgroup, but DEJU is passing it as a SpatialGroup at all levels of rez
				bird.abund<-calcCompress(by.list=by.list,comp.field="ObservationCount",calc.fun=c("mean","var","NROW"),
						data.table=base.data,support.site.fields=support.site.fields,effort.base=support.effort,new.name="Abund")
			}
			
			#Can do no more...
			bird.abund$StandardError<-sqrt(bird.abund$varAbund/bird.abund$SampleSize)
			names(bird.abund)[names(bird.abund)=="meanAbund"]<-"Abundance"
			names(bird.abund)[names(bird.abund)=="varAbund"]<-"Variance"
			if(guild!="")names(bird.abund)[names(bird.abund)=="TaxonGroup"]<-guild	
			names(bird.abund)[names(bird.abund)=="SpatialGroup"]<-sb.name	
			
			## Prepare bird.abund to be ready for RavianResults object
			field.order<-c(field.sort.order,"Abundance","Variance","StandardError","SampleSize")
			bird.abund<-bird.abund[,c(field.order,names(bird.abund)[!names(bird.abund) %in% field.order])]
			
			bird.abund<-bird.abund[order(bird.abund[,guild.n],bird.abund[,time.var],bird.abund[,sb.name]),]	#bird.abund[,"ProjectName"],
			
			res.table<-bird.abund[,names(bird.abund) %in% field.order]
			y.label <- "Abundance (Shorebirds per Sampling Unit)"
			
			## Prepare results for RavianResultsAnalysisTable object 
			table.title<-paste("Estimates of Abundance (Shorebirds per Sampling Unit) Summarized", guild.t,sep="")
			if(summarize.by!="SUgroup") table.title<-paste(table.title," and ",sb.name,sep="")
			
			support <- bird.abund[,!(names(bird.abund) %in% c("Abundance","Density","Variance","StandardError","SampleSize"))]
			if(guild=="")support <- merge(support,support.species,all.x=TRUE)
			table.notes<-paste("Total sampling events:",full.N)
			if(na.obs.count>0) table.notes<-paste(table.notes,". Number of sampling events with 0 observations: ",na.obs.count,sep="")
			
			plot.params<-list()
			plot.params$y.var<-"Abundance"
			plot.params$y.label<-"Abundance (Shorebirds per Sampling Unit)"
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year",time.var)  
			plot.params$g.var<-c(sb.name)
			plot.params$g.label<-c(sb.name)
			if(guild=="") {
				plot.params$g.var<-c(sb.name,"CommonName")
				plot.params$g.label<-c(sb.name,"Species")
			}else{
				plot.params$g.var<-c(sb.name,guild)
				plot.params$g.label<-c(sb.name,guild)
			}
						
			## now we have to create the results object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.table
			SupportData(res)<- support
			Process(res)<- "Abundance"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,
					guild=guild,spatial.units=spatial.units)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			SupportData(res)<-support
			Call(res)<- ea.call
			return(res)
		}
)

#' Estimate Simple Species Richness from ShoreBirdData object
#' 
#' @param object An ShoreBirdData object.
#' @param summarize.by String that denotes the field to summarize the data by.
#' @param time.var String that denotes the field to summarize the data by temporally. Default is YearCollected, thus producing annual estimates
#' @param spatial.units String providing a general name for the group of spatial units, if these are provided (must not have blank spaces)
setMethod("estimateRichness", signature(object = "ShoreBirdData"),
		function(object, summarize.by="SUgroup", time.var = "YearCollected", 
				spatial.units="", ...) {
			##Note to Leo: the variable guild, in estimation of richness, plays only a cosmetic value
			##That is, it is to be used for the title of the resulting table, as it affects nothing else
			ea.call<-match.call()
			if (is.null(object)) {stop("A data object is required.")}
			sb.name<-ifelse(spatial.units!="",spatial.units,"SUgroup")
			#get Plot-level list of species
			# The following are the starting set of parameters...
			support.site.fields<-c(time.var,summarize.by,"Visit")	#"ProjectCode","ProjectName",
			by.list<-c(time.var,summarize.by,"Visit")	#"ProjectName","ProjectCode",
			
			if(summarize.by!="SUgroup"){
				support.site.fields<-c(time.var,summarize.by,"SUgroup","Visit")		#"ProjectCode","ProjectName",
				by.list<-c(time.var,summarize.by,"SUgroup","Visit")		#"ProjectName","ProjectCode",
			}
			
			base.fields.list<-c(support.site.fields,"SpeciesCode")
			support.effort<-unique(EffortData(object)[,support.site.fields])
			total.E<-NROW(support.effort)
			data.temp<-unique(ObsData(object)[,names(ObsData(object)) %in% base.fields.list])
			#HERE call function to deal with mixed flock taxa
			data.temp<-correctSpeciesForFlocks(data.temp)
			total.N<-nrow(data.temp)
			#remove noObs records...
			data.temp<-subset(data.temp,!is.na(SpeciesCode))
			total.S<-NROW(unique(ObsData(object)$SpeciesCode))
			full.data<-calcCompress(by.list=by.list,comp.field="SpeciesCode",calc.fun="NROW",data.table=data.temp,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="SampleSize")
			full.data$SpeciesCount<-full.data$SampleSize
			#We now have a table with number of species per visit to Plot - counting those with 0 species...
			total.O<-sum(full.data$SpeciesCount==0)
			
			##Second compression: to SUgroup and time.var (i.e., combining visits data). 
			support.site.fields<-support.site.fields[!(support.site.fields) %in% c("Visit")]
			by.list<-by.list[!(by.list) %in% c("Visit")]
			bird.rich<-calcCompress(by.list=by.list,comp.field="SpeciesCount",calc.fun=c("mean","var","NROW"),data.table=full.data,
					support.site.fields=support.site.fields,effort.base=support.effort,new.name="Rich")
			
			##Third compression: if summarize.by is not Plot... (so, summarizing by plot and then by summarize.by)
			if(summarize.by!="SUgroup"){
				support.site.fields<-support.site.fields[!(support.site.fields) %in% c("SUgroup")]
				by.list<-by.list[!(by.list) %in% c("SUgroup")]
				bird.rich<-calcCompress(by.list=by.list,comp.field="meanRich",calc.fun=c("mean","var","NROW"),data.table=bird.rich,
						support.site.fields=support.site.fields,effort.base=support.effort,new.name="Rich")
			}
			
			##Extend here if ever wanting to summarize by obs.group
			
			bird.rich$StandardError<-sqrt(bird.rich$varRich/bird.rich$SampleSize)
			names(bird.rich)[names(bird.rich)=="meanRich"]<-"Richness"
			names(bird.rich)[names(bird.rich)=="varRich"]<-"Variance"
			
			#Now sort and arrange fields and prepare to populate object...
			bird.richness<-bird.rich[order(bird.rich[,time.var],bird.rich[,summarize.by]),]	#bird.rich[,"ProjectName"],
			field.order<-c(summarize.by,time.var,"Richness","Variance","StandardError","SampleSize")	#"ProjectName","ProjectCode",
			bird.richness<-bird.richness[,c(field.order,names(bird.richness)[!names(bird.richness) %in% field.order])]
			
			names(bird.richness)[names(bird.richness)==summarize.by]<-sb.name
			
			res.table<-bird.richness[,c(time.var,sb.name,"Richness","Variance","StandardError","SampleSize")]	#c("ProjectCode",
			support<-bird.richness[,!(names(bird.richness) %in% c("Richness","Variance","StandardError","SampleSize"))]
			table.title<-paste("Mean Species Richness from Shorebird Data Summarized by ",sb.name,sep="")
			table.notes<-paste("Total number of sampling events: ",total.E,". Total number of taxa (including mixed flocks): ",total.S,
					". Total number of observations: ",total.N,". Total number of sampling events with 0 species: ",total.O,sep="")
			plot.params<-list()
			plot.params$y.var<-"Richness"
			plot.params$y.label <- paste("Richness (Species per ",sb.name,")",sep="")
			plot.params$x.var<-time.var
			plot.params$x.label<-ifelse(time.var=="YearCollected","Year",ifelse(time.var=="MonthCollected","Month",time.var))
			plot.params$g.var<-sb.name
			plot.params$g.label<-sb.name
			
			#Finally, populate the RavianResults object
			res<-new("RavianSampleSummaryTable")
			ResultsTable(res)<- res.table
			SupportData(res)<- support
			Process(res)<- "Richness"
			TableTitle(res)<-table.title
			Notes(res)<-table.notes
			ProcessParameters(res)<-list(summarize.by=summarize.by,time.var=time.var,spatial.units=spatial.units)
			PlotParameters(res)<-plot.params
			DataStoreData(res)<-DataDefn(object)
			Call(res)<- ea.call
			return(res)
		}
)

#' Set generic to  method that collapses data to SUgroups for ShoreBirdData object
#' 
#' @name collapseToSUgroup
#' @param object A ShoreBirdData object.  See specific Ravian objects for details
#' @param FUN A string naming a function to use to summarize the observations across plots in a SUgroup - at present "sum", "mean", "min" and "max" supported
setGeneric("collapseToSUgroup",
		function(object, FUN, ...) standardGeneric("collapseToSUgroup"))

#' Collapse ShoreBirdData object observation and effort data to the SUgroup level
#' 
#' @name collapseToSUgroup
#' @param object An ShoreBirdData object.
#' @param FUN A string naming a function to use to summarize the observations across plots in a SUgroup - at present "sum", "mean", "min" and "max" supported
setMethod("collapseToSUgroup", signature(object = "ShoreBirdData"),
		function(object, FUN="sum", ...) {
			ea.call<-match.call()
			if (is.null(object)) {stop("A ShoreBirdData object is required.")}
			ef.df<-EffortData(object)
			#remove Plot and PlotName, get unique values of the rest
			ef.df<-ef.df[,which(!names(ef.df) %in% c("Plot","PlotName","SamplingUnitId","SUgroup","Geopolitical","HabRegion","Habitat","Site"))]
			ef.df<-unique(ef.df)
			EffortData(object)<-ef.df
			#aggregate on ObsCount by all others using FUN
			obs.df<-ObsData(object)
			phyl<-obs.df[,c("SpeciesCode","ScientificName","CommonName","PhylogenOrder")]
			phyl<-unique(phyl)
			phyl<-na.omit(phyl)
			projmd<-unique(obs.df[,c("ProjectCode","ProjectName")])
			obn<-names(obs.df)
			obn<-subset(obn,!obn %in% c("Plot","PlotName","ObservationCount","SamplingUnitId","FlyOver",
							"ScientificName","CommonName","PhylogenOrder","ProjectName",
							"SUgroup","Geopolitical","HabRegion","Habitat","Site"))	
			by.lst<-list()
			for(bbb in obn){ 
				by.lst[[bbb]]<-obs.df[,bbb]
			}
			obs.df2<-aggregate(obs.df$ObservationCount,by=by.lst,FUN)
			noc<-obs.df2$x
			ncobs<-ncol(obs.df2)-1
			obs.df2<-obs.df2[,1:ncobs]
			obs.df2$ObservationCount<-noc
			obs.df3<-merge(obs.df2,phyl) #test this!
			obs.df4<-merge(obs.df3,projmd) #test this!
			ObsData(object)<-obs.df4
			return(object)
		}
)


#' Function to duplicate rows as needed to split mixed-species flock (ShoreBirdData only) taxa into basal species
#' 
#' @name correctSpeciesForFlocks
#' @param dft A data frame of data from a ShoreBirdData object.
#' @return A data frame with repeated records such that each flock code in the data is repeated as many times as there
#' 	are constituent species in the flock code, and the code of the species is provided with each record
correctSpeciesForFlocks<-function(dft){
	#this is a simple function to duplicate rows as needed to split mixed flock taxa into basal species
	ch<-odbcConnect("PFSSsupport-Redhat")
	flock.species<-sqlQuery(ch, "SELECT * FROM flockspecies;")
	close(ch)
	flock.codes<-unique(flock.species$FlockCode)
	flock.species<-flock.species[,c("FlockCode","SpeciesCode")]
	names(flock.species)<-c("SpeciesCode","SpeciesCode2")
	dft.species<-subset(dft,!SpeciesCode %in% flock.codes)
	dft.flocks<-subset(dft,SpeciesCode %in% flock.codes)
	dft.fsp<-merge(dft.flocks,flock.species,by="SpeciesCode",all.x=TRUE)
	dft.fsp$SpeciesCode<-dft.fsp$SpeciesCode2
	dft.fsp<-dft.fsp[,which(names(dft.fsp)!="SpeciesCode2")]
	dft.final<-rbind(dft.species,dft.fsp)
	return(dft.final)
}

#' Set generic to  method that that rarefies individual species' codes to flock species codes in observation data in a ShoreBirdData object
#' 
#' @name rarefyToFlock
#' @param object A ShoreBirdData object. 
#' @param spatial.groups A json string specifying the spatial grouping requested for the data
#' @param obs.groups A json string specifying the observation groupings requested for the data
#' @param more.filters A string with more query filtering specifications
#' @param more.obs.filters A string with more query filtering specifications applicable to the observations query only
setGeneric("rarefyToFlock",
		function(object, spatial.groups, obs.groups, more.filters, more.obs.filters, ...) standardGeneric("rarefyToFlock"))

#' Rarefy individual species' codes to flock species codes in observation data in a ShoreBirdData object
#' 
#' @param object An ShoreBirdData object.
#' @param spatial.groups A json string specifying the spatial grouping requested for the data
#' @param obs.groups A json string specifying the observation groupings requested for the data
#' @param more.filters A string with more query filtering specifications
#' @param more.obs.filters A string with more query filtering specifications applicable to the observations query only
setMethod("rarefyToFlock", signature(object = "ShoreBirdData"),
		function(object, spatial.groups="", obs.groups="", more.filters="", more.obs.filters="",...) {
			if (is.null(object)) {stop("A ShoreBirdData object is required.")}
			if(class(object)!="ShoreBirdData") {stop("A ShoreBirdData object is required.")}
			
			ch<-odbcConnect("PFSSsupport-Redhat")
			flock.species<-sqlQuery(ch, "SELECT * FROM flockspecies;")
			close(ch)
			flk.sp<-unique(flock.species$SpeciesCode)
			
			usp<-unique(ObsData(object)$SpeciesCode)
			if(sum(usp %in% flk.sp)==0){	#none of the species selected are flocking species
				return(object)
			}else{
				flk.cd<-usp[which(usp %in% flk.sp)]		#get the species for these
				fsp<-subset(flock.species,SpeciesCode %in% flk.cd)
				flk.nw<-unique(fsp$FlockCode)
				#we must now add these flock codes to the species codes being queried...
				whq<-Where(Query(DataDefn(object)))
				sci<-regexpr("SpeciesCode IN (",whq,fixed=TRUE)
				whq2<-substr(whq,sci+17,nchar(whq))
				sci2<-regexpr(")",whq2,fixed=TRUE)
				nexpp<-substr(whq,sci,sci + 17 + sci2 - 2)
				nexp<-paste(nexpp,",'",paste(flk.nw,collapse="','"),"')",sep="")
				pref<-substr(whq,1,sci-1)
				suff<-substr(whq,sci + 17 + sci2,nchar(whq))
				nws<-paste(pref,nexp,suff,sep="")
				
				obs.data.query<-try(buildQueryList(data.obj=object, data.type="obs", more.filters=more.filters, more.obs.filters=more.obs.filters), silent=TRUE)
				if(inherits(obs.data.query,"try-error")){
					res<-paste(obs.data.query, collapse=" ")
					class(res)<-"try-error"
					return(res)
				}else{
					#query the data again and see if the return does indeed have flock codes
					Where(obs.data.query)<-nws
					Query(DataDefn(object))<-obs.data.query
					obs.data<-try(getDataRavian(DataDefn(object)),silent=TRUE)
					if(inherits(obs.data,"try-error")){
						res<-paste(obs.data, collapse=" ")
						class(res)<-"try-error"
						return(res)
					}else{
						nusp<-unique((obs.data$result.data)$SpeciesCode)
						if(length(usp)==length(nusp)){
							return(object)
						}else{
							obs.dat.all<- obs.data$result.data
							#need to homogenize species codes to a single flock code...
							sp.flk<-unique(flock.species[,c("SpeciesCode","RarefiedCode","RarefiedScientificName","RarefiedCommonName","RarefiedPhylogenOrder")])
							obs.dat.sf<-merge(obs.dat.all, sp.flk, all.x=TRUE)
							obs.dat.sf$SpeciesCode<-ifelse(is.na(obs.dat.sf$RarefiedCode),as.character(obs.dat.sf$SpeciesCode),as.character(obs.dat.sf$RarefiedCode))
							obs.dat.sf$ScientificName<-ifelse(is.na(obs.dat.sf$RarefiedCode),as.character(obs.dat.sf$ScientificName),as.character(obs.dat.sf$RarefiedScientificName))
							obs.dat.sf$CommonName<-ifelse(is.na(obs.dat.sf$RarefiedCode),as.character(obs.dat.sf$CommonName),as.character(obs.dat.sf$RarefiedCommonName))
							obs.dat.sf$PhylogenOrder<-ifelse(is.na(obs.dat.sf$RarefiedCode),as.character(obs.dat.sf$PhylogenOrder),as.character(obs.dat.sf$RarefiedPhylogenOrder))
							obs.dat.sf<-obs.dat.sf[,which(!names(obs.dat.sf) %in% c("RarefiedCode","RarefiedScientificName","RarefiedCommonName","RarefiedPhylogenOrder"))]
							#now homogenize flock codes to general flock codes...
							mflk.flk<-unique(flock.species[,c("FlockCode","RarefiedCode","RarefiedScientificName","RarefiedCommonName","RarefiedPhylogenOrder")])
							obs.dat<-merge(obs.dat.sf, mflk.flk, by.x="SpeciesCode",by.y="FlockCode",all.x=TRUE)
							obs.dat$SpeciesCode<-ifelse(is.na(obs.dat$RarefiedCode),as.character(obs.dat$SpeciesCode),as.character(obs.dat$RarefiedCode))
							obs.dat$ScientificName<-ifelse(is.na(obs.dat$RarefiedCode),as.character(obs.dat$ScientificName),as.character(obs.dat$RarefiedScientificName))
							obs.dat$CommonName<-ifelse(is.na(obs.dat$RarefiedCode),as.character(obs.dat$CommonName),as.character(obs.dat$RarefiedCommonName))
							obs.dat$PhylogenOrder<-ifelse(is.na(obs.dat$RarefiedCode),as.character(obs.dat$PhylogenOrder),as.character(obs.dat$RarefiedPhylogenOrder))
							obs.dat<-obs.dat[,which(!names(obs.dat) %in% c("RarefiedCode","RarefiedScientificName","RarefiedCommonName","RarefiedPhylogenOrder"))]
							
							#attach the spatial.groups info
							if(spatial.groups!="") {	#links by SamplingUnitID
								spatial.groups.l<-fromJSON(spatial.groups)
								onsg<-names(spatial.groups.l)
								sg<-as.data.frame(unlist(spatial.groups.l,recursive=FALSE))
								sgn<-rownames(sg)
								ssnn<-array()
								for(ii in 1:NROW(sgn)){
									for(jj in 1:NROW(onsg)){
										if(grepl(onsg[jj],sgn[ii])==TRUE)ssnn[ii]<-onsg[jj]
									}
								}
								sgf<-as.data.frame(cbind(sg,ssnn),row.names=NULL)
								colnames(sgf)<-c("SamplingUnitId","SpatialGroup")
								sggf<-merge(obs.dat,sgf,by=intersect(names(obs.dat),names(sgf)),all.x=TRUE)
								sggf$SpatialGroup<-ifelse(is.na(sggf$SpatialGroup),"unassigned",as.character(sggf$SpatialGroup))
								obs.dat<-sggf
							}
							
							#Now attach the obs.groups info
							if(obs.groups!="") {	#links by variable specified in json string
								o.groups<-fromJSON(obs.groups)
								onog<-names(o.groups)
								#get group names and group membership, then assign values of group membership to the data
								#this should be with a merge, so we need a table of group codes and their group member values...
								#then merge by code value
								og.table<-vector()
								for(kk in 1:NROW(o.groups[[1]])){	#here is a point of extension, where the numeral 1 can be a loop numeral
									togt<-cbind(as.data.frame(o.groups[[1]][kk]),names(o.groups[[1]][kk]))
									names(togt)<-c(onog,"ObservationsGroup")
									og.table<-rbind(og.table,togt)
								}
								og.df<-as.data.frame(og.table)
								#merge now...
								oggf<-merge(obs.dat,og.df,by=intersect(names(obs.dat),names(og.df)),all.x=TRUE)
								oggf$ObservationsGroup<-ifelse(is.na(oggf$ObservationsGroup),"unassigned",as.character(oggf$ObservationsGroup))
								obs.dat<-oggf
								Metadata(object)[["observation.groups"]]=o.groups
							}
							ObsData(object)<-obs.dat
							return(object)
						}	
					}
				}
			}
		})

