# RavianWeb.estimateRichness.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org, mherzog@prbo.org
# Creation Date: Oct 20, 2009
###############################################################################

RavianWeb.Abundance.PFSS <- function(formData) {
	options(warn=-1)
	results<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	#more.filters="(JulianDay >= 314 and JulianDay <= 354)"
	more.filters="((JulianDay >= 314 AND JulianDay <= 365) OR (JulianDay >= 1 AND JulianDay <= 46))"	#extending to
	more.obs.filters=""
	#### We are leaving the taxon.groups slot usage here, but it CANNOT be used for PFSS because of the rarefaction to flocks
	#### One option would be to use either-or.  For example, the call to rarefy can be done only IF there is no taxon group...
	taxon.groups<-""	#formData$TaxonGroups
	taxon.groups.name<-""	#formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	obs.groups.name<-formData$ObservationGroupsName
		
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters=more.obs.filters,taxon.groups="", spatial.groups=spatial.groups, 
					obs.groups=obs.groups),silent=TRUE) #try-catch
	
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	###HERE: add the temporal group "Season" to aggregate Nov to Feb in EffortData and ObsData
	data.obj<-try(addSeason(data.obj),silent=TRUE)
	if (inherits(data.obj,"try-error")) {
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal=1, sink.error=TRUE)
		return(results)	#ends here - can't continue
	}
	
	usp<-unique(ObsData(data.obj)$SpeciesCode)
	obs.dat<-ObsData(data.obj)
	if(NROW(obs.dat)==0){
		results[[1]]<-populate.RWOError(error="Ravian Message: No observational data available for the selection.", formData, data.obj = data.obj, res.ordinal=1, sink.error=FALSE)
		return(results)
	}
	if(length(unique(ObsData(data.obj)[,c("SpeciesCode")]))>10){
		results[[1]]<-populate.RWOError(error="Ravian Message: The selection contains more than 10 species, the limit of the Analyst.  Please select fewer species.", formData=formData, data.obj = do.test, res.ordinal="1", sink.error=FALSE)
		return(results)	#ends here - can't continue
	}
	
	#Here method to convert species to flocks if needed
	data.obj<-try(rarefyToFlock(object=data.obj, spatial.groups=spatial.groups, obs.groups=obs.groups, more.filters=more.filters, more.obs.filters=more.obs.filters),silent=TRUE)
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	#Note Addendum IF there was rarification...
	nusp<-unique(ObsData(data.obj)$SpeciesCode)
	note.add<-""
	if(!identical(usp,nusp)){
		note.add<-"Some or all species selected may have also been detected as part of mixed flocks in the selected survey events selected. Therefore, the taxa have been rarefied to the most encompassing mixed flock definition."
	}
	#setting default arguments for Ravian method...
	#time.var<-"YearCollected"
	time.var<-"Season"
	summarize.by<-ifelse(spatial.groups=="","SUgroup","SpatialGroup")
	
	test.ab<-try(estimateAbundance(object = data.obj,summarize.by=summarize.by,time.var=time.var,
					guild="",spatial.units=spatial.groups.name,obs.group=obs.groups.name),silent=TRUE)  #guild MUST be "" - read above
	
	zz<-1
	if (inherits(test.ab,"try-error")) {
		results[[zz]]<-populate.RWOError(error=test.ab, formData=formData, data.obj=do.test, res.ordinal=zz)
		return(results)
	} else {	#We have abundance estimates...
		#report the results table - beautify column names first
		ab.obj<-try(checkRowColumnNames(object=test.ab), silent=TRUE)
		if(inherits(ab.obj,"try-error")){ab.obj<-test.ab}
		test.df<-try(do.call("as.data.frame",args=list(x=ab.obj),envir=.GlobalEnv), silent=TRUE)
		if (inherits(test.df,"try-error")) {
			results[[zz]]<-populate.RWOError(error=test.df, formData=formData, data.obj = test.ab, res.ordinal=zz)
			return(results)	#ends here - can't continue
		} else{
			if(note.add!=""){
				notes.add<-paste(Notes(test.ab),note.add)
				Notes(test.ab)<-notes.add
			}
			results[[zz]]<-populate.RWOTable(ordinal = zz, title=TableTitle(test.ab),table.obj=test.df, table.note=Notes(test.ab))
		}
		
		########################################
		#Make and store graphs
		#First beautify the labels
		ab.plt.obj<-try(checkPlotLabels(test.ab), silent=TRUE)
		if(inherits(ab.plt.obj,"try-error")) ab.plt.obj<-test.ab
		#Now determine if you need facet or plot as is 
		rst<-ResultsTable(ab.plt.obj)
		sst<-SupportData(ab.plt.obj)
		tgf<-ifelse(taxon.groups!="",taxon.groups.name,"CommonName")
		sgf<-ifelse(spatial.groups!="",spatial.groups.name,summarize.by)
		for(ttt in unique(rst[,c(tgf)])){
			srt<-subset(rst,rst[,c(tgf)]==ttt)
			sst2<-subset(sst,sst[,(tgf)]==ttt)
			com.n<-sst2[1,"CommonName"]
			s.ab.plt.obj<-ab.plt.obj
			SupportData(s.ab.plt.obj)<-sst2
			#subset by spatial location if unique>9
			if((length(unique(srt[,c(sgf)]))>9 | obs.groups.name!="") & nrow(srt)>0){
				for(vvv in unique(srt[,c(sgf)])){
					srt2<-subset(srt,srt[,c(sgf)]==vvv)
					if(nrow(srt2)>0){
						#subset by obs.groups, if the exist
						if(obs.groups.name!=""){
							ogs<-fromJSON(obs.groups)
							for(nnn in names(ogs[[1]])){
								srt3<-subset(srt2,srt2[,c(obs.groups.name)]==nnn)
								if(nrow(srt3)>0){
									ResultsTable(s.ab.plt.obj)<-srt3
									plot.subset<-paste("- Graph for Species = ",com.n," and ",sgf," = ",vvv," and ",obs.groups.name," = ",nnn,".",sep="")
									zz<-zz+1
									results[[zz]]<-makeRavianPlot(dat.obj=s.ab.plt.obj,plot.type="point",plot.subset=plot.subset,zz=zz,formData=formData)
								}
							}
						}else{
							ResultsTable(s.ab.plt.obj)<-srt2
							plot.subset<-paste("- Graph for Species = ",com.n," and ",sgf," = ",vvv,".",sep="")
							zz<-zz+1
							results[[zz]]<-makeRavianPlot(dat.obj=s.ab.plt.obj,plot.type="point",plot.subset=plot.subset,zz=zz,formData=formData)
						}
					}
				}
			}else{	#let the plotting function handle spatial group partitioning
				ResultsTable(s.ab.plt.obj)<-srt
				plot.subset<-paste("- Graph for Species = ",com.n,".",sep="")
				zz<-zz+1
				results[[zz]]<-makeRavianPlot(dat.obj=s.ab.plt.obj,plot.type="point",plot.subset=plot.subset,zz=zz,formData=formData)
			}
		}
		
		######################################
		#estimate trend 
		reg.type<-"simple"
		#subset by taxon.group (tgf in ResultsTable)
		for(ttt in unique(rst[,c(tgf)])){
			srt<-subset(rst,rst[,c(tgf)]==ttt)
			sst2<-subset(sst,sst[,(tgf)]==ttt)
			com.n<-sst2[1,"CommonName"]
			res.t.obj<-test.ab
			ResultsTable(res.t.obj)<-srt
			SupportData(res.t.obj)<-sst2
			if (min(srt$StandardError, na.rm=TRUE)<=0 | ("TRUE" %in% is.na(srt$StandardError))) {
				results.trend<-try(trend(res.t.obj,weighted=FALSE,reg.type=reg.type,do.log=FALSE),silent=TRUE)
			} else {
				results.trend<-try(trend(res.t.obj,weighted=TRUE,reg.type=reg.type,do.log=FALSE),silent=TRUE)
			}
			zz<-zz+1
			if (inherits(results.trend,"try-error")) {
				sink.error<-ifelse(grepl("Ravian Message:",results.trend),FALSE,TRUE)
				results[[zz]]<-populate.RWOError(error=results.trend, formData=formData, data.obj = test.ab, res.ordinal=zz, sink.error=sink.error)
				return(results)	#ends here - can't continue
			}else{
				trend.dat<-paste("Estimate for Species =",com.n)
				trend.title<-paste(TableTitle(results.trend),". ",trend.dat, sep="")
				trend.note<-paste("Data source: ",TableTitle(test.ab),". ",Notes(results.trend), sep="") #REPORT METHOD!
				results[[zz]]<-populate.RWOTable(ordinal = zz, title=trend.title,table.obj=ResultsTable(results.trend), table.note=trend.note)
				
				#plot this trend estimate - remove all groups 
				PlotParameters(res.t.obj)$g.var<-""
				PlotParameters(res.t.obj)$g.label<-""
				plt.par<-PlotParameters(res.t.obj)
				plt.par$g.var<-""
				plt.par$g.label<-""
				PlotParameters(res.t.obj)<-plt.par
				ttl.smooth<-switch(reg.type,"simple"="","loess"=" Using Locally Weighed (loess) Smoother","cubic"=" Using Cubic Spline Smoother")
				plot.ttl<-paste("Trend in Abundance over ",time.var,". ",trend.title,ttl.smooth,sep="")
				tmp.plot<-try(plot(res.t.obj, plot.type="point",facet.wrap=FALSE,reg.type=reg.type),silent=TRUE)
				zz<-zz+1
				if (inherits(tmp.plot,"try-error")) {
					sink.error<-ifelse(grepl("Ravian Message:",tmp.plot),FALSE,TRUE)
					results[[zz]]<-populate.RWOError(error=tmp.plot, formData=formData, data.obj = res.t.obj, res.ordinal=zz, sink.error=sink.error)
				}else{
					results[[zz]]<-populate.RWOGraph(ordinal=zz, title=plot.ttl, graph.obj = ResultsGraph(tmp.plot), graph.note=trend.note)
				}
			}
		}
		#estimate trend with LOESS smoother
		reg.type<-"loess"
		#subset by taxon.group (tgf in ResultsTable)
		for(ttt in unique(rst[,c(tgf)])){
			srt<-subset(rst,rst[,c(tgf)]==ttt)
			sst2<-subset(sst,sst[,(tgf)]==ttt)
			com.n<-sst2[1,"CommonName"]
			res.t.obj<-test.ab
			ResultsTable(res.t.obj)<-srt
			SupportData(res.t.obj)<-sst2
			if (min(srt$StandardError, na.rm=TRUE)<=0 | ("TRUE" %in% is.na(srt$StandardError))) {
				results.trend<-try(trend(res.t.obj,weighted=FALSE,reg.type=reg.type,do.log=FALSE),silent=TRUE)
			} else {
				results.trend<-try(trend(res.t.obj,weighted=TRUE,reg.type=reg.type,do.log=FALSE),silent=TRUE)
			}
			zz<-zz+1
			if (inherits(results.trend,"try-error")) {
				sink.error<-ifelse(grepl("Ravian Message:",results.trend),FALSE,TRUE)
				results[[zz]]<-populate.RWOError(error=results.trend, formData=formData, data.obj = test.ab, res.ordinal=zz, sink.error=sink.error)
			}else{
				trend.dat<-paste("Estimate for Species =",com.n)
				trend.title<-paste(TableTitle(results.trend),". ",trend.dat, sep="")
				trend.note<-paste("Data source: ",TableTitle(test.ab),". ",Notes(results.trend), sep="") #REPORT METHOD!
				results[[zz]]<-populate.RWOTable(ordinal = zz, title=trend.title,table.obj=ResultsTable(results.trend), table.note=trend.note)
			
				#try to plot this trend - remove all groups 
				PlotParameters(res.t.obj)$g.var<-""
				PlotParameters(res.t.obj)$g.label<-""
				plt.par<-PlotParameters(res.t.obj)
				plt.par$g.var<-""
				plt.par$g.label<-""
				PlotParameters(res.t.obj)<-plt.par
				ttl.smooth<-switch(reg.type,"simple"="","loess"=" Using Locally Weighed (loess) Smoother","cubic"=" Using Cubic Spline Smoother")
				plot.ttl<-paste("Trend in Abundance over ",time.var,". ",trend.title,ttl.smooth,sep="")
				tmp.plot<-try(plot(res.t.obj, plot.type="point",facet.wrap=FALSE,reg.type=reg.type),silent=TRUE)
				zz<-zz+1
				if (inherits(tmp.plot,"try-error")) {
					sink.error<-ifelse(grepl("Ravian Message:",tmp.plot),FALSE,TRUE)
					results[[zz]]<-populate.RWOError(error=tmp.plot, formData=formData, data.obj = res.t.obj, res.ordinal=zz, sink.error=sink.error)
				}else{
					results[[zz]]<-populate.RWOGraph(ordinal=zz, title=plot.ttl, graph.obj = ResultsGraph(tmp.plot), graph.note=trend.note)
				}
			}
		}
	}
	return(results)
}