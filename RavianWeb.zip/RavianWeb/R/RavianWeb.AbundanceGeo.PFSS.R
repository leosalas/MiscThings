# RavianWeb.Abundance.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org, mherzog@prbo.org
# Creation Date: Oct 20, 2009
###############################################################################


RavianWeb.AbundanceGeo.PFSS <- function(formData) {
	options(warn=-1)
	results<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(ProtocolType=dt, data.level=data.level, dsn="ravian_wh")
	
	GeoDataObsDataLink(do.test)<-formData$GeoDataObsLink
	lpvals<-formData$GeoLinkParVals1
	
	#### sanity
	q1<-'SELECT unique_number, unique_id, unitid, buff_dist, id, 
			val AS FloodCd, meta.id, ST_AREA(meta.geom) as AreaTotal, 
			SUM(ST_Area(the_geom)) AS AreaFlooded, 
			SUM(ST_Area(the_geom))/ST_AREA(meta.geom) AS Pflood FROM (
			SELECT rid, id, (gv).geom AS the_geom, (gv).val FROM (
			SELECT rid, id, ST_Intersection(rast, geom) AS gv FROM "snwrwater", "all_buffers_merge" WHERE 
			ST_Intersects(rast, geom) AND unique_number = '
	q2<-' AND buff_dist = '
	q3<-') innerQry	) outerQry INNER JOIN "all_buffers_merge" AS meta USING (id) 
			GROUP BY unique_number,  unique_id, buff_dist, id, val, meta.id, meta.geom, meta.unitid;'
	ql<-list(c(q1,q2,q3))
	qstr<-toJSON(ql)
	
	#qstr<-formData$QueryGeo
	aqpv<-formData$GeoLinkParVals2
	gdd<-try(CADCgeo(ds="PostgreSQL", cType="DBI", lpv=lpvals, qs=qstr),silent=TRUE)
	if(inherits(gdd,"try-error")){
		results[[1]]<-populate.RWOError(error=gdd, formData=formData, data.obj = do.test, res.ordinal="1")
		return(results)	#ends here - can't continue
	}else{
		GeoDataDefn(do.test)<-gdd
	}
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	more.filters<-""
	if(dt=="Band")more.filters<-"NetHours IS NOT NULL"
	if(dt=="PointCount")more.filters<-"ProtocolCode NOT IN ('VCP300_PLAYBACK','VCP300_2xOBS_DEP','VCP300_2xOBS_IND')"
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	obs.groups.name<-formData$ObservationGroupsName
	########
	
	############
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters="", taxon.groups=taxon.groups, 
					spatial.groups=spatial.groups, obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	
	
	############
	##HERE loop through values of link parameters 1 and 2 and of queries
	#first, replace the glpv
	lpvals<-as.character(unique(EffortData(data.obj)[,GeoDataObsDataLink(do.test)]))
	LinkParameterValues(gdd)<-lpvals
	##Here loop changing the Query slot in the gdd to reflect a different year and flood raster...
	ras.names<-c('n120800e','n121101e','n112802e','n112303e','n120304e','n112005e','n112306e','n122007e','n011509e','n111509e')
	fl.rasters<-as.data.frame(cbind(ras.names,flood.year=c(2000:2009)))
	flood.yr.df<-data.frame()
	for(zz in 1:nrow(fl.rasters)){
		zln<-fl.rasters[zz,1];yrr<-fl.rasters[zz,2]
		q11<-paste('SELECT unique_number, unique_id, unitid, buff_dist, id, 
						val AS FloodCd, meta.id, ST_AREA(meta.geom) as AreaTotal, 
						SUM(ST_Area(the_geom)) AS AreaFlooded, 
						SUM(ST_Area(the_geom))/ST_AREA(meta.geom) AS Pflood FROM (
						SELECT rid, id, (gv).geom AS the_geom, (gv).val FROM (
						SELECT rid, id, ST_Intersection(rast, geom) AS gv FROM "',zln,'", "all_buffers_merge" WHERE 
						ST_Intersects(rast, geom) AND unique_number = ',sep='')
		ql<-list(c(q11,q2,q3))
		Query(gdd)<-ql
		GeoDataDefn(data.obj)<-gdd
		flood.df<-data.frame()
		for(vv in aqpv){
			geo.data.df<-try(getGeoDataRavian(gdd,vv),silent=TRUE)
			if(inherits(geo.data.df,"try-error")){
				results[[1]]<-populate.RWOError(error=geo.data.df, formData=formData, data.obj = data.obj, res.ordinal="1")
				return(results)	#ends here - can't continue
			}
			gd.df<-subset(geo.data.df,floodcd==1,select=c("linkpar","areatotal","areaflooded","pflood"))
			names(gd.df)<-c("SamplingUnitId",paste(c("buffer_area","areaflooded","pflooded"),vv,sep="_"))
			if(NROW(flood.df)==0){
				flood.df<-gd.df
			}else{
				flood.df<-merge(flood.df,gd.df)
			}
		}
		flood.df$year.flood<-yrr
		if(NROW(flood.yr.df)==0){
			flood.yr.df<-flood.df
		}else{
			flood.yr.df<-rbind(flood.yr.df,flood.df)
		}
	}
	
	#now getting the urbanization layer data
	q11<-'SELECT unique_number, unique_id, unitid, buff_dist, id, 
			val AS UrbanCd, meta.id, ST_AREA(meta.geom) as AreaTotal, 
			SUM(ST_Area(the_geom)) AS TotalUrban 
			FROM (
			SELECT rid, id, (gv).geom AS the_geom, (gv).val FROM (
			SELECT rid, id, ST_Intersection(rast, geom) AS gv FROM "recl_bhd00", "all_buffers_merge" WHERE 
			ST_Intersects(rast, geom) AND unique_number = '
	ql<-list(c(q11,q2,q3))
	Query(gdd)<-ql
	GeoDataDefn(data.obj)<-gdd
	urban.df<-data.frame()
	for(vv in aqpv){
		geo.data.df<-try(getGeoDataRavian(gdd,vv),silent=TRUE)
		if(inherits(geo.data.df,"try-error")){
			results[[1]]<-populate.RWOError(error=geo.data.df, formData=formData, data.obj = data.obj, res.ordinal="1")
			return(results)	#ends here - can't continue
		}
		gd.df<-geo.data.df[,c("linkpar","areatotal","totalurban","urbancd")]	
		gd.df$t.urb<-gd.df$totalurban*gd.df$urbancd
		gd.df.u<-aggregate(t.urb~linkpar,data=gd.df,FUN=sum)
		names(gd.df.u)<-c("SamplingUnitId",paste("urban",vv,sep="_"))
		if(NROW(urban.df)==0){
			urban.df<-gd.df.u
		}else{
			urban.df<-merge(urban.df,gd.df.u)
		}
	}
	geo.attrib.df<-merge(flood.yr.df,urban.df,by="SamplingUnitId")
	
	GeoData(data.obj)<-geo.attrib.df
	
	###Things you can try now...
	#effobs.df<-as.data.frame(data.obj,optional="merged")
	#longgeo.df<-as.data.frame(data.obj,optional="geo")
	#widegeo.df<-as.data.frame(data.obj,source.table="byspecies")

	###Calculate richness per SU per year
	iii<-0
	t.vars<-c("YearCollected","PlotName","Visit","NROW")
	test.ct<-crossTabulate(object = data.obj, t.vars = t.vars)
	q<-ResultsTable(test.ct)
	q2<-q[,2:ncol(q)]
	for(cc in 1:ncol(q2)){q2[,cc]<-as.numeric(q2[,cc])}
	q$TotalAbundance<-rowSums(q2)
	rich<-data.frame("Year"=names(q2),"Abundance"=colSums(q2))
	q3<-matrix(nrow=nrow(q2), ncol=ncol(q2))
	for(rr in 1:nrow(q2)){
		for(cc in 1:ncol(q2)){
			q3[rr,cc]<-ifelse(q2[rr,cc]>0,1,0)
		}
	}
	q$TotalRichness<-rowSums(q3)
	rich$Richness<-colSums(q3)
	
	##too many sampling units for this, but so you can see
	##p<-ggplot(data=q,aes(x=PlotName,y=TotalAbundance)) + geom_bar() + coord_flip()
	##p2<-ggplot(data=q,aes(x=PlotName,y=TotalRichness)) + geom_bar() + coord_flip()
	iii<-iii+1
	p<-ggplot(data=rich,aes(x=Year,y=Abundance)) + geom_bar() + coord_flip()
	results[[iii]]<-populate.RWOGraph(ordinal=iii, title="Total number of detections by Year", graph.obj = p, graph.note="All species combined")
	iii<-iii+1
	p2<-ggplot(data=rich,aes(x=Year,y=Richness)) + geom_bar() + coord_flip()
	results[[iii]]<-populate.RWOGraph(ordinal=iii, title="Species Richness by Year", graph.obj = p2, graph.note="")
	
	#describe CommonName
	iii<-iii+1
	test.dv<-try(describeVariable(object=data.obj, var="CommonName", type="d"), silent=TRUE)
	if (inherits(test.dv,"try-error")) {
		sink.error<-ifelse(grepl("Ravian Message:",test.dv), FALSE, TRUE)
		results[[iii]]<-populate.RWOError(error=test.dv, formData, data.obj=data.obj, res.ordinal=iii, sink.error=sink.error)
	} else {	#we have a description
		t.titl<-"Richness, Diversity, Dominance and Evenness Indices"
		results[[iii]]<-populate.RWOTable(ordinal = iii, title=t.titl,table.obj=ResultsTable(test.dv), table.note=Notes(test.dv))
	}
	
	return(results)

}



