# TODO: Add comment
# 
# Author: lsalas
# Date Created: April 3, 2015
###############################################################################

RavianWeb.Dispatch<-function(formData){
	#function to dispatch calls to processes in RavianWeb using new php-R abstraction layer
	source("/var/www/html/Analyst/CADC.R")
	
	#pass call to process
	results<-try(do.call(paste("RavianWeb.",formData$Process,sep=""),args=list(formData)),silent=TRUE)
	
	#evaluate response
	if(inherits(results,"try-error")){
		#if an error was returned, capture properly
		results[[1]]<-populate.RWOError(error=results, formData, res.ordinal="1")
	}
	
	#convert output to XML
	results.out<-try(do.call("RavianWeb.Output",args=list(results=results),envir=.GlobalEnv), silent=TRUE)
	
	#evaluate return
	if(inherits(results.out,"try-error")){
		#error generating XML, so, doing "by hand"...
		temp.file<-basename(tempfile(pattern=""))
		error.msg<-paste("An error has occurred when attempting to generate the XML tree.",
			"Please report the following error to developers: ", temp.file)
		save(results.out, formData, results, error.msg, file=paste("/var/www/html/tmp/",temp.file,".RData",sep=""))
		xmlgenPart1<-"<?xml version='1.0'?><RavianResults><RavianResultSet><RavianResult><RavianResultInfo><RavianResultOrdinal>1</RavianResultOrdinal><RavianResultType>Error</RavianResultType><RavianResultTitle>RavianWeb error message</RavianResultTitle><RavianResultNote></RavianResultNote></RavianResultInfo><RavianResultErrorMessage>"
		xmlgenPart2<-"</RavianResultErrorMessage></RavianResult></RavianResultSet></RavianResults>"
		resultsOut<-paste(xmlgenPart1,error.msg,xmlgenPart2,sep="")
	}else{
		#no errors generating XML
		resultsOut<-results.out
	}
	
	#cat results
	print(resultsOut)
}