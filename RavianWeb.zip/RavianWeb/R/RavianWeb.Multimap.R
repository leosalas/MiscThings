# TODO: Add comment
# 
# Author: lsalas
# Date created: Apr 8, 2010
###############################################################################


RavianWeb.Multimap <- function(formData) {
	options(warn=-1)
	results<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	if(do == "BBSData")do<-"PointCountData"
	if(do == "eBirdData")do<-"AreaSearchData"
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(ProtocolType=dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	more.filters<-""
	#if(dt=="Band")more.filters<-"NetHours IS NOT NULL"
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters="", taxon.groups=taxon.groups, 
					spatial.groups=spatial.groups,obs.groups=obs.groups),silent=TRUE) #try-catch
	co<-0
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		if(grepl("Ravian Message: There are no records available for analyses.", data.obj)==TRUE & dt=="PointCount" & grepl("SpeciesCode",formData$obsSQL)) data.obj<-"Ravian Message: No data to summarize - all records for this location are beyond 50m or fly-overs."
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	} else {
		#will produce: 
		#	- plot of sampling events by year, so need summary by that
		#	- diversity/evenness estimates table
		#	- estimate richness
		#	- phenology of diversity (to be added soon)
		#if species selected then:
		#	- plot of abundance estimate abundance
		#	- phenology plot of abundance (and other params if dt=="Band")(to be added soon)
		
		#so, defining path:
		if(!grepl("SpeciesCode",formData$obsSQL) & !grepl("CommonName",formData$obsSQL)){	#No species selected
			tv<-array(dim=c(1,4)) #can just create the string vector directly, but using the matrix instead in case we want to add other tables in the future
			st.titl<-array(dim=2)
			if(dt=="Band"){	
				tv[1,]<-c("YearCollected","YearCollected","JulianDay","NROW")
				#tv[2,]<-c("CommonName","YearCollected","ObservationCount","sum")
				st.titl[1]<-"Frequency of banding events by Year"
				#st.titl[2]<-"Number of captures by Year"
			}
			if(dt=="PointCount" | dt=="BBS"){	
				tv[1,]<-c("YearCollected","YearCollected","Visit","NROW")
				#tv[2,]<-c("CommonName","YearCollected","ObservationCount","sum")
				st.titl[1]<-"Frequency of visits by Year"
				#st.titl[2]<-"Number of observations by Year"
			}
			if(dt=="AreaSearch" | dt=="eBird"){	
				tv[1,]<-c("YearCollected","YearCollected","Visit","NROW")
				#tv[2,]<-c("CommonName","YearCollected","ObservationCount","sum")
				st.titl[1]<-"Frequency of visits by Year"
				#st.titl[2]<-"Number of observations by Year"
			}
			for(iii in 1:nrow(tv)){
				co=iii-1
				t.vars<-tv[iii,]
				test.ct<-try(crossTabulate(object = data.obj, t.vars = t.vars), silent=TRUE)
				if (inherits(test.ct,"try-error")) {
					results[[iii]]<-populate.RWOError(error=test.ct, formData, data.obj=do.test, res.ordinal=1, sink.error=TRUE)
				} else {	#we have a table/crosstable
					#beautify row/col headers
					ct.obj<-try(checkRowColumnNames(test.ct), silent=TRUE)
					if (inherits(ct.obj,"try-error")) ct.obj<-test.ct	
					if(iii==1){
						qq<-ResultsTable(ct.obj)
						qq$Count<-as.integer(as.character(qq$Count))
						qq$Count<-ifelse(qq$Count>5,5,qq$Count)
						bb<-ggplot2::ggplot(data=qq,aes(x=Year,y=Count)) + geom_point(size=4)
						pltxtfnty<-ggplot2::theme(axis.title.y=element_text(angle=90,size=16),
								axis.text.y=element_text(size=14))
						pltheme<-ggplot2::theme_bw()
						pltbrks<-ggplot2::scale_y_continuous(breaks=c(1,2,3,4,5),labels=c("1","2","3","4","5+"),limits=c(0,6))
						pllabs<-ggplot2::labs(y="Number of Visits")
						cc <- bb + pltxtfnty + pltheme + pltbrks + pllabs
					}else{
						results[[co]]<-populate.RWOTable(ordinal = co, title=st.titl[co],table.obj=ResultsTable(ct.obj), table.note="")
					}
				}
			}
			#Diversity/evenness - results will make little sense for eBird data
			test.dv<-try(describeVariable(object=data.obj, var="CommonName", type="d"), silent=TRUE)
			if (inherits(test.dv,"try-error")) {
				co=co+1
				results[[co]]<-populate.RWOError(error=test.dv, formData, data.obj=do.test, res.ordinal=co, sink.error=TRUE)
			} else {	#we have a description
				co=co+1
				t.titl<-"Richness, Diversity, Dominance and Evenness Indices"
				t.note<-""
				if(dt=="eBird")t.note<-"Diversity, dominance and evenness indices are not appropriate to eBird data"
				results[[co]]<-populate.RWOTable(ordinal = co, title=t.titl,table.obj=ResultsTable(test.dv), table.note=t.note)
			}
			#Estimate richness...
			if (dt=="AreaSearch") {	
				summarize.by = "Plot"
				sampling.unit = "Plot"
				time.var="YearCollected"
			}
			if (dt=="Band") {
				summarize.by = "StationName"
				sampling.unit = "StationName"
				time.var="YearCollected"
			}
			if (dt=="PointCount" | dt=="BBS") { 
				summarize.by = "Transect"
				sampling.unit = "Point"
				time.var="YearCollected"
			}
			
			if(spatial.groups != "") summarize.by="SpatialGroup"
			sink.error<-FALSE
			if(dt=="eBird"){
				return(results)
			}else{
				test.ri<-try(estimateRichness(object = data.obj,summarize.by=summarize.by,sampling.unit=sampling.unit,time.var=time.var,
								guild=taxon.groups.name,spatial.units=spatial.groups.name),silent=TRUE)
				if (inherits(test.ri,"try-error")) {
					co=co+1
					results[[co]]<-populate.RWOError(error=test.ri, formData, data.obj=data.obj, res.ordinal=co)
					return(results)
				} else {	#We have richness estimates...
					#store the table
					#change row and col headers first
					co=co+1
					ri.obj<-try(checkRowColumnNames(test.ri), silent=TRUE)
					if(inherits(ri.obj,"try-error")) ri.obj<-test.ri
					test.df<-try(do.call("as.data.frame",args=list(x=ri.obj),envir=.GlobalEnv),silent=TRUE)		
					if (inherits(test.df,"try-error")) {
						results[[co]]<-populate.RWOError(error=test.df, formData, data.obj = test.ri, res.ordinal=co)
						return(results)	#ends here - can't continue
					} else{
						results[[co]]<-populate.RWOTable(ordinal = co, title=TableTitle(test.ri),table.obj=test.df[,-1], table.note="")
						
						########################################
						#store the graph
						#First beautify the labels
						ri.plt.obj<-try(checkPlotLabels(test.ri), silent=TRUE)
						if(inherits(ri.plt.obj,"try-error")) ri.plt.obj<-test.ri
						tmp.plot<-try(plot(ri.plt.obj, plot.type="point",facet.wrap=FALSE),silent=TRUE)
						if (inherits(tmp.plot,"try-error")){
							co=co+1
							ifelse(grepl("Ravian Message:",tmp.plot), sink.error<-FALSE, sink.error<-TRUE)
							results[[co]]<-populate.RWOError(error=tmp.plot, formData, data.obj = test.ri, res.ordinal=co, sink.error=sink.error)
						} else {
							co=co+1
							results[[co]]<-populate.RWOGraph(ordinal=co, title=GraphTitle(tmp.plot), graph.obj = ResultsGraph(tmp.plot), graph.note="")
						}
						
						######################################
						#estimate trend
						if(NROW(ResultsTable(test.ri))>1){
							if ((min(test.df$Variance, na.rm=TRUE)<=0) | ("TRUE" %in% is.na(test.df$Variance))) {
								results.trend<-try(trend(test.ri,weighted=FALSE,reg.type="simple",do.log=FALSE),silent=TRUE)
							} else {
								results.trend<-try(trend(test.ri,weighted=TRUE,reg.type="simple",do.log=FALSE),silent=TRUE)
							}
							if (inherits(results.trend,"try-error")) {
								co=co+1
								sink.error<-ifelse(grepl("Ravian Message:",results.trend), FALSE, TRUE)
								results[[co]]<-populate.RWOError(error=results.trend, formData, data.obj = test.ri, res.ordinal=co, sink.error=sink.error)
							}else{
								co=co+1
								if(NROW(PlotParameters(test.ri)$g.var)>1 | is.null(PlotParameters(test.ri)$g.var) | ((NROW(PlotParameters(test.ri)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ri)$g.var)]))>1))){
									trend.dat<-paste("Regression estimated combining all categories of ",paste(PlotParameters(test.ri)$g.var,collapse=" x "),".", sep="")
								}else {
									trend.dat<-""
								}
								trend.note<-paste("Data source: ",TableTitle(test.ri),". ",trend.dat,Notes(results.trend), sep="")
								results[[co]]<-populate.RWOTable(ordinal = co, title=TableTitle(results.trend),table.obj=ResultsTable(results.trend), table.note="")
							}
							if (!inherits(tmp.plot,"try-error") & !inherits(results.trend,"try-error")){
								##################################
								#Plotting the trend
								ggg<-ResultsGraph(tmp.plot)
								class(ggg)<-c("gg","ggplot")
								plttrnd<-ggplot2::stat_abline(intercept=ResultsTable(results.trend)[,2][1], slope=ResultsTable(results.trend)[,2][2])
								trnd.plot1<-ggg + plttrnd
								class(trnd.plot1)<-"ggplot"
								co=co+1
								results[[co]]<-populate.RWOGraph(ordinal=co, title=TableTitle(results.trend), graph.obj = trnd.plot1, graph.note="")
								
								##################################
								##If we ever want to plot by grouping vars, this is the easiest way...Just showing off here - sorry!
								if(NROW(PlotParameters(test.ri)$g.var)>1 | is.null(PlotParameters(test.ri)$g.var) | ((NROW(PlotParameters(test.ri)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ri)$g.var)]))>1))){
									trnd.plot2<-ggg + geom_smooth(method = "lm", se=F)
									class(trnd.plot2)<-"ggplot"
									plt.title<-paste(TableTitle(results.trend),". Regression lines shown by category of",paste(PlotParameters(test.ri)$g.var,collapse=" x "))
									trend.note<-paste("Data source: ",TableTitle(test.ri),". ",Notes(results.trend), sep="")
									co=co+1
									results[[co]]<-populate.RWOGraph(ordinal=co, title=plt.title, graph.obj = trnd.plot2, graph.note="")
								}
							}
						}
					}
				}
			}
			if(inherits(cc,"ggplot")){
				co=co+1
				results[[co]]<-populate.RWOGraph(ordinal=co, title="Number of Visits per Year", graph.obj = cc, graph.note="")
			}
			return(results)
		}else{	#A species selected
			if(dt=="eBird"){
				res.obj<-"Ravian Message: It is not currently possible estimate abundance from eBird data. Please select another dataset."
				results[[1]]<-populate.RWOError(error=res.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=FALSE)
				return(results)	#ends here - can't continue
			}else{
				effort.flag<-FALSE
				if (dt=="AreaSearch") {
					summarize.by = "Plot"
					sampling.unit = "Plot"	
					time.var="YearCollected"
					units = "Hectare"
					radius<-NULL
				}
				if (dt=="Band") {
					#check for effort
					if(sum(is.na(EffortData(data.obj)$NetHours))>0)effort.flag<-TRUE
					summarize.by = "StationName"
					sampling.unit<-"StationName"
					time.var="YearCollected"
					units<-"2"
					radius<-NULL
				}
				if (dt=="PointCount" | dt=="BBS") {
					radius<-NULL
					if (grepl("DistanceFromObserver",formData$obsSQL)) {
						eee<-substr(formData$obsSQL,start=(regexpr("DistanceFromObserver",formData$obsSQL)+20),stop=nchar(formData$obsSQL))
						radius<-as.numeric(substr(eee,start=regexpr("<=",eee)+2,stop=ifelse(grepl(" AND ",eee),regexpr(" AND ",eee)-1,nchar(eee))))
					}
					summarize.by = "Transect"
					sampling.unit<-"Point"
					time.var="YearCollected"
					units<-"Hectare"
				}
				if(spatial.groups != "") summarize.by="SpatialGroup"
				sink.error<-FALSE
				if(effort.flag==TRUE & nrow(EffortData(data.obj))==sum(is.na(EffortData(data.obj)$NetHours))){
					res.obj<-"Ravian Message: Some or all the selected data have no associated effort. Cannot estimate abundance from banding data without net-hour effort."
					co<-co+1
					results[[co]]<-populate.RWOError(error=res.obj, formData=formData, data.obj=do.test, res.ordinal=co, sink.error=FALSE)
					return(results)
				}else{
					#remove NA rows and warn emptor
					table.note=""
					if(effort.flag==TRUE){
						table.note<-"Caution: some records had no net hours - estimates are not reliable."
						tmp.eff.t<-subset(EffortData(data.obj), !is.na(EffortData(data.obj)$NetHours))
						EffortData(data.obj)<-tmp.eff.t
						if(NROW(tmp.eff.t)==0){
							res.obj<-"Ravian Message: Some or all the selected data have no associated effort. Cannot estimate abundance from banding data without net-hour effort."
							co<-co+1
							results[[co]]<-populate.RWOError(error=res.obj, formData=formData, data.obj=data.obj, res.ordinal=co, sink.error=FALSE)
							return(results)
						}
						tmp.obs.t<-subset(ObsData(data.obj), !is.na(ObsData(data.obj)$NetHours))
						if(NROW(tmp.obs.t)==0){
							res.obj<-"Ravian Message: Some or all the selected data have no associated effort. Cannot estimate abundance from banding data without net-hour effort."
							co<-co+1
							results[[co]]<-populate.RWOError(error=res.obj, formData=formData, data.obj=data.obj, res.ordinal=co, sink.error=FALSE)
							return(results)
						}
						ObsData(data.obj)<-tmp.obs.t
					}
					phplt<-try(pheno.plot(object=data.obj,fields=c("ObservationCount"),bin.size=10,type="circular"))
					if (inherits(phplt,"try-error")==FALSE) {
						co<-co+1
						results[[co]]<-populate.RWOGraph(ordinal=co, title="Phenology of frequency of counts in 10-day bins", graph.obj = ResultsGraph(phplt), graph.note="")
					}
					test.ab<-try(estimateAbundance(object = data.obj,summarize.by=summarize.by,sampling.unit=sampling.unit,time.var=time.var,
									units=units,guild=taxon.groups.name,spatial.units=spatial.groups.name,radius=radius),silent=TRUE)
					
					if (inherits(test.ab,"try-error")) {
						co<-co+1
						results[[co]]<-populate.RWOError(error=test.ab, formData=formData, data.obj=do.test, res.ordinal=co)
						return(results)
					} else {	#We have abundance estimates...
						#store the table
						#beautify column names first
						ab.obj<-try(checkRowColumnNames(object=test.ab), silent=TRUE)
						if(inherits(ab.obj,"try-error")) ab.obj<-test.ab
						test.df<-try(do.call("as.data.frame",args=list(x=ab.obj),envir=.GlobalEnv),silent=TRUE)		#this is for test only??  Delete it?
						co<-co+1
						if (inherits(test.df,"try-error")) {
							results[[co]]<-populate.RWOError(error=test.df, formData=formData, data.obj = test.ab, res.ordinal="1")
							return(results)	#ends here - can't continue
						} else{
							results[[co]]<-populate.RWOTable(ordinal = co, title=TableTitle(test.ab),table.obj=test.df, table.note=table.note)
							
							########################################
							#store the graph
							#First beautify the labels
							ab.plt.obj<-try(checkPlotLabels(test.ab), silent=TRUE)
							if(inherits(ab.plt.obj,"try-error")) ab.plt.obj<-test.ab
							co<-co+1
							tmp.plot<-try(plot(ab.plt.obj, plot.type="point",facet.wrap=FALSE),silent=TRUE)
							if (inherits(tmp.plot,"try-error")){
								ifelse(grepl("Ravian Message:",tmp.plot), sink.error<-FALSE, sink.error<-TRUE)
								results[[co]]<-populate.RWOError(error=tmp.plot, formData=formData, data.obj = test.ab, res.ordinal=co, sink.error=sink.error)
							} else {
								results[[co]]<-populate.RWOGraph(ordinal=co, title=GraphTitle(tmp.plot), graph.obj = ResultsGraph(tmp.plot), graph.note=table.note)
							}
							
							######################################
							#estimate trend
							if ((min(test.df$Variance, na.rm=TRUE)<=0) | ("TRUE" %in% is.na(test.df$Variance))) {
								results.trend<-try(trend(test.ab,weighted=FALSE,reg.type="simple",do.log=FALSE),silent=TRUE)
							} else {
								results.trend<-try(trend(test.ab,weighted=TRUE,reg.type="simple",do.log=FALSE),silent=TRUE)
							}
							co<-co+1
							if (inherits(results.trend,"try-error")) {
								ifelse(grepl("Ravian Message:",results.trend), sink.error<-FALSE, sink.error<-TRUE)
								results[[co]]<-populate.RWOError(error=results.trend, formData=formData, data.obj = test.ab, res.ordinal=co, sink.error=sink.error)
								return(results)	#ends here - can't continue
							}else{
								if(NROW(PlotParameters(test.ab)$g.var)>1 | ((NROW(PlotParameters(test.ab)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ab)$g.var)]))>1))){
									trend.dat<-paste("Regression estimated combining all categories of ",paste(PlotParameters(test.ab)$g.var,collapse=" x "),".", sep="")
								}else {
									trend.dat<-""
								}
								trend.note<-paste("Data source: ",TableTitle(test.ab),". ",trend.dat,Notes(results.trend), sep="")
								results[[co]]<-populate.RWOTable(ordinal = co, title=TableTitle(results.trend),table.obj=ResultsTable(results.trend), table.note=table.note)
								if (inherits(tmp.plot,"try-error")){
									return(results)
								}else{
									co<-co+1
									##################################
									#Plotting the trend
									ggg<-ResultsGraph(tmp.plot)
									class(ggg)<-c("gg","ggplot")
									plttrnd<-ggplot2::stat_abline(intercept=ResultsTable(results.trend)[,2][1], slope=ResultsTable(results.trend)[,2][2])
									trnd.plot1<-ggg + plttrnd
									class(trnd.plot1)<-"ggplot"
									results[[co]]<-populate.RWOGraph(ordinal=co, title=TableTitle(results.trend), graph.obj = trnd.plot1, graph.note=table.note)
									##################################
									##If we ever want to plot by grouping vars, this is the easiest way...Just showing off here - sorry!
									if(NROW(PlotParameters(test.ab)$g.var)>1 | ((NROW(PlotParameters(test.ab)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ab)$g.var)]))>1))){
										trnd.plot2<-ggg + geom_smooth(method = "lm", se=F)
										class(trnd.plot2)<-"ggplot"
										plt.title<-paste(TableTitle(results.trend),". Regression lines shown by category of",paste(PlotParameters(test.ab)$g.var,collapse=" x "))
										trend.note<-paste("Data source: ",TableTitle(test.ab),". ",Notes(results.trend), sep="")
										co<-co+1
										results[[co]]<-populate.RWOGraph(ordinal=co, title=plt.title, graph.obj = trnd.plot2, graph.note=table.note)
									}
									return(results)	#normal ending
								}
							}
						}
					}
				}
			}
		}
	}
}