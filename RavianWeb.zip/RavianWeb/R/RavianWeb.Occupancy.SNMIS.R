# RavianWeb.Occupancy.SNMIS.R
# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Creation Date: Mar 2, 2011
###############################################################################


RavianWeb.Occupancy.SNMIS <- function(formData) {
	options(warn=-1)
	results<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	more.filters<-"ProtocolCode NOT IN ('VCP300_PLAYBACK','VCP300_2xOBS_DEP','VCP300_2xOBS_IND')"
	more.obs.filters<-"DistanceFromObserver<=100"
	#if(dt=="Band")more.filters<-"NetHours IS NOT NULL"
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	obs.groups.name<-formData$ObservationGroupsName
	
	########
	reg.type<-"simple"
	############
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters=more.obs.filters, taxon.groups=taxon.groups, 
					spatial.groups=spatial.groups, obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
		summarize.by = ifelse(spatial.groups=="","StudyArea","SpatialGroup") 
		sampling.unit<-"Point"
		time.var="YearCollected"
	
		test.ab<-try(estimateOccupancy(object = data.obj,summarize.by=summarize.by,time.var=time.var,
						guild=taxon.groups.name,spatial.units=spatial.groups.name,obs.group=obs.groups.name),silent=TRUE)
		
	zz<-1
	if (inherits(test.ab,"try-error")) {
		results[[zz]]<-populate.RWOError(error=test.ab, formData=formData, data.obj=do.test, res.ordinal=zz)
		return(results)
	} else {	#We have abundance estimates...
		#report the results table - beautify column names first
		ab.obj<-try(checkRowColumnNames(object=test.ab), silent=TRUE)
		if(inherits(ab.obj,"try-error")) ab.obj<-test.ab
		test.df<-try(do.call("as.data.frame",args=list(x=ab.obj),envir=.GlobalEnv),silent=TRUE)
		if (inherits(test.df,"try-error")) {
			results[[zz]]<-populate.RWOError(error=test.df, formData=formData, data.obj = test.ab, res.ordinal=zz)
			return(results)	#ends here - can't continue
		} else{
			tbl.ttl<-paste("Point-level Estimates of Occupancy (Proportion of Points With Detections Within 100m) by",spatial.groups.name,"and Year")
			#test.df<-test.df[,c(-1,-4,-5)]
			sp.list<-"Species: selected species."
			if(taxon.groups!=""){
				tgsp<-fromJSON(taxon.groups)
				splst<-paste(tgsp[[1]],collapse=", ")
				sp.list<-paste("Species: ",splst,".",sep="")
			}
			table.note<-Notes(test.ab)
			table.note<-paste(sp.list,table.note)
			results[[zz]]<-populate.RWOTable(ordinal = zz, title=tbl.ttl,table.obj=test.df, table.note=table.note)
		}
		
		########################################
		#Make and store graphs
		#First beautify the labels
		ab.plt.obj<-try(checkPlotLabels(test.ab), silent=TRUE)
		if(inherits(ab.plt.obj,"try-error")) ab.plt.obj<-test.ab
		TableTitle(ab.plt.obj)<-tbl.ttl
		#Now determine if you need facet or plot as is 
		rst<-ResultsTable(ab.plt.obj)
		sst<-SupportData(ab.plt.obj)
		tgf<-ifelse(taxon.groups!="",taxon.groups.name,"ScientificName")
		sgf<-ifelse(spatial.groups!="",spatial.groups.name,summarize.by)
		plot.subset<-""
		for(ttt in unique(rst[,c(tgf)])){
			ss.note<-paste("Subset: ",tgf," = ",ttt,sep="")
			srt<-subset(rst,rst[,c(tgf)]==ttt)
			sst2<-subset(sst,sst[,(tgf)]==ttt)
			s.ab.plt.obj<-ab.plt.obj
			SupportData(s.ab.plt.obj)<-sst2
			#subset by spatial location if unique>9
			if(length(unique(srt[,c(sgf)]))>9 | obs.groups.name!=""){
				for(vvv in unique(srt[,c(sgf)])){
					ss.note<-paste(ss.note,"; ",sgf," = ",vvv,".",sep="")
					srt2<-subset(srt,srt[,c(sgf)]==vvv)
					#subset by obs.groups, if they exist
					if(obs.groups.name!=""){
						ogs<-fromJSON(obs.groups)
						for(nnn in names(ogs[[1]])){
							ss.note<-paste(ss.note,"; ",ogs[[1]]," = ",nnn,sep="")
							srt3<-subset(srt2,srt2[,c(obs.groups.name)]==nnn)
							ResultsTable(s.ab.plt.obj)<-srt3
							#plot.subset<-paste("- Plot for ",ttt," and ",vvv," and ",nnn,".",sep="")
							zz<-zz+1
							results[[zz]]<-makeRavianPlot(dat.obj=s.ab.plt.obj,plot.type="point",plot.subset=plot.subset,zz=zz,formData=formData)
						}
					}else{
						ResultsTable(s.ab.plt.obj)<-srt2
						#plot.subset<-paste("- Plot for ",ttt," and ",vvv,".",sep="")
						zz<-zz+1
						results[[zz]]<-makeRavianPlot(dat.obj=s.ab.plt.obj,plot.type="point",plot.subset=plot.subset,zz=zz,formData=formData)
					}
				}
			}else{	#let the plotting function handle spatial group partitioning
				ResultsTable(s.ab.plt.obj)<-srt
				#plot.subset<-paste("- Plot for ",ttt,".",sep="")
				zz<-zz+1
				results[[zz]]<-makeRavianPlot(dat.obj=s.ab.plt.obj,plot.type="point",plot.subset=plot.subset,zz=zz,formData=formData)
			}
		}
		
		######################################
		#estimate trend 
		#subset by taxon.group (tgf in ResultsTable)
		for(ttt in (unique(rst[,c(tgf)]))){
			srt<-subset(rst,rst[,c(tgf)]==ttt)
			sst2<-subset(sst,sst[,(tgf)]==ttt)
			res.t.obj<-test.ab
			ResultsTable(res.t.obj)<-srt
			SupportData(res.t.obj)<-sst2
			if (min(srt$StandardError, na.rm=TRUE)<=0 | ("TRUE" %in% is.na(srt$StandardError))) {
				results.trend<-try(trend(res.t.obj,weighted=FALSE,reg.type=reg.type,do.log=FALSE),silent=TRUE)
			} else {
				results.trend<-try(trend(res.t.obj,weighted=TRUE,reg.type=reg.type,do.log=FALSE),silent=TRUE)
			}
			zz<-zz+1
			if (inherits(results.trend,"try-error")) {
				sink.error<-ifelse(grepl("Ravian Message:",results.trend),FALSE,TRUE)
				results[[zz]]<-populate.RWOError(error=results.trend, formData=formData, data.obj = test.ab, res.ordinal=zz, sink.error=sink.error)
				return(results)	#ends here - can't continue
			}else{
				#remove intercept, add CI
				table.obj=ResultsTable(results.trend)
				table.obj<-table.obj[c(-1),]
				se.est<-table.obj$SE_value
				slope.est<-table.obj$Value
				signif.note<-""
				if(!is.null(se.est) & !is.na(se.est) & !is.null(slope.est) & !is.na(slope.est) & se.est!=0){
					up.ci<-round(slope.est+(1.96*se.est),digits=3)
					lw.ci<-round(slope.est-(1.96*se.est),digits=3)
					ci.val<-paste("(",lw.ci,",",up.ci,")",sep="")
					table.obj$Confidence_Interval<-ci.val
					if((slope.est>0 & lw.ci<0) | (slope.est<0 & up.ci>0))signif.note<-"Slope p-value < 0.05"
				}else{
					table.obj$Confidence_Interval<-"N/A"
				}
				trend.title<-paste("Simple linear trend estimate of Occupancy by year for ",ttt,".", sep="")
				if(spatial.groups.name=="Bioregion"){
					trend.dat<-signif.note
				}else{
					trend.dat<-paste("Regression estimated combining all categories of ",spatial.groups.name,".", signif.note, sep="")
				}
				trend.note<-paste("Data source: ",tbl.ttl,". ",trend.dat,Notes(results.trend), sep="")
				results[[zz]]<-populate.RWOTable(ordinal = zz, title=trend.title,table.obj=table.obj, table.note=trend.note)
				
				#plot this trend estimate - remove all groups
				PlotParameters(res.t.obj)$g.var<-""
				PlotParameters(res.t.obj)$g.label<-""
				#remove standard errors so these are not plotted
				res.tbl<-ResultsTable(res.t.obj)
				res.tbl$StandardError<-0
				ResultsTable(res.t.obj)<-res.tbl
				ttl.smooth<-switch(reg.type,"simple"="","loess"=" Using Locally Weighed (loess) Smoother","cubic"=" Using Cubic Spline Smoother")
				plot.ttl<-paste("Trend in Occupancy over ",time.var,". ",trend.title,ttl.smooth,sep="")
				tmp.plot<-try(plot(res.t.obj, plot.type="point",facet.wrap=FALSE,reg.type=reg.type),silent=TRUE)
				zz<-zz+1
				if (inherits(tmp.plot,"try-error")) {
					sink.error<-ifelse(grepl("Ravian Message:",tmp.plot),FALSE,TRUE)
					results[[zz]]<-populate.RWOError(error=tmp.plot, formData=formData, data.obj = res.t.obj, res.ordinal=zz, sink.error=sink.error)
				}else{
					graph.obj<-ResultsGraph(tmp.plot)
					class(graph.obj)<-c("gg","ggplot")
					graph.obj<-graph.obj + stat_smooth(method="lm", se=TRUE)
					class(graph.obj)<-"ggplot"
					results[[zz]]<-populate.RWOGraph(ordinal=zz, title=trend.title, graph.obj = graph.obj, graph.note=trend.note)
				}
			}
		}
	}
	return(results)
}
