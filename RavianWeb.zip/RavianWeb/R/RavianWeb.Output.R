# TODO: Add comment
# Provides a test set of "formData" for RavianWeb
# Author: lsalas
###############################################################################

#This wrapper is supposed to loop through all RWO objects in the list submitted,
#and execute in each the method that converts them into XML
#then append each XML segment to the bottom of the full list
#HOWEVER... it may not work that way and instead, the method will be abandoned
#and this wrapper will do the whole XML on the list, not as a method
#This because it may not be possible to create snippets of XML on the fly

###LEOOOO tables cannot contain NA values!

RavianWeb.Output<-function (results){
	#HERE we can put a sort on the results by ordinal before parsing
	#HERE we can filter out some of the result objects
	results.clean<-removeNullsBlanks(results)
	#create the XML doc
	KK<-XML::xmlTree("RavianResults")	#root
	#add top node 
	KK$addNode("RavianResultSet",close=FALSE)
	#loop through each RWO in results
	# TODO: Check for duplicate ordinals, and if exists then... what? Put one of them at the bottom of the list?
	nob<-length(results.clean)
	for(pp in 1:nob){
		#retrieve the RWO object
		rwoo<-results.clean[[pp]]
		#call method makeXML and pass the XMLDoc
		xml.seg.add<-try(makeXML(rwo.obj=rwoo,xml.doc=KK), silent=TRUE)
		#append the segment
		KK<-xml.seg.add
	}	
	KK$closeTag() # </RavianResultSet
	KK$closeTag() # </RavianResults>
	return(XML::saveXML(KK))
}

#function to dispatch the functions to remove nulls and blanks from results
removeNullsBlanks<-function(results.list){
	for(rrr in 1:length(results.list)){
		cro<-results.list[[rrr]]
		if(as.character(class(cro))=="RavianWebOutGraph") {
			cro.clean<-cleanGraphOut(cro,rrr)
		} else if(as.character(class(cro)) %in% c("RavianWebOutTable","RavianWebOutXTable")) {
			cro.clean<-cleanTableOut(cro,rrr)
		} else {
			cro.clean<-cleanErrorOut(cro,rrr)
		}
		results.list[[rrr]]<-cro.clean
	}
	return(results.list)
}

cleanGraphOut<-function(rwog,rrr){
	if(length(ResultOrdinal(rwog))==0) ResultOrdinal(rwog)<-rrr
	if(length(ResultType(rwog))==0) ResultType(rwog)<-"Graph"
	if(length(ResultTitle(rwog))==0) ResultTitle(rwog)<-"Graph"
	if(length(ResultNote(rwog))==0) ResultNote(rwog)<-"NA"

	if(length(ResultGraph(rwog))==0) {
		#convert the object into an error
		new.rwo<-new("RavainWebOutSystemError")
		ResultOrdinal(new.rwo)<-rrr
		ResultType(new.rwo)<-"System Error"
		ResultTitle(new.rwo)<-"Attention"
		ResultNote(new.rwo)<-"A graph was expected"
		ResultError(new.rwo)<-"An error occured, but details are missing"
		rwog<-new.rwo
	}
	return(rwog)
}

cleanTableOut<-function(rwot,rrr){
	if(length(ResultOrdinal(rwot))==0) ResultOrdinal(rwot)<-rrr
	if(length(ResultType(rwot))==0) ResultType(rwot)<-"Table"
	if(length(ResultTitle(rwot))==0) ResultTitle(rwot)<-"Table"
	if(length(ResultNote(rwot))==0) ResultNote(rwot)<-"NA"

	if(as.character(class(rwot))=="RavianWebOutTable"){
		rwot.table<-ResultTable(rwot)
	}else{
		rwot.table<-ResultXTable(rwot)
	}
	if(length(rwot.table)==0) {
		#convert the object into an error object
		new.rwo<-new("RavainWebOutSystemError")
		ResultOrdinal(new.rwo)<-rrr
		ResultType(new.rwo)<-"System Error"
		ResultTitle(new.rwo)<-"Attention"
		ResultNote(new.rwo)<-"A table was expected"
		ResultError(new.rwo)<-"An error occured, but details are missing"
		rwot<-new.rwo
	}else{
		#check for NA's or NULL's in every column and replace with "NA"
		for(ccc in 1:NCOL(rwot.table)){
			if(is.factor(rwot.table[,ccc])) rwot.table[,ccc]<-as.character(rwot.table[,ccc])
			
			for(zzz in 1:NROW(rwot.table)){
				rwot.table[zzz,ccc]<-ifelse(is.na(rwot.table[zzz,ccc]),"NA",rwot.table[zzz,ccc])
				rwot.table[zzz,ccc]<-ifelse(is.null(rwot.table[zzz,ccc]),"NA",rwot.table[zzz,ccc])
				rwot.table[zzz,ccc]<-ifelse(is.nan(rwot.table[zzz,ccc]),"NA",rwot.table[zzz,ccc])
			}

		}
		if(as.character(class(rwot))=="RavianWebOutTable"){
			ResultTable(rwot)<-rwot.table
		}else{
			ResultXTable(rwot)<-rwot.table
		}
	}
	return(rwot)
}

cleanErrorOut<-function(rwog,rrr){
	if(length(ResultOrdinal(rwog))==0) ResultOrdinal(rwog)<-rrr
	if(length(ResultType(rwog))==0) ResultType(rwog)<-"Error"
	if(length(ResultTitle(rwog))==0) ResultTitle(rwog)<-"Error"
	if(length(ResultNote(rwog))==0) ResultNote(rwog)<-"NA"
	if(length(ResultError(rwog))==0) ResultError(rwog)<-"An error occured, but details are missing"
	return(rwog)
}
