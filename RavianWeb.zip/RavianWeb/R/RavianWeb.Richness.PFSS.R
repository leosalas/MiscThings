# RavianWeb.estimateRichness.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org, mherzog@prbo.org
# Creation Date: Oct 20, 2009
###############################################################################

RavianWeb.Richness.PFSS <- function(formData) {
	options(warn=-1)
	results<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	#more.filters="(JulianDay >= 314 and JulianDay <= 354)"
	more.filters="((JulianDay >= 314 AND JulianDay <= 365) OR (JulianDay >= 1 AND JulianDay <= 46))"	#extending to
	more.obs.filters="SpeciesCode IN ('NOLA','SOLA','BBPL','EUGP','AMGP','LEGP','PAGP','LGPL',
				'LSAP','GSAP','COPL','SNPL','WIPL','CRPL','SEPL','PIPL','LRPL','KILL','MOPL','EUDO','PEEP','SMAL','EUOY','AMOY',
				'BLOY','BWST','BNST','HAST','AMAV','TESA','COSA','SPSA','GRSA','SOSA','GTTA','WATA','SPRE','GRYE','COMG','WILL','LEYE',
				'MASA','WOSA','COMR','XYEL','YELL','UPSA','LICU','ESCU','WHIM','BTCU','FECU','SBCU','EUCU','LBCU','XNUM','BTGD',
				'HUGO','BTGO','MAGO','ALMG','LARG','RUTU','BLTU','XBRT','SURF','ROCK','GRKN','REKN','SAND','SESA','WESA','RNST','LIST',
				'TEST','LTST','LESA','WRSA','BASA','PESA','SPTS','PUSA','ROSA','DUNL','CUSA','STSA','XWLD','XWLS','XWSD','LSPD','WCAL',
				'WEDU','WLDU','WLSA','XCAL','XSLS','XSMS','SBSA','BBIS','BBSA','RUFF','SBDO','LBDO','DOWI','MEDI','XDOW','JASN','WISN',
				'COSN','PTSN','EUWO','AMWO','WIPH','RNPH','REPH','PHAL','XPHL','XWRP')"
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	obs.groups.name<-formData$ObservationGroupsName
		
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters=more.obs.filters, taxon.groups="", spatial.groups=spatial.groups, 
					obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	obs.dat<-ObsData(data.obj)
	if(NROW(obs.dat)==0){
		results[[1]]<-populate.RWOError(error="Ravian Message: No observational data available for the selection.", formData, data.obj = data.obj, res.ordinal=1, sink.error=FALSE)
		return(results)
	}
	###HERE: add the temporal group "Season" to aggregate Nov to Feb in EffortData and ObsData - this function is in RavainWeb.Summary.PFSS
	data.obj<-try(addSeason(data.obj),silent=TRUE)
	if (inherits(data.obj,"try-error")) {
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal=1, sink.error=TRUE)
		return(results)	#ends here - can't continue
	}
	
	#remove sampling.units
	#remove guild and add obs.group
	
	time.var<-"Season"
	summarize.by<-ifelse(spatial.groups=="","SUgroup","SpatialGroup")

	test.ri<-try(estimateRichness(object = data.obj,summarize.by=summarize.by,time.var=time.var,
					spatial.units=spatial.groups.name,obs.group=obs.groups.name),silent=TRUE)
	
	zz<-1
	if (inherits(test.ri,"try-error")) {
		sink.error<-ifelse(grepl("Ravian Message:",test.ri), FALSE, TRUE)
		results[[zz]]<-populate.RWOError(error=test.ri, formData, data.obj=data.obj, res.ordinal=zz,sink.error=sink.error)
		return(results)
	} else {	#We have abundance estimates...
		#store the table
		#change row and col headers first
		ri.obj<-try(checkRowColumnNames(test.ri), silent=TRUE)
		if(inherits(ri.obj,"try-error")) ri.obj<-test.ri
		test.df<-try(do.call("as.data.frame",args=list(x=ri.obj),envir=.GlobalEnv),silent=TRUE)		
		if (inherits(test.df,"try-error")) {
			sink.error<-ifelse(grepl("Ravian Message:",test.df), FALSE, TRUE)
			results[[zz]]<-populate.RWOError(error=test.df, formData, data.obj = test.ri, res.ordinal=zz,sink.error=sink.error)
			return(results)	#ends here - can't continue
		} #else...
		results[[zz]]<-populate.RWOTable(ordinal = zz, title=TableTitle(test.ri),table.obj=test.df, table.note=Notes(test.ri))
		
		########################################
		#store the graph
		#First beautify the labels
		zz<-zz+1
		ri.plt.obj<-try(checkPlotLabels(test.ri), silent=TRUE)
		if(inherits(ri.plt.obj,"try-error")) ri.plt.obj<-test.ri
		
		tmp.plot<-try(plot(ri.plt.obj, plot.type="point",facet.wrap=FALSE),silent=TRUE)
		if (inherits(tmp.plot,"try-error")){
			sink.error<-ifelse(grepl("Ravian Message:",tmp.plot), FALSE, TRUE)
			results[[zz]]<-populate.RWOError(error=tmp.plot, formData, data.obj = test.ri, res.ordinal=zz, sink.error=sink.error)
		} else {
			results[[zz]]<-populate.RWOGraph(ordinal=2, title=GraphTitle(tmp.plot), graph.obj = ResultsGraph(tmp.plot), graph.note=Notes(tmp.plot))
		}
		
		######################################
		#estimate trend
		zz<-zz+1
		if ((min(test.df$Variance, na.rm=TRUE)<=0) | ("TRUE" %in% is.na(test.df$Variance))) {
			results.trend<-try(trend(test.ri,weighted=FALSE,reg.type="simple",do.log=FALSE),silent=TRUE)
		} else {
			results.trend<-try(trend(test.ri,weighted=TRUE,reg.type="simple",do.log=FALSE),silent=TRUE)
		}
		if (inherits(results.trend,"try-error")) {
			sink.error<-ifelse(grepl("Ravian Message:",results.trend), FALSE, TRUE)
			results[[zz]]<-populate.RWOError(error=results.trend, formData, data.obj = test.ri, res.ordinal=zz, sink.error=sink.error)
			return(results)	#ends here - can't continue
		}else{
			if(NROW(PlotParameters(test.ri)$g.var)>1 | is.null(PlotParameters(test.ri)$g.var) | ((NROW(PlotParameters(test.ri)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ri)$g.var)]))>1))){
				trend.dat<-paste("Regression estimated combining all categories of ",paste(PlotParameters(test.ri)$g.var,collapse=" x "),".", sep="")
			}else {
				trend.dat<-""
			}
			trend.note<-paste("Data source: ",TableTitle(test.ri),". ",trend.dat,Notes(results.trend), sep="")
			results[[zz]]<-populate.RWOTable(ordinal = zz, title=TableTitle(results.trend),table.obj=ResultsTable(results.trend), table.note=trend.note)
		}
		
		if (inherits(tmp.plot,"try-error")){
			return(results)
		}else{
			##################################
			#Plotting the trend
			zz<-zz+1
			ggg<-ResultsGraph(tmp.plot)
			class(ggg)<-c("gg","ggplot")
			plttrnd<-ggplot2::stat_abline(intercept=ResultsTable(results.trend)[,2][1], slope=ResultsTable(results.trend)[,2][2])
			trnd.plot1<-ggg + plttrnd
			class(trnd.plot1)<-"ggplot"
			results[[zz]]<-populate.RWOGraph(ordinal=zz, title=TableTitle(results.trend), graph.obj = trnd.plot1, graph.note=trend.note)
		
			##################################
			##If we ever want to plot by grouping vars, this is the easiest way...Just showing off here - sorry!
			if(NROW(PlotParameters(test.ri)$g.var)>1 | is.null(PlotParameters(test.ri)$g.var) | ((NROW(PlotParameters(test.ri)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ri)$g.var)]))>1))){
				zz<-zz+1
				trnd.plot2<-ggg + geom_smooth(method = "lm", se=F)
				class(trnd.plot2)<-"ggplot"
				plt.title<-paste(TableTitle(results.trend),". Regression lines shown by category of",paste(PlotParameters(test.ri)$g.var,collapse=" x "))
				trend.note<-paste("Data source: ",TableTitle(test.ri),". ",Notes(results.trend), sep="")
				tmp.plt<-try(populate.RWOGraph(ordinal=zz, title=plt.title, graph.obj = trnd.plot2, graph.note=trend.note),silent=TRUE)
				if(!inherits(tmp.plt,"try-error"))results[[zz]]<-tmp.plt
			}
			return(results)
		}
	}
}