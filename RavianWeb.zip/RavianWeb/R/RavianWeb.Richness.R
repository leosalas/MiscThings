# RavianWeb.estimateRichness.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org, mherzog@prbo.org
# Creation Date: Oct 20, 2009
###############################################################################

RavianWeb.Richness <- function(formData) {
	options(warn=-1)
	results<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	more.filters=""
	if(dt=="PointCount")more.filters<-"ProtocolCode NOT IN ('VCP300_PLAYBACK','VCP300_2xOBS_DEP','VCP300_2xOBS_IND')"
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	obs.groups.name<-formData$ObservationGroupsName
	spatialRez<-formData$SpatialResolution
	
	guild<-formData$TaxonGroupsName #Here it has only aesthetic value - a list of species is submitted and richness estimates are requested but
			 #considering only these species, so the group name is used in title
	
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters="", taxon.groups="", spatial.groups=spatial.groups, 
					obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	#remove sampling.units
	#remove guild and add obs.group
	
	time.var<-"YearCollected"
	summarize.by.default<-switch(dt,"AreaSearch"="Plot","PointCount"="Transect","Band"="StationName")
	summarize.by<-ifelse(spatialRez=="",summarize.by.default,spatialRez)	#here
	summarize.by<-ifelse(spatial.groups=="",summarize.by,"SpatialGroup")	#here
	#summarize.by<-ifelse(spatial.groups=="",summarize.by.default,"SpatialGroup")

	test.ri<-try(estimateRichness(object = data.obj,summarize.by=summarize.by,time.var=time.var,
					spatial.units=spatial.groups.name,obs.group=obs.groups.name),silent=TRUE)
	zz<-1
	if (inherits(test.ri,"try-error")) {
		sink.error<-ifelse(grepl("Ravian Message:",test.ri), FALSE, TRUE)
		results[[zz]]<-populate.RWOError(error=test.ri, formData, data.obj=data.obj, res.ordinal=zz,sink.error=sink.error)
		return(results)
	} else {	#We have abundance estimates...
		#store the table
		#change row and col headers first
		ri.obj<-try(checkRowColumnNames(test.ri), silent=TRUE)
		if(inherits(ri.obj,"try-error")) ri.obj<-test.ri
		test.df<-try(do.call("as.data.frame",args=list(x=ri.obj),envir=.GlobalEnv),silent=TRUE)		
		if (inherits(test.df,"try-error")) {
			sink.error<-ifelse(grepl("Ravian Message:",test.df), FALSE, TRUE)
			results[[zz]]<-populate.RWOError(error=test.df, formData, data.obj = test.ri, res.ordinal=zz,sink.error=sink.error)
			return(results)	#ends here - can't continue
		} #else...
		results[[zz]]<-populate.RWOTable(ordinal = zz, title=TableTitle(test.ri),table.obj=test.df, table.note=Notes(test.ri))
		
		########################################
		#store the graph
		#First beautify the labels
		if(summarize.by!="Point"){
			ri.plt.obj<-try(checkPlotLabels(test.ri), silent=TRUE)
			if(inherits(ri.plt.obj,"try-error")) ri.plt.obj<-test.ri
			
			tmp.plot<-try(plot(ri.plt.obj, plot.type="point",facet.wrap=FALSE),silent=TRUE)
			if (inherits(tmp.plot,"try-error")){
				sink.error<-ifelse(grepl("Ravian Message:",tmp.plot), FALSE, TRUE)
				results[[2]]<-populate.RWOError(error=tmp.plot, formData, data.obj = test.ri, res.ordinal="2", sink.error=sink.error)
			} else {
				results[[2]]<-populate.RWOGraph(ordinal=2, title=GraphTitle(tmp.plot), graph.obj = ResultsGraph(tmp.plot), graph.note=Notes(tmp.plot))
			}
			
			######################################
			#estimate trend
			#must re-set summarize.by, because if there is a spatial group, then the name is already a column name in the richness table (=test.ri)
			summarize.by<-ifelse(spatial.groups=="",summarize.by,spatial.groups.name)
			if ((min(test.df$Variance, na.rm=TRUE)<=0) | ("TRUE" %in% is.na(test.df$Variance))) {
				results.trend<-try(trend(test.ri,weighted=FALSE,reg.type="simple",do.log=FALSE,group=summarize.by),silent=TRUE)
			} else {
				results.trend<-try(trend(test.ri,weighted=TRUE,reg.type="simple",do.log=FALSE,group=summarize.by),silent=TRUE)
			}
			if (inherits(results.trend,"try-error")) {
				sink.error<-ifelse(grepl("Ravian Message:",results.trend), FALSE, TRUE)
				results[[3]]<-populate.RWOError(error=results.trend, formData, data.obj = test.ri, res.ordinal="3", sink.error=sink.error)
				return(results)	#ends here - can't continue
			}else{
				if(NROW(PlotParameters(test.ri)$g.var)>1 | is.null(PlotParameters(test.ri)$g.var) | ((NROW(PlotParameters(test.ri)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ri)$g.var)]))>1))){
					trend.dat<-paste("Regression estimated combining all categories of ",paste(PlotParameters(test.ri)$g.var,collapse=" x "),".", sep="")
				}else {
					trend.dat<-""
				}
				trend.note<-paste("Data source: ",TableTitle(test.ri),". ",trend.dat,Notes(results.trend), sep="")
				results[[3]]<-populate.RWOTable(ordinal = 3, title=TableTitle(results.trend),table.obj=ResultsTable(results.trend), table.note=trend.note)
			}
			
			if (inherits(tmp.plot,"try-error")){
				return(results)
			}else{
				##################################
				#Plotting the overall trend
				results.trend2<-try(trend(test.ri,weighted=TRUE,reg.type="simple",do.log=FALSE,group=NA),silent=TRUE)
				if (!inherits(results.trend2,"try-error")) {
					ggg<-ResultsGraph(tmp.plot)
					class(ggg)<-c("gg","ggplot")
					plttrnd<-ggplot2::stat_abline(intercept=ResultsTable(results.trend2)[,2][1], slope=ResultsTable(results.trend2)[,2][2])
					trnd.plot1<-ggg + plttrnd
					class(trnd.plot1)<-"ggplot"
					results[[4]]<-populate.RWOGraph(ordinal=4, title=TableTitle(results.trend2), graph.obj = trnd.plot1, graph.note=trend.note)
					##################################
					##If we ever want to plot by grouping vars, this is the easiest way...
					if(NROW(PlotParameters(test.ri)$g.var)>1 | is.null(PlotParameters(test.ri)$g.var) | ((NROW(PlotParameters(test.ri)$g.var)==1) & (NROW(unique(test.df[,which(names(test.df)==PlotParameters(test.ri)$g.var)]))>1))){
						trnd.plot2<-ggg + geom_smooth(method = "lm", se=F)
						class(trnd.plot2)<-"ggplot"
						plt.title<-paste(TableTitle(results.trend),". Regression lines shown by category of",paste(PlotParameters(test.ri)$g.var,collapse=" x "))
						trend.note<-paste("Data source: ",TableTitle(test.ri),". ",Notes(results.trend), sep="")
						results[[5]]<-populate.RWOGraph(ordinal=5, title=plt.title, graph.obj = trnd.plot2, graph.note=trend.note)
					}
				}else{
					sink.error<-ifelse(grepl("Ravian Message:",results.trend2), FALSE, TRUE)
					results[[5]]<-populate.RWOError(error=results.trend2, formData, data.obj = test.ri, res.ordinal="5", sink.error=sink.error)
					return(results)	
				}
			}
		}
		return(results)
	}
}