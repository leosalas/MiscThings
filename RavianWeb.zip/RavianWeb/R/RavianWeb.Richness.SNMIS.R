# RavianWeb.estimateRichness.R
# TODO: Add comment
# 
# Author: Leo Salas, Mark Herzog
# Contact: lsalas@prbo.org, mherzog@prbo.org
# Creation Date: Oct 20, 2009
###############################################################################

RavianWeb.Richness.SNMIS <- function(formData) {
	options(warn=-1)
	results<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	more.filters<-"ProtocolCode NOT IN ('VCP300_PLAYBACK','VCP300_2xOBS_DEP','VCP300_2xOBS_IND')"
	more.obs.filters<-"DistanceFromObserver<=100"
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	
	guild<-formData$TaxonGroupsName #Here it has only aesthetic value - a list of species is submitted and richness estimates are requested but
	#considering only these species, so the group name is used in title
	
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters=more.obs.filters, taxon.groups="", 
					spatial.groups=spatial.groups,obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData=formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	
		radius<-NULL
		if (grepl("DistanceFromObserver",formData$obsSQL)) {
			eee<-substr(formData$obsSQL,start=(regexpr("DistanceFromObserver",formData$obsSQL)+20),stop=nchar(formData$obsSQL))
			radius<-as.numeric(substr(eee,start=regexpr("<=",eee)+2,stop=ifelse(grepl(" AND ",eee),regexpr(" AND ",eee)-1,nchar(eee))))
		} 
		summarize.by = ifelse(spatial.groups=="","StudyArea","SpatialGroup")
		sampling.unit = "Transect"
		time.var="YearCollected"

	
	sink.error<-FALSE
	test.ri<-try(estimateRichness(object = data.obj,summarize.by=summarize.by,sampling.unit=sampling.unit,time.var=time.var,
					guild=guild,spatial.units=spatial.groups.name),silent=TRUE)
	
	if (inherits(test.ri,"try-error")) {
		results[[1]]<-populate.RWOError(error=test.ri, formData, data.obj=data.obj, res.ordinal="1")
		return(results)
	} else {	#We have abundance estimates...
		#store the table
		#change row and col headers first
		ri.obj<-try(checkRowColumnNames(test.ri,guild.type="",su.type=spatial.groups.name), silent=TRUE)
		if(inherits(ri.obj,"try-error")) ri.obj<-test.ri
		test.df<-try(do.call("as.data.frame",args=list(x=ri.obj),envir=.GlobalEnv),silent=TRUE)		
		if (inherits(test.df,"try-error")) {
			results[[1]]<-populate.RWOError(error=test.df, formData, data.obj = test.ri, res.ordinal="1")
			return(results)	#ends here - can't continue
		} #else...
		#NOTE: spatial.groups.name cannot have blank spaces - if submitting name with underscore, then replace these with blanks in title
		tbl.ttl<-paste("Mean Species Richness (Number of Species per Point) Summarized by", spatial.groups.name)
		results[[1]]<-populate.RWOTable(ordinal = 1, title=tbl.ttl,table.obj=test.df, table.note=paste("Only birds detected within 100m are included.",Notes(test.ri)))
		
		########################################
		#store the graph
		#First beautify the labels
		ri.plt.obj<-try(checkPlotLabels(test.ri), silent=TRUE)
		if(inherits(ri.plt.obj,"try-error")) ri.plt.obj<-test.ri
		tmp.plot<-try(plot(ri.plt.obj, plot.type="point", facet.wrap=TRUE),silent=TRUE)
		if (inherits(tmp.plot,"try-error")){
			ifelse(grepl("Ravian Message:",tmp.plot), sink.error<-FALSE, sink.error<-TRUE)
			results[[2]]<-populate.RWOError(error=tmp.plot, formData, data.obj = test.ri, res.ordinal="2", sink.error=sink.error)
		} else {
			results[[2]]<-populate.RWOGraph(ordinal=2, title=tbl.ttl, graph.obj = ResultsGraph(tmp.plot), graph.note=Notes(tmp.plot))
		}
		
		######################################
		#estimate trend
		if ((min(test.df$Variance, na.rm=TRUE)<=0) | ("TRUE" %in% is.na(test.df$Variance))) {
			results.trend<-try(trend(test.ri,weighted=FALSE,reg.type="simple",do.log=FALSE),silent=TRUE)
		} else {
			results.trend<-try(trend(test.ri,weighted=TRUE,reg.type="simple",do.log=FALSE),silent=TRUE)
		}
		if (inherits(results.trend,"try-error")) {
			ifelse(grepl("Ravian Message:",results.trend), sink.error<-FALSE, sink.error<-TRUE)
			results[[3]]<-populate.RWOError(error=results.trend, formData, data.obj = test.ri, res.ordinal="3", sink.error=sink.error)
			return(results)	#ends here - can't continue
		}else{
			#remove intercept
			table.obj=ResultsTable(results.trend)
			table.obj<-table.obj[c(-1),]
			#add CI
			se.est<-table.obj$SE_value
			slope.est<-table.obj$Value
			signif.note<-""
			if(!is.null(se.est) & !is.na(se.est) & !is.null(slope.est) & !is.na(slope.est) & se.est!=0){
				up.ci<-round(slope.est+(1.96*se.est),digits=3)
				lw.ci<-round(slope.est-(1.96*se.est),digits=3)
				ci.val<-paste("(",lw.ci,",",up.ci,")",sep="")
				table.obj$Confidence_Interval<-ci.val
				if((slope.est>0 & lw.ci<0) | (slope.est<0 & up.ci>0))signif.note<-"Slope p-value < 0.05"
			}else{
				table.obj$Confidence_Interval<-"N/A"
			}

			#IF CI excludes 0, note significance
			trend.note<-paste("Data source: ",tbl.ttl,". ",signif.note,Notes(results.trend), sep="")
			results[[3]]<-populate.RWOTable(ordinal = 3, title=TableTitle(results.trend),table.obj=table.obj, table.note=trend.note)
		}
		
		if (inherits(tmp.plot,"try-error")){
			return(results)
		}else{
			##################################
			#Plotting the trend
			ggg<-ResultsGraph(tmp.plot)
			class(ggg)<-c("gg","ggplot")
			plttrnd<-ggplot2::stat_abline(intercept=ResultsTable(results.trend)[,2][1], slope=ResultsTable(results.trend)[,2][2])
			trnd.plot1<-ggg + plttrnd
			class(trnd.plot1)<-"ggplot"
			results[[4]]<-populate.RWOGraph(ordinal=4, title=TableTitle(results.trend), graph.obj = trnd.plot1, graph.note=trend.note)
		
			return(results)
		}
	}
}