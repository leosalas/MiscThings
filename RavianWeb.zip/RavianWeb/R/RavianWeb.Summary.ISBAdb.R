# TODO: Add comment
# 
# Author: lsalas
# Date created: May 14, 2011
###############################################################################

##This is being developed and requires fixing the data, then use the proper object methods.
RavianWeb.Summary.ISBAdb <- function(formData) {
	options(warn=-1)
	results<-list()
	rr.objects<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	more.filters<-""
	more.obs.filters=""
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	
	sgn<-ifelse(spatial.groups=="","PlotName","SpatialGroup")
	sgnn<-ifelse(spatial.groups=="","Selected Pond(s)","Selected Pond Complex(ex)")
	tgn <- ifelse(taxon.groups=="","CommonName","TaxonGroup")
	tgnn <- ifelse(taxon.groups=="","Selected Species","Selected Guild(s)")
		
	if(taxon.groups!="") tgtn<-"for Species Guilds"
	
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters=more.obs.filters, taxon.groups=taxon.groups, 
					spatial.groups=spatial.groups,obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	
	#get areas
	suid<-unique(EffortData(data.obj)$SamplingUnitId)
	wkt.sql<-paste("SELECT SamplingUnitId,CAST(AsText(CoordinatesCollection) AS CHAR) FROM SamplingUnit WHERE SamplingUnitId IN (",paste(suid,collapse=","),")",sep="")
	library(RODBC)
	library(RPostgreSQL)
	conn<-try(odbcConnect(dsn="PRBOdb"),silent=TRUE)
	if(inherits(conn,"try-error") | conn<0){
		results[[1]]<-populate.RWOError(error=conn, formData, data.obj = data.obj, res.ordinal="1", sink.error=TRUE)
		return(results)	#ends here - can't continue
	}else{ #got connection
		wkt.data<-try(sqlQuery(conn, wkt.sql,rows_at_time=1), silent=TRUE)
		closeDatabase(conn)
		if(inherits(wkt.data,"try-error") | NROW(wkt.data)==0) {
			results[[1]]<-populate.RWOError(error=wkt.data, formData, data.obj = data.obj, res.ordinal="1", sink.error=TRUE)
			return(results)
		}else{# got wkts, now get areas
			names(wkt.data)<-c("suid","wkt")
			if(NROW(wkt.data)<length(suid)){
				wkt.data<-merge(as.data.frame(suid),wkt.data,by="suid",all.x=TRUE)
			}
			drv<-dbDriver("PostgreSQL")
			con <- try(dbConnect(drv,host="spdb.pointblue.org",dbname="spatial",port="5432",user="postgres"),silent=TRUE)
			if(!inherits(con,"try-error")){ #got psql connection
				areas.df<-data.frame()
				for(sss in 1:nrow(wkt.data)){
					wktt<-wkt.data[sss,2]
					suv<-wkt.data[sss,1]
					if(is.na(wktt)){
						area.r<-c(suv,1)
					}else{
						sql.str<-paste("SELECT ROUND(CAST(ST_Area(the_geog) * 0.0001 as numeric),2) As hectares FROM (SELECT geography(ST_GeomFromText('",wktt,"', 4326))) As foo(the_geog);",sep="")
						areaval <- try(dbGetQuery(con, statement = sql.str), silent=TRUE)
						area.r<-c(suv,areaval[1,1])
					}
					areas.df<-rbind(areas.df,area.r)
				}
				dbDisconnect(con)
				names(areas.df)<-c("SamplingUnitId","AreaHa")
			}else{
				results[[1]]<-populate.RWOError(error=con, formData, data.obj = data.obj, res.ordinal="1", sink.error=TRUE)
				return(results)
			}
		}
		#append area to Obs df and Effort df
		ars<-ObsData(data.obj)
		ars<-merge(ars,areas.df,by="SamplingUnitId",all.x=TRUE)
		ars$AreaSurveyed<-ars$AreaHa
		ars<-ars[,which(!names(ars) %in% "AreaHa")]
		ObsData(data.obj)<-ars
		eff<-EffortData(data.obj)
		eff<-merge(eff,areas.df,by="SamplingUnitId",all.x=TRUE)
		eff$AreaSurveyed<-eff$AreaHa
		eff<-eff[,which(!names(eff) %in% "AreaHa")]
		EffortData(data.obj)<-eff
	}
	
	merged<-try(do.call("as.data.frame",args=list(x=data.obj,source.table="merged"),envir=.GlobalEnv),silent=TRUE)
	if (inherits(merged,"try-error")) {
		ifelse(grepl("Ravian Message:",merged)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=merged, formData, data.obj = data.obj, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	
	iii<-0
	totals<-try(estimateTotals(data.obj,summarize.by=sgn,guild=tgn),silent=TRUE)
	if (inherits(totals,"try-error")) {
		ifelse(grepl("Ravian Message:",totals)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=totals, formData, data.obj = data.obj, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	#############Richness
	#deal with mixed species flocks for estimating richness.  Start with the total number of codes...
	#FilterList(do.test)$obsSQL<-""
	#rich.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters=more.obs.filters, taxon.groups=taxon.groups, 
	#				spatial.groups=spatial.groups,obs.groups=obs.groups),silent=TRUE) #try-catch
	rich.obj<-data.obj
	#if (inherits(rich.obj,"try-error")) {
	#	ifelse(grepl("Ravian Message:",rich.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
	#	results[[1]]<-populate.RWOError(error=rich.obj, formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
	#	return(results)	#ends here - can't continue
	#}
	mergrch<-try(do.call("as.data.frame",args=list(x=rich.obj,source.table="merged"),envir=.GlobalEnv),silent=TRUE)
	if (inherits(mergrch,"try-error")) {
		ifelse(grepl("Ravian Message:",mergrch)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=mergrch, formData, data.obj = rich.obj, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
		
	lnk<-c("ProjectCode", "ProjectName", sgn, "ProtocolCode","YearCollected", "MonthCollected", "DayCollected", "TideLevel") #
	if(sgn=="PlotName")lnk<-c(lnk,"Visit")
	mergednoz<-subset(mergrch,ObservationCount>0)
	minrich<-aggregate(as.formula(paste("SpeciesCode ~",paste(lnk,collapse=" + "))),data=mergednoz,FUN=spcnt)
	names(minrich)<-c(lnk,"Richness")
	#but then...
	ab.note<-""
	ch<-odbcConnect("ISBAdbSupport")
	mix.species<-sqlQuery(ch, "SELECT * FROM mixed_speciescodes;")
	close(ch)
	mx.sp<-unique(mix.species$SingleSpeciesCode)
	mx.mxsp<-unique(mix.species$MixedSpeciesCode)
	usp<-unique(ObsData(rich.obj)$SpeciesCode)
	#Here method to re-query IF SpeciesCode IN (species part of mixed flocks)
	if(sum(usp %in% mx.sp)>0){
		#The purpose of this is only to extend abundance estimates to include mixed species
		##############################################
		mxsp.cd<-usp[which(usp %in% mx.sp)]		#get the species for these
		mxsp<-subset(mix.species,SingleSpeciesCode %in% mxsp.cd)
		mix.nw<-unique(mxsp$MixedSpeciesCode)
		whq<-Where(Query(DataDefn(rich.obj)))
		sci<-regexpr("SpeciesCode IN (",whq,fixed=TRUE)
		whq2<-substr(whq,sci+17,nchar(whq))
		sci2<-regexpr(")",whq2,fixed=TRUE)
		nexpp<-substr(whq,sci,sci + 17 + sci2 - 2)
		nexp<-paste(nexpp,",'",paste(mix.nw,collapse="','"),"')",sep="")
		pref<-substr(whq,1,sci-1)
		suff<-substr(whq,sci + 17 + sci2,nchar(whq))
		nws<-paste(pref,nexp,suff,sep="")
		
		obs.data.query<-try(buildQueryList(data.obj=rich.obj, data.type="obs", more.filters=more.filters, more.obs.filters=more.obs.filters), silent=TRUE)
		if(inherits(obs.data.query,"try-error")){
			res<-paste(obs.data.query, collapse=" ")
			results[[1]]<-populate.RWOError(error=res, formData, data.obj = do.test, res.ordinal="1", sink.error=TRUE)
			return(results)	#ends here - can't continue
		}else{
			#query the data again and see if the return does indeed have mixed species codes
			Where(obs.data.query)<-nws
			Query(DataDefn(rich.obj))<-obs.data.query
			obs.data<-try(getDataRavian(DataDefn(rich.obj)),silent=TRUE)
			if(inherits(obs.data,"try-error")){
				res<-paste(obs.data, collapse=" ")
				results[[1]]<-populate.RWOError(error=res, formData, data.obj = do.test, res.ordinal="1", sink.error=TRUE)
				return(results)	#ends here - can't continue
			}else{
				nusp<-unique((obs.data$result.data)$SpeciesCode)
				if(length(usp)!=length(nusp)){
					mergmx<-merge(EffortData(rich.obj),obs.data$result.data,all.x=TRUE)
					maxrich<-aggregate(as.formula(paste("SpeciesCode ~",paste(lnk,collapse=" + "))),data=mergmx,FUN=spcnt)
					minrich<-merge(minrich,maxrich,all.x=TRUE)
					minrich$Richness<-ifelse(minrich$Richness==minrich$SpeciesCode,minrich$SpeciesCode,paste(minrich$Richness,"-",minrich$SpeciesCode))
					minrich<-minrich[,c(lnk,"Richness")]
					ab.note<-"The surveys in the sample reported mixed species groups; in these cases richness estimates are reported as a range. "
				}
			}
		}
	}
	
	#DONE! attach to totals table!
	totals.df<-ResultsTable(totals)
	totals.df<-merge(totals.df,minrich,by=lnk,all.x=TRUE)
	totals.df$Richness<-ifelse(is.na(totals.df$Richness),"0",totals.df$Richness)
	#re-arrange the fields like so
	fld.ord<-c(sgn,"ProtocolCode","YearCollected","MonthCollected","DayCollected","NumPondsSurveyed","TideLevel","AreaSurveyed","Richness")
	obs.fld<-names(totals.df)[which(!names(totals.df) %in% c(fld.ord,"ProjectCode","ProjectName","Visit"))]
	if(length(obs.fld)>1){
		tcnt<-apply(totals.df[,obs.fld],1,sum)
	}else{
		tcnt<-totals.df[,obs.fld]
	}
	totals.df$TotalCount<-tcnt
	totals.df<-totals.df[,c(subset(fld.ord,fld.ord != ""),obs.fld,"TotalCount")]	
	
	#need to average covariates by event and then append to totals.df
	cov.fld<-c("Salinity","Temperature","DepthMin","OxygenMgl","phLevel")
	lnk.cov<-c("ProtocolCode","YearCollected","MonthCollected","DayCollected","TideLevel",sgn)
	obs.df<-ObsData(data.obj)
	obs.df<-obs.df[,c(lnk,cov.fld)]
	for(cvv in cov.fld){
		cov.vals<-try(aggregate(formula=as.formula(paste(cvv,"~",paste(lnk,collapse="+"),sep="")),data=obs.df,FUN=mean,na.action=na.omit),silent=TRUE)
		if(!inherits(cov.vals,"try-error")){
			totals.df<-merge(totals.df,cov.vals[,c(cvv,lnk.cov)],by=c(lnk.cov),all.x=TRUE)
		}
	}
	
	
	n.rec<-sum(totals.df$NumPondsSurveyed)
	n.noobs<-sum(subset(totals.df,Richness==0,select="NumPondsSurveyed")[,1])
	#Now report this table at the end
	
	#Here add the plot of weighted geometric mean by location for the period selected, faceted by tide levels 
	#Limit to no more than 6 locations
	uloc<-unique(totals.df[,sgn])
	if(length(uloc)>6){
		iii<-iii+1
		results[[iii]]<-populate.RWOError(error="Ravian Message: The number of ponds/complexes selected for plotting is larger than 6 - please select fewer ponds/complexes", formData, data.obj = do.test, res.ordinal=iii, sink.error=FALSE)
	}else{
		plot.df<-data.frame()
		for(ppp in uloc){
			tplot.df<-subset(totals.df,totals.df[,sgn]==ppp)
			tid<-unique(tplot.df$TideLevel)
			for(bbb in tid){
				ttplot.df<-subset(tplot.df,TideLevel==bbb)
				if(nrow(ttplot.df)>0){
					#tpsurv<-sum(ttplot.df$NumPondsSurveyed)
					tpsurv<-sum(ttplot.df$AreaSurveyed)
					#ttplot.df$wlogAb<-log(ttplot.df$TotalCount+1)*ttplot.df$NumPondsSurveyed
					ttplot.df$wlogAb<-(log(ttplot.df$TotalCount+1))*ttplot.df$AreaSurveyed
					tlogab<-sum(ttplot.df$wlogAb)
					wavab<-round(exp(tlogab/tpsurv)-(1/nrow(ttplot.df)),2)
					if(NROW(plot.df)==0){
						plot.df<-data.frame(Location=ppp,Weighted_Mean=wavab,Tide=bbb)
					}else{
						plot.df<-rbind(plot.df,data.frame(Location=ppp,Weighted_Mean=wavab,Tide=bbb))
					} 
					
				}
			}
		}
		names(plot.df)<-c("Location","Weighted_Mean","Tide")
		title<-paste("Weighted Geometric Mean of Number of Birds by Tide at",ppp)
		table.note<-"Mean is for all taxa selected and all survey events combined, and are weighted by the total area of ponds surveyed in each location."
		iii<-iii+1
		results[[iii]]<-populate.RWOTable(ordinal=iii, title=title, table.obj = plot.df, table.note=table.note)
		
		ptdf<-totals.df[,c(sgn,"TotalCount","TideLevel")]
		names(ptdf)<-c("Location","Count","Tide")
		plot.df<-merge(plot.df,ptdf,by=c("Location","Tide"),all.x=TRUE)
		wpp<-ggplot(data=plot.df,aes(x=Location,y=Count)) + geom_point(size=4,alpha=0.5) + geom_point(aes(y=Weighted_Mean),colour="red",size=5,shape=17) +
				theme_bw() + xlab("") + ylab("Number of Birds") + coord_flip() + 
				theme(axis.title.x=element_text(vjust=0,size=16),axis.text.y=element_text(size=14),
						axis.text.x=element_text(size=16),strip.text.x=element_text(size=14)) +
				facet_grid(~Tide)
		hgt<-ifelse(length(uloc)<4,250,525)
		assign("plot.df",plot.df,envir=.GlobalEnv)
		graph.note<-paste(table.note,"Each dot represents the count during a sampling event; the red triangle indicates the geometric mean value.")
		iii<-iii+1
		results[[iii]]<-populate.RWOGraph(ordinal=iii, title=title, graph.obj = wpp, graph.note=graph.note,hgt=hgt)
	}
	
	iii<-iii+1
	title<-paste("Totals of Waterbird Use by Tide Level in Surveys at",sgnn,"for",tgnn)
	note<-paste("Number of records selected = ",n.rec,"; number of records with no observations = ",n.noobs,". Richness is the total number of taxa observed in each pond/complex surveyed, for the user-selected taxa only. ",ab.note,sep="")
	totals.df<-totals.df[,which(!names(totals.df) %in% c("ProjectName"))]
	ttdfn<-names(totals.df);ttdfn[grep("SpatialGroup",ttdfn)]<-"PondComplex"
	names(totals.df)<-ttdfn
	results[[iii]]<-populate.RWOTable(ordinal = iii, title=title,table.obj=totals.df, table.note=note)
	
	return(results)
	
}

spcnt<-function(x){
	sc<-NROW(unique(na.omit(x)))
	return(sc)
	}