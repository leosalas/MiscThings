# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 22, 2009
###############################################################################

RavianWeb.Summary.PFSS <- function(formData) {
	options(warn=-1)
	results<-list()
	rr.objects<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	sgc = "SUgroup"
	sgtn = "SurveySite"
	if(spatial.groups!=""){
		sgc = "SpatialGroup"
		sgtn = spatial.groups.name
	}
	#more.filters="(JulianDay >= 314 and JulianDay <= 354)"
	more.filters="((JulianDay >= 314 AND JulianDay <= 365) OR (JulianDay >= 1 AND JulianDay <= 46))"	#extending to
	more.obs.filters="SpeciesCode IN ('NOLA','SOLA','BBPL','EUGP','AMGP','LEGP','PAGP','LGPL',
			'LSAP','GSAP','COPL','SNPL','WIPL','CRPL','SEPL','PIPL','LRPL','KILL','MOPL','EUDO','PEEP','SMAL','EUOY','AMOY',
			'BLOY','BWST','BNST','HAST','AMAV','TESA','COSA','SPSA','GRSA','SOSA','GTTA','WATA','SPRE','GRYE','COMG','WILL','LEYE',
			'MASA','WOSA','COMR','XYEL','YELL','UPSA','LICU','ESCU','WHIM','BTCU','FECU','SBCU','EUCU','LBCU','XNUM','BTGD',
			'HUGO','BTGO','MAGO','ALMG','LARG','RUTU','BLTU','XBRT','SURF','ROCK','GRKN','REKN','SAND','SESA','WESA','RNST','LIST',
			'TEST','LTST','LESA','WRSA','BASA','PESA','SPTS','PUSA','ROSA','DUNL','CUSA','STSA','XWLD','XWLS','XWSD','LSPD','WCAL',
			'WEDU','WLDU','WLSA','XCAL','XSLS','XSMS','SBSA','BBIS','BBSA','RUFF','SBDO','LBDO','DOWI','MEDI','XDOW','JASN','WISN',
			'COSN','PTSN','EUWO','AMWO','WIPH','RNPH','REPH','PHAL','XPHL','XWRP')"
	#Do we do anything with taxon groups?? Only the title...??
	tgtn = ""
	if(taxon.groups!="")tgtn = " for Selected Species"
	obs.groups<-formData$ObservationGroups
	
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters=more.obs.filters, taxon.groups=taxon.groups, 
					spatial.groups=spatial.groups,obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal=1, sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	###HERE: add the temporal group "Season" to aggregate Nov to Feb in EffortData and ObsData
	data.obj<-try(addSeason(data.obj),silent=TRUE)
	if (inherits(data.obj,"try-error")) {
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal=1, sink.error=TRUE)
		return(results)	#ends here - can't continue
	}
	#CAREFUL!! We need to process the spatial groups AFTER the query to set summarization to basal SUgroup
	data.obj<-try(collapseToSUgroup(data.obj,FUN="sum"),silent=TRUE)
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal=1, sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	
	obs.dat<-ObsData(data.obj)
	if(NROW(obs.dat)==0){
		results[[1]]<-populate.RWOError(error="Ravian Message: No observational data available for the selection.", formData, data.obj = data.obj, res.ordinal=1, sink.error=FALSE)
		return(results)
	}
	
	###Then the tabulations  LEOOO: think about using an xml file for this!
			tv<-array(dim=c(3,4))
			#if(spatial.groups!="")tv<-array(dim=c(5,4))								#In theory ALWAYS passing grouped data
			tv[1,]<-c("Season","SpatialGroup","ObservationCount","sum") 		#total birds by location and year
			tv[2,]<-c("Season","SpatialGroup","SpeciesCode","NROW")			#total species by location and year
			tv[3,]<-c("Season","SpatialGroup","JulianDay","NROW")			#sampling effort  USE Visit??
			#tv[4,]<-c("YearCollected","SUgroup","ObservationCount","sum") 			#total birds by SUgroup and year
			#tv[5,]<-c("YearCollected","SUgroup","SpeciesCode","NROW")				#total species by SUgroup and year

			
			#Do we need a function to make the table labels pretty?
	zz<-0
	
	#make the plots here
	#proportion of shorebird genera (all years selected, all localities selected)
	#sum across all genera
	#add genus
	gg<-substr(obs.dat$ScientificName,1,regexpr(" ",obs.dat$ScientificName,fixed=TRUE))
	gg<-gsub(".$", "", gg)
	gg<-ifelse(gg=="","Unknown",gg)
	gg<-ifelse(is.na(gg),"Unknown",gg)
	obs.dat$Genus<-gg
	
	#Genus plot  NOTE!!! If we can link species to common groups like Lapwings, etc, then use that instead?
	#qq<-aggregate(obs.dat$ObservationCount,by=list(obs.dat$YearCollected,obs.dat$Genus,obs.dat[,sgc]),FUN="sum")
	#names(qq)<-c("Year","Genus",sgtn,"TotalCount")
	qq<-aggregate(obs.dat$ObservationCount,by=list(obs.dat$Season,obs.dat$Genus,obs.dat[,sgc]),FUN="sum")
	names(qq)<-c("Season","Genus",sgtn,"TotalCount")
	qq$Genus<-as.character(qq$Genus)
	qq<-subset(qq,!is.na(TotalCount) & Genus!="Unknown")
	#Make plots only if number of years * number of locations <= 12
		#uyr<-sort(unique(qq$Year))
		uyr<-sort(unique(qq$Season))
		ngs<-unique(qq[,sgtn])
		if((length(uyr)*length(ngs))<=12){
			for(yyy in uyr){
				#q2<-subset(qq,Year==yyy)
				q2<-subset(qq,Season==yyy)
				#now subset by sgc
				usg<-unique(q2[,sgtn])
				for(ggg in usg){
					q3<-eval(substitute(subset(q2,xxx==ggg), list(xxx=as.name(sgtn))))
					plt<-makePFSSPlot(q3, xvar="Genus", ggg,fac=FALSE)
					zz<-zz + 1
					results[[zz]]<-populate.RWOGraph(ordinal=zz, title=plt[[2]], graph.obj = plt[[1]], 
							graph.note=paste("Bars show the proportion of total shorebirds counted by ", sgtn, " and season = ", yyy,". Numbers on the bars are total counts.",sep=""))
				}
			}
		}
		#HERE!!!! A plot with all years combined and all sites combined
		qqa<-aggregate(obs.dat$ObservationCount,by=list(obs.dat$Genus,obs.dat[,sgc]),FUN="sum")
		names(qqa)<-c("Genus",sgtn,"TotalCount")
		qqa$Genus<-as.character(qqa$Genus)
		qqa<-subset(qqa,!is.na(TotalCount) & Genus!="Unknown")
		plt<-makePFSSPlot(qqa, xvar="Genus", sgvarval="all locations combined",fac=FALSE)
		plt.ttl<-"Relative Abundance of the Most Common Genera of Shorebirds - all years and locations combined"
		zz<-zz + 1
		results[[zz]]<-populate.RWOGraph(ordinal=zz, title=plt.ttl, graph.obj = plt[[1]], 
				graph.note="Bars show the proportion of total shorebirds counted throughout all locations and years. Numbers on the bars are total counts.")
	
	#Species plot
	#qq<-aggregate(obs.dat$ObservationCount,by=list(obs.dat$YearCollected,obs.dat$CommonName,obs.dat[,sgc]),FUN="sum")
	#names(qq)<-c("Year","Species",sgtn,"TotalCount")
	qq<-aggregate(obs.dat$ObservationCount,by=list(obs.dat$Season,obs.dat$CommonName,obs.dat[,sgc]),FUN="sum")
	names(qq)<-c("Season","Species",sgtn,"TotalCount")
	qq$Species<-as.character(qq$Species)
	qq<-subset(qq,!is.na(TotalCount) & Species!="Unknown")
	if((length(uyr)*length(ngs))<8){
		#uyr<-sort(unique(qq$Year))
		uyr<-sort(unique(qq$Season))
		for(yyy in uyr){
			#q2<-subset(qq,Year==yyy)
			q2<-subset(qq,Season==yyy)
			usg<-unique(q2[,sgtn])
			for(ggg in usg){
				q3<-eval(substitute(subset(q2,xxx==ggg), list(xxx=as.name(sgtn))))
				plt<-makePFSSPlot(q3, xvar="Species", ggg, fac=FALSE)
				zz<-zz + 1
				results[[zz]]<-populate.RWOGraph(ordinal=zz, title=plt[[2]], graph.obj = plt[[1]], 
						graph.note=paste("Bars show the proportion of total shorebirds counted by ", sgtn, " and season = ", yyy,". Numbers on the bars are total counts.",sep=""))
			}
		}
	}
	#Here: a plot of all years and locations combined
	qqa<-aggregate(obs.dat$ObservationCount,by=list(obs.dat$CommonName,obs.dat[,sgc]),FUN="sum")
	names(qqa)<-c("Species",sgtn,"TotalCount")
	qqa$Species<-as.character(qqa$Species)
	qqa<-subset(qqa,!is.na(TotalCount) & Species!="Unknown")
	plt<-makePFSSPlot(qqa, xvar="Species", sgvarval="all locations combined",fac=FALSE)
	plt.ttl<-"Relative Abundance of the Most Common Species of Shorebirds - all years and locations combined"
	zz<-zz + 1
	results[[zz]]<-populate.RWOGraph(ordinal=zz, title=plt.ttl, graph.obj = plt[[1]], 
			graph.note="Bars show the proportion of total shorebirds counted throughout all locations and years. Numbers on the bars are total counts.")

	
		#the tables now...
		nt<-3
		#if(!spatial.groups.name %in% c("Site","Habitat","Geopolitical","Region"))nt<-5
		for(iii in 1:nt){
			#t.vars<-tv[iii,]
			#test.ct<-try(crossTabulate(object = data.obj, t.vars = t.vars), silent=TRUE)
			test.ct<-try(crossTabulate2(object = data.obj, cellVar=tv[iii,3], colsVar=tv[iii,1], groupVars=tv[iii,2], FUN=tv[iii,4]), silent=TRUE)
			zz<-zz + 1
			if (inherits(test.ct,"try-error")) {
				results[[zz]]<-populate.RWOError(error=test.ct, formData, data.obj=do.test, res.ordinal=zz, sink.error=TRUE)
			} else {	#we have a table/crosstable
				#beautify row/col headers
				ct.obj<-try(checkRowColumnNames(test.ct), silent=TRUE)
				if (inherits(ct.obj,"try-error")) ct.obj<-test.ct	
				t.titl<-getTitlePFSS(iii,spatial.groups.name)
				#Here add extra column indicating to which SpatialGroupsName a SpatialGroup belongs IF iii >3
				res.tbl<-ResultsTable(ct.obj)
				if(iii %in% c(4,5)){	#ATTENTION!!!!!
					if(!sgtn %in% c("SurveySite","Site","Selected Locations")){
						res.tbl.a<-try(addSUidentity(res.tbl,sgtn),silent=TRUE)
						if(!inherits(res.tbl.a,"try-error"))res.tbl<-res.tbl.a
					}
				}
				nts.tbl<-Notes(test.ct)
				if(iii == 1){
					nts.tbl<-paste(nts.tbl," Total number of shorebirds counted on surveys between ~15 November and 15 December of the survey year.  Variation in the total count is the result of natural fluctuations and the number of survey visits within the survey window [see table of visits below].",sep="")
				}
				results[[zz]]<-populate.RWOTable(ordinal = zz, title=t.titl,table.obj=res.tbl, table.note=nts.tbl)
			}
		}

	##Additional table of total number of observations by visit
	test.ct<-try(crossTabulate2(object = data.obj, cellVar="ObservationCount", colsVar="SpatialGroup", groupVars=c("Season","JulianDay"), FUN="sum"), silent=TRUE)
	zz<-zz + 1
	if (inherits(test.ct,"try-error")) {
		results[[zz]]<-populate.RWOError(error=test.ct, formData, data.obj=do.test, res.ordinal=zz, sink.error=TRUE)
	} else {	#we have a table/crosstable
		#beautify row/col headers
		ct.obj<-try(checkRowColumnNames(test.ct), silent=TRUE)
		if (inherits(ct.obj,"try-error")) ct.obj<-test.ct	
		t.titl<-"Total number of shorebirds counted by Site for each survey date"
		res.tbl<-ResultsTable(ct.obj)
		nts.tbl<-Notes(test.ct)
		results[[zz]]<-populate.RWOTable(ordinal = zz, title=t.titl,table.obj=res.tbl, table.note=nts.tbl)
	}

	#make a table of species in the selection
	sp.tbl<-unique(obs.dat[,c("PhylogenOrder","SpeciesCode","CommonName")])
	sp.tbl<-sp.tbl[order(sp.tbl$PhylogenOrder),]
	zz<-zz+1
	if(nrow(sp.tbl)>0){
		sp.tbl.f<-try(replaceFieldNames(sp.tbl), silent=TRUE)
		if (inherits(sp.tbl.f,"try-error")) sp.tbl.f<-sp.tbl
		results[[zz]]<-populate.RWOTable(ordinal = zz, title="List of taxa in the selected sample",table.obj=sp.tbl.f, table.note="")
	}else{
		results[[zz]]<-populate.RWOError(error="Ravian Message: No taxa in data selection.", formData, data.obj=obs.dat, res.ordinal=zz, sink.error=FALSE)
	}
	return(results) #normal ending
}
	
getTitlePFSS<-function(iii,sgtn){
	niv<-as.character(iii)
	table.titl<-""
		
			table.titl<-switch(niv,
					"1" = paste("Total Number of Shorebirds by", sgtn, "and Season"),
					"2" = paste("Total Number of Species by", sgtn, "and Season"),
					"3" = paste("Number of visits to", sgtn, "sites by Season"),
					"4" = "Total Number of Shorebirds by Sampling Unit and Season",
					"5" = "Total Number of Species by Sampling Unit and Season"
			)	
			if(sgtn=="Site" & iii==3)table.titl<-"Number of visits to Sites by Season"
	return(table.titl)
}	
	
makePFSSPlot<-function(pfss.df, xvar, sgvarval, fac=FALSE){
	res.pp<-list()
	stc<-sum(pfss.df$TotalCount)
	pfss.df$RelAbundance<-round((pfss.df$TotalCount/stc),digits=2)
	pfss.df<-pfss.df[order(pfss.df$TotalCount, decreasing=TRUE),]
	pfss.df<-pfss.df[1:6,]
	pfss.df$xvariable<-pfss.df[,c(xvar)]
	pfss.df<-na.omit(pfss.df)
	nrc<-NROW(pfss.df)
	nrec<-switch(as.character(nrc),
			"6" = "Six",
			"5"	= "Five",
			"4" = "Four",
			"3" = "Three",
			"2" = "Two",
			"1" = "Single"
			)
	plt.ttl<-paste("Relative Abundance of the",nrec,"Most Common Species of Shorebirds at", sgvarval)
	if(xvar=="Genus" & nrc>1)plt.ttl<-paste("Relative Abundance of the",nrec,"Most Common Genera of Shorebirds at",sgvarval)
	if(xvar=="Genus" & nrc==1)plt.ttl<-paste("Relative Abundance of the",nrec,"Most Common Genus of Shorebirds at",sgvarval)
	#plt.sfx<-ifelse(fac==TRUE,"by Year",paste("for Year",pfss.df[1,"Year"]))
	plt.sfx<-ifelse(fac==TRUE,"by Season",paste("for Season",pfss.df[1,"Season"]))
	plt.ttl<-paste(plt.ttl,plt.sfx)
	assign("pfss.df",pfss.df,envir=.GlobalEnv)
	
	#pp<-ggplot(data=pfss.df,aes(x=xvariable,y=RelAbundance, label=TotalCount)) + geom_bar(aes(fill=xvariable), stat="identity") +  
	#		geom_text(vjust=1.5, colour="white") + labs(y="Relative Abundance",x="Taxon") + theme_bw()
	#p2<-pp + opts(axis.title.x=theme_blank(), axis.text.x=theme_blank())
	#p3<-p2 + opts(legend.title = theme_blank())
	##
	pp<-ggplot(data=pfss.df,aes(x=xvariable,y=RelAbundance, label=TotalCount)) + geom_bar(stat="identity") +  
			geom_text(vjust=-0.3, colour="black",size=5) + labs(y="Relative Abundance",x="") + theme_bw()
	p2<-pp + theme(axis.text.x=element_text(angle=30,size=14, hjust=1, vjust=1), axis.title.y=element_text(angle=90,size=14),axis.text.y=element_text(size=12))

	if(fac==TRUE)p2<-p2 + facet_wrap(~Year, ncol=2,scales = "free_y") 
	res.pp[[1]]<-p2
	res.pp[[2]]<-plt.ttl
	return(res.pp)
}
	
addSUidentity<-function(res.tbl,sgtn){
	sgn<-ifelse(sgtn=="Region","HabRegion",sgtn) 
	ch<-odbcConnect("PFSSsupport-Redhat")
	su.tbl<-sqlQuery(ch, paste("SELECT SUgroup,Site,", sgn,"FROM app_transect;"))
	close(ch)
	names(su.tbl)<-c("SUgroup","Site",sgtn)
	tbl.tmp<-merge(res.tbl,su.tbl,all.x=TRUE)
	tbl.tmp[,c(sgtn)]<-ifelse(is.na(tbl.tmp[,c(sgtn)]),as.character(tbl.tmp$SUgroup),as.character(tbl.tmp[,c(sgtn)]))
	tbl.tmp<-unique(tbl.tmp)
		return(tbl.tmp)
}

addSeason<-function(data.obj){
	obs<-ObsData(data.obj); eff<-EffortData(data.obj)
	obs$Season<-ifelse((obs$JulianDay >= 1 & obs$JulianDay <= 46),
			paste(obs$YearCollected-1,"-",obs$YearCollected,sep=""),paste(obs$YearCollected,"-",obs$YearCollected+1,sep=""))
	eff$Season<-ifelse((eff$JulianDay >= 1 & eff$JulianDay <= 46),
			paste(eff$YearCollected-1,"-",eff$YearCollected,sep=""),paste(eff$YearCollected,"-",eff$YearCollected+1,sep=""))
	#don't do this! Why do it? Let the user figure out her mistake if data are unbalanced
	#mxy<-max(eff$YearCollected)
	#obs<-subset(obs,!paste(obs$YearCollected,obs$MonthCollected,sep="") %in% c(paste(mxy,"10",sep=""),paste(mxy,"11",sep=""),paste(mxy,"12",sep="")))
	#eff<-subset(eff,!paste(eff$YearCollected,eff$MonthCollected,sep="") %in% c(paste(mxy,"10",sep=""),paste(mxy,"11",sep=""),paste(mxy,"12",sep="")))
	ObsData(data.obj)<-obs; EffortData(data.obj)<-eff
	return(data.obj)
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
