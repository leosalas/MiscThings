# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 22, 2009
###############################################################################

RavianWeb.Summary <- function(formData) {
	options(warn=-1)
	results<-list()
	rr.objects<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	more.filters<-""
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	obs.groups<-formData$ObservationGroups
	
	tgtn <- ""
	if(taxon.groups!="") tgtn<-"for Selected Species"
	
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters="", taxon.groups=taxon.groups, 
					spatial.groups=spatial.groups,obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal="1", sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	
	###First the tabulations  LEOOO: think about using an xml file for this!
	if(dt=="Band"){
			#t.vars<-c("YearCollected","MonthCollected","NetHours","sum")
			tv<-array(dim=c(4,4))	#dim=c(5,4)
			tv[1,]<-c("MonthCollected","YearCollected","NetHours","sum")	
			tv[2,]<-c("MonthCollected","CommonName","ObservationCount","sum")
			tv[3,]<-c("YearCollected","CommonName","ObservationCount","sum") 
			tv[4,]<-c("MonthCollected","MonthCollected","CommonName","sum")	#this needs to be plotted
			#tv[5,]<-c("CommonName","CommonName",NA,"NROW")
	}
	if(dt=="PointCount"){
			tv<-array(dim=c(6,4)) #dim=c(7,4)	
			tv[1,]<-c("YearCollected","Point","Visit","NROW")
			tv[2,]<-c("MonthCollected","Point","Visit","NROW")	
			tv[3,]<-c("MonthCollected","YearCollected","ObservationCount","sum") 
			tv[4,]<-c("MonthCollected","YearCollected","CommonName","NROW")	
			tv[5,]<-c("YearCollected","CommonName","ObservationCount","sum")	
			tv[6,]<-c("MonthCollected","CommonName","ObservationCount","sum")
			#tv[7,]<-c("CommonName","CommonName",NA,"NROW")
	}
	if(dt=="AreaSearch"){
			tv<-array(dim=c(6,4))	#dim=c(7,4)
			tv[1,]<-c("YearCollected","Plot","Visit","NROW")
			tv[2,]<-c("MonthCollected","Plot","Visit","NROW")	
			tv[3,]<-c("MonthCollected","YearCollected","ObservationCount","sum") 
			tv[4,]<-c("MonthCollected","YearCollected","CommonName","NROW")	
			tv[5,]<-c("YearCollected","CommonName","ObservationCount","sum")	
			tv[6,]<-c("MonthCollected","CommonName","ObservationCount","sum")
			#tv[7,]<-c("CommonName","CommonName",NA,"NROW")
	}
	for(iii in 1:nrow(tv)){
		t.vars<-tv[iii,]
		test.ct<-try(crossTabulate(object = data.obj, t.vars = t.vars), silent=TRUE)
		rr.objects[[iii]]<-test.ct
		if (inherits(test.ct,"try-error")) {
			results[[iii]]<-populate.RWOError(error=test.ct, formData, data.obj=do.test, res.ordinal=iii, sink.error=TRUE)
		} else {	#we have a table/crosstable
			#beautify row/col headers
			ct.obj<-try(checkRowColumnNames(test.ct), silent=TRUE)
			if (inherits(ct.obj,"try-error")) ct.obj<-test.ct	
			t.titl<-getTitle(dt,iii,tgtn)
			results[[iii]]<-populate.RWOTable(ordinal = iii, title=t.titl,table.obj=ResultsTable(ct.obj), table.note=Notes(test.ct))
		}
	}
	#describe sampling
	if(dt=="PointCount"){
		iii<-iii+1
		ds.obj<-try(describeSampling(object = data.obj), silent=TRUE)
		if (inherits(ds.obj,"try-error")) {
			results[[iii]]<-populate.RWOError(error=ds.obj, formData, data.obj=data.obj, res.ordinal=iii, sink.error=TRUE)
		} else {	#got a description
			results[[iii]]<-populate.RWOTable(ordinal = iii, title=TableTitle(ds.obj),table.obj=ResultsTable(ds.obj), table.note=Notes(ds.obj))
		}
	}

	#describe CommonName
		iii<-iii+1
		test.dv<-try(describeVariable(object=data.obj, var="CommonName", type="d"), silent=TRUE)
		if (inherits(test.dv,"try-error")) {
			sink.error<-ifelse(grepl("Ravian Message:",test.dv), FALSE, TRUE)
			results[[iii]]<-populate.RWOError(error=test.dv, formData, data.obj=do.test, res.ordinal=iii, sink.error=sink.error)
		} else {	#we have a description
			t.titl<-"Richness, Diversity, Dominance and Evenness Indices"
			results[[iii]]<-populate.RWOTable(ordinal = iii, title=t.titl,table.obj=ResultsTable(test.dv), table.note=Notes(test.dv))
		}

	#finally, plotting whatever needs to, if any
	tmp.plot<-NULL
	p.titl<-getTitle(dt,4,tgtn)
	if(dt=="Band"){
		#plot #4
		rro<-rr.objects[[4]]
		ct.plt.obj<-try(checkPlotLabels(rro), silent=TRUE)
		if(inherits(ct.plt.obj,"try-error")) ct.plt.obj<-rro
		tmp.plot<-plot(x=ct.plt.obj,plot.type="bar",facet.wrap=FALSE)
	} 
	if(!is.null(tmp.plot)){
		iii<-iii+1
		if (inherits(tmp.plot,"try-error")){
			ifelse(grepl("Ravian Message:",tmp.plot), sink.error<-FALSE, sink.error<-TRUE)
			results[[iii]]<-populate.RWOError(error=tmp.plot, formData=formData, data.obj = rro, res.ordinal=iii, sink.error=sink.error)
		} else {
			results[[iii]]<-populate.RWOGraph(ordinal=iii, title=p.titl, graph.obj = ResultsGraph(tmp.plot), graph.note=Notes(tmp.plot))
		}
	}
	return(results) #normal ending
}
	
getTitle<-function(dt,iii,tgtn=""){
	niv<-as.character(iii)
	table.titl<-""
	if(dt=="Band"){
			table.titl<-switch(niv,
					"1" = paste("Total Net-Hours by Month and Year",tgtn),
					"2" = paste("Total Number of Captures of each Species by Month",tgtn),
					"3" = paste("Total Number of Captures of each Species by Year",tgtn),
					"4" = paste("Total Number of Species Captured per Month",tgtn),
					"5" = paste("Total Number of Records per Species",tgtn)
			)
	}else if(dt=="PointCount"){
			table.titl<-switch(niv,
					"1" = paste("Total Number of Visits to each Point by Year",tgtn),
					"2" = paste("Total Number of Visits to each Point by Month",tgtn),
					"3" = paste("Total Number of Observations by Month and Year",tgtn),
					"4" = paste("Total Number of Species by Month and Year",tgtn),
					"5" = paste("Total Number of Observations of each Species by Year",tgtn),
					"6" = paste("Total Number of Observations of each Species by Month",tgtn),
					"7" = paste("Total Number of Records per Species",tgtn)
			)	 
	}else if(dt=="AreaSearch"){
			table.titl<-switch(niv,
					"1" = paste("Total Number of Visits to each Plot by Year",tgtn),
					"2" = paste("Total Number of Visits to each Plot by Month",tgtn),
					"3" = paste("Total Number of Observations by Month and Year",tgtn),
					"4" = paste("Total Number of Species by Month and Year",tgtn),
					"5" = paste("Total Number of Observations of each Species by Year",tgtn),
					"6" = paste("Total Number of Observations of each Species by Month",tgtn),
					"7" = paste("Total Number of Records per Species",tgtn)
			)
	}else{}
	return(table.titl)
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
