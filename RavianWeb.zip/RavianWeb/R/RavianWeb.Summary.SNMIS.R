# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 22, 2009
###############################################################################

RavianWeb.Summary.SNMIS <- function(formData) {
	options(warn=-1)
	results<-list()
	rr.objects<-list()
	dt<-formData$DataType
	do<-paste(dt,"Data", sep="")
	do.test<-new(do)
	data.level<-formData$level
	DataDefn(do.test)<-CADC(dt, data.level=data.level, dsn="ravian_wh")
	FilterList(do.test)<-list(obsSQL=formData$obsSQL,
			eventSQL=formData$eventSQL)
	if(dt=="PointCount")more.filters<-"ProtocolCode NOT IN ('VCP300_PLAYBACK','VCP300_2xOBS_DEP','VCP300_2xOBS_IND')"
	taxon.groups<-formData$TaxonGroups
	taxon.groups.name<-formData$TaxonGroupsName
	spatial.groups<-formData$SpatialGroups
	spatial.groups.name<-formData$SpatialGroupsName
	sgc = "StudyArea"
	sgtn = "Forest"
	if(spatial.groups!=""){
		sgc = "SpatialGroup"
		sgtn = spatial.groups.name
	}
	#Do we do anything with taxon groups?? Only the title...??
	tgtn = ""
	if(taxon.groups!="")tgtn = " for Selected Species"
	obs.groups<-formData$ObservationGroups
	
	data.obj<-try(getAvianData(object=do.test, more.filters=more.filters, more.obs.filters="", taxon.groups=taxon.groups, 
					spatial.groups=spatial.groups,obs.groups=obs.groups),silent=TRUE) #try-catch
	
	if (inherits(data.obj,"try-error")) {
		ifelse(grepl("Ravian Message:",data.obj)==TRUE, sink.error<-FALSE, sink.error<-TRUE)
		results[[1]]<-populate.RWOError(error=data.obj, formData, data.obj = do.test, res.ordinal=1, sink.error=sink.error)
		return(results)	#ends here - can't continue
	}
	
	##First, the number of sampling events
	n.samp.events<-try(getNumberEvents(eff.dat=EffortData(data.obj),sgtn=sgtn),silent=TRUE)

	if (inherits(n.samp.events,"try-error")) {
		results[[2]]<-populate.RWOError(error=n.samp.events, formData, data.obj=do.test, res.ordinal=2, sink.error=TRUE)
	} else {	#we have a sampling event counts table
		results[[2]]<-populate.RWOTable(ordinal = 2, title=TableTitle(n.samp.events),table.obj=ResultsTable(n.samp.events), table.note=Notes(n.samp.events))
	}
	
	###Then the tabulations  LEOOO: think about using an xml file for this!
			tv<-array(dim=c(3,4))	
			tv[1,]<-c("YearCollected",sgc,"Transect","NROW")
			tv[2,]<-c("YearCollected",sgc,"ObservationCount","sum") 	
			tv[3,]<-c("YearCollected","CommonName","ObservationCount","sum")	

	for(iii in 1:nrow(tv)){
		t.vars<-tv[iii,]
		test.ct<-try(crossTabulate(object = data.obj, t.vars = t.vars), silent=TRUE)
		zz<-iii
		if(iii>1)zz<-iii+1
		if (inherits(test.ct,"try-error")) {
			results[[zz]]<-populate.RWOError(error=test.ct, formData, data.obj=do.test, res.ordinal=zz, sink.error=TRUE)
		} else {	#we have a table/crosstable
			#beautify row/col headers
			ct.obj<-try(checkRowColumnNames(test.ct), silent=TRUE)
			if (inherits(ct.obj,"try-error")) ct.obj<-test.ct	
			t.titl<-getTitleSNMIS(iii,sgtn,tgtn)
			results[[zz]]<-populate.RWOTable(ordinal = zz, title=t.titl,table.obj=ResultsTable(ct.obj), table.note=Notes(test.ct))
		}
	}
	#altering table 2 to report visits to transects
	
	#if(no.sp) {#describe CommonName
	#	iii<-iii+1
	#	test.dv<-try(describeVariable(object=data.obj, var="CommonName", type="d"), silent=TRUE)
	#	if (inherits(test.dv,"try-error")) {
	#		results[[iii]]<-populate.RWOError(error=test.dv, formData, data.obj=do.test, res.ordinal=iii, sink.error=TRUE)
	#	} else {	#we have a description
	#		t.titl<-"Richness, Diversity, Dominance and Evenness Indices"
	#		results[[iii]]<-populate.RWOTable(ordinal = iii, title=t.titl,table.obj=ResultsTable(test.dv), table.note=Notes(test.dv))
	#	}
	#}
	
	return(results) #normal ending
}
	
getTitleSNMIS<-function(iii,sgtn,tgtn){
	niv<-as.character(iii)
	table.titl<-""
		
			table.titl<-switch(niv,
					"1" = paste("Total Number of Transects in ",sgtn," by Year",sep=""),
					"2" = paste("Total Number of Observations by ",sgtn," and Year",sep=""),
					"3" = "Total Number of Observations of each Species by Year"
			)	
	return(table.titl)
}	
	
getNumberEvents<-function(eff.dat,sgtn){
	eff.fld<-c("SpatialGroup","Transect","YearCollected","JulianDay")
	table.note<-""
	diff.visit<-(nrow(unique(eff.dat[,c("SpatialGroup","Transect","YearCollected","Visit","JulianDay")])))-(nrow(unique(eff.dat[,c("SpatialGroup","Transect","YearCollected","Visit")])))
	if(diff.visit>0) table.note<-paste("Number of visits to transects that spanned more than 1 day:",diff.visit)
	eff.data<-unique(eff.dat[,eff.fld])
	visits.m<-melt(eff.data, id=c("SpatialGroup","Transect","YearCollected","JulianDay"))
	visits.c<-cast(visits.m,SpatialGroup + YearCollected ~ ., fun.aggregate="NROW",value="JulianDay")
	names(visits.c)<-c("Spatial Group","Year Collected","No. Survey Events")
	res<-new("RavianSummaryTable")
	ResultsTable(res) <- as.data.frame(visits.c) 	 	
	Process(res) <- "Summary.SNMIS"			
	TableTitle(res) <- paste("Total Number of Survey Events (Transect Visits) to ",sgtn," by Year",sep="")			
	Notes(res) <- table.note			
	return(res)
}	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
