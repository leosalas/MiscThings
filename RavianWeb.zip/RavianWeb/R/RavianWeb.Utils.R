# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 21, 2009
###############################################################################

populate.RWOError<-function(error, formData, data.obj=NULL, res.ordinal=NULL, err.note="", sink.error=TRUE){
	#Takes an error report and returns it as a RavianWebOutSystemError or RavianWebOutUserError object, plus logs to file
	if(sink.error==TRUE){
		rwo<-new("RavianWebOutSystemError")
		ResultType(rwo)<-"System Error"
		temp.file<-basename(tempfile(pattern=""))
		error.message<-paste("An error has occurred in the Analyst.",
				"Please report the following error number to the developers:", temp.file)
		if(grepl("Windows",Sys.info()["sysname"])){
			save(formData, data.obj, error, file=paste(tempdir(),"/",temp.file,".RData",sep=""))	#locally
		}else{
			save(formData, data.obj, error, file=paste("/var/www/html/tmp/",temp.file,".RData",sep=""))	#on the server
		}
		ResultTitle(rwo)<-"Error"
	} else {
		rwo<-new("RavianWebOutUserError")
		ResultType(rwo)<-"User Error"
		error.message<-paste(error,collapse=" ")
		error.message<-substr(error.message,17,nchar(error.message)) #this removes the "Ravian Message: " prefix
		ResultTitle(rwo)<-"Attention"
	}
	ifelse(is.null(res.ordinal)==TRUE,ResultOrdinal(rwo)<-"1",ResultOrdinal(rwo)<-as.character(res.ordinal))
	ResultError(rwo)<-error.message
	ResultNote(rwo)<-err.note
	return(rwo)
}

populate.RWOTable<-function(ordinal, title, table.obj, table.note=""){
	rwo<-new("RavianWebOutTable")
	ResultOrdinal(rwo)<-as.character(ordinal)
	ResultType(rwo)<-"Table"
	ResultTitle(rwo)<-title
	ResultTable(rwo)<-table.obj
	ResultNote(rwo)<-table.note
	return(rwo)
}

populate.RWOGraph<-function(ordinal, title, graph.obj, graph.note="",wdt=700,hgt=525){
	if(grepl("Windows",Sys.info()["sysname"])){
		tpd<-tempdir()		#if locally
	}else{
		tpd<-"/var/www/html/tmp"		
	}
	tmpf<-tempfile(pattern="RavianWeb", tmpdir=tpd)
	png(filename=tmpf, width = wdt, height = hgt)
		print(graph.obj)
	dev.off()
	img <- readBin(tmpf, "raw", file.info(tmpf)[1, "size"])
	enc <-  base64Encode(img, "character")
	rwo<-new("RavianWebOutGraph")
	ResultOrdinal(rwo)<-as.character(ordinal)
	ResultType(rwo)<-"Graph"
	ResultTitle(rwo)<-title
	ResultGraph(rwo)<-enc[1]
	ResultNote(rwo)<-graph.note
	TempFileName(rwo)<-tmpf
	return(rwo)
}

populate.RWOXTable<-function(ordinal, title, table.obj, table.note=""){
	rwo<-new("RavianWebOutXTable")
	ResultOrdinal(rwo)<-as.character(ordinal)
	ResultType(rwo)<-"Table"
	ResultTitle(rwo)<-title
	ResultXTable(rwo)<-table.obj
	ResultNote(rwo)<-table.note
	return(rwo)
}

makeRavianPlot<-function(dat.obj,plot.type,facet.wrap=FALSE,plot.subset="",zz,formData){
	tmp.plot<-try(plot(x=dat.obj, plot.type=plot.type,facet.wrap=facet.wrap),silent=TRUE)
	if (inherits(tmp.plot,"try-error")){
		sink.error<-ifelse(grepl("Ravian Message:",tmp.plot),FALSE,TRUE)
		results.plot<-populate.RWOError(error=tmp.plot, formData=formData, data.obj = dat.obj, res.ordinal=zz, sink.error=sink.error)
	}else{
		GraphTitle(tmp.plot)<-paste(TableTitle(dat.obj),plot.subset)
		graph.note=paste("Bars around estimates are +/- 1 Standard Deviation.",Notes(tmp.plot))
		results.plot<-populate.RWOGraph(ordinal=zz, title=GraphTitle(tmp.plot), graph.obj = ResultsGraph(tmp.plot), graph.note=graph.note)
	}
}

deleteTempPlots<-function(results){
	filenams<-character()
	for(rr in 1:length(results)){
		tro<-results[[rr]]
		if(class(tro)=="RavianWebOutGraph"){
			filenams<-c(filenams,TempFileName(tro))
		}
	}
	if(length(filenams)>0) file.remove(filenams)
}
