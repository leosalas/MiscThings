# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 20, 2009
###############################################################################

#Create the class and subclasses
#add method to class, with argument being the XML doc to which the XML snippet will be appended

#' Abstract class for RavianWebOut
#' 
#' Abstract class for RavianWebOut
#' @slot ResultOrdinal character string that contains a position number for the object in an output list of RavianWebOut objects
#' @slot ResultType character string that specifies the type of result contained in the object - currently supported: table, graph
#' @slot ResultTitle character string that holds the title of the result object
#' @exportClass RavianWebOut
setClass("RavianWebOut", representation(
				ResultOrdinal = "character",
				ResultType = "character", 
				ResultTitle = "character",
				ResultNote = "character"))

#' Instantiate a new RavianWebOut object
#' 
#' @nord
#' @exportMethod initialize 
setMethod("initialize",
		signature(.Object = "RavianWebOut"),
		function (.Object, ...) 
		{	
			.Object@ResultOrdinal <- ""
			.Object@ResultType <- ""
			.Object@ResultTitle <- ""
			.Object
		}
)


#' Set ResultOrdinal slot of RavianWebOut object.
#' 
#' @name setResultOrdinal
#' @param object A RavianWebOut object
#' @param value character string to put into ResultOrdinal slot.
#' @nord
setGeneric("ResultOrdinal<-", 
		function(object, value)	standardGeneric("ResultOrdinal<-"))
#' @nord
setReplaceMethod("ResultOrdinal",signature(object="RavianWebOut"),
		function(object,value) {
			slot(object,"ResultOrdinal")<-value
			validObject(object)
			object
		})

#' Retrieve ResultOrdinal slot value of RavianWebOut object.
#' 
#' @param object A RavianWebOut object
#' @nord
setGeneric("ResultOrdinal", 
		function(object) standardGeneric("ResultOrdinal"))
#' @nord
setMethod("ResultOrdinal", signature(object="RavianWebOut"),
		function(object) slot(object,"ResultOrdinal"))

#' Set ResultType slot of RavianWebOut object.
#' 
#' @name setResultType
#' @param object A RavianWebOut object
#' @param value character string to put into ResultType slot.
#' @nord
setGeneric("ResultType<-", 
		function(object, value)	standardGeneric("ResultType<-"))
#' @nord
setReplaceMethod("ResultType",signature(object="RavianWebOut"),
		function(object,value) {
			slot(object,"ResultType")<-value
			validObject(object)
			object
		})

#' Retrieve ResultOrdinal slot value of RavianWebOut object.
#' 
#' @param object A RavianWebOut object
#' @nord
setGeneric("ResultType", 
		function(object) standardGeneric("ResultType"))
#' @nord
setMethod("ResultType", signature(object="RavianWebOut"),
		function(object) slot(object,"ResultType"))

#' Set ResultTitle slot of RavianWebOut object.
#' 
#' @name setResultTitle
#' @param object A RavianWebOut object
#' @param value character string to put into ResultTitle slot.
#' @nord
setGeneric("ResultTitle<-", 
		function(object, value)	standardGeneric("ResultTitle<-"))
#' @nord
setReplaceMethod("ResultTitle",signature(object="RavianWebOut"),
		function(object,value) {
			slot(object,"ResultTitle")<-value
			validObject(object)
			object
		})

#' Retrieve ResultNote slot value of RavianWebOut object.
#' 
#' @param object A RavianWebOut object
#' @nord
setGeneric("ResultNote", 
		function(object) standardGeneric("ResultNote"))
#' @nord
setMethod("ResultNote", signature(object="RavianWebOut"),
		function(object) slot(object,"ResultNote"))

#' Set ResultNote slot of RavianWebOut object.
#' 
#' @name setResultNote
#' @param object A RavianWebOut object
#' @param value character string to put into ResultNote slot.
#' @nord
setGeneric("ResultNote<-", 
		function(object, value)	standardGeneric("ResultNote<-"))
#' @nord
setReplaceMethod("ResultNote",signature(object="RavianWebOut"),
		function(object,value) {
			slot(object,"ResultNote")<-value
			validObject(object)
			object
		})

#' Retrieve ResultTitle slot value of RavianWebOut object.
#' 
#' @param object A RavianWebOut object
#' @nord
setGeneric("ResultTitle", 
		function(object) standardGeneric("ResultTitle"))
#' @nord
setMethod("ResultTitle", signature(object="RavianWebOut"),
		function(object) slot(object,"ResultTitle"))

###### Sub-classes #########
#' RavianWebOutGraph - subclass of RavianWebOut
#' 
#' RavianWebOutGraph - subclass of RavianWebOut
#' @slot ResultGraph character string holding text-encoded graph
#' @slot TempFileName character string holding the name of the temporary file created to write the plot
#' @exportClass RavianWebOutGraph
setClass("RavianWebOutGraph",contains=c("RavianWebOut"),
		representation(
				ResultGraph = "character",
				TempFileName = "character"
		)
)

#' Instantiate a new RavianWebOutGraph object
#' 
#' @nord
#' @exportMethod initialize 
setMethod("initialize",
		signature(.Object = "RavianWebOutGraph"),
		function (.Object, ...) 
		{	
			.Object@ResultOrdinal <- ""
			.Object@ResultType <- ""
			.Object@ResultTitle <- ""
			.Object@ResultGraph<- ""
			.Object@TempFileName<- ""
			.Object
		}
)

#' RavianWebOutTable - subclass of RavianWebOut
#' 
#' RavianWebOutTable - subclass of RavianWebOut
#' @slot ResultTable data frame holding a table
#' @exportClass RavianWebOutTable
setClass("RavianWebOutTable",contains=c("RavianWebOut"),
		representation(
				ResultTable = "data.frame"
		)
)

#' Instantiate a new RavianWebOutTable object
#' 
#' @nord
#' @exportMethod initialize 
setMethod("initialize",
		signature(.Object = "RavianWebOutTable"),
		function (.Object, ...) 
		{	
			.Object@ResultOrdinal <- ""
			.Object@ResultType <- ""
			.Object@ResultTitle <- ""
			.Object@ResultTable<- data.frame()
			.Object
		}
)

#' RavianWebOutXTable - subclass of RavianWebOut
#' 
#' RavianWebOutXTable - subclass of RavianWebOut
#' @slot ResultTable table-class object holding an  xtable
#' @exportClass RavianWebOutXTable
setClass("RavianWebOutXTable",contains=c("RavianWebOut"),
		representation(
				ResultXTable = "matrix"
		)
)

setMethod("initialize",
		signature(.Object = "RavianWebOutXTable"),
		function (.Object, ...) 
		{	
			.Object@ResultOrdinal <- ""
			.Object@ResultType <- ""
			.Object@ResultTitle <- ""
			.Object@ResultXTable<- matrix()
			.Object
		}
)

#' RavianWebOutSystemError - subclass of RavianWebOut
#' 
#' RavianWebOutSystemError - subclass of RavianWebOut
#' @slot Error-class object holding an error string
#' @exportClass RavianWebOutSystemError
setClass("RavianWebOutSystemError",contains=c("RavianWebOut"),
		representation(
				ResultError = "character"
		)
)

setMethod("initialize",
		signature(.Object = "RavianWebOutSystemError"),
		function (.Object, ...) 
		{	
			.Object@ResultOrdinal <- ""
			.Object@ResultType <- ""
			.Object@ResultTitle <- ""
			.Object@ResultError<- ""
			.Object
		}
)

#' RavianWebOutUserError - subclass of RavianWebOut
#' 
#' RavianWebOutUserError - subclass of RavianWebOut
#' @slot Error-class object holding an error string
#' @exportClass RavianWebOutUserError
setClass("RavianWebOutUserError",contains=c("RavianWebOut"),
		representation(
				ResultError = "character"
		)
)

setMethod("initialize",
		signature(.Object = "RavianWebOutUserError"),
		function (.Object, ...) 
		{	
			.Object@ResultOrdinal <- ""
			.Object@ResultType <- ""
			.Object@ResultTitle <- ""
			.Object@ResultError<- ""
			.Object
		}
)

####and their methods....####
#' Set ResultGraph slot of RavianWebOutGraph object.
#' 
#' @name setResultGraph
#' @param object A RavianWebOutGraph object
#' @param value character string to put into ResultGraph slot.
#' @nord
setGeneric("ResultGraph<-", 
		function(object, value)	standardGeneric("ResultGraph<-"))
#' @nord
setReplaceMethod("ResultGraph",signature(object="RavianWebOutGraph"),
		function(object,value) {
			slot(object,"ResultGraph")<-value
			validObject(object)
			object
		})

#' Retrieve ResultGraph slot value of RavianWebOutGraph object.
#' 
#' @param object A RavianWebOutGraph object
#' @nord
setGeneric("ResultGraph", 
		function(object) standardGeneric("ResultGraph"))
#' @nord
setMethod("ResultGraph", signature(object="RavianWebOutGraph"),
		function(object) slot(object,"ResultGraph"))


#' Set TempFileName slot of RavianWebOutGraph object.
#' 
#' @name setTempFileName
#' @param object A RavianWebOutGraph object
#' @param value character string to put into TempFileName slot.
#' @nord
setGeneric("TempFileName<-", 
		function(object, value)	standardGeneric("TempFileName<-"))

#' @nord
setReplaceMethod("TempFileName",signature(object="RavianWebOutGraph"),
		function(object,value) {
			slot(object,"TempFileName")<-value
			validObject(object)
			object
		})

#' Retrieve TempFileName slot value of RavianWebOutGraph object.
#' 
#' @param object A RavianWebOutGraph object
#' @nord
setGeneric("TempFileName", 
		function(object) standardGeneric("TempFileName"))

#' @nord
setMethod("TempFileName", signature(object="RavianWebOutGraph"),
		function(object) slot(object,"TempFileName"))


#' Set ResultTable slot of RavianWebOutTable object.
#' 
#' @name setResultTable
#' @param object A RavianWebOutTable object
#' @param value data frame to put into ResultTable slot.
#' @nord
setGeneric("ResultTable<-", 
		function(object, value)	standardGeneric("ResultTable<-"))
#' @nord
setReplaceMethod("ResultTable",signature(object="RavianWebOutTable"),
		function(object,value) {
			slot(object,"ResultTable")<-value
			validObject(object)
			object
		})

#' Retrieve ResultTable slot value of RavianWebOutTable object.
#' 
#' @param object A RavianWebOutTable object
#' @nord
setGeneric("ResultTable", 
		function(object) standardGeneric("ResultTable"))
#' @nord
setMethod("ResultTable", signature(object="RavianWebOutTable"),
		function(object) slot(object,"ResultTable"))


#' Set ResultXTable slot of RavianWebOutXTable object.
#' 
#' @name setResultXTable
#' @param object A RavianWebOutXTable object
#' @param value data frame to put into ResultTable slot.
#' @nord
setGeneric("ResultXTable<-", 
		function(object, value)	standardGeneric("ResultXTable<-"))
#' @nord
setReplaceMethod("ResultXTable",signature(object="RavianWebOutXTable"),
		function(object,value) {
			slot(object,"ResultXTable")<-value
			validObject(object)
			object
		})

#' Retrieve ResultXTable slot value of RavianWebOutXTable object.
#' 
#' @param object A RavianWebOutXTable object
#' @nord
setGeneric("ResultXTable", 
		function(object) standardGeneric("ResultXTable"))
#' @nord
setMethod("ResultXTable", signature(object="RavianWebOutXTable"),
		function(object) slot(object,"ResultXTable"))




#' Set ResultError slot of RavianWebOutSystemError object.
#' 
#' @name setResultError
#' @param object A RavianWebOutSystemError object
#' @param value string to put into ResultError slot.
#' @nord
setGeneric("ResultError<-", 
		function(object, value)	standardGeneric("ResultError<-"))
#' @nord
setReplaceMethod("ResultError",signature(object="RavianWebOutSystemError"),
		function(object,value) {
			slot(object,"ResultError")<-value
			validObject(object)
			object
		})

#' Retrieve ResultError slot value of RavianWebOutSystemError object.
#' 
#' @param object A RavianWebOutSystemError object
#' @nord
setGeneric("ResultError", 
		function(object) standardGeneric("ResultError"))
#' @nord
setMethod("ResultError", signature(object="RavianWebOutSystemError"),
		function(object) slot(object,"ResultError"))


#' Set ResultError slot of RavianWebOutUserError object.
#' 
#' @name setResultError
#' @param object A RavianWebOutUserError object
#' @param value string to put into ResultError slot.
#' @nord
setReplaceMethod("ResultError",signature(object="RavianWebOutUserError"),
		function(object,value) {
			slot(object,"ResultError")<-value
			validObject(object)
			object
		})

#' Retrieve ResultError slot value of RavianWebOutUserError object.
#' 
#' @param object A RavianWebOutUserError object
#' @nord
setMethod("ResultError", signature(object="RavianWebOutUserError"),
		function(object) slot(object,"ResultError"))


###### makeXML method ###################
#' Convert RavianWebOut object into XML node
#'  
#' Convert RavianWebOut object into XML node within an open tree
#' 
#' @param RWOobject A RavianWebOut object.
#' @param XMLobject A XMLInternalDOM object.
#' 
#' @exportMethod makeXML
setGeneric("makeXML", 
		function(rwo.obj, xml.doc) standardGeneric("makeXML"))
#' @exportMethod makeXML 
setMethod("makeXML",signature(rwo.obj="RavianWebOut"), 
		function(rwo.obj, xml.doc=NULL) {
			#Here the code to add nodes to the passed tree
			#Check that xml.doc is not null
			if(is.null(xml.doc)==TRUE) {
				#create and return an error object to be catched by the wrapper
				error<-"XML document is empty"
				class(error)<-"try-error"
				return(error)  
			}
			
			#Check that rwo.obj has needed info - if it doesn't, fail "gracefully" by returning the xml doc "as is"
			if(is.null(rwo.obj)==TRUE | ResultOrdinal(rwo.obj)=="" | ResultType(rwo.obj)=="" | ResultTitle(rwo.obj)=="") return(xml.doc)
			if(ResultType(rwo.obj)=="Graph"){
					if(ResultGraph(rwo.obj)=="") return(xml.doc)
				} 
			if(ResultType(rwo.obj)=="Table"){
				if(class(rwo.obj)=="RavianWebOutTable"){
					if(length(ResultTable(rwo.obj))==0) return(xml.doc)
				}
				if(class(rwo.obj)=="RavianWebOutXTable"){
					if(length(ResultXTable(rwo.obj))==0) return(xml.doc)
				}
			}
			
			#Here code to add node to the xml document
				xml.doc$addNode("RavianResult",close=FALSE)
				xml.doc$addNode("RavianResultInfo",close=FALSE)
				xml.doc$addNode("RavianResultOrdinal",ResultOrdinal(rwo.obj))
				xml.doc$addNode("RavianResultType",ResultType(rwo.obj))
				xml.doc$addNode("RavianResultTitle",ResultTitle(rwo.obj))
				xml.doc$addNode("RavianResultNote",ResultNote(rwo.obj))
				if(ResultType(rwo.obj)=="Graph") xml.doc$addNode("RavianImageFormat","PNG")
				#if(ResultType(rwo.obj)=="Error") xml.doc$addNode("RavianErrorLogNumber",ResultErrorLog(rwo.obj))
				xml.doc$closeTag() #</RavianResultInfo>
				#if result object is an error msg...must be a graph (a RavianResultMessage only for the wrapper and callRavian, not here)
				#sooo...for now at least, the following is valid
				if(ResultType(rwo.obj)=="Graph") {
					xml.doc$addNode("RavianImageStream",ResultGraph(rwo.obj))
				}else if(grepl("Error",ResultType(rwo.obj))){
					xml.doc$addNode("RavianResultErrorMessage",ResultError(rwo.obj))
				} else {
					ifelse(class(rwo.obj)=="RavianWebOutTable",res.table<-ResultTable(rwo.obj),res.table<-ResultXTable(rwo.obj))		#DO NOT force a data frame here or crosstables won't work.  Make it be a df elsewhere, if needed
					xml.doc$addNode("RavianResultFieldNames",
							.children = sapply(colnames(res.table), function(x) xml.doc$addNode("FieldName", x)))
					xml.doc$addNode("RavianResultDataRows",close=FALSE)
					for (Row in 1:ifelse(is.null(nrow(res.table))==TRUE,1,nrow(res.table))) {
						xml.doc$addNode("RavianResultDataRow", close=FALSE)
						for (Col in 1:ifelse(is.null(ncol(res.table))==TRUE,1,ncol(res.table)))  {
							if(is.numeric(res.table[Row,Col])==TRUE){
								if(res.table[Row,Col]>0) xml.doc$addNode("RowValue",round(res.table[Row,Col],2),attrs=c(FieldName=colnames(res.table)[Col]))
								else xml.doc$addNode("RowValue",signif(res.table[Row,Col],2),attrs=c(FieldName=colnames(res.table)[Col]))
							} else{
								xml.doc$addNode("RowValue",as.character(res.table[Row,Col]),attrs=c(FieldName=colnames(res.table)[Col]))	
							}
						}
						xml.doc$closeTag() # </RavianResultDataRow>
					}
					xml.doc$closeTag() #</RavianResultDataRows>
				}
				xml.doc$closeTag() #</RavianResult>
			#return the xml doc (still open)	
			return(xml.doc)
		})