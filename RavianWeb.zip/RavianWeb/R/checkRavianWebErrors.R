# TODO: Add comment
# 
# Author: mherzog
# Date Created: May 5, 2009
###############################################################################


checkRavianWebErrors<-function (formData) {
	error<-""
	required<-c("Process","DataType","eventSQL")
	if(is.null(formData)==TRUE) error<-"Ravian message: No information found in the analysis request."
	for (formName in required) {
		if (formData[formName]=="") error<-paste(error,formName," parameter is a required field.")
		chFV<-checkFormValue(form.value=as.character(formData[formName]), form.name=formName)
		if (!is.null(chFV)) error<-paste(error,chFV,sep="")
	}
	#check json objects, if present
	#first TaxonGroups
	tg<-formData$TaxonGroups
	if(tg!=""){
		#check that there is information
		tgl<-try(fromJSON(tg))
		if(inherits(tgl,"try-error")){
			error<-paste(error,"Ravian message: Taxon groups have been provided but json string cannot be parsed. Improper format?")
		}else{
			if(length(tgl)==0){
				error<-paste(error,"Ravian message: Taxon groups have been provided but there are no taxon groups defined, or improperly formated json string?")
			}else{
				for(jjj in 1:length(tgl)){
					if(length(tgl[[jjj]])==0)error<-paste(error,"Ravian message: At least one of the levels of Taxon Groups has no associated taxa.")
				}
			}
		}
		#check that there is an obsSQL
		obflt<-formData$obsSQL
		if(obflt=="" | grepl("SpeciesCode",obflt)==FALSE){
			error<-paste(error,"Ravian message: Taxon groups have been provided without a filter for species codes")
		}
	}
	sg<-formData$SpatialGroups
	if(sg!=""){
		#check that there is information
		sgl<-try(fromJSON(sg))
		if(inherits(sgl,"try-error")){
			error<-paste(error,"Ravian message: Spatial groups have been provided but json string cannot be parsed. Improper format?")
		}else{
			if(length(sgl)==0){
				error<-paste(error,"Ravian message: Spatial groups have been provided but there are no spatial groups defined, or improperly formated json string?")
			}else{
				for(jjj in 1:length(sgl)){
					if(length(sgl[[jjj]])==0)error<-paste(error,"Ravian message: At least one of the levels of Spatial Groups has no associated sampling units.")
				}
			}
		}
		
	}
	og<-formData$ObservationGroups
	if(og!=""){
		#check that there is information
		ogl<-try(fromJSON(og))
		if(inherits(ogl,"try-error")){
			error<-paste(error,"Ravian message: Observation groups have been provided but json string cannot be parsed. Improper format?")
		}else{
			if(length(ogl)==0){
				error<-paste(error,"Ravian message: Observation groups have been provided but there are no habitat types defined, or improperly formated json string?")
			}else{
				for(jjj in 1:length(ogl)){
					if(length(ogl[[jjj]])==0)error<-paste(error,"Ravian message: At least one of the levels of Observation Groups has no associated habitat types.")
				}
			}
		}
		
	}
	##Check for spatialRez value
	srv<-formData$SpatialResolution
	dt<-formData$DataType
	if(srv!="" & dt!="PointCount"){
		error<-paste(error,"Spatial resolution options are only available for point count data.")
	}else if(dt=="PointCount"){
		if(!srv %in% c("Point","Transect")){
			error<-paste(error,"Invalid value provided for the spatial resolution parameter. Valid values: Point or Transect.")
		}
	}else{}
	return(error)
}

checkFormValue<-function (form.value=NULL,form.name=NULL) {
	err<-NULL
# appropriate values are defined here (but if this gets more complicated, could be stored in a separate file	
	valid.values<-list(
			Process=c("Abundance","Richness","Summary","Multimap","Abundance.SNMIS","Richness.SNMIS","Summary.SNMIS",
					"Occupancy","Occupancy.SNMIS","Summary.PFSS","Richness.PFSS","Abundance.PFSS","Summary.ISBAdb",
					"AbundanceGeo.PFSS","Summary.OCOF"),
			DataType=c("PointCount","Band","AreaSearch","eBird","BBS","ShoreBird","ISBAdb","ShoreBirdGeo","OCOFgeo","eBird_SEADC","BBS_SEADC")
	)
	if(grepl(form.name,paste(names(valid.values),collapse=","))==TRUE){
		if (grepl(form.value,paste(valid.values[form.name],collapse=","))==FALSE) err<-paste(form.name," contains an unallowed value: ",form.value,".",sep="")
	}
	return(err)
}

