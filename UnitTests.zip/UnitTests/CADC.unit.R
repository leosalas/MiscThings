# CADC.R
# TODO: Add comment
# 
# Author: Leo Salas
# Contact: lsalas@prbo.org
# Creation Date: April 6, 2010
###############################################################################

CADC<-function(ProtocolType, data.level="0", dsn="") {#Here we could pass the dsn or create on-the-fly as below, the dsn is provided by the wrapper
	## This file should not be part of public package.
	tmp<-new("DataStore")
	DataStructure(tmp)<- "RavianWarehouse"
	ConnectionType(tmp)<- "ODBC"
	if(dsn==""){
		dsn="DSN=UnitWarehouses_Devel"
		driver="/usr/lib64/libmyodbc3.so"
		server="localhost"
		db.database="ravian_unit_wh"
		db.user="ravian"
		db.password="zakufeme"
		DSN(tmp)<- createDSN(
				DSN=dsn,		#this may be required, so could use "tempConString" for example...
				driver=driver,
				server=server,
				database=db.database,
				user=db.user,
				password=db.password)
	}else{
		DSN(tmp)<-as.character(dsn)
	}
	tbl.name<-switch(ProtocolType,
			PointCount = "pointCount_unit_wh",
			Band = "band_unit_wh",
			AreaSearch = "RavianAreaSearch")
	if(is.null(tbl.name))tbl.name<-"pointCount_unit_wh"
	TableName(tmp)<-tbl.name
	return(tmp)
}
