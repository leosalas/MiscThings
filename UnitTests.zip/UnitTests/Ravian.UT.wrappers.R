# TODO: Add comment
# 
# Author: lsalas
# Date created: Jan 26, 2010
###############################################################################


################################################################################
# WRAPPER FUNCTIONS FOR CADC.R
########################################################
# Function to test CADC.R output
getCADC.DSN.out<-function(data.type, data.level,dsn.val){
	gdsn<-CADC(ProtocolType=data.type,data.level=data.level,dsn=dsn.val)
	return(gdsn)
}

###############################################################################
#  WRAPPER FUNCTIONS FOR RavianUtils.R
########################################################
# Wrapper function to test creating a connection - connectDatabase
test.connectDatabase<-function(dsn){ 
	if(dsn=="default"){
		tst.con<-connectDatabase()
	}else{
		tst.con<-connectDatabase(dsn)
	}
	if(is.numeric(tst.con) & tst.con > 0)conResult=TRUE
	else conResult=FALSE
	closeDatabase(tst.con,ODBC=TRUE)
	return(conResult)
}

########################################################
# Wrapper function to test closure of a connection - closeDatabase
test.closeDatabase<-function(dsn){ 
	tst.con<-connectDatabase(dsn)
	ttt<-TRUE
	ttt<-closeDatabase(tst.con,ODBC=TRUE)
	if(ttt==TRUE)conResult<-FALSE
	else conResult<-TRUE
	return(conResult)
}

########################################################
# Wrapper function to test compressData
test.compressData<-function(query.obs,by.list,field,new.name,func){
	# create a connection and retrieve some data using query
	tst.con<-connectDatabase(dsn="UnitWarehouses_Devel")
	obs.data<-sqlQuery(tst.con, query.obs)
	closeDatabase(tst.con,ODBC=TRUE)
	# compress it
	by<-list()
	for(by.name in by.list){
		eval(substitute(by$x<-obs.data$x,list(x=by.name)))
	}
	tst.comp<-compressData(data=obs.data,by=by,field=field,new.name=new.name,FUN=func)
	return(tst.comp)
}

########################################################
# Wrapper function to test calcCompress
test.calcCompress<-function(query.obs,query.eff,by.list,comp.field,calc.fun,support.site.fields,new.name){
	# create a connection and retrieve some data using query
	tst.con<-connectDatabase(dsn="UnitWarehouses_Devel")
	data.table<-sqlQuery(tst.con, query.obs)
	effort.base<-sqlQuery(tst.con, query.eff)
	closeDatabase(tst.con,ODBC=TRUE)
	#calcCompress it
	comp.dat<-calcCompress(by.list,comp.field,calc.fun,data.table,support.site.fields,effort.base,new.name)
	return(comp.dat)
}

################################################################################
# WRAPPER FUNCTIONS FOR DataStore.R
########################################################
test.getData<-function(obs.eff,select.v,where.v,dsn.v){
	#getData needs a DataStore object, which must have a QueryList object, so must make both
	tql<-new("QueryList")
	Select(tql)<-select.v
	ifelse(obs.eff=="eff",Distinct(tql)<-TRUE,Distinct(tql)<-FALSE)
	From(tql)<-"pointCount_unit_wh"
	Where(tql)<-where.v
	GroupBy(tql)<-""
	Having(tql)<-""
	OrderBy(tql)<-""
	#DataStore...
	tds<-new("DataStore")
	ConnectionType(tds)<-"ODBC"
	DSN(tds)<-dsn.v
	TableName(tds)<-"pointCount_unit_wh"
	Query(tds)<-tql
	#now to getData
	ddd<-getData(tds)
	return(ddd)
}


################################################################################
# WRAPPER FUNCTIONS FOR AvianData.R
########################################################
#Must start with a test of buildQueryList
test.buildQueryList<-function(data.type="obs", more.filters=""){
	ad.obj<-new("PointCountData")
	DataDefn(ad.obj)<-CADC(ProtocolType="PointCount",dsn="")
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714)"
	o.flt="SpeciesCode IN ('NOPI','RUDU','BBPL')"
	FilterList(ad.obj)<-list(obsSQL=o.flt,eventSQL=e.flt)
	qqq<-buildQueryList(ad.obj, data.type=data.type, more.filters=more.filters)
	return(qqq)
}

# Follow with a test of getAvianData
test.getAvianData<-function(data.type, o.flt = "",e.flt = "", more.filters=NULL, taxon.groups="", spatial.groups=""){
	dt<-paste(data.type,"Data", sep="")
	ad.obj<-new(dt)
	DataDefn(ad.obj)<-CADC(data.type)
	FilterList(ad.obj)<-list(obsSQL=o.flt,
			eventSQL=e.flt)
	data.obj<-getAvianData(object=ad.obj, more.filters=more.filters, taxon.groups=taxon.groups, spatial.groups=spatial.groups)
	return(data.obj)
}
	
	
################################################################################
# WRAPPER FUNCTIONS FOR RavianResultsTable.R
########################################################
#This wrapper simply creates and populates an object of the class
test.RavianResultsTable<-function(){
	v1<-c("YBCH","BLRA","BAEA","SESA","BGSW","BANS")
	df<-as.data.frame(cbind(v1,"2010",c(4,5,6)))
	colnames(df)<-c("SpeciesCode","YearCollected","SomeMonth")
	rrt<-new("RavianResultsTable")
	ResultsTable(rrt)<-df
	Process(rrt)<-"Unit Test"
	TableTitle(rrt)<-"Some SpeciesCodes and by YearCollected and SomeMonth"
	Notes(rrt)<-"SomeMonth intentionally misspelled to test non-translation"
	ProcessParameters(rrt)<-list()
	return(rrt)
}
	

################################################################################
# WRAPPER FUNCTIONS FOR RavianSummaryTable.R
########################################################
#This wrapper simply creates and populates an object of the class
test.RavianSummaryTable<-function(more.filters,spatial.group,taxon.group){
	#get a populated object
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	taxon.groups<-toJSON(list("guild A"=c('NOPI','RUDU'),"guild B"=c('BBPL')))
	spatial.groups<-toJSON(list("Area A"=c(10708,10710,10711,10713,10714,10715,10716,10717),
					"Area B"=c(10989,10990,10991,10993,10994,10995,10996,10997)))
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters=more.filters, taxon.groups=taxon.groups, spatial.groups=spatial.groups)
	#melt-cast it
	id.vars<-c("TaxonGroup","SpatialGroup","ProjectCode","YearCollected","Transect","Point","Visit","SpeciesCode")
	melt.data <- melt(ObsData(tst.obj),id.vars,measure.vars="ObservationCount",variable_name="ObservationCount")
	cast.eq<-"TaxonGroup+SpatialGroup+ProjectCode+YearCollected+Transect+Point+Visit+SpeciesCode~ObservationCount"
	base.table <- data.frame(cast(melt.data,cast.eq,fun.aggregate="sum"))
	#calcCompress it to Point...
	by.list<-c("ProjectCode",spatial.group,"Point","YearCollected",taxon.group)
	comp.field<-"ObservationCount"
	calc.fun<-c("mean","var")
	data.table<-base.table
	support.site.fields<-c(spatial.group,"ProjectCode","ProjectName")
	effort.base<-unique(EffortData(tst.obj)[,c(spatial.group,"ProjectCode","ProjectName")])
	new.name<-"Abund"
	comp.dat<-calcCompress(by.list,comp.field,calc.fun,data.table,support.site.fields,effort.base,new.name)
	#calcCompress it to spatial.group
	by.list<-c("ProjectCode",spatial.group,"YearCollected",taxon.group)
	comp.field<-"meanAbund"
	calc.fun<-c("mean","var")
	data.table<-comp.dat
	new.name<-"Abund"
	comp.dat<-calcCompress(by.list,comp.field,calc.fun,data.table,support.site.fields,effort.base,new.name)
	names(comp.dat)[names(comp.dat)=="meanAbund"]<-"Abundance"
	names(comp.dat)[names(comp.dat)=="varAbund"]<-"Variance"
	rst<-new("RavianSummaryTable")
	ResultsTable(rst)<-comp.dat
	Process(rst)<-"Unit Test"
	TableTitle(rst)<-"PointCount data to test RavianSummaryTable methods"
	Notes(rst)<-paste("Compresseed to",spatial.group,"by",taxon.group)
	return(rst)
}


################################################################################
# WRAPPER FUNCTIONS FOR RavianSampleSummaryTable.R
########################################################
#This wrapper simply creates and populates an object of the class
test.RavianSampleSummaryTable<-function(more.filters){
	#get a populated object
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters=more.filters, taxon.groups="", spatial.groups="")
	#melt-cast it
	id.vars<-c("ProjectCode","YearCollected","Transect","Point","Visit","SpeciesCode")
	melt.data <- melt(ObsData(tst.obj),id.vars,measure.vars="ObservationCount",variable_name="ObservationCount")
	cast.eq<-"ProjectCode+YearCollected+Transect+Point+Visit+SpeciesCode~ObservationCount"
	base.table <- data.frame(cast(melt.data,cast.eq,fun.aggregate="sum"))
	#calcCompress it to Point...
	by.list<-c("ProjectCode","Transect","Point","YearCollected","SpeciesCode")
	comp.field<-"ObservationCount"
	calc.fun<-c("mean","var")
	data.table<-base.table
	support.site.fields<-c("ProjectCode","ProjectName","Transect")
	effort.base<-unique(EffortData(tst.obj)[,c("ProjectCode","ProjectName","StudyArea","LocalityID","Transect")])
	new.name<-"Abund"
	comp.dat<-calcCompress(by.list,comp.field,calc.fun,data.table,support.site.fields,effort.base,new.name)
	#calcCompress it to Transect...
	by.list<-c("ProjectCode","Transect","YearCollected","SpeciesCode")
	comp.field<-"meanAbund"
	calc.fun<-c("mean","var")
	data.table<-comp.dat
	new.name<-"Abund"
	comp.dat<-calcCompress(by.list,comp.field,calc.fun,data.table,support.site.fields,effort.base,new.name)
	names(comp.dat)[names(comp.dat)=="meanAbund"]<-"Abundance"
	names(comp.dat)[names(comp.dat)=="varAbund"]<-"Variance"
	rst<-new("RavianSampleSummaryTable")
	ResultsTable(rst)<-comp.dat
	Process(rst)<-"Unit Test"
	TableTitle(rst)<-"PointCount data to test RavianSummaryTable methods"
	support.data.fields<-c("ProjectCode","ProjectName","StudyArea","Transect")
	SupportData(rst)<-as.data.frame(effort.base[,c(support.data.fields)])
	Notes(rst)<-"Compresseed to Transect and Species"
	return(rst)
}

