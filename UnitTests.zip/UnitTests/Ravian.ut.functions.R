# TODO: Add comment
# 
# Author: lsalas
# Date created: Jan 26, 2010
###############################################################################
#it is assumed here that the caller function (be it the test suite maker or the test file function) will load the
#source file that contains the functions called below (i.e. /RavianVault/test/UnitTests/test.target.functions.R)

#############################################################
#test functions for RavianUtils.R
#############################################################
test.CADC.out<-function(){
	source("/home/lsalas/UnitTests/CADC.R") #doing this to test new dynamic access level feature
	dsn.tst<-c("Driver={MySQL ODBC 5.1 Driver};Server=data.prbo.org;Database=ravian_wh;User=ravian;Password=zakufeme;Port=3306;Option=2049")
	if (Sys.info()[1]=="Linux")dsn.tst<-c("DSN=DataWarehouses_Devel;Driver=/usr/lib64/libmyodbc3.so;Server=localhost;Database=ravian_wh;User=ravian;Password=zakufeme;Port=3306;Option=2049")
	#test if fetching the proper table...
	checkIdentical(TableName(getCADC.DSN.out(data.type="PointCount", data.level="2", dsn.val="RavianWarehouse-Data")),c("RavianPointCountLevel2_v1"))
	checkIdentical(TableName(getCADC.DSN.out(data.type="AreaSearch", data.level="b", dsn.val="RavianWarehouse-Data")),c("RavianAreaSearchBase_v1"))
	#test default data level
	checkIdentical(TableName(getCADC.DSN.out(data.type="Band", data.level="", dsn.val="RavianWarehouse-Data")),c("RavianBandingLevel0_v1"))
	#test if using dsn
	checkIdentical(DSN(getCADC.DSN.out(data.type="AreaSearch", data.level="", dsn.val="RavianWarehouse-Data")),c("RavianWarehouse-Data"))
	#test if building dsn - default if dsn not provided
	checkIdentical(DSN(getCADC.DSN.out(data.type="AreaSearch", data.level="", dsn.val="")),dsn.tst)
	#test default table - if ProtcolType not provided, data.level not provided
	checkIdentical(TableName(getCADC.DSN.out(data.type="", data.level="", dsn.val="RavianWarehouse-Data")),c("RavianPointCountLevel0_v1"))
	source("/home/lsalas/UnitTests/CADC.unit.R")
}

#############################################################
#test functions for RavianUtils.R
#############################################################
test.RavianUtils.makeDSN<-function(){
	dsn.tst<-c("Driver={MySQL ODBC 5.1 Driver};Server=data.prbo.org;Database=ravian_unit_wh;User=readme;Password=spoestoe;Port=3306;Option=2049")
	if (Sys.info()[1]=="Linux")dsn.tst<-c("RavianWarehouse-Data;Driver=/usr/lib64/libmyodbc3.so;Server=data.prbo.org;Database=ravian_unit_wh;User=readme;Password=spoestoe;Port=3306;Option=2049")
	checkIdentical(createDSN(DSN="RavianWarehouse-Data",driver="/usr/lib64/libmyodbc3.so",server="data.prbo.org",database="ravian_unit_wh",
					user="readme",password="spoestoe",port=3306,option=2049),dsn.tst)
	checkException(createDSN(DSN="",driver="/usr/lib64/libmyodbc3.so",server=NULL,database="ravian_unit_wh",
					user="readme",password="readme",port=3306,option=2049))
}

test.RavianUtils.defaultConn<-function(){
	checkTrue(test.connectDatabase(dsn="default"))	#Passing nothing and expecting connection - default behavior is to use dsn
}

test.RavianUtils.connUseDSN<-function(){
	checkTrue(test.connectDatabase(dsn="DataWarehouses_Devel"))
	checkException(test.connectDatabase(dsn="WrongDSN"))	
}

test.RavianUtils.connMakeDSN<-function(){
	dsn.tst<-c("Driver={MySQL ODBC 5.1 Driver};Server=data.prbo.org;Database=ravian_unit_wh;User=readme;Password=spoestoe;Port=3306;Option=2049")
	if (Sys.info()[1]=="Linux")dsn.tst<-c("DSN=RavianWarehouse-Data;Driver=/usr/lib64/libmyodbc3.so;Server=data.prbo.org;Database=ravian_unit_wh;User=ravian;Password=zakufeme;Port=3306;Option=2049")
	checkTrue(test.connectDatabase(dsn.tst))
	checkException(createDSN(DSN="",driver="/usr/lib64/libmyodbc3.so",server=NULL,database="ravian_unit_wh",
					user="readme",password="readme",port=3306,option=2049))
}

test.RavianUtils.closeConn<-function(){
	checkTrue(test.closeDatabase(dsn="DataWarehouses_Devel"))	
}

test.RavianUtils.compressData<-function(){
	query.obs<-"select * from pointCount_unit_wh"
	by.list<-c("ProjectCode","ProtocolCode","Transect","Point","SpeciesCode")
	field<-"ObservationCount"
	new.name<-"testComp"
	func<-c("NROW","sum")
	ddd<-test.compressData(query.obs=query.obs,by.list=by.list,field=field,new.name=new.name,func=func)
	#check that NROW and SUM are the same
	nrow.res<-ddd$SampleSize
	sum.res<-ddd$sumtestComp
	checkIdentical(nrow.res,sum.res)
	#check that the result matches what's expected
	##############
	#Verify this!!!
	##############
	exp.res<-c(27,38,1,4,24,2,15,24,12,40,8,24,23,9,1,30,4,5)
	if (Sys.info()[1]=="Linux")exp.res<-c(38,27,1,4,24,2,15,24,12,8,24,23,9,1,30,40,4,5)
	checkTrue(isTRUE(all.equal(sum.res,exp.res)))
}

test.RavianUtils.calcComp<-function(){
	query.obs<-"select * from pointCount_unit_wh"
	query.eff<-"select ProjectCode,ProtocolCode,Transect,Point,StudyArea,SamplingUnitId,SpeciesCode from pointCount_unit_wh"
	by.list<-c("ProjectCode","ProtocolCode","Transect","Point","SpeciesCode")
	comp.field<-"ObservationCount"
	new.name<-"testComp"
	calc.fun<-c("sum","var")
	support.site.fields<-c("ProjectCode","ProtocolCode","Transect","Point","StudyArea","SamplingUnitId")
	ddd<-test.calcCompress(query.obs=query.obs,query.eff=query.eff,by.list=by.list,comp.field=comp.field,new.name=new.name,
			calc.fun=calc.fun,support.site.fields=support.site.fields)
	sum.res<-ddd$sumtestComp
	exp.res<-c(27,38,1,4,24,2,15,24,12,40,8,24,23,9,1,30,4,5)
	if (Sys.info()[1]=="Linux")exp.res<-c(38,27,1,4,24,2,15,24,12,8,24,23,9,1,30,40,4,5)
	checkTrue(isTRUE(all.equal(sum.res,exp.res)))	#calcCompress returns what's expected
	checkTrue(grep("StudyArea",names(ddd))>0)		#calcCompress merged fields from effort table
	checkIdentical(18,as.numeric(nrow(ddd)))		#calcCompress did not add empty data rows - remember, merging as left join with all effort
	checkTrue(sum(is.na(ddd$vartestComp))==0)		#calcCompress replaced NAs with 0s - there should be a couple NA's otherwise
}

#############################################################
#test function for QueryList.R
#############################################################
test.QueryList.buildQuery<-function(){
	tql<-new("QueryList")
	Select(tql)<-"SpeciesCode,CommonName,sum(ObservationCount)"
	Distinct(tql)<-TRUE
	From(tql)<-"pointCount_unit_wh"
	Where(tql)<-"Transect = 'HAM::12533'"
	GroupBy(tql)<-"SpeciesCode,CommonName"
	Having(tql)<-""
	OrderBy(tql)<-"SpeciesCode DESC"
	q.str<-buildQuery(tql)
	exp.str<-c("SELECT DISTINCT SpeciesCode,CommonName,sum(ObservationCount) FROM pointCount_unit_wh WHERE Transect = 'HAM::12533' GROUP BY SpeciesCode,CommonName ORDER BY SpeciesCode DESC")
	checkIdentical(as.character(q.str),exp.str)
}

#############################################################
#test functions for DataStore.R
#############################################################
test.DataStore.getData<-function(){
	#testing first with observational data
	ggg<-test.getData(obs.eff="obs",select.v="SpeciesCode",where.v="Transect = 'HAM::12533'",dsn.v="UnitWarehouses_Devel")
	#test that a list is returned
	checkIdentical(names(ggg),c("result.data","query.sql"))
	#test that the returned query is as expected
	checkIdentical(ggg$query.sql,c("SELECT SpeciesCode FROM pointCount_unit_wh WHERE Transect = 'HAM::12533'"))
	#test that the data retrieved has the correct number of rows
	checkTrue(nrow(ggg$result.data)==147)
	#testing now the effort data
	ggg<-test.getData(obs.eff="eff",select.v="Point",where.v="Transect = 'HAM::12533'",dsn.v="UnitWarehouses_Devel")
	#test that the returned query is as expected 	
	checkIdentical(ggg$query.sql,c("SELECT DISTINCT Point FROM pointCount_unit_wh WHERE Transect = 'HAM::12533'"))
	#testing for correct number of rows
	checkTrue(nrow(ggg$result.data)==8)
	#testing retrieval with a built-on-the-fly dsn
	dsn.v<-c("Driver={MySQL ODBC 5.1 Driver};Server=data.prbo.org;Database=ravian_unit_wh;User=readme;Password=spoestoe;Port=3306;Option=2049")
	if (Sys.info()[1]=="Linux")dsn.v<-c("DSN=UnitWarehouses_Devel;Driver=/usr/lib64/libmyodbc3.so;Server=localhost;Database=ravian_unit_wh;User=ravian;Password=zakufeme;Port=3306;Option=2049")
	ggg<-test.getData(obs.eff="eff",select.v="Point",where.v="Transect = 'HAM::12533'",dsn.v=dsn.v)
	checkTrue(nrow(ggg$result.data)==8)
}


#############################################################
#test functions for AvianData.R
#############################################################
#test functions for buildQueryList 
test.AvianData.buildQueryList<-function(){
	www<-test.buildQueryList(data.type="obs", more.filters="")
	exp.q<-c("ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714) AND SpeciesCode IN ('NOPI','RUDU','BBPL')")
	exp.f<-c("ProjectCode, ProjectName, LocalityID, SamplingUnitId, StudyArea, Transect, TransectName, Point, Visit, YearCollected, MonthCollected, JulianDay, Time, Collector, ScientificName, CommonName, SpeciesCode, TaxonId, DistanceFromObserver, FlyOver, InFocalHabitat, ObservationCount, NoObservations")
	checkTrue(class(www)=="QueryList")	#returning the class ...
	checkIdentical(Where(www),exp.q)	#returning the correct filter for obsdata
	checkIdentical(Select(www),exp.f)	#returning the correct list of fields for obsdata
	www<-test.buildQueryList(data.type="eff", more.filters="")
	exp.q<-c("ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714)")
	exp.f<-c("ProjectCode, ProjectName, LocalityID, SamplingUnitId, StudyArea, Transect, TransectName, Point, Visit, ProtocolCode, YearCollected, MonthCollected, DayCollected, JulianDay, ProportionAreaSurveyed")
	checkIdentical(Where(www),exp.q)	#returning the correct filter for effdata
	checkIdentical(Select(www),exp.f)	#returning the correct list of fields for effdata
	www<-test.buildQueryList(data.type="obs", more.filters="MonthCollected IN (4,5,9)")
	exp.q<-c(exp.q<-c("ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714) AND SpeciesCode IN ('NOPI','RUDU','BBPL') AND MonthCollected IN (4,5,9)"))
	checkIdentical(Where(www),exp.q)	#includes the more.filters
}

# testing getAvianData
test.AvianData.getAvianData<-function(){
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	#testing data retrieval without obsSQL, groupings or more.filters
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups="", spatial.groups="")
	checkTrue(nrow(ObsData(tst.obj))==291)	#obs data
	checkTrue(nrow(EffortData(tst.obj))==38)	#effort data
	#testing data retrieval with obsSQL
	o.flt="SpeciesCode IN ('NOPI','RUDU','BBPL')"
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups="", spatial.groups="")
	checkTrue(nrow(ObsData(tst.obj))==291)	#obs data
	#testing taxon grouping - incremental...
	taxon.groups<-toJSON(list("group A"=c('NOPI'),"group B"=c('BBPL')))
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups=taxon.groups, spatial.groups="")
	checkTrue(grep("TaxonGroup",names(ObsData(tst.obj)))>0)	#the variable TaxonGroup was created with 
	checkTrue(grep("group A",unique(ObsData(tst.obj)$TaxonGroup))>0)	#the variable TaxonGroup has one of the assigned names
	checkTrue(grep("unassigned",unique(ObsData(tst.obj)$TaxonGroup))>0)	#the variable TaxonGroup has unassigned for codes not in grouping information
	checkTrue(grep("taxon.group",names(Metadata(tst.obj)))>0)	#the grouping info is in the Metadata
	#testing spatial grouping - incremental...
	spatial.groups<-toJSON(list("Area A"=c(10708,10710,10711,10713,10714,10715,10716,10717),
					"Area B"=c(10989,10990,10991,10993,10994,10995,10996,10997)))
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups=taxon.groups, spatial.groups=spatial.groups)
	checkTrue(grep("SpatialGroup",names(EffortData(tst.obj)))>0)	#the variable SpatialGroup was created with 
	checkTrue(grep("Area A",unique(EffortData(tst.obj)$SpatialGroup))>0)	#the variable SpatialGroup has one of the assigned names
	checkTrue(grepl("unassigned",paste(unique(EffortData(tst.obj)$SpatialGroup),collapse=""))==FALSE)	#the variable SpatialGroup has NO unassigned values
	checkTrue(grep("spatial.group",names(Metadata(tst.obj)))>0)	#the grouping info is in the Metadata
	#testing for more.filters - incremental, this would have all components...
	more.filters="MonthCollected IN (4,5,9)"	#this is usually for banding data, for queries that require data with effort (e.g., abundance)
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters=more.filters, taxon.groups=taxon.groups, spatial.groups=spatial.groups)
	checkTrue(sum(EffortData(tst.obj)$MonthCollected==1)==0)
	checkTrue(sum(EffortData(tst.obj)$MonthCollected==3)==0)
	checkTrue(sum(EffortData(tst.obj)$MonthCollected==5)==9)
}

#testing as.data.frame
test.AvianData.as.data.frame<-function(){
	#get a populated object
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups="", spatial.groups="")
	#now test...
	ddd<-as.data.frame(tst.obj)		#testing default - must return ObsData table
	checkTrue(class(ddd)=="data.frame")	#it's a data frame
	checkTrue(nrow(ddd)==291)	#correct number of obs
	checkException(grep("ProtocolCode",names(ddd))>0) 	#Has no event data field
	checkTrue(grep("ScientificName",names(ddd))>0)	#Has an obs data field
	ppp<-as.data.frame(tst.obj, source.table="ObsData")	#getting named ObsData
	checkIdentical(ddd,ppp)	#must be equal to previous
	ddd<-as.data.frame(tst.obj, source.table="EffortData")		#testing retrieval of effort data
	checkTrue(nrow(ddd)==38)	#correct number of obs
	checkTrue(grep("ProtocolCode",names(ddd))>0) 	#Has event data field
	checkException(grep("ScientificName",names(ddd))>0)	#Has no obs data field
	selected.fields<-c("ScientificName","CommonName","SpeciesCode")
	ddd<-as.data.frame(tst.obj,selected.fields=selected.fields)
	checkIdentical(names(ddd),selected.fields)
}

#testing listSpecies
test.AvianData.listSpecies<-function(){
	#get a populated object
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups="", spatial.groups="")
	#now test...
	ddd<-listSpecies(tst.obj)	#testing default - should retrieve common names
	checkTrue(NROW(ddd)==3)		#correct number of returns
	checkTrue(grep("Northern Pintail",ddd)>0)	#It is common names
	ddd<-listSpecies(tst.obj,display="SpeciesCode")
	qqq<-as.factor(c("NOPI", "RUDU", "BBPL"))
	checkEquals(ddd,qqq)	#got the right list - confirmed with simple query with above parameters
	#Note that we could force a known result via the o.flt argument above, or more.filters - same result
}


#############################################################
#test functions for RavianResultsTable.R
#############################################################
test.RavianResultsTable.as.data.frame<-function(){
	df<-as.data.frame(cbind(c("YBCH","BLRA","BAEA","SESA","BGSW","BANS"),"2010",c(4,5,6)))
	colnames(df)<-c("SpeciesCode","YearCollected","SomeMonth")
	www<-test.RavianResultsTable()
	tdf<-as.data.frame(www)
	checkTrue(class(tdf)=="data.frame")	#returns correct class
	checkIdentical(tdf,df)	#the same object is returned
}

test.RavianResultsTable.checkRowColumnNames<-function(){
	df<-as.data.frame(cbind(c("YBCH","BLRA","BAEA","SESA","BGSW","BANS"),"2010",c(4,5,6)))
	colnames(df)<-c("SpeciesCode","YearCollected","SomeMonth")
	www<-test.RavianResultsTable()
	qqq<-checkRowColumnNames(www)
	rdf<-as.data.frame(qqq)
	checkIdentical(names(rdf),c("Species Code", "Year","SomeMonth"))	#tests translation of first two, and not of last one
	#now adding a first column of names, to be changed by method and test for proper change
	fstc<-c("sum","NROW","max","min","mean","se")
	dffc<-cbind(fstc,df)
	colnames(dffc)<-c("SomeNames","SpeciesCode","YearCollected","SomeMonth")
	ResultsTable(www)<-dffc
	qqq<-checkRowColumnNames(www)
	rdf<-as.data.frame(qqq)
	checkIdentical(as.vector(rdf$SomeNames),c("TOTAL","Count","Maximum","Minimum","Mean","Standard Error"))	#tests translation of first column names
}


#############################################################
#test functions for RavianSummaryTable.R
#############################################################
test.RavianSummaryTable.plot<-function(){
	plot.file.loc<-"c:/Documents and Settings/lsalas/workspace/RavianVault/test/UnitTests/RData/Unit.test.graph1.RData"
	if (Sys.info()[1]=="Linux")plot.file.loc<-"/home/lsalas/UnitTests/RData/Unit.test.graph1.RData"
	load(plot.file.loc)
	#testing the point plot
	###########################
	res.obj<-test.RavianSummaryTable(more.filters="",spatial.group="Transect",taxon.group="SpeciesCode")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	ppl$g.var<-"SpeciesCode"
	ppl$g.label<-"Species"
	PlotParameters(res.obj)<-ppl
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph1)	#got a graph and it is identical to pre-inspected, encoded graph in RData file, testing partition by species
	#######################
	ppl$g.var<-c("Transect","SpeciesCode")
	ppl$g.label<-c("Transect","Species")
	PlotParameters(res.obj)<-ppl
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph2)	#got a graph with partition by species and by some spatial variable
	#################################
	res.obj<-test.RavianSummaryTable(more.filters="",spatial.group="SpatialGroup",taxon.group="SpeciesCode")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	ppl$g.var<-c("SpatialGroup","SpeciesCode")
	ppl$g.label<-c("Type_of_Place","Species")
	PlotParameters(res.obj)<-ppl
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph3)	#make the spatial grouping custom...
	##################################
	res.obj<-test.RavianSummaryTable(more.filters="",spatial.group="SpatialGroup",taxon.group="TaxonGroup")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	ppl$g.var<-c("SpatialGroup","TaxonGroup")
	ppl$g.label<-c("Type_of_Place","Guild")
	PlotParameters(res.obj)<-ppl
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph4)	#make the spatial grouping and the taxon grouping both custom...
	###################################
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=TRUE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph5) #Now testing the wrap
	##################################
	#testing with only one species selected
	res.obj<-test.RavianSummaryTable(more.filters="SpeciesCode IN ('NOPI')",spatial.group="Transect",taxon.group="SpeciesCode")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	ppl$g.var<-"Transect"
	ppl$g.label<-"Transect"
	PlotParameters(res.obj)<-ppl
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=TRUE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph6)
	#testing with only one transect selected
	res.obj<-test.RavianSummaryTable(more.filters="Transect IN ('HAM::12533')",spatial.group="Transect",taxon.group="SpeciesCode")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	ppl$g.var<-"SpeciesCode"
	ppl$g.label<-"Species"
	PlotParameters(res.obj)<-ppl
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph7)
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=TRUE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph8)
	qqq<-plot(x=res.obj,plot.type="bar",facet.wrap=TRUE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph9)
	qqq<-plot(x=res.obj,plot.type="histogram",facet.wrap=TRUE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph10)
	#testing with only one transect and one species selected
	res.obj<-test.RavianSummaryTable(more.filters="Transect IN ('HAM::12533') AND SpeciesCode IN ('NOPI')",spatial.group="Transect",taxon.group="SpeciesCode")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	PlotParameters(res.obj)<-ppl
	qqq<-plot(x=res.obj,plot.type="point",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph11)
	qqq<-plot(x=res.obj,plot.type="bar",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph12)
	qqq<-plot(x=res.obj,plot.type="histogram",facet.wrap=FALSE)
	ttt<-base64Encode(ResultsGraph(qqq),"character")
	checkIdentical(ttt,test.graph13)
	
	#put here code to test geom density - of Abundance
	#res.obj<-test.RavianSummaryTable(more.filters="",spatial.group="Transect",taxon.group="SpeciesCode")
		
}

test.RavianSummaryTable.checkPlotLabels<-function(){
	res.obj<-test.RavianSummaryTable(more.filters="",spatial.group="Transect",taxon.group="SpeciesCode")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"YearCollected"
	ppl$y.var<-"MonthCollected"
	ppl$y.label<-"MonthCollected"
	ppl$g.var<-"SpeciesCode"
	ppl$g.label<-"SpeciesCode"
	PlotParameters(res.obj)<-ppl
	qqq<-checkPlotLabels(res.obj)
	checkTrue(PlotParameters(qqq)$x.label=="Year")
	checkTrue(PlotParameters(qqq)$y.label=="Month")
	checkException(PlotParameters(qqq)$g.label=="Species") #Not altering the group label, not yet anyhow...
}

#############################################################
#test functions for RavianSampleSummaryTable.R
#############################################################
test.RavianSampleSummaryTable.as.data.frame<-function(){
	res.obj<-test.RavianSampleSummaryTable(more.filters="")
	rdf<-as.data.frame(res.obj)
	checkTrue(grep("StudyArea",names(rdf))>0)	#merged the Results and Support tables, otherwise StudyArea would not be there
	checkTrue(nrow(ResultsTable(res.obj))==nrow(rdf))	#no inflation of data, so merged correctly
}

test.RavianSampleSummaryTable.trend<-function(){
	res.obj<-test.RavianSampleSummaryTable(more.filters="")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	PlotParameters(res.obj)<-ppl
	tro <- trend(res.obj)
	checkTrue(class(tro)=="RavianResultsTable")
	#to confirm proper calculation of trend, compare Year intercept with manual calc - values here were calculated 
	#independently in Excel using the AnalysisToolPack
	#Results were confirmed but there was a rounding difference at the fifth decimal place for intercept, so using R results to check
	exp.res<-c(3128.121679,-1.559481)
	obs.res<-as.vector(ResultsTable(tro)[["Coefficient Value"]])
	checkEqualsNumeric(obs.res,exp.res)
	#repeat the above but using one year to test the check of XVarTrend
	res.obj<-test.RavianSampleSummaryTable(more.filters="YearCollected IN (2001)")
	ppl<-list()
	ppl$x.var<-"YearCollected"
	ppl$x.label<-"Year"
	ppl$y.var<-"Abundance"
	ppl$y.label<-"Abundance"
	PlotParameters(res.obj)<-ppl
	tro <- trend(res.obj)
	checkException(class(tro)=="RavianResultsTable")
	err.msg<-c("Ravian Message: Dataset contains only one value for the x-axis variable Year. Trend analysis cannot be performed.")
	checkIdentical(tro[1],err.msg)
}

#############################################################
#test function for crossTabulate.R
#############################################################
test.crossTabulate.crossTabulate<-function(){
	#get a populated object
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups="", spatial.groups="")
	tv<-c("MonthCollected","YearCollected","ObservationCount","sum")
	ct.obj<-crossTabulate(tst.obj,tv)
	checkTrue(class(ct.obj)=="RavianSummaryTable")
	mmm<-as.vector(ResultsTable(ct.obj)$MonthCollected)
	y1<-as.numeric(as.vector(ResultsTable(ct.obj)[["2001"]]))
	y2<-as.numeric(as.vector(ResultsTable(ct.obj)[["2002"]]))
	y3<-as.numeric(as.vector(ResultsTable(ct.obj)[["2003"]]))
	checkIdentical(mmm,c("1","3","4","5","9","10"))
	checkIdentical(TableTitle(ct.obj),c("Total ObservationCount by MonthCollected and YearCollected"))	#check makeTitle
	checkIdentical(Notes(ct.obj),c("Total records =  291"))	#check countRecordsNulls
	#The following values were confirmed through queries using the below sql (and changing month and year values accordingly)
	#SELECT sum(ObservationCount) FROM `pointCount_unit_wh` WHERE ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND 
	#SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)
	#AND MonthCollected = 10 and YearCollected = 2003
	#Group By MonthCollected, YearCollected
	checkEqualsNumeric(y1,c(54,11,3,0,4,0))
	checkEqualsNumeric(y2,c(0,0,112,19,6,0))
	checkEqualsNumeric(y3,c(0,0,68,13,0,1))
	###Checking special cases.......
	#cannot yet check banding data, so NO CHECKS yet for special cases tv3="NetHours", or "SexRatio" or "AgeRatio"
	tv<-c("MonthCollected","YearCollected","Visit","NROW")		#special case tv3="Visit"
	ct.obj<-crossTabulate(tst.obj,tv)
	y1<-as.numeric(as.vector(ResultsTable(ct.obj)[["2001"]]))
	y2<-as.numeric(as.vector(ResultsTable(ct.obj)[["2002"]]))
	y3<-as.numeric(as.vector(ResultsTable(ct.obj)[["2003"]]))
	checkEqualsNumeric(y1,c(1,1,2,0,1,0))
	checkEqualsNumeric(y2,c(0,0,2,2,1,0))
	checkEqualsNumeric(y3,c(0,0,2,1,0,1))
	#the above results can be verified with the following sql (changing month and year values accodingly)
	#Select count(*) from (SELECT distinct t1.Visit, t1.MonthCollected,t1.YearCollected FROM `pointCount_unit_wh` AS t1 WHERE 
	#t1.ProjectCode = 'TIMA' AND t1.ProtocolCode = 'VCP10_TM' AND 
	#t1.SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)) as t2
	#where t2.MonthCollected = 4 and t2.YearCollected = 2003
	tv<-c("MonthCollected","YearCollected","SpeciesCode","NROW")		#special case tv3="SpeciesCode"
	ct.obj<-crossTabulate(tst.obj,tv)
	y1<-as.numeric(as.vector(ResultsTable(ct.obj)[["2001"]]))
	y2<-as.numeric(as.vector(ResultsTable(ct.obj)[["2002"]]))
	y3<-as.numeric(as.vector(ResultsTable(ct.obj)[["2003"]]))
	checkEqualsNumeric(y1,c(1,2,2,0,1,0))
	checkEqualsNumeric(y2,c(0,0,2,2,1,0))
	checkEqualsNumeric(y3,c(0,0,3,1,0,1))
	tv<-c("MonthCollected","YearCollected","CommonName","NROW")		#special case tv3="SpeciesCode"
	ct.obj<-crossTabulate(tst.obj,tv)
	y1<-as.numeric(as.vector(ResultsTable(ct.obj)[["2001"]]))
	y2<-as.numeric(as.vector(ResultsTable(ct.obj)[["2002"]]))
	y3<-as.numeric(as.vector(ResultsTable(ct.obj)[["2003"]]))
	checkEqualsNumeric(y1,c(1,2,2,0,1,0))
	checkEqualsNumeric(y2,c(0,0,2,2,1,0))
	checkEqualsNumeric(y3,c(0,0,3,1,0,1))
	tv<-c("MonthCollected","YearCollected","ScientificName","NROW")		#special case tv3="SpeciesCode"
	ct.obj<-crossTabulate(tst.obj,tv)
	y1<-as.numeric(as.vector(ResultsTable(ct.obj)[["2001"]]))
	y2<-as.numeric(as.vector(ResultsTable(ct.obj)[["2002"]]))
	y3<-as.numeric(as.vector(ResultsTable(ct.obj)[["2003"]]))
	checkEqualsNumeric(y1,c(1,2,2,0,1,0))
	checkEqualsNumeric(y2,c(0,0,2,2,1,0))
	checkEqualsNumeric(y3,c(0,0,3,1,0,1))
	#the sql above (for Visit checks) can be used, just replacing Visit with SpeciesCode or ScientificName
}

#############################################################
#test function for describeVariable.R
#############################################################
test.describeVariable.describeVariable<-function(){
	#get a populated object
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups="", spatial.groups="")
	#now test...
	ggg<-describeVariable(object=tst.obj, var="SpeciesCode", type="d")
	checkTrue(class(ggg)=="RavianSummaryTable")	#got the right kind of object
	checkIdentical(as.vector(ResultsTable(ggg)[2,1]),c("Shannon (H')"))	#proper contents
	checkEqualsNumeric(as.vector(ResultsTable(ggg)[3,2]),c(2.668))	#proper calculation discrete variable
	ccc<-describeVariable(object=tst.obj, var="DistanceFromObserver", type="c")
	checkEqualsNumeric(as.numeric(as.vector(ResultsTable(ccc)[4,2])),c(245.3))	#proprer calculation continuous variable
}

#############################################################
#test function for PointCountData.R
#############################################################
test.PointCountData.estimateAbundance<-function(){
	#get a populated object
	o.flt=""
	e.flt="ProjectCode = 'TIMA' AND ProtocolCode = 'VCP10_TM' AND SamplingUnitId IN (10708,10710,10711,10713,10714,10715,10716,10717,10989,10990,10991,10993,10994,10995,10996,10997)"
	tst.obj<-test.getAvianData(data.type="PointCount", o.flt=o.flt,e.flt=e.flt, more.filters="", taxon.groups="", spatial.groups="")
	ab.obj<-estimateAbundance(tst.obj) 	#testing default
	checkTrue(class(ab.obj)=="RavianSampleSummaryTable")
	#given the filters above, the results must have 3 species, 3 years and 2 sites, so 18 rows
	checkTrue(nrow(ResultsTable(ab.obj))==18)
	exp.names=c("ProjectCode","Transect","YearCollected","Abundance","Variance","StandardError","SampleSize","ScientificName")
	checkIdentical(names(ResultsTable(ab.obj)),exp.names)
	#now checking the 3 numeric columns
	#All these results were confirmed via Excel, sheet in vault (testAb.xls)
	obs.ab<-as.vector(ResultsTable(ab.obj)[,4])
	exp.ab<-c(11.4166667,0.9166667,0,0.6,2.2,0,0.3,7.8,0,0,0,3,0,0,14.0625,0.125,0,4.625)
	checkEquals(obs.ab,exp.ab)
	obs.vr<-as.vector(ResultsTable(ab.obj)[,5])
	exp.vr<-c(316.472222,3.361111,0,0.8,5.2,0,0.2,65.325,0,0,0,2,0,0,198.602679,0.0625,0,7.229167)
	checkEquals(obs.vr,exp.vr)
	obs.se<-as.vector(ResultsTable(ab.obj)[,6])
	exp.se<-c(8.8948331,0.9166667,0,0.4,1.0198039,0,0.2,3.6145539,0,0,0,1,0,0,4.9825029,0.1250000,0,1.3443555)
	checkEquals(obs.se,exp.se)
	###########################
	#test with su=transect - given the data selected, results should be identical to above!
	ab.obj<-estimateAbundance(tst.obj,sampling.unit="Transect")
	obs.ab<-as.vector(ResultsTable(ab.obj)[,4])
	checkEquals(obs.ab,exp.ab)
	obs.vr<-as.vector(ResultsTable(ab.obj)[,5])
	checkEquals(obs.vr,exp.vr)
	obs.se<-as.vector(ResultsTable(ab.obj)[,6])
	checkEquals(obs.se,exp.se)
	###########################
	#test with su=transect and sb=StudyArea
	ab.obj<-estimateAbundance(tst.obj,sampling.unit="Transect",summarize.by="StudyArea")
	obs.ab<-as.vector(ResultsTable(ab.obj)[,4])
	checkEquals(obs.ab,exp.ab)
	obs.vr<-sum(ResultsTable(ab.obj)[,5])
	checkTrue(obs.vr==0)
	obs.se<-sum(ResultsTable(ab.obj)[,6])
	checkTrue(obs.se==0)
}
