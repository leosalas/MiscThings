# TODO: Add comment
# 
# Author: lsalas
# Date created: Jan 26, 2010
###############################################################################


library(Ravian)
library(RUnit)
library(RCurl)
parent.dir<-"/home/lsalas"
#source(paste(parent.dir,"/UnitTests/CADC.R",sep="")) #loading the UT CADC first!
source(paste(parent.dir,"/UnitTests/CADC.unit.R",sep=""))
source(paste(parent.dir,"/UnitTests/Ravian.UT.wrappers.R",sep=""))


# Below are the suites of tests for each of the R files in Ravian
# Tested in collating order (see Description file for collating order)

#####################################
# Suite for CADC.R
testsuite.CADC<-defineTestSuite("CADC.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.CADC", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.CADC)
printTextProtocol(testResult)

######################################
# Suite for RavianUtils.R
testsuite.RavianUtils<-defineTestSuite("RavianUtils.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.RavianUtils", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.RavianUtils)
printTextProtocol(testResult)

######################################
# Suite for QueryList.R
testsuite.QueryList<-defineTestSuite("QueryList.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.QueryList", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.QueryList)
printTextProtocol(testResult)

######################################
# Suite for DataStore.R
testsuite.DataStore<-defineTestSuite("DataStore.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.DataStore", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.DataStore)
printTextProtocol(testResult)

######################################
# Suite for AvianData.R
testsuite.AvianData<-defineTestSuite("AvianData.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.AvianData", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.AvianData)
printTextProtocol(testResult)

######################################
# Suite for RavianResultsTable.R
testsuite.RavianResultsTable<-defineTestSuite("RavianResultsTable.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.RavianResultsTable", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.RavianResultsTable)
printTextProtocol(testResult)

######################################
# Suite for RavianSummaryTable.R
testsuite.RavianSummaryTable<-defineTestSuite("RavianSummaryTable.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.RavianSummaryTable", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.RavianSummaryTable)
printTextProtocol(testResult)

######################################
# Suite for RavianSampleSummaryTable.R
testsuite.RavianSampleSummaryTable<-defineTestSuite("RavianSampleSummaryTable.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.RavianSampleSummaryTable", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.RavianSampleSummaryTable)
printTextProtocol(testResult)

######################################
# Suite for crossTabulate.R
testsuite.crossTabulate<-defineTestSuite("crossTabulate.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.crossTabulate", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.crossTabulate)
printTextProtocol(testResult)

######################################
# Suite for describeVariable.R
testsuite.describeVariable<-defineTestSuite("describeVariable.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.describeVariable", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.describeVariable)
printTextProtocol(testResult)

######################################
# Suite for PointCountData.R
testsuite.PointCountData<-defineTestSuite("PointCountData.unit.test",
		dirs = file.path(parent.dir,"/UnitTests"),
		testFileRegexp = "Ravian.ut.functions.R",
		testFuncRegexp = "test.PointCountData", 
		rngKind = "Marsaglia-Multicarry",
		rngNormalKind = "Kinderman-Ramage")

testResult <- runTestSuite(testsuite.PointCountData)
printTextProtocol(testResult)



