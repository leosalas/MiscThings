# TODO: Add comment
# 
# Author: lsalas
###############################################################################

# Function to generate all outputs for BirdObservations report
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project or unit. Valid values: project, unit
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by sampling event date. Valid values: year, date
# @param taxonGroup Integer (0/1) indicating to Ravian to treat the guild definition as a single taxon instead of as a collection of taxa
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one species/guild per column, reporting only total counts
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
BirdObservations<-function(dataObj, spatialGroup="project", temporalGroup="year",taxonGroup=0,pivot=0,...){
	
	#merge the data
	dataObj<-mergeRavianData(dataObj,by="long")
	data<-MergedData(dataObj)
	#data$StudyArea<-data$ProjectName	#This is an IWMM standard
	reslst<-list()
	
	#first a summary table
	tsum<-try(getOverallSummary(data),silent=TRUE)
	if(inherits(tsum,"try-error")){
		#return the error
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error generating the overall Summaries table"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Summary of Visits to Units by Month and Year"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-tsum
		reslst<-c(reslst,tblObj)
	}
	
	
	aggfml<-"ObservationCount~"
	ttlfml<-"ObservationCount~"
	durfml<-"SurveyDurationMinutes~"
	arefml<-"PlotAreaSqMeters~"
	dfnams<-character()
	#determine if reporting by project or unit: spatialGroup
	if(spatialGroup=="unit"){
		aggfml<-paste(aggfml,"PlotName",sep="")
		ttlfml<-paste(ttlfml,"PlotName",sep="")
		durfml<-paste(durfml,"PlotName",sep="")
		arefml<-paste(arefml,"PlotName",sep="")
		dfnams<-c(dfnams,"Unit")
		agg.space<-"Unit"
	}else{	#defaults to project
		aggfml<-paste(aggfml,"StudyArea",sep="")
		ttlfml<-paste(ttlfml,"StudyArea",sep="")
		durfml<-paste(durfml,"StudyArea",sep="")
		arefml<-paste(arefml,"StudyArea",sep="")
		dfnams<-c(dfnams,"Project")
		agg.space<-"Project"
	}
	
	#determine if reporting by year or date: temporalGroup
	if(temporalGroup=="date"){
		aggfml<-paste(aggfml,"ObservationDate",sep="+")
		ttlfml<-paste(ttlfml,"ObservationDate",sep="+")
		durfml<-paste(durfml,"ObservationDate",sep="+")
		dfnams<-c(dfnams,"Date")
		agg.time<-"Date"
	}else{	#defaults to year
		aggfml<-paste(aggfml,"YearCollected",sep="+")
		ttlfml<-paste(ttlfml,"YearCollected",sep="+")
		durfml<-paste(durfml,"YearCollected",sep="+")
		dfnams<-c(dfnams,"Year")
		agg.time<-"Year"
	}
	
	#determine if reporting by species or guild
	if(taxonGroup==1){
		aggfml<-paste(aggfml,"Guild",sep="+")
		dfnams<-c(dfnams,"Guild")
		agg.taxon<-"Guild"
	}else{	#default: reporting by species
		aggfml<-paste(aggfml,"CommonName",sep="+")
		dfnams<-c(dfnams,"Species")
		agg.taxon<-"Species"
	}
	
	resdf<-try(getSummaries(df=data,aggfml=aggfml,ttlfml=ttlfml,durfml=durfml,arefml=arefml,dfnams=dfnams),silent=TRUE)
	if(!inherits(resdf,"try-error")){
		#Here - determine if pivoting, and do so if...
		if(pivot==1){
			resdf<-try(makePivot(df=resdf,agg.space=agg.space,agg.taxon=agg.taxon,agg.time=agg.time),silent=TRUE)
			#evaluate again if there is an error
			if(!inherits(resdf,"try-error")){ #pivot and no errors
				#Returning a RavianResultTable object
				tblObj<-new("RavianResultTable")
				ResultTitle(tblObj)<-"Summary of Bird Observations"
				ResultType(tblObj)<-"Table"
				ResultTable(tblObj)<-resdf
				reslst<-c(reslst,tblObj)
			}else{ #error pivoting
				#return the error
				eo<-new("RavianResultError")
				ResultTitle(eo)<-"Error pivoting Bird Observations Summaries"
				ResultType(eo)<-"Error"
				ErrorDescription(eo)<-paste(resdf,collapse=", ")
				SinkObjects(eo)<-list(object=dataObj,spatialGroup=spatialGroup,temporalGroup=temporalGroup,taxonGroup=taxonGroup,pivot=pivot,df=data,aggfml=aggfml,ttlfml=ttlfml,durfml=durfml,arefml=arefml,dfnams=dfnams)
				ErrorDate(eo)<-as.character(Sys.time())
				reslst<-c(reslst,eo)
			}
		}else{ #no pivot and no error
			#Returning a RavianResultTable object
			tblObj<-new("RavianResultTable")
			ResultTitle(tblObj)<-"Summary of Bird Observations"
			ResultType(tblObj)<-"Table"
			ResultTable(tblObj)<-resdf
			reslst<-c(reslst,tblObj)
		}
	}else{
		#error getting the summaries
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error completing requested Bird Observations Summaries"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(resdf,collapse=", ")
		SinkObjects(eo)<-list(object=dataObj,spatialGroup=spatialGroup,temporalGroup=temporalGroup,taxonGroup=taxonGroup,pivot=pivot,df=data,aggfml=aggfml,ttlfml=ttlfml,durfml=durfml,arefml=arefml,dfnams=dfnams)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}
	
	return(reslst)
}

# Function to generate the overall summaries table for BirdObservations report
# 
# @param data A data frame, with effort and observation data merged "long"
getOverallSummary<-function(data){
	tsa<-data[,c("ProjectName","PlotName","YearCollected","MonthCollected","DayCollected","SpeciesCode","ObservationCount")]
	tsv<-aggregate(as.formula("DayCollected~ProjectName+PlotName+YearCollected+MonthCollected"),
			data=unique(tsa[,c("ProjectName","PlotName","YearCollected","MonthCollected","DayCollected")]),FUN=NROW)
	names(tsv)<-c("Project","Unit","Year","Month","NumVisits")
	
	tsd<-aggregate(as.formula("ObservationCount~ProjectName+PlotName+YearCollected+MonthCollected"),data=tsa,FUN=sum)
	names(tsd)<-c("Project","Unit","Year","Month","TotalBirdCount")
	
	tst<-aggregate(as.formula("SpeciesCode~ProjectName+PlotName+YearCollected+MonthCollected"),
			data=unique(tsa[,c("ProjectName","PlotName","YearCollected","MonthCollected","SpeciesCode")]),FUN=NROW)
	names(tst)<-c("Project","Unit","Year","Month","TotalTaxa")
	
	tsss<-aggregate(as.formula("ObservationCount~ProjectName+PlotName+YearCollected+MonthCollected+SpeciesCode"),
			data=tsa[,c("ProjectName","PlotName","YearCollected","MonthCollected","SpeciesCode","ObservationCount")],FUN=sum)
	names(tsss)<-c("Project","Unit","Year","Month","Species","Count")
	tsss<-merge(tsss,tsd,all.x=TRUE)
	tsss$pBA<-tsss$Count/tsss$TotalBirdCount
	tss<-aggregate(as.formula("pBA~Project+Unit+Year+Month"),data=tsss,FUN=function(x){round(exp(-1*sum(x*log(x))),2)})
	names(tss)<-c("Project","Unit","Year","Month","DiversityInd")
	
	tsum<-merge(tsv,tsd,all.x=TRUE)
	tsum<-merge(tsum,tst,all.x=TRUE)
	tsum<-merge(tsum,tss,all.x=TRUE)
	tsum$TotalTaxa<-ifelse(is.na(tsum$TotalTaxa),0,tsum$TotalTaxa)
	tsum$DiversityInd<-ifelse(is.na(tsum$DiversityInd),0,tsum$DiversityInd)
	
	return(tsum)
}

# Function to generate the summaries table for BirdObservations report
# 
# @param df A data frame, with effort and observation data merged "long"
# @param aggfml A string with the general aggregation formula for counts, max (i.e., the spatial, temporal, and taxon dimensions)
# @param ttlfml A string with the aggregation formula for totals (i.e., the spatial and temporal dimensions, not taxon)
# @param durfml A string with the aggregation formula for total time surveyed (i.e., the spatial and temporal dimensions, not taxon)
# @param arefml A string with the aggregation formula for total area surveyed (i.e., the spatial dimension only)
# @param dfnams A character vector with the final naming of the columns that result from the aggregation of counts
# @author Leo Salas \email{lsalas@@prbo.org}
getSummaries<-function(df,aggfml,ttlfml,durfml,arefml,dfnams){
	counts<-aggregate(as.formula(aggfml),data=df,FUN=sum,na.rm=TRUE)	#this is totalCount
	names(counts)<-c(dfnams,"Count")
	
	totals<-aggregate(as.formula(ttlfml),data=df,FUN=sum,na.rm=TRUE)
	namsttl<-dfnams[which(!dfnams %in% c("Guild","Species"))]
	names(totals)<-c(namsttl,"Total")
	
	counts<-merge(counts,totals,all.x=TRUE)
	counts$RelFrequency<-round(counts$Count/counts$Total,digits=4)						#this is frequency
	
	avg.count<-aggregate(as.formula(aggfml),data=df,FUN=mean,na.rm=TRUE) #this is average count
	names(avg.count)<-c(dfnams,"avgCount")
	avg.count$avgCount<-round(avg.count$avgCount,digits=3)
	countavg<-merge(counts,avg.count,by=dfnams,all.x=TRUE)
	
	max.count<-aggregate(as.formula(aggfml),data=df,FUN=max,na.rm=TRUE) #this is max count
	names(max.count)<-c(dfnams,"maxCount")
	countavgmax<-merge(countavg,max.count,by=dfnams,all.x=TRUE)
	
	df$SurveyDurationMinutes<-ifelse(is.na(df$SurveyDurationMinutes),0,df$SurveyDurationMinutes)
	total.survey.mins<-aggregate(as.formula(durfml),data=df,FUN=sum)
	names(total.survey.mins)<-c(namsttl,"SurveyDurationMinutes")
	total.survey.mins$SurveyDurationMinutes<-round(total.survey.mins$SurveyDurationMinutes*60)
	countavgmaxtime<-merge(countavgmax,total.survey.mins,all.x=TRUE)
	countavgmaxtime$SurveyDurationHours<-round(countavgmaxtime$SurveyDurationMinutes/60,digits=4)
	countavgmaxtime$BirdsPerHour<-round(countavgmaxtime$Count/countavgmaxtime$SurveyDurationHours,digits=0)	#this is birds per hour
	
	df$PlotAreaSqMeters<-ifelse(is.na(df$PlotAreaSqMeters),1200,df$PlotAreaSqMeters)
	total.survey.area<-aggregate(as.formula(arefml),data=df,FUN=sum,na.rm=TRUE)
	namsare<-namsttl[which(!namsttl %in% c("Year","Date"))]
	names(total.survey.area)<-c(namsare,"PlotAreaSqMeters")
	countavgmaxta<-merge(countavgmaxtime,total.survey.area,by=namsare,all.x=TRUE)
	countavgmaxta$SurveyAreaHectares<-round(countavgmaxta$PlotAreaSqMeters/10000,digits=2)
	countavgmaxta$BirdsPerHectare<-ifelse(countavgmaxta$SurveyAreaHectares==0,NA,round(countavgmaxta$Count/countavgmaxta$SurveyAreaHectares,digits=2))	#this is avgAbundance
	resnams<-c(names(countavgmax)[which(names(countavgmax)!="Total")],"BirdsPerHour","BirdsPerHectare")
	countavgmaxta<-countavgmaxta[,resnams]
	countavgmaxta<-countavgmaxta[order(countavgmaxta[,resnams[1]],countavgmaxta[,resnams[2]],countavgmaxta[,resnams[3]]),]
	return(countavgmaxta)
	
}

# Function to generate a pivot table for BirdObservations report. Pivots are only possible for Year groupings of reports
# 
# @param df A data frame with the result of the BirdObservations report, unpivoted
# @param agg.space The name of the spatial dimension in the report: Unit or Project
# @param agg.taxon The name of the taxon dimension in the report: Species or Guild
# @param agg.time The time unit in the report: Year or Date
makePivot<-function(df,agg.space,agg.taxon,agg.time){
	prep.df<-df[,c(agg.time,agg.space,agg.taxon,"Count")]
	prep.df$spacetime<-paste(prep.df[,agg.space],prep.df[,agg.time],sep=":")
	pvt.df<-unique(data.frame(prep.df[,agg.taxon]));names(pvt.df)<-agg.taxon
	for(st in (unique(prep.df$spacetime))){
		pdf<-subset(prep.df,spacetime==st)
		tpvt<-reshape(pdf[c(agg.taxon,"spacetime","Count")],v.names="Count",idvar=c(agg.taxon),timevar="spacetime",direction="wide")
		names(tpvt)<-c(agg.taxon,st)
		pvt.df<-merge(pvt.df,tpvt,by=agg.taxon,all.x=TRUE)
		pvt.df[,st]<-ifelse(is.na(pvt.df[,st])==TRUE,0,pvt.df[,st])
	}
	
	return(pvt.df)
}

