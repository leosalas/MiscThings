# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate the Bird-use-days estimate: the total number of birds of a taxon/guild observed in a defined period of time
# 
# Function to generate the Bird-use-days estimate: the total number of birds of a taxon/guild observed in a defined period of time
# 
# @param dataObj An RavianData object
# @param spatialGroup String providing the level of spatial grouping: unit or project - defaults to unit
# @param taxonGroup Boolean: should the results be grouped by guild? Only feasible if there is a Guild variable in the observational data. Default 0
# @author Leo Salas \email{lsalas@@prbo.org}
BirdUseDays<-function(dataObj, spatialGroup="unit", taxonGroup=0,...){
	#One table/graph per unit and season, up to 6 taxa per table/graph
	#if submitting more than one unit or project, must serialize these
	#Dates: always treated as seasonal, so several years mean serializing seasons
	#reports are for unit or project, so need the spatialGroup selector
	#reports may be for guild, so need the taxonGroup selector
	
	#This now reports the table and the graph
	#See Jim Lyons e-mail for final resolution on CIs
		
	library(splines)
	res.lst<-list()	#a list of resulting tables
	eff<-EffortData(dataObj)
	if(TRUE %in% grepl("Season",names(eff))){
		eff<-subset(eff,!is.na(eff$PlotAreaSqMeters) & eff$PlotAreaSqMeters>0)
		if(nrow(eff)==0){
			eo<-new("RavianResultWarning")
			ResultTitle(eo)<-"Warning - the unit(s) selected lack information about size."
			ResultType(eo)<-"Warning"
			WarningDescription(eo)<-"The unit(s) selected lack information about size. This information is needed in order to estimate Bird Use Days adjusted for area size."
			res.lst<-c(res.lst,eo)
		}else{
			#eff$PlotAreaSqMeters<-ifelse(is.null(eff$PlotAreaSqMeters)||is.na(eff$PlotAreaSqMeters)||eff$PlotAreaSqMeters==0,1200,eff$PlotAreaSqMeters)
			eff$PlotAreaHa<-eff$PlotAreaSqMeters/10000
			eff<-unique(eff[,c("ProjectName","ProtocolCode","StudyArea","PlotName","PlotAreaHa","SamplingUnitId","YearCollected","MonthCollected","DayCollected","ObservationDate","Season")])
			
			#if a guild aggregation is requested, we need to aggregate the data for these... else aggregate at the species level THEN check for max 6 of these.
			#if data at the project level are requested, we must aggregate the data for these... else aggregate at the unit level
			#If data from more than one project/unit are selected, or more than one season, serialize
			obs<-ObsData(dataObj)
			taxon.name<-"Species"; t.name<-"CommonName"
			if(taxonGroup==1 && TRUE %in% grepl("Guild",names(obs))){
				taxon.name<-"Guild"
				t.name<-"Guild"
			}
			
			if(spatialGroup=="project"){
				spatial.name<-"Project";s.name<-"ProjectName"
			}else{
				spatial.name<-"Unit";s.name<-"PlotName"
			}
			obs<-obs[,c(s.name,"ProtocolCode","SamplingUnitId","YearCollected","MonthCollected","DayCollected","ObservationDate",t.name,"ObservationCount")]
			
			#cycle through seasons, spatial groups, and taxa and calculate bud's, append to res.table
			uyn<-unique(eff$Season)
			
			for(yy in uyn){	#subset by season
				effy<-subset(eff,Season==yy)
				usn<-as.character(na.omit(unique(effy[,s.name])))
				for(ss in usn){	#subset by spatial group
					effys<-subset(effy,effy[,s.name]==ss)
					#now check that we have enough dates in the season - if we do, then calculate table
					#need a table per season and spatial group
					resTableArea<-data.frame()
					resTableObs<-data.frame()
					plotdata<-data.frame()
					if(NROW(unique(effys$ObservationDate))>4){
						obsys<-subset(obs,obs[,s.name]==ss & ObservationDate %in% unique(effys$ObservationDate))
						utn<-as.character(na.omit(unique(obsys[,t.name])))
						for(tt in utn){
							#merge the effort table with observations... (left join)
							#first add up all counts at each unit and date (but note that the name of the unit will be in the table only if s.name is Unit)
							obsyst<-subset(obsys,obsys[,t.name]==tt)
							fml<-paste("ObservationCount ~ ",s.name,"+ ProtocolCode + SamplingUnitId + YearCollected + MonthCollected + DayCollected + ObservationDate +",t.name)
							obsysts<-aggregate(as.formula(fml),data=obsyst,FUN=sum)
							
							#then merge with effort (note that effort does contain the unit name, because it must have all the effort)
							datays<-merge(effys,obsysts,all.x=TRUE)
							datays<-datays[,c("ObservationCount","ObservationDate","Season",t.name,s.name,"PlotAreaHa")]
							datays$ObservationCount<-ifelse(is.na(datays$ObservationCount),0,datays$ObservationCount)
							datays[,t.name]<-tt
							
							#now aggregate at the appropriate spatial grouping level
							fmla<-paste("PlotAreaHa~ObservationDate+Season+",t.name,"+",s.name)
							datanm<-aggregate(as.formula(paste("ObservationCount~ObservationDate+Season+",t.name,"+",s.name)),data=datays,FUN=sum)
							dataha<-aggregate(as.formula(paste("PlotAreaHa~ObservationDate+Season+",t.name,"+",s.name)),data=datays,FUN=sum)
							datasp<-merge(datanm,dataha)
							
							#use CountByArea instead of plain old ObservationCount
							datasp$CountByArea<-datasp$ObservationCount/datasp$PlotAreaHa
							##need a table with date, season, location, species/taxon.group, and count
							
							plotdata<-rbind(plotdata,datasp)
							res.df<-estimateTrapezoids(datasp,countField="CountByArea") 
							res.df[,taxon.name]<-tt
							res.df$Location<-ss
							res.df<-res.df[,c(taxon.name,"Location","StartDate","EndDate","BUD","Corrected_BUD","Variance","LowerLim","UpperLim","Ndays")]
							resTableArea<-rbind(resTableArea,res.df)
							
							#HERE do the table without area...
							resobs.df<-estimateTrapezoids(datasp,countField="ObservationCount") 
							resobs.df[,taxon.name]<-tt
							resobs.df$Location<-ss
							resobs.df<-resobs.df[,c(taxon.name,"Location","StartDate","EndDate","BUD","Corrected_BUD","Variance","LowerLim","UpperLim","Ndays")]
							resTableObs<-rbind(resTableObs,resobs.df)
						}
						if(nrow(resTableArea)>0){
							styr<-format(min(resTableArea$StartDate),"%Y")
							#Returning a RavianResultTable object
							tblObj<-new("RavianResultTable")
							ResultTitle(tblObj)<-paste("Bird Use Days (adjusted for area) for",ss,"and Year",styr)
							ResultType(tblObj)<-"Table"
							ResultTable(tblObj)<-resTableArea
							res.lst<-c(res.lst,tblObj)
							
							tblObj<-new("RavianResultTable")
							ResultTitle(tblObj)<-paste("Bird Use Days (unadjusted for area) for",ss,"and Year",styr)
							ResultType(tblObj)<-"Table"
							ResultTable(tblObj)<-resTableObs
							res.lst<-c(res.lst,tblObj)
							
							#now a Migration Curve plot...
							addwarn<-""
							if(NROW(utn)>5){
								plttax<-utn[1:5]
								pltTable<-subset(plotdata,plotdata[,t.name] %in% plttax)
								addwarn<-paste("Warning: only the first 5 species are being plotted at",ss,"for season",yy)
							}else{
								pltTable<-plotdata
							}
							ttltxt<-paste("Migration Curve for",ss,"and Starting Year",styr)
							taxname<-t.name
							
							argsLst<-list(data=pltTable,taxname=taxname,ttltxt=ttltxt)	#,collbl=collbl
							#we save all the above in a graphics object and the environment and send back to Ravian
							grphObj<-new("RavianResultGraph")
							ResultTitle(grphObj)<-paste("Migration Curve for",ss,"and Year",styr)
							ResultType(grphObj)<-"Graph"
							ResultGraphArgs(grphObj)<-argsLst
							ResultGraphPltFunction(grphObj)<-"makeBUDPlobj"
							res.lst<-c(res.lst,grphObj)
							
							##and a Migration Curve uncorrected for area...
							ttltxt<-paste("Migration Curve for",ss,"and Starting Year",styr,"(unadjusted for area)")
							argsLst<-list(data=pltTable,taxname=taxname,ttltxt=ttltxt)	#,collbl=collbl
							##we save all the above in a graphics object and the environment and send back to Ravian
							grphObj2<-new("RavianResultGraph")
							ResultTitle(grphObj2)<-paste("Migration Curve for",ss,"and Year",styr)
							ResultType(grphObj2)<-"Graph"
							ResultGraphArgs(grphObj2)<-argsLst
							ResultGraphPltFunction(grphObj2)<-"makeBUDPlobjUncorrectedByArea"
							res.lst<-c(res.lst,grphObj2)
							
							##and add a warning
							if(addwarn!=""){
								eo<-new("RavianResultWarning")
								ResultTitle(eo)<-"More than 5 species to plot"
								ResultType(eo)<-"Warning"
								WarningDescription(eo)<-addwarn
								res.lst<-c(res.lst,eo)
							}
							
							#Or here??
						}
					}else{
						eo<-new("RavianResultWarning")
						ResultTitle(eo)<-paste("Warning - insufficient number of days in the data (need at least 5) for Season ",yy," at ",ss,".",sep="")
						ResultType(eo)<-"Warning"
						WarningDescription(eo)<-paste("Not enough survey dates in the sample to compute Bird Use Days for Season ",yy," at ",ss,".",sep="")
						res.lst<-c(res.lst,eo)
					}
				}
			}
		}
		
	}else{
		eo<-new("RavianResultWarning")
		ResultTitle(eo)<-"Warning - there is no date period definition in the data."
		ResultType(eo)<-"Warning"
		WarningDescription(eo)<-"No date period definition in the data: no start and end dates, and/or no seasonal=1 parameter. You must set the parameter seasonal=1 and provide start and end dates."
		res.lst[[1]]<-eo
	}
	return(res.lst)
}

# Function to generate the Bird Use Dats estimates with the trapezoid method
# 
# Function to generate the Bird Use Dats estimates with the trapezoid method
# 
# @param df A data frame with all the data used to estimate the Bird Use Days
# @author Leo Salas \email{lsalas@@prbo.org}
estimateTrapezoids<-function(df,countField="ObservationCount"){
	df<-df[order(df$ObservationDate),]
	lng<-nrow(df)
	c<-df[,countField]
	if(class(df$ObservationDate)!="Date"){
		df$ObservationDate<-as.Date(as.character(df$ObservationDate))
	}
	t<-df$ObservationDate
	stdate<-min(df$ObservationDate);eddate<-max(df$ObservationDate)
	
	sdc<-sd(c);							
	sc<-numeric();diff.t<-numeric()		
	
	for(xx in 2:(lng)){
		dift<-as.numeric(t[xx]-t[xx-1])
		smc<-(dift)*(c[xx]+c[xx-1])*0.5
		#vmc<-(dift^2)*c[xx]*0.25*varc
		sc<-c(sc,smc);diff.t<-c(diff.t,dift) #vc<-c(vc,vmc);
	}
	#simple BUD from trapezoid method, and simple variance under assumption that samples are IID.
	tauc<-sum(sc)
	#vtauc<-sum(vc)
	avg.t<-floor(mean(diff.t)); if(avg.t==0){avg.t<-1}
	
	#calculating the Bue correction for non-zero start or end counts, but using average days between samples instead of life expectancy of spawners
	cb1<-0;cbn<-0
	if(c[1]!=0){
		cb1<-c[1]*avg.t/2
	}
	if(c[lng]!=0){
		cbn<-c[lng]*avg.t/2
	}
	buetauc<-tauc+cb1+cbn
	
	## calculating variance assuming non-independence in counts, using a spline curve approximation with no a priori modality assumptions 
	## we use as number of knots = number of dates - 1
	## need to calculate phi = (1/(n-3))*sum(((c-c_hat)^2)/c_hat) - see Millar et al 2013, eq 5
	## So, need c_hat estimates, from glm splines, dividing the squared residual by the predicted value 
	if(sum(c>0)>3){
		gdf<-data.frame(x=t,y=c)
		nknots<-lng-1
		fml<-as.formula(paste("y~bs(x,degree=3,knots=",nknots,")",sep=""))
		sgm<-try(glm(fml,data=gdf,family="quasipoisson"),silent=TRUE)
		if(!inherits(sgm,"try-error")){
			gdf$fitted<-sgm$fitted;	#gdf$phi_s<-((as.numeric(gdf$y-gdf$spred))^2)/gdf$spred
			gdf$res<-sgm$residuals
			gdf$phi_s2<-(gdf$res^2)/gdf$fitted
			
			mlt<-1/(lng-3)
			s_phi<-mlt*sum(gdf$phi_s)	#this is phi
			
			## Then we calculate variance using the overdispersion value phi and Millar's et al. equation 6
			
			nvs<-numeric()
			for(xx in 2:(lng-1)){
				vs<-((as.numeric(t[xx+1]-t[xx-1]))^2)*gdf$fitted[xx];nvs<-c(nvs,vs)
			}
			vtaucs<-0.25*s_phi*sum(nvs)
			
			se_est<-sqrt(vtaucs)
			#uciv<-buetauc+(pt(0.0975,df=1)*se_est)
			#lciv<-buetauc-pt(0.025,df=1)*se_est
			#Using z instead of t dist for CIs
			uciv<-buetauc+(1.96*se_est)
			lciv<-buetauc-(1.96*se_est)
			if(lciv<=0){
				lciv<-NA	#This per request from IWMM Tech Team - they want to distinguish those situations where the CI is wonkers and goes below 0 from those others where it cannot be estimated
			}
		}else{
			vtaucs<-0
			uciv<-0
			lciv<-0
		}
		
	}else{
		vtaucs<-0
		uciv<-0
		lciv<-0
	}
	
	res.df<-data.frame(StartDate=stdate,EndDate=eddate,BUD=tauc,Corrected_BUD=buetauc,Variance=vtaucs,UpperLim=uciv,LowerLim=lciv,Ndays=lng)		#Var=vtauc,
	return(res.df)
}

# Function to generate the ggplot graph for Migration Curves
# 
# Function to generate the ggplot graph for Migration Curves
# 
# @param argsLst A list with all the named arguments to be used by the plot-generating function
# @param ttltxt the title of the plot
# @author Leo Salas \email{lsalas@@prbo.org}
makeBUDPlobj<-function(data,taxname,ttltxt="Bird Use Days plot"){
	spnm<-unique(data[,taxname])
	if(NROW(spnm)==1){	#Plotly makes us do this, because otherwise it removes the legend
		ttltxt<-paste(ttltxt,"for",spnm)
	}
	if(NROW(unique(data[,taxname]))>1){
		##jittering 
		padj<-max(data$CountByArea,na.rm=TRUE)*0.03
		if(taxname=="CommonName"){
			p<-ggplot(data=data,aes(x=ObservationDate,y=CountByArea)) + 
					#geom_point(aes(color=CommonName)) + 
					geom_jitter(aes(color=CommonName),height=padj,width=0) +
					geom_line(aes(color=CommonName)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					labs(x="Date",y="Birds Per Hectare",title=ttltxt,color="Species")
		}else{
			p<-ggplot(data=data,aes(x=ObservationDate,y=CountByArea)) + 
					#geom_point(aes(color=Guild)) +
					geom_jitter(aes(color=Guild),height=padj,width=0) +
					geom_line(aes(color=Guild)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					labs(x="Date",y="Birds Per Hectare",title=ttltxt,color="Guild")
		}
	}else{
		if(taxname=="CommonName"){
			p<-ggplot(data=data,aes(x=ObservationDate,y=CountByArea)) + 
					geom_point(aes(color=CommonName)) + 
					geom_line(aes(color=CommonName)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					labs(x="Date",y="Birds Per Hectare",title=ttltxt,color="Species")
		}else{
			p<-ggplot(data=data,aes(x=ObservationDate,y=CountByArea)) + 
					geom_point(aes(color=Guild)) + 
					geom_line(aes(color=Guild)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					labs(x="Date",y="Birds Per Hectare",title=ttltxt,color="Guild")
		}
	}
	
	
	return(p)
}

# Function to generate the ggplot graph for Migration Curves - but using the total birds counted uncorrected for area
# 
# Function to generate the ggplot graph for Migration Curves - but using the total birds counted uncorrected for area
# 
# @param argsLst A list with all the named arguments to be used by the plot-generating function
# @param ttltxt the title of the plot
# @author Leo Salas \email{lsalas@@prbo.org}
makeBUDPlobjUncorrectedByArea<-function(data,taxname,ttltxt="Bird Use Days plot uncorrected for Area"){
	spnm<-unique(data[,taxname])
	if(NROW(spnm)==1){	#Plotly makes us do this, because otherwise it removes the legend
		ttltxt<-paste(ttltxt,"for",spnm)
	}
	if(NROW(unique(data[,taxname]))>1){
		#jittering 
		padj<-max(data$ObservationCount,na.rm=TRUE)*0.03
		if(taxname=="CommonName"){
			p<-ggplot(data=data,aes(x=ObservationDate,y=ObservationCount)) + 
					geom_jitter(aes(color=CommonName),height=padj,width=0) + 
					geom_line(aes(color=CommonName)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					theme(plot.title=element_text(size=11)) +
					labs(x="Date",y="# Birds",title=ttltxt,color="Species")
		}else{
			p<-ggplot(data=data,aes(x=ObservationDate,y=ObservationCount)) + 
					geom_jitter(aes(color=Guild),height=padj,width=0) + 
					geom_line(aes(color=Guild)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					theme(plot.title=element_text(size=11)) +
					labs(x="Date",y="# Birds",title=ttltxt,color="Guild")
		}
	}else{
		if(taxname=="CommonName"){
			p<-ggplot(data=data,aes(x=ObservationDate,y=ObservationCount)) + 
					geom_point(aes(color=CommonName)) + 
					geom_line(aes(color=CommonName)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					theme(plot.title=element_text(size=11)) +
					labs(x="Date",y="# Birds",title=ttltxt,color="Species")
		}else{
			p<-ggplot(data=data,aes(x=ObservationDate,y=ObservationCount)) + 
					geom_point(aes(color=Guild)) + 
					geom_line(aes(color=Guild)) +
					theme(axis.text.x=element_text(size=10)) +
					theme(axis.text.y=element_text(size=10)) +
					theme(axis.title.x=element_text(size=12)) +
					theme(axis.title.y=element_text(size=12)) +
					theme(plot.title=element_text(size=11)) +
					labs(x="Date",y="# Birds",title=ttltxt,color="Guild")
		}
	}
	
	
	return(p)
}

