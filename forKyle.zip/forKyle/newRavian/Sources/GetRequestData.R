# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate a table with the data from the request
# 
# @param dataObj A RavianData object
# @author Leo Salas \email{lsalas@@prbo.org}
GetRequestData<-function(dataObj,...){
	#merge the data
	dataObj<-mergeRavianData(dataObj,by="long")
	data<-MergedData(dataObj)
	reslst<-list()
	#Returning a RavianResultTable object
	tblObj<-new("RavianResultTable")
	ResultTitle(tblObj)<-"Selected data"
	ResultType(tblObj)<-"Table"
	ResultTable(tblObj)<-data
	reslst<-c(reslst,tblObj)
	
	return(reslst)
	
}

