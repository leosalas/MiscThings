# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate a table with the GLC transect data from the request
# 
# @param dataObj A RavianData object
# @author Leo Salas \email{lsalas@@prbo.org}
GetRequestGLCData<-function(dataObj,...){
	#merge the data
	eff<-EffortData(dataObj)
	obs<-ObsData(dataObj)
	nms<-names(eff);nms<-nms[which(nms %in% names(obs))]
	data<-try(merge(eff,obs,by=nms,all.x=TRUE),silent=TRUE)
	reslst<-list()
	#Returning a RavianResultTable object
	tblObj<-new("RavianResultTable")
	ResultTitle(tblObj)<-"Selected data"
	ResultType(tblObj)<-"Table"
	ResultTable(tblObj)<-data
	reslst<-c(reslst,tblObj)
	
	return(reslst)
	
}

