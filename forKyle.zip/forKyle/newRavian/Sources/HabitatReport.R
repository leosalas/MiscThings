# TODO: Add comment
# 
# Author: lsalas
###############################################################################

###############
# Function to generate the habitat report: the summary of metrics at the unit level per date/year
# 
# Function to generate the habitat report: the summary of metrics at the unit level per date/year
# 
# @param dataObj A RavianData object
# @param reportMetric A string vector naming one or more of the possible variables to summarize. If ommitted, all possible variables will be summarized.
# @author Leo Salas \email{lsalas@@prbo.org}
HabitatReport<-function(dataObj, reportMetric="all", ...){
	#Report is always by plot (unit) and year/season.
	# User may select one or several ponds, one or several years.
	#so, first get the data
	eff<-EffortData(dataObj)
	tG<-ifelse("TRUE" %in% grepl("Season",names(eff),fixed=T),"Season","YearCollected")
	tGn<-ifelse(tG=="YearCollected","Year","Season")
	
	#This needs to report: 
	funlst<-c("min", "max", "median", "mean", "sd")
	
	#This needs to report on - each a table: 
	habitatReportTables<-list(
		salinity=c("WaterMeasuredSalinityLevel"), #consider: "Wind","Visibility","StartTemperature"
		waterGauge=c("WaterGaugeReading"),
		waterDepth=c("WaterDepthPercentDry","WaterDepthPercent0To5CM","WaterDepthPercent5To15CM","WaterDepthPercent15To25CM","WaterDepthPercentOver25CM","WaterDepthPercentSaturatedMud"),
		habitatCover=c("HabitatCoverWater","HabitatCoverForest","HabitatCoverEmergent","HabitatCoverBareGround","HabitatCoverScrubShrub"),
		vegetationHeight=c("VegetationHeightPercentLessThan2_5Cm","VegetationHeightPercent2_5To15Cm","VegetationHeightPercent15To30Cm","VegetationHeightPercent30To60Cm","VegetationHeightPercent60CmTo3M","VegetationHeightPercent3To6M","VegetationHeightPercentOver6M")
		#interspersion=c("Interspersion"),	#this is a char!
		#disturbanceLevel=c("DisturbanceSeverity","ChronicHumanDisturbance","DisturbanceRaptors","DisturbanceAircraft","DisturbanceBoats","DisturbanceMotorVehicles","DisturbanceFishing","DisturbanceHunting","DisturbanceLooseDogs","DisturbancePedestrians")
	)
	
	waterDepthOrder.df<-data.frame(WaterhDepthOrder=rep(c(1:6),5),
			Parameter=c("maxWaterDepthPercent0To5CM","maxWaterDepthPercent5To15CM","maxWaterDepthPercent15To25CM","maxWaterDepthPercentOver25CM","maxWaterDepthPercentSaturatedMud","maxWaterDepthPercentDry",
					"meanWaterDepthPercent0To5CM","meanWaterDepthPercent5To15CM","meanWaterDepthPercent15To25CM","meanWaterDepthPercentOver25CM","meanWaterDepthPercentSaturatedMud","meanWaterDepthPercentDry",
					"medianWaterDepthPercent0To5CM","medianWaterDepthPercent5To15CM","medianWaterDepthPercent15To25CM","medianWaterDepthPercentOver25CM","medianWaterDepthPercentSaturatedMud","medianWaterDepthPercentDry",
					"minWaterDepthPercent0To5CM","minWaterDepthPercent5To15CM","minWaterDepthPercent15To25CM","minWaterDepthPercentOver25CM","minWaterDepthPercentSaturatedMud","minWaterDepthPercentDry",
					"sdWaterDepthPercent0To5CM","sdWaterDepthPercent5To15CM","sdWaterDepthPercent15To25CM","sdWaterDepthPercentOver25CM","sdWaterDepthPercentSaturatedMud","sdWaterDepthPercentDry"))
	vegHeightOrder.df<-data.frame(VegetationHeightOrder=rep(c(1:7),5),
			Parameter=c("maxVegetationHeightPercentLessThan2_5Cm","maxVegetationHeightPercent2_5To15Cm","maxVegetationHeightPercent15To30Cm","maxVegetationHeightPercent30To60Cm","maxVegetationHeightPercent60CmTo3M","maxVegetationHeightPercent3To6M","maxVegetationHeightPercentOver6M",
					"meanVegetationHeightPercentLessThan2_5Cm","meanVegetationHeightPercent2_5To15Cm","meanVegetationHeightPercent15To30Cm","meanVegetationHeightPercent30To60Cm","meanVegetationHeightPercent60CmTo3M","meanVegetationHeightPercent3To6M","meanVegetationHeightPercentOver6M",
					"medianVegetationHeightPercentLessThan2_5Cm","medianVegetationHeightPercent2_5To15Cm","medianVegetationHeightPercent15To30Cm","medianVegetationHeightPercent30To60Cm","medianVegetationHeightPercent60CmTo3M","medianVegetationHeightPercent3To6M","medianVegetationHeightPercentOver6M",
					"minVegetationHeightPercentLessThan2_5Cm","minVegetationHeightPercent2_5To15Cm","minVegetationHeightPercent15To30Cm","minVegetationHeightPercent30To60Cm","minVegetationHeightPercent60CmTo3M","minVegetationHeightPercent3To6M","minVegetationHeightPercentOver6M",
					"sdVegetationHeightPercentLessThan2_5Cm","sdVegetationHeightPercent2_5To15Cm","sdVegetationHeightPercent15To30Cm","sdVegetationHeightPercent30To60Cm","sdVegetationHeightPercent60CmTo3M","sdVegetationHeightPercent3To6M","sdVegetationHeightPercentOver6M"))
	
	
	#Don't need these, but jic
	#eff$PlotAreaSqMeters<-ifelse(is.null(eff$PlotAreaSqMeters)|is.na(eff$PlotAreaSqMeters),1200,eff$PlotAreaSqMeters)
	#eff$PlotAreaHa<-eff$PlotAreaSqMeters/10000
	
	restables<-try(generateHabitatReportTables(habitatReportTables=habitatReportTables,eff=eff,funlst=funlst,tG=tG,tGn=tGn),silent=TRUE)
	
	reslst<-list()
	
	if(!inherits(restables,"try-error")){
		#now need to make each element of the list a proper RavianResultTable object
		if(NROW(restables)>0){
			
			for(rrr in names(restables)){
				nme<-switch(rrr,"waterGauge"="Water Gauge","waterDepth"="Water Depth","salinity"="Salinity Level","habitatCover"="Habitat Cover","vegetationHeight"="Vegetation Height","interspersion"="Interspersion","disturbanceLevel"="Disturbance Level")
				ttl<-paste("Summary statistics for", nme, "data.")
				#if(rrr=="waterGauge"){
				#	readUnits<-as.character(unique(eff$WaterGaugeReadingUnits))
				#	readUnits<-paste("(",paste(readUnits,collapse=", "),")",sep="")
				#	ttl<-paste(ttl,readUnits)
				#}
				if(rrr=="waterDepth"){
					rtbl<-restables[[rrr]]
					rtbl<-merge(rtbl,waterDepthOrder.df,by="Parameter",all.x=TRUE)
					nc<-ncol(rtbl)
					rtbl<-rtbl[,c(1,nc,2:(nc-1))]
					restables[[rrr]]<-rtbl
				}else if(rrr=="vegetationHeight"){
					rtbl<-restables[[rrr]]
					rtbl<-merge(rtbl,vegHeightOrder.df,by="Parameter",all.x=TRUE)
					nc<-ncol(rtbl)
					rtbl<-rtbl[,c(1,nc,2:(nc-1))]
					restables[[rrr]]<-rtbl
				}else{}
				tblObj<-new("RavianResultTable")
				ResultTitle(tblObj)<-ttl
				ResultType(tblObj)<-"Table"
				ResultTable(tblObj)<-restables[[rrr]]
				reslst[[rrr]]<-tblObj
			}
			
		}else{
			#return a warning
			eo<-new("RavianResultWarning")
			ResultTitle(eo)<-"Warning - failed to summarize habitat report"
			ResultType(eo)<-"Warning"
			WarningDescription(eo)<-"Warning:: no data to summarize in the selection"
			reslst[[1]]<-eo
		}
	}else{
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error generating Site Conditions Report"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-"There was an error generating the Site Conditions report."
		SinkObjects(eo)<-list(dataObj=dataObj, temporalGroup=temporalGroup)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst[[1]]<-eo
	}
	
	return(reslst)
}
	
# Function to generate the Habitat Report Tables
#
# @param habitatReportTables A list with each element being a character vector; the name of the list element is the type of variable, and its components are the variables to summarize
# @param eff A data frame with the effort data, since Habitat Conditions are covariates of the survey effort
# @param funlst A character vector naming the summarization functions to apply to each variable, in the order to be applied
# @param tG A string naming the temporal grouping variable
# @param tGn A string with a user-friendly name for the temporal grouping variable
generateHabitatReportTables<-function(habitatReportTables,eff,funlst,tG,tGn){
	#then something like this... to create the table for each of the above	
	ttlSsn<-ifelse(tGn=="Season","Season","Yr")
	restables<-list()
	for(ttt in names(habitatReportTables)){	#sapply?
		tblfields<-habitatReportTables[[ttt]]
		resTable<-data.frame()
		if(ttt=="interspersion"){
			intdata<-eff[,c("PlotName",tG,"Interspersion")]
			intdata<-na.omit(intdata)
			if(nrow(intdata)>0){
				tdf<-aggregate(as.formula(paste("Interspersion~PlotName+",tG,sep="")),data=eff,FUN="unique",na.rm=TRUE)
				names(tdf)<-c("Unit",tGn,"Interspersion")
				restables[[ttt]]<-tdf
			}
		}else{
			for(fff in tblfields){	#sapply?
				if(sum(!is.na(eff[,fff]))>0){	#need to have data to aggregate
					for(funct in funlst){	#sapply?
						tdf<-aggregate(as.formula(paste(fff,"~PlotName+",tG,sep="")),data=eff,FUN=funct,na.rm=TRUE)
						names(tdf)<-c("Unit",tGn,paste(funct,fff,sep=""))
						if(nrow(resTable)==0){	#in case this is the first table...
							resTable<-tdf
						}else{
							resTable<-merge(resTable,tdf)
						}
					}
				}
			}
			if(NROW(resTable)>0){
				parNames<-names(resTable)[3:ncol(resTable)];tdf<-data.frame(Parameter=parNames)
				outTable<-as.data.frame(t(resTable[,c(3:ncol(resTable))]))
				resTable$tcolnames<-paste(resTable$Unit,"_",ttlSsn,resTable[,tGn],sep="")
				names(outTable)<-resTable$tcolnames
				outTable<-cbind(tdf,outTable)
				row.names(outTable)<-NULL
				restables[[ttt]]<-outTable
			}
		}
	}
	return(restables)
}


