# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate the bird migration curve report: the total counts per date
# 
# Function to generate the bird migration curve report: the total counts per date
# 
# @param iwmmObject An IWMMData object
# @param taxon.groups.name String providing the name (i.e., column name) of the taxon/guild grouping variable
# @param spatial.groups.name String providing the name (i.e., column name) of the spatial grouping variable
# @param observation.groups.name String providing the name (i.e., column name) of the observation grouping variable
# @param htout Should output be in html format? Defaults to n (return javascript)
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
MigrationCurve<-function(iwmmObject, taxon.groups.name="", spatial.groups.name="", observation.groups.name="",htout="n",...){
	#being called from Report, we know the object must be an IWMM data object and must have data, so...
		
	#need a table with date, species/taxon.group, and count
	#if submitting spatial.groups or observation.groups, then must serially graph these
	#merge the data
	data<-as.data.frame(iwmmObject,by="merged")
	data$StudyArea<-data$ProjectName
	data<-subset(data,!is.na(CommonName))
	if(nrow(data)==0){
		err<-"Error: no data, or species identified in the selection"; class(err)<-"try-error"
		return(err)
	}
	dat.fields<-c("CommonName","ObservationCount","ObservationDate")
	taxon.name<-"CommonName"
	if(taxon.groups.name!=""){
		dat.fields<-c("TaxonGroup","ObservationCount","ObservationDate")
		taxon.name<-taxon.groups.name	#or just use "Guild" here?
	}
	titlePlots<-"Migration Curve Report"
	#res.txt<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
	#		"<script src=\"http://code.highcharts.com/highcharts.js\"></script>\n  ",sep="")

    plt<-"";divdeclarations<-""
	
	if(spatial.groups.name!=""){
		for(gg in unique(data$SpatialGroup)){
			dat<-subset(data,SpatialGroup==gg)
			if(observation.groups.name!=""){
				for(oo in unique(data$ObservationsGroup)){
					odat<-subset(dat,ObservationsGroup==gg)
					df<-odat[,dat.fields]; names(df)<-c("Taxon","Count","ObservationDate")
					plt.tmp<-makeOnePlot(df=df,taxon.name=taxon.name,htout=htout,plot.titl=paste("Bird Migration Curve for",gg,"and",oo))
					if(!inherits(plt.tmp,"try-error")){
						if(htout=="n"){
							idp1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
							p1<-plt.tmp$html(idp1)
							pw1<-paste(substr(p1,1,regexpr("chart ",p1)-1),paste("chart_",idp1," ",sep=""),substr(p1,regexpr("chart ",p1)+6,nchar(p1)),sep="")
							plt<-paste(plt,pw1,sep="")
							divval1<-paste("<div id=\"",idp1,"\"></div>\n ",sep="")
							divdeclarations<-paste(divdeclarations,divval1,sep="")
						}else{
							plt<-paste(plt,plt.tmp)
						}
					}else{
						return(plt.tmp)
					}
				}
			}else{	#group only by spatial groups
				df<-dat[,dat.fields]; names(df)<-c("Taxon","Count","ObservationDate")
				plt.tmp<-makeOnePlot(df=df,taxon.name=taxon.name,htout=htout,plot.titl=paste("Bird Migration Curve for",gg))
				if(!inherits(plt.tmp,"try-error")){
					if(htout=="n"){
						idp1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
						p1<-plt.tmp$html(idp1)
						pw1<-paste(substr(p1,1,regexpr("chart ",p1)-1),paste("chart_",idp1," ",sep=""),substr(p1,regexpr("chart ",p1)+6,nchar(p1)),sep="")
						plt<-paste(plt,pw1,sep="")
						divval1<-paste("<div id=\"",idp1,"\"></div>\n ",sep="")
						divdeclarations<-paste(divdeclarations,divval1,sep="")
					}else{
						plt<-paste(plt,plt.tmp)
					}
				}else{
					return(plt.tmp)
				}
			}
		}
	}else if(observation.groups.name!=""){		#CAREFUL: This is not either or
		for(gg in unique(data$ObservationsGroup)){
			dat<-subset(data,ObservationsGroup==gg)
			df<-dat[,dat.fields]; names(df)<-c("Taxon","Count","ObservationDate")
			plt.tmp<-makeOnePlot(df=df,taxon.name=taxon.name,htout=htout,plot.titl=paste("Bird Migration Curve for",gg))
			if(!inherits(plt.tmp,"try-error")){
				if(htout=="n"){
					idp1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
					p1<-plt.tmp$html(idp1)
					pw1<-paste(substr(p1,1,regexpr("chart ",p1)-1),paste("chart_",idp1," ",sep=""),substr(p1,regexpr("chart ",p1)+6,nchar(p1)),sep="")
					plt<-paste(plt,pw1,sep="")
					divval1<-paste("<div id=\"",idp1,"\"></div>\n ",sep="")
					divdeclarations<-paste(divdeclarations,divval1,sep="")
				}else{
					plt<-paste(plt,plt.tmp)
				}
			}else{
				return(plt.tmp)
			}
		}
	}else{
		df<-data[,dat.fields]; names(df)<-c("Taxon","Count","ObservationDate")
		plt.tmp<-makeOnePlot(df=df,taxon.name=taxon.name,htout=htout,plot.titl="Bird Migration Curve")
		if(!inherits(plt.tmp,"try-error")){
			if(htout=="n"){
				idp1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
				p1<-plt.tmp$html(idp1)
				pw1<-paste(substr(p1,1,regexpr("chart ",p1)-1),paste("chart_",idp1," ",sep=""),substr(p1,regexpr("chart ",p1)+6,nchar(p1)),sep="")
				plt<-paste(plt,pw1,sep="")
				divval1<-paste("<div id=\"",idp1,"\"></div>\n ",sep="")
				divdeclarations<-paste(divdeclarations,divval1,sep="")
				tail<-paste(divdeclarations,sep="")
				plt<-paste(plt,tail,sep="")
			}else{
				plt<-plt.tmp
			}
		}else{
			return(plt.tmp)
		}
	}
	if(htout=="n"){	#closing the highcharts code for the set of plots
		tail<-paste(divdeclarations,sep="")
		plt<-paste(plt,tail,sep="")
	}
	
	return(plt)
	
	
}

makeOnePlot<-function(df,taxon.name,htout,plot.titl="",outT="g"){
	if(NROW(unique(df$Taxon))>5){
		taxa<-unique(df$Taxon)[1:5]
		df<-subset(df,Taxon %in% taxa)
	}
	dfa<-aggregate(as.formula("Count~Taxon+ObservationDate"),data=df,FUN=sum)
	names(dfa)<-c(taxon.name,"ObservationDate","Count")
	plt.txt<-makeMigCurvePlot(plot.df=dfa,htout=htout,plot.titl=plot.titl)
	return(plt.txt)
}

makeMigCurvePlot<-function(plot.df,htout="n",plot.titl=""){
	if(htout=="n"){ 	#in javascript - Highcharts
		#A list object with the following elements: df (data.frame), x (x-axis parameter), y (y-axis parameter), 
		# 		type (character vector with the plot types: line, bubble, scatter, spline - see highcharts for more detail), group (grouping parameter, deterimining the number and colors of lines, etc.),
		# 		size (parameter altering the size of bubbles, if using bubbles or other scalable icons). This is all for now, until package is better developed.
		# 		title (string with title)
		## ATTENTION!!!!
		## This library does not manage POSIX variables
		## soooo........
		stdat<-min(plot.df$ObservationDate)
		ordDat<-data.frame(ObservationDate=stdat,OrdinalDate=1)
		uqdats<-sort(unique(plot.df$ObservationDate))
		for(ddd in 2:NROW(uqdats)){
			difdat<-as.numeric(uqdats[ddd]-stdat)
			tmpdfdat<-data.frame(ObservationDate=uqdats[ddd],OrdinalDate=difdat)
			ordDat<-rbind(ordDat,tmpdfdat)
		}
		plot.df<-merge(plot.df,ordDat,by="ObservationDate",all.x=TRUE)
		pldata<-list(
				df=plot.df,
				x="OrdinalDate",
				y="Count",
				type="line",
				group="CommonName",
				size=2,
				title=plot.titl)
		pp<-try(create.HighchartGraph(pldata),silent=TRUE)
		return(pp)
		
	}else{	#base64 encoded png
		p1<-ggplot(data=plot.df,aes(x=ObservationDate,y=Count)) + geom_line(aes(colour=CommonName)) + labs(y="Count", x="ObservationDate", colour="Common Name") +
				theme(axis.text.x=element_text(size=10)) + theme_bw()
		pp<-try(makeHTMLplot(p1,capt=plot.titl,wdt=800, hgt=500),silent=TRUE)
		return(pp)
	}
}

