# TODO: Try-catch the regressions and make prediction plot conditional to it
# 
# Author: lsalas
###############################################################################


# Function to generate all outputs for the summary of secretive marshbird data 
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project, or study area, or transect, or point. Valid values: project, studyarea, transect, point
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by season. Valid values: year, season
# @param taxonGroup Integer (0/1) indicating to Ravian to treat the guild definition as a single taxon instead of as a collection of taxa
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one species/guild per column, reporting only total counts
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
RavianAnalystMarshbirdAbundance<-function(dataObj, spatialGroup="transect", temporalGroup="year",taxonGroup=0,pivot=0,...){
	
	reslst<-list()
	
	#merge the data
	mrgObj<-mergeRavianData(dataObj,by="long") #Can't do - need to rename BirdCount to ObservationCount
	mrg<-MergedData(mrgObj)
	if(inherits(mrg,"try-error")){
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error merging event and observation tables"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		idvars<-c("ProjectCode","ProtocolCode")
		mrg$Location<-"StudyArea"
		if(spatialGroup=="transect"){
			mrg$Location<-paste(mrg$StudyArea,mrg$Transect,sep=":")
		}else if(spatialGroup=="point"){
			mrg$Location<-paste(mrg$StudyArea,mrg$Transect,mrg$Point,sep=":")
		}else{}
		
		## First must add visit field...
		mrg$ObservationDate<-paste(mrg$YearCollected,mrg$MonthCollected,mrg$DayCollected,sep="-")
		tdates<-unique(mrg[,c(idvars,"StudyArea","Transect","ObservationDate")])
		#create the visit field
		tdates$ppt<-paste(tdates$ProjectCode,tdates$ProtocolCode,tdates$StudyArea,tdates$Transect,sep=":")	
		ttdates<-ldply(.data=unique(tdates$ppt), .fun=function(x,df){
					tdf<-subset(df,ppt==x);
					tdf<-tdf[order(tdf$ObservationDate),];
					tdf$Visit<-1:(nrow(tdf));
					return(tdf)
				},df=tdates)
		ttdates<-ttdates[,c(idvars,"StudyArea","Transect","ObservationDate","Visit")]
		mrgdf<-merge(mrg[,which(names(mrg)!="Visit")],ttdates,by=c(idvars,"StudyArea","Transect","ObservationDate"),all.x=T)
		
		#Then collapse to the max per point per temporal group (year, or month, or date) and species...
		tempgroup<-"YearCollected"
		if(temporalGroup=="month"){
			mrgdf$YearMonth<-paste(mrgdf$YearCollected,mrgdf$MonthCollected,sep="_")
			tempgroup<-"YearMonth";
		}else if(temporalGroup=="date"){
			tempgroup<-"ObservationDate"
		}else{}
		maxdf<-aggregate(as.formula(paste("ObservationCount~",paste(idvars,collapse="+"),"+StudyArea+Transect+Point",
								"+Location+",tempgroup,"+CommonName")),data=mrgdf,FUN=max)
		
		#if guild, then aggregate by guild
		if(taxonGroup==1){
			guilddf<-unique(mrg[,c("CommonName","Guild")])
			maxdf<-merge(maxdf,guilddf,by="CommonName",all.x=T)
			maxg<-aggregate(as.formula(paste("ObservationCount~",paste(idvars,collapse="+"),"+StudyArea+Transect+Point",
									"+Location+",tempgroup,"+Guild",sep="")),data=maxdf,FUN=sum)
			taxag<-"Guild";taxan<-"guild"
		}else{
			maxg<-maxdf
			taxag<-"CommonName";taxan<-"species"
		}
		
		#then average by location:
		avgdf<-aggregate(as.formula(paste("ObservationCount~",paste(idvars,collapse="+"),"+Location",
								"+",tempgroup,"+",taxag,sep="")),data=maxg,FUN=mean)
		avgsd<-aggregate(as.formula(paste("ObservationCount~",paste(idvars,collapse="+"),"+Location",
								"+",tempgroup,"+",taxag,sep="")),data=maxg,FUN=sd)
		names(avgdf)<-gsub("ObservationCount","MeanCount",names(avgdf))
		names(avgsd)<-gsub("ObservationCount","SdCount",names(avgsd))
		avgdf<-merge(avgdf,avgsd,by=c(idvars,"Location",tempgroup,taxag))
		avgdf$SdCount<-ifelse(is.na(avgdf$SdCount),0,avgdf$SdCount)
		
		#outputs:
		# 1) Report the summarization table
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-paste("Total Number of Detections per ",taxan,", ",spatialGroup,", and ",temporalGroup,sep="")
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-avgdf
		reslst<-c(reslst,tblObj)
		
		# 2) plot of abundance - all species combined - MUST distinguish in the wh for target species
		plot.df<-aggregate(as.formula(paste("MeanCount~Location+",tempgroup,sep="")),data=avgdf,FUN=sum)
		#a line per Location
		ttltxt<-paste("Total Counts by",spatialGroup,"and",temporalGroup)
		argsLst<-list(data=plot.df,ttltxt=ttltxt,xvar=tempgroup)
		grphObj<-new("RavianResultGraph")
		ResultTitle(grphObj)<-ttltxt
		ResultType(grphObj)<-"Graph"
		ResultGraphArgs(grphObj)<-argsLst
		ResultGraphPltFunction(grphObj)<-"makePlobjCountByTempGroupByLocation"
		reslst<-c(reslst,grphObj)
		
		# 3) estimate a trend in abundance over Years by location and taxag - this needs to happen on mrgdf
		#mrgdf has both YearCollected and tempgroup, mrgdf must have Location and taxag, and it does
		# IF the span of years > 2
		if(NROW(unique(mrgdf$YearCollected))>2){
			if(NROW(unique(mrgdf[,taxag]))>1){
				if(NROW(unique(mrgdf$Location))>1){
					regmdl<-try(lm(as.formula(paste("ObservationCount~Location+YearCollected+",taxag,sep="")),data=mrgdf),silent=TRUE)
					ttlval<-paste("Trend of overall",taxan,"abundance across all locations",sep="")
					noteval<-paste("The year trend is estimated after accounting for the effects of location and ",taxan,".",sep="")
					
				}else{
					regmdl<-try(lm(as.formula(paste("ObservationCount~YearCollected+",taxag,sep="")),data=mrgdf),silent=TRUE)
					ttlval<-paste("Trend of overall",taxan,"abundance",sep="")
					noteval<-paste("The year trend is estimated after accounting for the effects of ",taxan,".",sep="")
				}
				
			}else{
				if(NROW(unique(mrgdf$Location))>1){
					regmdl<-try(lm(as.formula("ObservationCount~Location+YearCollected"),data=mrgdf),silent=TRUE)
					ttlval<-paste("Trend of ",taxan,"abundance across all locations",sep="")
					noteval<-"The year trend is estimated after accounting for the effects of location"
				}else{
					regmdl<-try(lm(as.formula("ObservationCount~YearCollected"),data=mrgdf),silent=TRUE)
					ttlval<-paste("Trend of ",taxan,"abundance",sep="")
					noteval<-""
				}
			}
			if(!inherits(regmdl,"try-error")){
				#report the slope by year and species
				coefdata<-as.data.frame((summary(regmdl))$coefficients)
				coefdata$Coefficient<-row.names(coefdata)
				row.names(coefdata)<-NULL
				regdf<-subset(coefdata,Coefficient=="YearCollected")
				regdf<-regdf[,c(5,1,2,3,4)]
				regdf$Coefficient<-"Year trend"
				tblObj<-new("RavianResultTable")
				ResultTitle(tblObj)<-ttlval
				ResultType(tblObj)<-"Table"
				ResultTable(tblObj)<-regdf
				ResultNotes(tblObj)<-noteval
				reslst<-c(reslst,tblObj)
			}
			
		}
		
		
		# 4) plot the predicted regression if request includes only one species or guild
		if(NROW(unique(mrgdf[,taxag]))==1 && NROW(unique(mrgdf$YearCollected))>2 && !inherits(regmdl,"try-error")){
			locval<-unique(mrgdff$Location)[1]
			yrseq<-seq(min(mrgdff$YearCollected),max(mrgdff$YearCollected),by=1)
			preddf<-data.frame(Location=rep(locval,times=NROW(yrseq)),YearCollected=yrseq)
			estdf<-predict(regmdl,preddf,se=T)
			preddf$Predicted<-estdf$fit;preddf$SE<-estdf$se.fit
			preddf$ymin<-preddf$Predicted-(1.96*preddf$SE)
			preddf$ymax<-preddf$Predicted+(1.96*preddf$SE)
			ttltxt<-paste("Predicted abundance by year for",locval)
			argsLst<-list(data=preddf,ttltxt=ttltxt,xvar="YearCollected")
			grphObj<-new("RavianResultGraph")
			ResultTitle(grphObj)<-ttltxt
			ResultType(grphObj)<-"Graph"
			ResultGraphArgs(grphObj)<-argsLst
			ResultGraphPltFunction(grphObj)<-"makePlobjPredAbundByYear"
			reslst<-c(reslst,grphObj)
		}
	}
	return(reslst)
	
}

# Function to generate the ggplot graph for count by date by taxon
# 
# Function to generate the ggplot graph for count by date by taxon
# 
# @param data A data.frame with the data to plot
# @param ttltxt the title of the plot
# @param xvar The name of the variable to use as the x-axis variable
# @author Leo Salas \email{lsalas@@prbo.org}
makePlobjCountByTempGroupByLocation<-function(data,ttltxt="Total Counts by Year",xvar="YearCollected",addOverallSlope=TRUE){
	xttl<-ifelse(xvar=="ObservationDate","Observation Date",ifelse(xvar=="YearMonth","Year_Month","Year"))
	p<-ggplot(data=data,aes_string(x=xvar,y="MeanCount"))+
			geom_point(size=2,aes(color=Location)) +
			geom_smooth(method="lm",aes(color=Location),se=F) +
			theme_bw() + labs(x=xttl,y="Total Birds Counted",legend="Location")  
	if(addOverallSlope==TRUE && NROW(unique(data$Location))>1){
		p<-p+geom_smooth(method="lm",color="dark gray",se=F) 
	}
	return(p)
}


# Function to generate the ggplot graph for predicted count by date by taxon
# 
# Function to generate the ggplot graph for predicted count by date by taxon
# 
# @param data A data.frame with the data to plot
# @param ttltxt the title of the plot
# @param xvar The name of the variable to use as the x-axis variable
# @param locval The name for the location used as predictor
# @author Leo Salas \email{lsalas@@prbo.org}
makePlobjPredAbundByYear<-function(data,ttltxt="Predicted Counts by Year",xvar="YearCollected"){
	p<-ggplot(data=data,aes_string(x=xvar,y="Predicted"))+
			geom_ribbon(aes(ymin=ymin,ymax=ymax),color=I(rgb(225/255,225/255,225/255)),fill=I(rgb(225/255,225/255,225/255))) +
			geom_line(size=1.5,color="dark blue") +
			theme_bw() + labs(x="Year",y="Predicted Abundance")  
	return(p)
}



