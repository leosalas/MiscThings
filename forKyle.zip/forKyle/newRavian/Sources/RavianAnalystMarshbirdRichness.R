# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate all outputs for the summary of secretive marshbird data 
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project, or study area, or transect, or point. Valid values: project, studyarea, transect, point
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by season. Valid values: year, season
# @param taxonGroup Integer (0/1) indicating to Ravian to treat the guild definition as a single taxon instead of as a collection of taxa
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one species/guild per column, reporting only total counts
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
RavianAnalystMarshbirdRichness<-function(dataObj, spatialGroup="transect", temporalGroup="year",taxonGroup=0,pivot=0,...){
	reslst<-list()
	
	#merge the data
	mrgObj<-mergeRavianData(dataObj,by="long") #Can't do - need to rename BirdCount to ObservationCount
	mrg<-MergedData(mrgObj)
	if(inherits(mrg,"try-error")){
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error merging event and observation tables"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		idvars<-c("ProjectCode","ProtocolCode")
		mrg$Location<-"StudyArea"
		if(spatialGroup=="transect"){
			mrg$Location<-paste(mrg$StudyArea,mrg$Transect,sep=":")
		}else if(spatialGroup=="point"){
			mrg$Location<-paste(mrg$StudyArea,mrg$Transect,mrg$Point,sep=":")
		}else{}
		
		## First must add visit field...
		mrg$ObservationDate<-paste(mrg$YearCollected,mrg$MonthCollected,mrg$DayCollected,sep="-")
		tdates<-unique(mrg[,c(idvars,"StudyArea","Transect","ObservationDate")])
		#create the visit field
		tdates$ppt<-paste(tdates$ProjectCode,tdates$ProtocolCode,tdates$StudyArea,tdates$Transect,sep=":")	
		ttdates<-ldply(.data=unique(tdates$ppt), .fun=function(x,df){
					tdf<-subset(df,ppt==x);
					tdf<-tdf[order(tdf$ObservationDate),];
					tdf$Visit<-1:(nrow(tdf));
					return(tdf)
				},df=tdates)
		ttdates<-ttdates[,c(idvars,"StudyArea","Transect","ObservationDate","Visit")]
		mrgdf<-merge(mrg[,which(names(mrg)!="Visit")],ttdates,by=c(idvars,"StudyArea","Transect","ObservationDate"),all.x=T)
		
		#Then collapse to the max per point per temporal group (year, or month, or date) and species...
		tempgroup<-"YearCollected"
		if(temporalGroup=="month"){
			mrgdf$YearMonth<-paste(mrgdf$YearCollected,mrgdf$MonthCollected,sep="_")
			tempgroup<-"YearMonth";
		}else if(temporalGroup=="date"){
			tempgroup<-"ObservationDate"
		}else{}
		maxdf<-aggregate(as.formula(paste("ObservationCount~",paste(idvars,collapse="+"),"+StudyArea+Transect+Point",
								"+Location+",tempgroup,"+CommonName")),data=mrgdf,FUN=max)
		
		##############################
		#No guild aggregation
		##############################
		
		#then average by location:
		avgdf<-aggregate(as.formula(paste("ObservationCount~",paste(idvars,collapse="+"),"+Location",
								"+",tempgroup,"+CommonName",sep="")),data=maxdf,FUN=mean)
		names(avgdf)<-gsub("ObservationCount","MeanCount",names(avgdf))
		#remove 0 counts:
		avgdf<-subset(avgdf,MeanCount>0)
		
		#Add p for Shannon and Simpson, where total is the sum of mean by location and tempgroup
		totals<-aggregate(as.formula(paste("MeanCount~",paste(idvars,collapse="+"),"+Location",
								"+",tempgroup,sep="")),data=avgdf,FUN=sum)
		names(totals)<-gsub("MeanCount","TotalLocTime",names(totals))
		richdf<-merge(avgdf,totals,by=c(idvars,"Location",tempgroup),all.x=T)
		richdf$freq<-richdf$MeanCount/richdf$TotalLocTime
		richdf$lgfreq<-log(richdf$freq)
		richdf$lgShan<-richdf$freq*richdf$lgfreq
		richdf$sqfreq<-richdf$freq^2
		
		#Outputs:
		#1) A table of the number of species per transect per year
		udf<-unique(mrgdf[,c(idvars,"YearCollected","BirdCd")])
		summdf<-aggregate(as.formula(paste("BirdCd~",paste(idvars,collapse="+"),"+YearCollected",sep="")),data=udf,FUN=NROW)
		names(summdf)<-gsub("BirdCd","Richness",names(summdf))
		ttdw<-reshape(summdf,idvar=idvars,timevar="YearCollected",direction="wide")
		names(ttdw)<-gsub("Richness.","Year_",names(ttdw))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Total Number of Species per Transect and Year"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-ttdw
		reslst<-c(reslst,tblObj)
		
		#2) # Richness, Shannon, and Simpson indices at each location and time
		richdf$locTime<-paste(richdf$Location,richdf[,tempgroup],sep="::")
		indxdf<-ldply(.data=unique(richdf$locTime),.fun=function(x,df,tempgroup){
					dfx<-subset(df,locTime==x);
					rdf<-data.frame(Location=unique(dfx$Location),tempo<-unique(dfx[,tempgroup]),
							Richness=nrow(dfx),Shannon=round((-1)*sum(dfx$lgShan),3),Simpson=round(sum(dfx$sqfreq),3));
					names(rdf)<-c("Location",tempgroup,"Richness","Shannon","Simpson");
					return(rdf);
				},df=richdf,tempgroup=tempgroup)
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-paste("Diversity indices by location and",temporalGroup)
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-indxdf
		reslst<-c(reslst,tblObj)

		#3) Trends in richness at each location by year
		#Table (and plot - IF tempgroup is YearCollected)
		# IF the span of years > 2
		if(NROW(unique(indxdf$YearCollected))>2){
			#plot
			if(tempgroup=="YearCollected"){
				#a line per Location
				ttltxt<-paste("Richness by location and",temporalGroup)
				argsLst<-list(data=indxdf,ttltxt=ttltxt,xvar=tempgroup)
				grphObj<-new("RavianResultGraph")
				ResultTitle(grphObj)<-ttltxt
				ResultType(grphObj)<-"Graph"
				ResultGraphArgs(grphObj)<-argsLst
				ResultGraphPltFunction(grphObj)<-"makePlobjRichnessByTempGroupByLocation"
				reslst<-c(reslst,grphObj)
			}
		
			#regtable
			if(NROW(unique(indxdf$Location))>1){
				regmdl<-try(lm(as.formula("Richness~Location+YearCollected"),data=indxdf),silent=TRUE)
				ttlval<-paste("Trend of species richness across all locations",sep="")
				noteval<-"The year trend is estimated after accounting for the effects of location"
				
				regmdlall<-try(lm(as.formula("Richness~YearCollected"),data=indxdf),silent=TRUE)
				ttlvalall<-"Trend of overall species richness"
				notevalall<-""
			}else{
				regmdl<-try(lm(as.formula("Richness~YearCollected"),data=indxdf),silent=TRUE)
				ttlval<-paste("Trend of species richness",sep="")
				noteval<-""
				
				regmdlall<-NA
			}
			
			if(!inherits(regmdl,"try-error")){
				#report the slope by year and species
				coefdata<-as.data.frame((summary(regmdl))$coefficients)
				coefdata$Coefficient<-row.names(coefdata)
				row.names(coefdata)<-NULL
				regdf<-subset(coefdata,Coefficient=="YearCollected")
				regdf[,4]<-round(regdf[,4],4)
				regdf<-regdf[,c(5,1,2,3,4)]
				regdf$Coefficient<-"Year trend"
				tblObj<-new("RavianResultTable")
				ResultTitle(tblObj)<-ttlval
				ResultType(tblObj)<-"Table"
				ResultTable(tblObj)<-regdf
				ResultNotes(tblObj)<-noteval
				reslst<-c(reslst,tblObj)
			}
			
			#4) Overall (all locations combined) trend in richness by year
			if(!is.na(regmdlall) && !inherits(regmdlall,"try-error")){
				#report the slope by year and species
				coefdata<-as.data.frame((summary(regmdlall))$coefficients)
				coefdata$Coefficient<-row.names(coefdata)
				row.names(coefdata)<-NULL
				regdf<-subset(coefdata,Coefficient=="YearCollected")
				regdf[,4]<-round(regdf[,4],4)
				regdf<-regdf[,c(5,1,2,3,4)]
				regdf$Coefficient<-"Year trend"
				tblObj<-new("RavianResultTable")
				ResultTitle(tblObj)<-ttlvalall
				ResultType(tblObj)<-"Table"
				ResultTable(tblObj)<-regdf
				ResultNotes(tblObj)<-notevalall
				reslst<-c(reslst,tblObj)
			}
		}
		
		
	}
	return(reslst)
	
}

# Function to generate the ggplot graph for richness by year and location
# 
# Function to generate the ggplot graph for richness by year and location
# 
# @param data A data.frame with the data to plot
# @param ttltxt the title of the plot
# @author Leo Salas \email{lsalas@@prbo.org}
makePlobjRichnessByTempGroupByLocation<-function(data,ttltxt="Species Richness by Year and Location",xvar="YearCollected",addOverallSlope=TRUE){
	p<-ggplot(data=data,aes_string(x=xvar,y="Richness"))+
			geom_point(size=2,aes(color=Location)) +
			geom_smooth(method="lm",aes(color=Location),se=F) +
			theme_bw() + labs(x="",y="Species richness",legend="Location")  
	if(addOverallSlope==TRUE && NROW(unique(data$Location))>1){
		p<-p+geom_smooth(method="lm",color="dark gray",se=F) 
	}
	return(p)
}



