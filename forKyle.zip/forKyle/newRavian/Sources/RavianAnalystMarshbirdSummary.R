# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate all outputs for the summary of secretive marshbird data 
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project, or study area, or transect, or point. Valid values: project, studyarea, transect, point
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by season. Valid values: year, season
# @param taxonGroup Integer (0/1) indicating to Ravian to treat the guild definition as a single taxon instead of as a collection of taxa
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one species/guild per column, reporting only total counts
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
RavianAnalystMarshbirdSummary<-function(dataObj, spatialGroup="transect", temporalGroup="year",taxonGroup=0,pivot=0,...){
	
	reslst<-list()
	
	#merge the data
	mrgObj<-mergeRavianData(dataObj,by="long") #Can't do - need to rename BirdCount to ObservationCount
	mrg<-MergedData(mrgObj)
	if(inherits(mrg,"try-error")){
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error merging event and observation tables"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		idvars<-c("ProjectCode","ProtocolCode","StudyArea","Transect")
		
		## First must add visit field...
		mrg$ObservationDate<-paste(mrg$YearCollected,mrg$MonthCollected,mrg$DayCollected,sep="-")
		tdates<-unique(mrg[,c(idvars,"ObservationDate")])
		#create the visit field
		tdates$ppt<-paste(tdates$ProjectCode,tdates$ProtocolCode,tdates$StudyArea,tdates$Transect,sep=":")	
		ttdates<-ldply(.data=unique(tdates$ppt), .fun=function(x,df){
					tdf<-subset(df,ppt==x);
					tdf<-tdf[order(tdf$ObservationDate),];
					tdf$Visit<-1:(nrow(tdf));
					return(tdf)
				},df=tdates)
		ttdates<-ttdates[,c(idvars,"ObservationDate","Visit")]
		mrgdf<-merge(mrg[,which(names(mrg)!="Visit")],ttdates,by=c(idvars,"StudyArea","Transect","ObservationDate"),all.x=T)
		
		#summaries:
		#1) A table of when each transect was surveyed
		ttdw<-reshape(ttdates[,c(idvars,"Visit","ObservationDate")],idvar=idvars,timevar="Visit",direction="wide")
		names(ttdw)<-gsub("ObservationDate.","Visit_",names(ttdw))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Summary of Dates of Visits to Transects"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-ttdw
		reslst<-c(reslst,tblObj)
		
		#2) How many times each point was surveyed and how many birds (all species combined) were detected at each point each year
		pointvdf<-aggregate(as.formula("Visit~ProjectCode+ProtocolCode+StudyArea+Transect+Point+YearCollected"),data=mrgdf,FUN=max)
		names(pointvdf)<-gsub("Visit","MaxVisits",names(pointvdf))
		cnpoint<-unique(mrgdf[,c(idvars,"Point","YearCollected","Visit","CommonName","ObservationCount")])
		pointcount<-aggregate(ObservationCount~ProjectCode+ProtocolCode+StudyArea+Transect+Point+YearCollected,data=cnpoint,FUN=sum)
		names(pointcount)<-gsub("ObservationCount","TotalCounts",names(pointcount))
		sppoint<-unique(mrgdf[,c(idvars,"Point","YearCollected","CommonName")])
		pointsp<-aggregate(CommonName~ProjectCode+ProtocolCode+StudyArea+Transect+Point+YearCollected,data=sppoint,FUN=NROW)
		names(pointsp)<-gsub("CommonName","TotalSpecies",names(pointsp))
		pointw<-merge(pointvdf,pointcount,by=c(idvars,"Point","YearCollected"));pointw<-merge(pointw,pointsp,by=c(idvars,"Point","YearCollected"))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Number of Visits, Birds Counted, and Species Detected at Points per Year"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-pointw
		reslst<-c(reslst,tblObj)
		
		#3) How many birds and how many species were detected at each transect each year
		sptrans<-unique(mrgdf[,c(idvars,"YearCollected","CommonName")])
		transsp<-aggregate(CommonName~ProjectCode+ProtocolCode+StudyArea+Transect+YearCollected,data=sptrans,FUN=NROW)
		names(transsp)<-gsub("CommonName","NumSpecies",names(transsp))
		numtrans<-unique(mrgdf[,c(idvars,"YearCollected","CommonName","ObservationCount")])
		transnum<-aggregate(ObservationCount~ProjectCode+ProtocolCode+StudyArea+Transect+YearCollected,data=numtrans,FUN=sum,na.rm=T)
		names(transnum)<-gsub("ObservationCount","TotalCounts",names(transnum))
		transrep<-merge(transnum,transsp,by=c(idvars,"YearCollected"))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Number of Birds Counted and Species Detected in Transects per Year"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-transrep
		reslst<-c(reslst,tblObj)
		
		#4) How many birds and how many species were detected overall each year
		spall<-unique(mrgdf[,c("ProjectCode","ProtocolCode","YearCollected","CommonName")])
		allsp<-aggregate(CommonName~ProjectCode+ProtocolCode+YearCollected,data=spall,FUN=NROW)
		names(allsp)<-gsub("CommonName","NumSpecies",names(allsp))
		numall<-unique(mrgdf[,c("ProjectCode","ProtocolCode","YearCollected","CommonName","ObservationCount")])
		allnum<-aggregate(ObservationCount~ProjectCode+ProtocolCode+YearCollected,data=numall,FUN=sum,na.rm=T)
		names(allnum)<-gsub("ObservationCount","TotalCounts",names(allnum))
		allrep<-merge(allnum,allsp,by=c("ProjectCode","ProtocolCode","YearCollected"))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Number of Birds Counted and Species Detected overall per Year"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-allrep
		reslst<-c(reslst,tblObj)

		#5) How many birds of each taxon were detected overall by year
		countyr<-aggregate(ObservationCount~ProjectCode+ProtocolCode+CommonName+YearCollected,data=cnpoint,FUN=sum)
		countyrw<-reshape(countyr,idvar=c("ProjectCode","ProtocolCode","CommonName"),timevar="YearCollected",direction="wide")
		yn<-subset(names(countyrw),grepl("ObservationCount",names(countyrw),fixed=T))
		for(nn in yn){countyrw[,nn]<-ifelse(is.na(countyrw[,nn]),0,countyrw[,nn])}
		names(countyrw)<-gsub("ObservationCount.","",names(countyrw))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Number of Birds Counted per Species each Year"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-countyrw
		reslst<-c(reslst,tblObj)
	}
	return(reslst)
	
}

