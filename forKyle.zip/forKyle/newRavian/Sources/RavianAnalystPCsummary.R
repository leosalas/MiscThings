# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate all outputs for the summary of Point Count data 
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project, or study area, or transect, or point. Valid values: project, studyarea, transect, point
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by season. Valid values: year, season
# @param taxonGroup Integer (0/1) indicating to Ravian to treat the guild definition as a single taxon instead of as a collection of taxa
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one species/guild per column, reporting only total counts
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
RavianAnalystPCsummary<-function(dataObj, spatialGroup="transect", temporalGroup="year",taxonGroup=0,pivot=0,...){
	
	reslst<-list()
	
	#merge the data
	mrgObj<-mergeRavianData(dataObj,by="long") #Can't do - need to rename BirdCount to ObservationCount
	mrg<-MergedData(mrgObj)
	if(inherits(mrg,"try-error")){
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error merging event and observation tables"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		idvars<-c("ProjectCode","ProtocolCode","StudyArea","Transect")
		
		#summaries:
		#1) A table of when each transect was surveyed
		mrg$ObservationDate<-paste(mrg$YearCollected,mrg$MonthCollected,mrg$DayCollected,sep="-")
		tdates<-unique(mrg[,c(idvars,"ObservationDate")])
		#create the visit field
		tdates$ppt<-paste(tdates$ProjectCode,tdates$ProtocolCode,tdates$StudyArea,tdates$Transect,sep=":")	
		ttdates<-data.frame()
		for(tt in unique(tdates$ppt)){
			tdf<-subset(tdates,ppt==tt)
			tdf<-tdf[order(tdf$ObservationDate),]
			tdf$Visit<-1:(nrow(tdf))
			ttdates<-rbind(ttdates,tdf)
		}
		ttdw<-reshape(ttdates[,c(idvars,"Visit","ObservationDate")],idvar=idvars,timevar="Visit",direction="wide")
		nvc<-ncol(ttdw)-NROW(idvars)
		names(ttdw)<-c(idvars,paste("Visit",1:nvc,sep=""))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Summary of Dates of Visits to Transects"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-ttdw
		reslst<-c(reslst,tblObj)
		
	}
	return(reslst)
	
}
