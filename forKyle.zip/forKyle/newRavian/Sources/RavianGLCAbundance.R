# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate all outputs for the estimation of abundance visualizations of FixedTransect data 
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project, or study area, or transect. Valid values: project, studyarea, transect
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by season. Valid values: year, season
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one richness estimate per year per column
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
RavianGLCAbundance<-function(dataObj, spatialGroup="transect", temporalGroup="year",pivot=0,...){
	reslst<-list()
	
	#merge the data
	dataObj<-mergeRavianData(dataObj,by="long") 
	mrg<-MergedData(dataObj)
	#eff<-EffortData(dataObj)
	#obs<-ObsData(dataObj)
	#nms<-names(eff);nms<-nms[which(nms %in% names(obs))]
	#mrg<-try(merge(eff,obs,by=nms,all.x=TRUE),silent=TRUE)
	tg<-ifelse(temporalGroup=="year", "YearCollected", "Season")
	sg<-ifelse(spatialGroup=="transect","Transect",
			ifelse(spatialGroup=="studyarea","StudyArea","ProjectCode"))
	
	if(inherits(mrg,"try-error")){
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error merging event and observation tables"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		ducks<-c("ABDU","AMWI","BUFF","BWTE","CANV","BLSC","COEI","COGO","COME","GADW","GRSC","HOME","LESC","LTDU","MALL","MUSW","RBME","REDH","RNDU","RUDU",
				"UNSC","XSCO","SUSC","TUSW","UNCY","TRUS","UDID","UDAD","UNDU","UNME","XXSD","WODU","WWSC","XWFG","CAGO","XSCA","SCOT","UNSC")
		seaducks<-c("BUFF","BLSC","COGO","COME","HOME","RBME","XSCO","SUSC","UNDU","UNME","XXSD","WWSC","SCOT","UNSC")
		gulls<-c("GBBG","HERG","UNGU","RBGU","BOGU","GLGU")
		divingducks<-c("CANV","REDH","XSCA")
		grebes<-c("HOGR","GREB","RNGR")
		
		mrg$Guild<-ifelse(mrg$SpeciesCode %in% ducks,"Ducks",
				ifelse(mrg$SpeciesCode %in% seaducks,"Sea Ducks",
						ifelse(mrg$SpeciesCode %in% gulls,"Gulls",
								ifelse(mrg$SpeciesCode %in% divingducks,"Diving Ducks",
										ifelse(mrg$SpeciesCode %in% grebes,"Grebes","Other species")))))
		
		
		#first the graph indicating when the numbers of individuals by guild were seen
		plot.df<-aggregate(as.formula("ObservationCount~Guild+ObservationDate"),data=mrg,FUN=sum)
		plot.df<-subset(plot.df,ObservationCount>0)
		ttltxt<-"Total Counts by Date and Guild"
		argsLst<-list(data=plot.df,ttltxt=ttltxt,xvar="ObservationDate")
		grphObj<-new("RavianResultGraph")
		ResultTitle(grphObj)<-ttltxt
		ResultType(grphObj)<-"Graph"
		ResultGraphArgs(grphObj)<-argsLst
		ResultGraphPltFunction(grphObj)<-"makePlobjCountByDateTimeByGuild"
		reslst<-c(reslst,grphObj)
		
		#times of encounters plot
		if(TRUE %in% is.na(mrg$ObservationTm)){
			#skipping
		}else{
			plot.df<-aggregate(as.formula("ObservationCount~Guild+ObservationTm"),data=mrg,FUN=sum)
			plot.df$ObservationTm<-strptime(as.character(plot.df$ObservationTm),"%H:%M:%S")
			ttltxt<-"Total Counts by Time of Day and Guild"
			argsLst<-list(data=plot.df,ttltxt=ttltxt,xvar="ObservationTm")
			grphObj<-new("RavianResultGraph")
			ResultTitle(grphObj)<-ttltxt
			ResultType(grphObj)<-"Graph"
			ResultGraphArgs(grphObj)<-argsLst
			ResultGraphPltFunction(grphObj)<-"makePlobjCountByDateTimeByGuild"
			reslst<-c(reslst,grphObj)
		}
		
		
		#get the orders of distance bins by protocol, and the transect width definitions
		dba<-data.frame(
				ProtocolCode=c(rep("BRI_AERIALTR",4),rep("CLH_AERIALTR",5),rep("MIGOV_AERIALTR_6.5HRS",5),
						rep("USGS_GLWBSRV_200m",3),"WGLBBO_AERIALTR",rep("WGLBBO_AERIALTR2",6)),
				DistanceBinId=c("<100","100-200","<200","200-300","A","B","C","C2","D2","25","87.5","175","325","625",
						"0-100","100-200","200","1","0","1","12","123","2","23"),
				DistanceDef=c("<100m","100-200m","<200m","200-300m","<100m","100-200m","200-400m","200-400m","300-400m",
						"<50m","50-125m","125-225m","335-450m","450-800m",
						"<100m","100-200m","<200m","<200m","<100m","100-200m","<200m","<300m","200-300m","100-300m"),
				AreaDef=c(rep(300,4),rep(400,5),rep(800,5),rep(200,3),200,rep(300,6)))
		dbb<-data.frame(
				ProtocolCode=c("BRI_AERIALTR","CLH_AERIALTR","MIGOV_AERIALTR_6.5HRS","USGS_GLWBSRV_200m","WGLBBO_AERIALTR","WGLBBO_AERIALTR2"),
				AreaDef=c(300,400,800,200,200,300))
		
		#Table of densities		
		#need to aggregate separately the transect length and the count for areas 
		fmlc<-as.formula(paste("ObservationCount~Guild+ProjectCode+ProtocolCode+",tg,"+",sg,sep=""))
		fmld<-as.formula(paste("Length_Km~ProjectCode+ProtocolCode+",tg,"+",sg,sep=""))
		tblc<-aggregate(fmlc,data=mrg,FUN=sum)
		idvars<-unique(c("ProjectCode","ProtocolCode","Transect",sg,"YearCollected",tg,"ObservationDate"))
		tbld<-aggregate(fmld,data=unique(mrg[,c(idvars,"Length_Km")]),FUN=sum)
		
		tbl.df<-merge(tbld,tblc,all.x=T);tbl.df<-merge(tbl.df,dbb,all.x=TRUE);tbl.df<-subset(tbl.df,!is.na(AreaDef))
		tbl.df$AreaSurveyed_Km2<-round(tbl.df$Length_Km*tbl.df$AreaDef*2/1000,2)
		tbl.df$Density_BirdsKm2<-round(tbl.df$ObservationCount/tbl.df$AreaSurveyed_Km2,2)
		tbl.res<-reshape(tbl.df[,c("ProjectCode","ProtocolCode",tg,sg,"AreaSurveyed_Km2","Guild","Density_BirdsKm2")],
				idvar=c("ProjectCode","ProtocolCode",tg,sg,"AreaSurveyed_Km2"),
				timevar="Guild",direction="wide")
		names(tbl.res)<-gsub("Density_BirdsKm2.","",names(tbl.res))
		nn<-unique(tbl.df$Guild)
		for(nms in nn){
			tbl.res[,nms]<-ifelse(is.na(tbl.res[,nms]),0,tbl.res[,nms])
		}
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-paste("Summary of Simple Bird Density by Guild,",sg,"and",tg)
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-tbl.res
		reslst<-c(reslst,tblObj)
		return(reslst)
	}
}

# Function to generate the ggplot graph for count by date by guild
# 
# Function to generate the ggplot graph for count by date by guild
# 
# @param data A data.frame with the data to plot
# @param ttltxt the title of the plot
# @author Leo Salas \email{lsalas@@prbo.org}
makePlobjCountByDateTimeByGuild<-function(data,ttltxt="Total Counts by Date and Guild",xvar="ObservationDate"){
	xttl<-ifelse(xvar=="ObservationDate","Observation Date","Observation Time")
	p<-ggplot(data=data,aes_string(x=xvar,y="ObservationCount"))+
			geom_bar(stat="identity",width=1,colour="green",fill="green") +
			theme_bw() + labs(x=xttl,y="Total Birds Counted",legend="Guild") +
			facet_wrap(~Guild,ncol=1,scales="free_y") 
	return(p)
}

