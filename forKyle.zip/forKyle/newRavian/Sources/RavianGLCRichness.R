# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate all outputs for the estimation of richness of FixedTransect data 
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project, or study area, or transect. Valid values: project, studyarea, transect
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by season. Valid values: year, season
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one richness estimate per year per column
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
RavianGLCRichness<-function(dataObj, spatialGroup="transect", temporalGroup="year",pivot=0,...){
	
	reslst<-list()
	
	#merge the data
	dataObj<-mergeRavianData(dataObj,by="long") 
	mrg<-MergedData(dataObj)
	#eff<-EffortData(dataObj)
	#obs<-ObsData(dataObj)
	#nms<-names(eff);nms<-nms[which(nms %in% names(obs))]
	#mrg<-try(merge(eff,obs,by=nms,all.x=TRUE),silent=TRUE)
	if(inherits(mrg,"try-error")){
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error merging event and observation tables"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		mrg$ObservationCount<-ifelse(is.na(mrg$ObservationCount),0,mrg$ObservationCount)
		tg<-ifelse(temporalGroup=="year", "YearCollected", "Season")
		sg<-ifelse(spatialGroup=="transect","Transect",
				ifelse(spatialGroup=="studyarea","StudyArea","ProjectCode"))
		idvars<-unique(c("ProjectCode","ProtocolCode",sg,"YearCollected",tg))
		if(spatialGroup=="transect"){
			idvars<-unique(c("ProjectCode","ProtocolCode","StudyArea",sg,"YearCollected",tg))
		}
		rdf<-unique(mrg[,c(idvars,"SpeciesCode")])
		sdf<-unique(mrg[,c(idvars,"SpeciesCode","ObservationCount")])
		sdf<-subset(sdf,ObservationCount>0)
		
		#by spatialGroup and temporalGroup: Richness, Shannon, Simpson
		rich<-aggregate(as.formula(paste("SpeciesCode~",paste(idvars,collapse="+"),sep="")),data=rdf,FUN=NROW)
		names(rich)<-gsub("SpeciesCode","Richness",names(rich))
		#need to calculate shannon and simpson from sdf...
		#so here's the total per cat
		st1<-aggregate(as.formula(paste("ObservationCount~",paste(idvars,collapse="+"),sep="")),data=sdf,FUN=sum)
		names(st1)<-gsub("ObservationCount","TotalBirds",names(st1))
		smp<-merge(sdf,st1)
		divt1<-getDiversityIndices(smp,idvars=idvars,rich=rich)
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-paste("Summary of Diversity Indices by",sg,"and",tg)
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-divt1
		reslst<-c(reslst,tblObj)
		
		#(plot if NROW(temporal)>3 && NROW(spatial) <6)
		if(NROW(unique(divt1[,tg]))>3 && NROW(unique(divt1[,sg]))<6){
			ttltxt<-paste("Trend in richness by",sg)
			argsLst<-list(data=divt1,ttltxt=ttltxt,xvar=tg,gvar=sg)	
			#we save all the above in a graphics object and the environment and send back to Ravian
			grphObj<-new("RavianResultGraph")
			ResultTitle(grphObj)<-ttltxt
			ResultType(grphObj)<-"Graph"
			ResultGraphArgs(grphObj)<-argsLst
			ResultGraphPltFunction(grphObj)<-"makePlobjRichnessBySGandTG"
			reslst<-c(reslst,grphObj)
		}
	
	
		#by temporalGroup: Richness, Shannon, Simpson
		idvars2<-c("ProjectCode","ProtocolCode",tg)
		rich<-aggregate(as.formula(paste("SpeciesCode~",paste(idvars2,collapse="+"),sep="")),data=rdf,FUN=NROW)
		names(rich)<-gsub("SpeciesCode","Richness",names(rich))
		st2<-aggregate(as.formula(paste("ObservationCount~",paste(idvars2,collapse="+"),sep="")),data=sdf,FUN=sum)
		names(st2)<-gsub("ObservationCount","TotalBirds",names(st2))
		smp<-merge(sdf[,c("ProjectCode","ProtocolCode",tg,"ObservationCount")],st2)
		divt2<-getDiversityIndices(smp,idvars=idvars2,rich=rich)
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-paste("Summary of Diversity Indices by",tg)
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-divt2
		reslst<-c(reslst,tblObj)
		
		#(plot if NROW(temporal)>3
		if(NROW(unique(divt2[,tg]))>3){
			ttltxt<-paste("Diversity indices by",tg)
			argsLst<-list(data=divt2,ttltxt=ttltxt,idvar=idvars2,xvar=tg)	
			#we save all the above in a graphics object and the environment and send back to Ravian
			grphObj<-new("RavianResultGraph")
			ResultTitle(grphObj)<-ttltxt
			ResultType(grphObj)<-"Graph"
			ResultGraphArgs(grphObj)<-argsLst
			ResultGraphPltFunction(grphObj)<-"makePlobjRichnessByTG"
			reslst<-c(reslst,grphObj)
		}
	}
	return(reslst)
}

# Function to generate the Shannon and Simpson diversity indices
# 
# Function to generate the Shannon and Simpson diversity indices
# 
# @param df The data.frame with the data to summarize
# @param idvars The vector of variable names, all part of df, by which to summarize the data
# @param rich A data.frame with the richness data summarized by idvars already
# @author Leo Salas \email{lsalas@@prbo.org}
getDiversityIndices<-function(df,idvars,rich){
	df$pi<-df$ObservationCount/df$TotalBirds
	df$pilogpi<-df$pi*log(df$pi)
	shan<-aggregate(as.formula(paste("pilogpi~",paste(idvars,collapse="+"),sep="")),data=df,FUN=sum)
	shan$Diversity<-round(exp((-1)*shan$pilogpi),2)
	shan<-shan[,c(idvars,"Diversity")]
	df$pisq<-df$pi^2
	simp<-aggregate(as.formula(paste("pisq~",paste(idvars,collapse="+"),sep="")),data=df,FUN=sum)
	simp$Simpson<-round(1/simp$pisq,2)
	simp<-simp[,c(idvars,"Simpson")]
	divt<-merge(rich,shan);divt<-merge(divt,simp)
	return(divt)
}


# Function to generate the ggplot graph for Richness by spatial and temporal groups
# 
# Function to generate the ggplot graph for Richness by spatial and temporal groups
# 
# @param data A data.frame with the data to plot
# @param ttltxt the title of the plot
# @author Leo Salas \email{lsalas@@prbo.org}
makePlobjRichnessBySGandTG<-function(data,ttltxt="Trend in Richness",xvar="YearCollected",gvar="Transect"){
	data[,xvar]<-as.character(data[,xvar])
	p<-ggplot(data=data,aes_string(x=xvar,y="Richness")) + geom_line(aes(color=data[,gvar])) +
			labs(x="",y="# Taxa",color=gvar,title=ttltxt) 
	return(p)
}



# Function to generate the ggplot graph for diversity indices by temporal groups
# 
# Function to generate the ggplot graph for diversity indices by temporal groups
# 
# @param data A data.frame with the data to plot
# @param ttltxt the title of the plot
# @author Leo Salas \email{lsalas@@prbo.org}
makePlobjRichnessByTG<-function(data,ttltxt="Summary of Diversity Indices",idvar=c("ProjectCode","ProtocolCode","YearCollected"),xvar="YearCollected"){
	#must reshape long
	b<-reshape(data,idvar=idvar,varying=list(4:6),direction="long",times=names(data)[4:6],timevar="Index",v.names="Value")
	row.names(b)<-NULL
	b[,xvar]<-as.character(b[,xvar])
	p<-ggplot(data=b,aes_string(x=xvar,y="Value")) + geom_bar(stat="identity",aes(color=Index,fill=Index),position="dodge") +
			labs(x="",y="Index value",title=ttltxt) 
	return(p)
}