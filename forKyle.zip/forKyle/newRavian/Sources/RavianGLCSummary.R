# TODO: Add comment
# 
# Author: lsalas
###############################################################################


# Function to generate all outputs for the summary of FixedTransect data 
# 
# @param dataObj A RavianData object
# @param spatialGroup A string indicating if Ravian should analyze the data by project, or study area, or transect. Valid values: project, studyarea, transect
# @param temporalGroup A string indicating if Ravian should analyze the data by year or by season. Valid values: year, season
# @param taxonGroup Integer (0/1) indicating to Ravian to treat the guild definition as a single taxon instead of as a collection of taxa
# @param pivot Integer (0/1) indicating if the tables generated should be pivoted, and in that case, it is a wide table, with one species/guild per column, reporting only total counts
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
RavianGLCSummary<-function(dataObj, spatialGroup="project", temporalGroup="year",taxonGroup=0,pivot=0,...){
	
	reslst<-list()
	
	#merge the data
	dataObj<-mergeRavianData(dataObj,by="long") 
	mrg<-MergedData(dataObj)
	#eff<-EffortData(dataObj)
	#obs<-ObsData(dataObj)
	#nms<-names(eff);nms<-nms[which(nms %in% names(obs))]
	#mrg<-try(merge(eff,obs,by=nms,all.x=TRUE),silent=TRUE)
	if(inherits(mrg,"try-error")){
		eo<-new("RavianResultError")
		ResultTitle(eo)<-"Error merging event and observation tables"
		ResultType(eo)<-"Error"
		ErrorDescription(eo)<-paste(tsum,collapse=", ")
		SinkObjects(eo)<-list(object=data)
		ErrorDate(eo)<-as.character(Sys.time())
		reslst<-c(reslst,eo)
	}else{
		mrg$ObservationCount<-ifelse(is.na(mrg$ObservationCount),0,mrg$ObservationCount)
	
		idvars<-c("ProjectCode","ProtocolCode","StudyArea","Transect","Length_Km")
		
		#summaries:
		#1) A table of when each transect was surveyed
		tdates<-unique(mrg[,c(idvars,"ObservationDate")])
			#create the visit field
		tdates$ppt<-paste(tdates$ProjectCode,tdates$ProtocolCode,tdates$StudyArea,tdates$Transect,sep=":")	#DARN!!! How to break this dependency!
		ttdates<-data.frame()
		for(tt in unique(tdates$ppt)){
			tdf<-subset(tdates,ppt==tt)
			tdf<-tdf[order(tdf$ObservationDate),]
			tdf$Visit<-1:(nrow(tdf))
			ttdates<-rbind(ttdates,tdf)
		}
		ttdw<-reshape(ttdates[,c(idvars,"Visit","ObservationDate")],idvar=idvars,timevar="Visit",direction="wide")
		nvc<-ncol(ttdw)-NROW(idvars)
		names(ttdw)<-c(idvars,paste("Visit",1:nvc,sep=""))
		#Returning a RavianResultTable object
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Summary of Dates of Visits to Transects"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-ttdw
		reslst<-c(reslst,tblObj)
		
		#2) A table with transect, date, numObsRecords, totalbirds, total species
		ts1<-aggregate(as.formula(paste("ObservationCount~",paste(idvars, collapse="+"),"+ObservationDate",sep="")),data=mrg,FUN=NROW)
		names(ts1)<-gsub("ObservationCount","NumberOfRecords",names(ts1))
		ts2<-aggregate(as.formula(paste("ObservationCount~",paste(idvars, collapse="+"),"+ObservationDate",sep="")),data=mrg,FUN=sum,na.rm=T)
		names(ts2)<-gsub("ObservationCount","TotalObservationCount",names(ts2))
		ts3<-aggregate(as.formula(paste("SpeciesCode~",paste(idvars, collapse="+"),"+ObservationDate",sep="")),data=mrg,FUN=NROW)
		names(ts3)<-gsub("SpeciesCode","NumberOfTaxa",names(ts3))
		ttss<-merge(ts1,ts2,by=c(idvars,"ObservationDate"),all.x=T); ttss<-merge(ttss,ts3,by=c(idvars,"ObservationDate"),all.x=T)
		ttss$NumberOfTaxa<-ifelse(is.na(ttss$NumberOfTaxa),0,ttss$NumberOfTaxa)
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Total records, birds counted, and taxa detected per visit to Transect"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-ttss
		reslst<-c(reslst,tblObj)
		
		#3) A table with transect, totalbirds, total species
		tsb1<-aggregate(as.formula(paste("ObservationCount~",paste(idvars, collapse="+"),sep="")),data=mrg,FUN=sum,na.rm=T)
		names(tsb1)<-gsub("ObservationCount","TotalObservationCount",names(tsb1))
		tsb2<-aggregate(as.formula(paste("SpeciesCode~",paste(idvars, collapse="+"),sep="")),data=mrg,FUN=NROW)
		names(tsb2)<-gsub("SpeciesCode","NumberOfTaxa",names(tsb2))
		ttsb<-merge(tsb1,tsb2,by=idvars,all.x=T)
		ttsb$NumberOfTaxa<-ifelse(is.na(ttsb$NumberOfTaxa),0,ttsb$NumberOfTaxa)
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Total birds counted and taxa detected per Transect"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-ttsb
		reslst<-c(reslst,tblObj)
		
		#4) A table (and graph) of total counts by species
		tcsp<-aggregate(as.formula("ObservationCount~CommonName"),data=mrg,FUN=sum,na.rm=T)
		names(tcsp)<-gsub("ObservationCount","TotalObservationCount",names(tcsp))
		tblObj<-new("RavianResultTable")
		ResultTitle(tblObj)<-"Total birds counted per taxa detected overall"
		ResultType(tblObj)<-"Table"
		ResultTable(tblObj)<-tcsp
		reslst<-c(reslst,tblObj)
		
		#plot only if less than 10 taxa and minmax is less than 10-fold
		mmx<-max(tcsp$TotalObservationCount)/min(tcsp$TotalObservationCount)
		if(nrow(tcsp<11) && mmx<10){ #plot
			ttltxt<-"Total Counts Per Species"
			argsLst<-list(data=tcsp,ttltxt=ttltxt)	#,collbl=collbl
			#we save all the above in a graphics object and the environment and send back to Ravian
			grphObj<-new("RavianResultGraph")
			ResultTitle(grphObj)<-ttltxt
			ResultType(grphObj)<-"Graph"
			ResultGraphArgs(grphObj)<-argsLst
			ResultGraphPltFunction(grphObj)<-"makeCountsBySpeciesPlobj"
			reslst<-c(reslst,grphObj)
		}
		
		#5) plots of survey conditions...
	}
	return(reslst)
}

# Function to generate the ggplot graph for Total Counts per Species
# 
# Function to generate the ggplot graph for Total Counts per Species
# 
# @param data A data.frame with the data to plot
# @param ttltxt the title of the plot
# @author Leo Salas \email{lsalas@@prbo.org}
makeCountsBySpeciesPlobj<-function(data,ttltxt="Total Counts Per Species"){
	p<-ggplot(data=data,aes(x=CommonName,y=TotalObservationCount)) + geom_bar(stat="identity",color="light blue",fill="light blue") +
			labs(x="",y="Total birds counted",title=ttltxt) + coord_flip()
	return(p)
}
			