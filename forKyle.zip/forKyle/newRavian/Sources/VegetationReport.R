# TODO: Add comment
# 
# Author: lsalas
###############################################################################

#Spatially: always by unit
#Temporally: Selecting start and end years
#No regions or protocols or species selections
#No grouping by year or project or season

#This vegetation report must report on: 
#	Relative percent cover by annual and perennial vegetation
#	List of dominant plant species based on relative cover of individual plant species (50/20 rule)
#	Seed production index values based on seed head size, seed head density, and percent cover estimates for individual plant species (same as above)
#	Summary table, adding up SPI by unit

# Function to generate all outputs for vegetation report
# 
# Function to generate all outputs for vegetation report
# 
# @param dataObj A Ravian data object
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
VegetationReport<-function(dataObj, ...){
	#This needs to report on: 
	# T1: relative percent cover by annual and perennial vegetation
	# T2: list of dominant plant species (as determined by the Army Corps 50/20 rule)
	# T3: seed production index value, based on seed head size, seed head density, and percent cover estimate for each plant
	
	#so, first get the data
	eff<-EffortData(dataObj)
	obs<-ObsData(dataObj)
	data<-merge(eff,obs,all.x=TRUE)
	
	res.lst<-list()
	
	#First a summary table with where, when, who and how many
	tsum<-getSurveySummary(data)
	if(!inherits(tsum,"try-error")){
		summTblObj<-new("RavianResultTable")
		ResultTitle(summTblObj)<-paste("Annual Vegetation Summary")
		ResultType(summTblObj)<-"Table"
		ResultTable(summTblObj)<-tsum
		res.lst<-c(res.lst,summTblObj)
	}
	
	#T1 - relative percent cover	
	rpcd<-data
	t1t<-rpcd[,c("ProjectName","PlotName","AreaSurveyed","YearCollected","ScientificName","PlantPct","EmergentPct")]
	names(t1t)<-c("Project","Unit","AreaSurveyed_m2","Year","ScientificName","PlantPct","EmergentCover")
	#######
	t1<-data.frame()
	for(uu in unique(t1t$Unit)){
		tdf<-subset(t1t,Unit==uu)
		for(yy in unique(tdf$Year)){
			tdfy<-subset(tdf,Year==yy)
			tpc<-sum(tdfy$PlantPct,na.rm=TRUE)
			#tdf$RelativePctCover<-laply(.data=unique(tdfy$ScientificName),.fun=function(ss,df,tpc){
			#			spcov<-subset(df,ScientificName==ss,select="PlantPct")
			#			relcov<-ifelse(is.na(spcov),NA,as.numeric(as.character(spcov))/tpc)
			#			relcov<-round(relcov*100,digits=1)
			#			return(relcov)
			#		},df=tdfy,tpc=tpc)
			for(ss in unique(tdfy$ScientificName)){
				spcov<-subset(tdfy,ScientificName==ss)
				relcov<-ifelse(is.na(spcov$PlantPct),NA,as.numeric(as.character(spcov$PlantPct))/tpc)
				relcov<-round(relcov*100,digits=1)
				spcov$RelativePctCover<-relcov
				t1<-rbind(t1,spcov)
			}
			#t1<-rbind(t1,tdf)
		}
		
	}
	#######
	#t1$RelativePctCover<-ifelse(is.na(t1$EmergentCover),NA,
	#		ifelse(is.na(t1$PlantPct),NA,round(t1$EmergentCover*t1$PlantPct/100,digits=1)))
	#t1$PlantAreaCovered_Ha<-round(t1$RelativePctCover*t1$AreaSurveyed/1000000,digits=1)

	
	#T2 - dominant species 50/20: 
	t2<-rpcd[,c("ProjectName","PlotName","YearCollected","ScientificName","PlantPct","SeedHeadSizeDensityCd")]
	tt2<-data.frame()
	for(uu in unique(t2$PlotName)){
		tmpu<-subset(t2,PlotName==uu)
		for(yy in unique(tmpu$YearCollected)){
			tmpuy<-subset(tmpu,YearCollected==yy)
			t2tmp<-tmpuy[order(tmpuy$PlantPct,decreasing=TRUE),]
			t2tmp$CumulativePercentEmergent<-sapply(1:nrow(t2tmp),calcCumPct,t2tmp)
			ttlpctcover<-sum(t2tmp$PlantPct); threshDominant50<-ttlpctcover*0.5
			#...and the 20% rule...
			threshDominant20<-ttlpctcover*0.2
			t2tmp$Dominant<-ifelse(t2tmp$CumulativePercentEmergent<=threshDominant50,"Yes",
					ifelse(t2tmp$PlantPct>=threshDominant20,"Yes","No"))
			t2tmp<-t2tmp[,c("ProjectName","PlotName","YearCollected","ScientificName","Dominant")]
			names(t2tmp)<-c("Project","Unit","Year","ScientificName","Dominant")
			tt2<-rbind(tt2,t2tmp)
		}
	}
	#this is ready to merge with t1
	
	#T3 - SPI: see calculatins in VegReport_test_HarrisNeck.xlsx
	spidat<-data[,c("ProjectName","PlotName","YearCollected","ScientificName","DuckFoodInd","SeedHeadSizeCd","SeedHeadSizeDensityCd")]
	names(spidat)<-c("Project","Unit","Year","ScientificName","DuckFoodInd","SeedHeadSizeCd","SeedHeadSizeDensityCd")
	spidat<-subset(spidat,DuckFoodInd==1)
	if(nrow(spidat)>0){
		spidat<-merge(spidat,t1t[,c("Project","Unit","Year","ScientificName","PlantPct","EmergentCover")],
				by=c("Project","Unit","Year","ScientificName"),all.x=TRUE)
		spidat$RelativePctCover<-spidat$PlantPct*spidat$EmergentCover/100
		spidat$QualityScore<-sapply(1:nrow(spidat),calcQS,spidat)
		spidat$SeedProductionIndex<-sapply(1:nrow(spidat),calcSPI,spidat)
		t3<-spidat[,c("Project","Unit","Year","ScientificName","QualityScore","SeedProductionIndex")]
	}else{
		t3<-unique(data[,c("ProjectName","PlotName","YearCollected","ScientificName")])
		names(t3)<-c("Project","Unit","Year","ScientificName")
		t3$QualityScore<-NA;t3$SeedProductionIndex<-0
	}
	
	###################################################
	## Reporting...
	avTable<-merge(t1,tt2,by=c("Project","Unit","Year","ScientificName"),all.x=TRUE)
	#avTable<-merge(avTable,t3,by=c("Project","Unit","Year","ScientificName"),all.x=TRUE)
	avTblObj<-new("RavianResultTable")
	ResultTitle(avTblObj)<-paste("Annual Vegetation Report")
	ResultType(avTblObj)<-"Table"
	ResultTable(avTblObj)<-avTable
	res.lst<-c(res.lst,avTblObj)
	
	###Edits per Linda's request zen 358
	#spidat<-subset(t3,!is.na(SeedProductionIndex))
	#if(nrow(spidat)>0){
	#	spiTable<-aggregate(as.formula("SeedProductionIndex~Project+Unit+Year"),data=spidat,FUN=sum)
	#	spiTable<-spiTable[,c("Project","Unit","Year","SeedProductionIndex")]
	#	names(spiTable)<-c("Project","Unit","Year","TotalSeedProductionIndex")
	#	spiTblObj<-new("RavianResultTable")
	#	ResultTitle(spiTblObj)<-paste("Seed Production Index Report")
	#	ResultType(spiTblObj)<-"Table"
	#	ResultTable(spiTblObj)<-spiTable
	#}else{
	#	spiTblObj<-new("RavianResultWarning")
	#	ResultTitle(spiTblObj)<-"Warning - the request for analyses contained no duck food plants, or if any present, these lacked the necessary information to calculate the SPI."
	#	ResultType(spiTblObj)<-"Warning"
	#	WarningDescription(spiTblObj)<-"There were no plants with DuckFoodInd==1 or those present lacked the necessary information. Therefore, there is no estimate of SeedProductionInd to report."	
	#}
	#######
	
	spiTable<-aggregate(as.formula("SeedProductionIndex~Project+Unit+Year"),data=t3,FUN=sum)
	spiTable<-spiTable[,c("Project","Unit","Year","SeedProductionIndex")]
	names(spiTable)<-c("Project","Unit","Year","TotalSeedProductionIndex")
	spiTblObj<-new("RavianResultTable")
	ResultTitle(spiTblObj)<-paste("Seed Production Index Report")
	ResultType(spiTblObj)<-"Table"
	ResultTable(spiTblObj)<-spiTable
	res.lst<-c(res.lst,spiTblObj)
	
	## Per Linda's request, now changing this behavior (zen 358):
	if(sum(spiTable$TotalSeedProductionIndex==0)>0){
		noSPIObj<-new("RavianResultWarning")
		ResultTitle(noSPIObj)<-"Warning - the request for analyses contained some/all units with Seed Production Index = 0."
		ResultType(noSPIObj)<-"Warning"
		WarningDescription(noSPIObj)<-"There were no plants with DuckFoodInd==1 in some/all units, or those present lacked the necessary information to calculate the Seed Production Index."
		res.lst<-c(res.lst,noSPIObj)
	}
	########################
	
	for(uu in unique(avTable$Unit)){
		tmpu<-subset(avTable,Unit==uu)
		for(yy in unique(tmpu$Year)){
			df<-subset(tmpu,Year==yy)
			ttltxt<-paste("Plant Percent Cover for",uu,"and Year",yy)
			argsLst<-list(df=df,ttltxt=ttltxt)
			
			grphObj<-new("RavianResultGraph")
			ResultTitle(grphObj)<-ttltxt
			ResultType(grphObj)<-"Graph"
			ResultGraphArgs(grphObj)<-argsLst
			ResultGraphPltFunction(grphObj)<-"makePercentCoverPlot"
			res.lst<-c(res.lst,grphObj)
		}
	}
	
	return(res.lst)
	
}

# Function to generate the overall summaries table for Annual Vegetation Survey report
# 
# @param data A data frame, with effort and observation data merged "long"
getSurveySummary<-function(data){
	tsa<-aggregate(as.formula("PlantPct~ProjectName+PlotName+ObservationDate+ScientificName+LifeStrategy"),data=data,FUN=sum)
	tsa$LifeStrategy<-ifelse(grepl("Annual",tsa$LifeStrategy),"Annual","Perennial")
	ts0<-aggregate(as.formula("ScientificName~ProjectName+PlotName+ObservationDate"),data=tsa,FUN=NROW)
	names(ts0)<-c("Project","Unit","DateVisited","TotalPlantSpecies")
	tsa$PlantPct<-tsa$PlantPct/100
	tsa<-subset(tsa,PlantPct>0 & !is.na(PlantPct) & !is.null(PlantPct) & !is.nan(PlantPct))
	ts1<-aggregate(as.formula("PlantPct~ProjectName+PlotName+ObservationDate"),data=tsa,FUN=function(x){round(exp(-1*sum(x*log(x))),2)})
	names(ts1)<-c("Project","Unit","DateVisited","DiversityInd")
	ts2<-aggregate(as.formula("PlantPct~ProjectName+PlotName+ObservationDate+LifeStrategy"),data=tsa,FUN=sum)
	names(ts2)<-c("Project","Unit","DateVisited","LifeStrategy","PctCoverSum")
	ts2s<-data.frame()
	for(pp in unique(ts2$Project)){
		pdf<-subset(ts2,Project==pp)
		for(uu in unique(pdf$Unit)){
			pudf<-subset(pdf,Unit==uu)
			for(dd in unique(as.character(pudf$DateVisited))){
				puddf<-subset(pudf,DateVisited==dd)
				anv<-round(as.numeric(subset(puddf,LifeStrategy=="Annual")$PctCoverSum)*100)
				if(NROW(anv)==0){anv<-0}
				pnv<-round(as.numeric(subset(puddf,LifeStrategy=="Perennial")$PctCoverSum)*100)
				if(NROW(pnv)==0){pnv<-0}
				apcov<-paste("A:",anv,"/P:",pnv,sep="")
				tdf<-data.frame(Project=pp,Unit=uu,DateVisited=dd,AnnPerCoverPct=apcov)
				ts2s<-rbind(ts2s,tdf)
			}
		}
	}
	
	tsum<-merge(ts0,ts1,all.x=TRUE)
	tsum<-merge(tsum,ts2s,all.x=TRUE)
	return(tsum)
}

# Function to calculate the Quality Score of duck food items
#
# @param x A row in the data.frame being processed (using a ply function)
# @param df The data.frame being processed
calcQS<-function(x,df){
	#see evernote and e-mail from TJones on Jan21
	hs<-df[x,"SeedHeadSizeCd"]	#LSA
	hd<-df[x,"SeedHeadSizeDensityCd"] #HML
	if(is.na(hs) || is.na(hd)){
		qs<-NA
	}else{
		hsv<-ifelse(hs=="S",1,2)
		hdv<-ifelse(hd=="H",2,ifelse(hd=="M",1,0))
		qs<-hsv+hdv
	}
	return(qs)
}

# Function to calculate the Seed Production Index of duck food items
#
# @param x A row in the data.frame being processed (using a ply function)
# @param df The data.frame being processed
calcSPI<-function(x,df){
	pc<-df[x,"RelativePctCover"]
	qs<-df[x,"QualityScore"]
	if(is.na(pc) ||  is.na(qs)){
		spi<-0
	}else{
		#this partition of area scores is in TJones email of 12/31.
		as<-ifelse(pc<11,1,
				ifelse(pc<26,2,
						ifelse(pc<51,3,
								ifelse(pc<76,4,5))))
		spi<-as*qs
	}
	return(spi)	
}

# Function to calculate the Cumularive Percent of Emergent Plant Cover
#
# @param x A row in the data.frame being processed (using a ply function)
# @param df The data.frame being processed
calcCumPct<-function(x,df){
	if(x==1){
		cpc<-df[x,"PlantPct"]
	}else{
		apc<-as.numeric(df$PlantPct)
		gpc<-apc[1:x]
		cpc<-sum(gpc,na.rm=TRUE)
	}
	return(cpc)
}

# Function to generate the dot plot of Plant Percent Cover
#
# @param df The data.frame being plotted
# @param ttltxt A string with the title of the plot
makePercentCoverPlot<-function(df,ttltxt){
	df<-df[order(df$PlantPct),]
	df$orderingVal<-c(1:nrow(df))
	
	df<-within(df,{
				ScientificName<-reorder(ScientificName,orderingVal)
			})
	if(nrow(df)>20){
		df<-subset(df,orderingVal>(nrow(df)-20))
		ttltxt<-paste(ttltxt,"(top 20)")
	}
	df$Dominance<-ifelse(df$Dominant=="Yes","Dominant","Non-dominant")
	p<-ggplot(data=df,aes(x=ScientificName,y=PlantPct)) + 
			geom_point(aes(color=Dominance)) + 
			geom_segment(aes(y=0,yend=PlantPct,xend=ScientificName,color=Dominance)) + 
			theme_bw() + labs(x="",y="Plant %Cover",title=ttltxt) +
			theme(axis.text.x=element_text(size=10)) +
			theme(axis.text.y=element_text(size=10)) +
			theme(axis.title.x=element_text(size=12)) +
			theme(axis.title.y=element_text(size=12)) +
			theme(plot.title=element_text(size=11)) +
			coord_flip() 
	return(p)
}

