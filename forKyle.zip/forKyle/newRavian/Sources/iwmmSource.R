# TODO: Add comment
# 
# Author: lsalas
###############################################################################


########################################################################################################################
###									BirdObservations
########################################################################################################################

# Function to generate all outputs for BirdObservations report
# 
# Function to generate all outputs for BirdObservations report
# 
# @param iwmmObject An IWMMData object
# @param outType String specifying the output requested - only "table" or "graph" allowed. Defaults to table.
# @param outputFormat String indicating the specific table or graph requested (by location-year or unit-year; i.e., Plot or StudyArea), defaults to all.
# @param taxon.groups.name String providing the name (i.e., column name) of the taxon/guild grouping variable
# @param spatial.groups.name String providing the name (i.e., column name) of the spatial grouping variable
# @param observation.groups.name String providing the name (i.e., column name) of the observation grouping variable
# @param htout String indicating the format of the output. If "y" (default), output is html. Else it is javascript (highcharts for graph, jquery table for tables)
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
BirdObservations<-function(iwmmObject, outType="table", outputFormat="all", taxon.groups.name="", spatial.groups.name="", observation.groups.name="",htout="y",pivot="n",...){
	#being called from Report, we know the object must be an IWMM data object and must have data, so...
	
	#merge the data
	data<-as.data.frame(iwmmObject,by="merged")
	data$StudyArea<-data$ProjectName
	xvar<-ifelse(taxon.groups.name=="","Species",taxon.groups.name)
	data$PlotAreaSqMeters<-ifelse(is.null(data$PlotAreaSqMeters)|is.na(data$PlotAreaSqMeters),1200,data$PlotAreaSqMeters)
	
	#calculate overall values for taxon or taxon.group based on outputFormat: frequency,avgCount,avgAbundance,birdsPerHour,maxCount,totalCount
	#(we will ignore these for now and produce them all)
	#BUT... considering also spatial.groups, and observation.groups
	if(outType=="table"){
		if(outputFormat=="byUnitDate" | outputFormat=="all"){
			byUnitDate<-getSummaries(dat=data,agg.space="PlotName",agg.time="ObservationDate",taxon.groups.name,spatial.groups.name,observation.groups.name)
			id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			capt<-paste("<h3>","Summaries by Unit and Date","</h3>");idval1<-id1
			tb1<-makeIWMMtable(df=byUnitDate,fmt="html",capt=capt,idval1)
			#jsid1<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
			#    "\n  <script type=\"text/javascript\">\n  $(document).ready(function() {\n  $('#",idval1,"').DataTable();\n  } );\n  </script>\n  ",sep="")
		}else{
			tb1<-""
			#jsid1<-""
		}
		if(outputFormat=="byUnitYear" | outputFormat=="all"){
			byUnitYear<-getSummaries(dat=data,agg.space="PlotName",agg.time="YearCollected",taxon.groups.name,spatial.groups.name,observation.groups.name)
			if(pivot=="y"){byUnitYear<-makePivot(df=byUnitYear,agg.space="PlotName",xvar)}
			id2<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			capt<-paste("<h3>","Summaries by Unit and Year","</h3>");idval2<-id2
			tb2<-makeIWMMtable(df=byUnitYear,fmt="html",capt=capt,idval2)
			#jsid2<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
			#    "\n  <script type=\"text/javascript\">\n  $(document).ready(function() {\n  $('#",idval2,"').DataTable();\n  } );\n  </script>\n ",sep="")
		}else{
			tb2<-""
			#jsid2<-""
		}
		if(outputFormat=="bySiteDate" | outputFormat=="all"){
			bySiteDate<-getSummaries(dat=data,agg.space="StudyArea",agg.time="ObservationDate",taxon.groups.name,spatial.groups.name,observation.groups.name)
			id3<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			capt<-paste("<h3>","Summaries by Site and Date","</h3>");idval3<-id3
			tb3<-makeIWMMtable(df=bySiteDate,fmt="html",capt=capt,idval3)
			#jsid3<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
			#    "\n  <script type=\"text/javascript\">\n  $(document).ready(function() {\n  $('#",idval3,"').DataTable();\n  } );\n  </script>\n ",sep="")
		}else{
			tb3<-""
			#jsid3<-""
		}
		if(outputFormat=="bySiteYear" | outputFormat=="all"){
			bySiteYear<-getSummaries(dat=data,agg.space="StudyArea",agg.time="YearCollected",taxon.groups.name,spatial.groups.name,observation.groups.name)
			if(pivot=="y"){bySiteYear<-makePivot(df=bySiteYear,agg.space="StudyArea",xvar)}
			id4<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			capt<-paste("<h3>","Summaries by Site and Year","</h3>");idval4<-id4
			tb4<-makeIWMMtable(df=bySiteYear,fmt="html",capt=capt,idval4)
			#jsid4<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
			#    "\n  <script type=\"text/javascript\">\n  $(document).ready(function() {\n  $('#",idval4,"').DataTable();\n  } );\n  </script>\n ",sep="")
		}else{
			tb4<-""
			#jsid4<-""
		}
		
		if(outputFormat=="byYear" | outputFormat=="all"){
			byYear<-getSummaries(dat=data,agg.space="Locations",agg.time="YearCollected",taxon.groups.name,spatial.groups.name,observation.groups.name)
			if(pivot=="y"){byYear<-makePivot(df=byYear,agg.space="Locations",xvar)}
			id5<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			capt<-paste("<h3>","Summaries by Year (all locations)","</h3>");idval5<-id5
			tb5<-makeIWMMtable(df=byYear,fmt="html",capt=capt,idval5)
			#jsid5<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
			#    "\n  <script type=\"text/javascript\">\n  $(document).ready(function() {\n  $('#",idval5,"').DataTable();\n  } );\n  </script>\n  ",sep="")
		}else{
			tb5<-""
			#jsid5<-""
		}
		
		
		htv<-ifelse(tolower(formData$htout)=="y","html","js")
		if(formData$outType=="table" & htv=="html"){
			res<-paste(tb1,tb2,tb3,tb4,tb5)
		}else{
			res<-paste(tb1,tb2,tb3,tb4)
		}
	}else{ #graph output
		if(grepl("Unit",outputFormat,fixed=TRUE)==TRUE){
			aggvar<-"UnitYear"
			plot.df<-getSummaries(dat=data,agg.space="PlotName",agg.time="YearCollected",taxon.groups.name,spatial.groups.name,observation.groups.name)
			plot.df$UnitYear<-paste(plot.df$Unit,plot.df$YearCollected,sep="")
			if(NROW(unique(plot.df$Unit))>10){
				uu<-unique(as.character(plot.df$Unit))[1:10]
				plot.df<-subset(plot.df,as.character(Unit) %in% uu)
			}
		}else if(grepl("Site",outputFormat,fixed=TRUE)==TRUE){
			aggvar<-"SiteYear"
			plot.df<-getSummaries(dat=data,agg.space="StudyArea",agg.time="YearCollected",taxon.groups.name,spatial.groups.name,observation.groups.name)
			plot.df$SiteYear<-paste(plot.df$Site,plot.df$YearCollected,sep="")
			if(NROW(unique(plot.df$Site))>10){
				uu<-unique(as.character(plot.df$Site))[1:10]
				plot.df<-subset(plot.df,as.character(Site) %in% uu)
			}
		}else if(outputFormat=="byYear"){
			aggvar<-"LocationYear"
			plot.df<-getSummaries(dat=data,agg.space="Locations",agg.time="YearCollected",taxon.groups.name,spatial.groups.name,observation.groups.name)
			plot.df$LocationYear<-paste(plot.df$Locations,plot.df$YearCollected,sep="")
			if(NROW(unique(plot.df$Site))>10){
				uu<-unique(as.character(plot.df$Site))[1:10]
				plot.df<-subset(plot.df,as.character(Site) %in% uu)
			}
		}else{
			res<-"Error: Invalid output format specified."
			return(res)
		}
		#will create dot plots (two)
		#if unit or site <= 10 - mapped to color. If exceeds, then using first 10
		#In plot 1, the dot will be the average by year
		#In plot 2, the dot will be the max count by year
		#Each row is a taxon
		
		#Here loop by spatial/obs
		res.lst<-list(); res<-character()
		if(spatial.groups.name!=""){
			sgg<-unique(plot.df[,spatial.groups.name])
			for(sss in sgg){
				splot.df<-subset(plot.df,plot.df[,spatial.groups.name]==sss)
				if(observation.groups.name!=""){
					ogg<-unique(splot.df[,observation.groups.name])
					for(ooo in ogg){
						osplot.df<-subset(splot.df,splot.df[,observation.groups.name]==ooo)
						res.lst.tmp<-createBirdAbundGraphs(htout=htout,pdf=osplot.df,xvar=xvar,aggvar=aggvar,ogn=ooo,sgn=sss)
						if(htout=="n"){
							res.lst<-c(res.lst,res.lst.tmp)
						}else{
							res<-paste(res,res.lst.tmp)
						}
					}		
				}else{
					res.lst.tmp<-createBirdAbundGraphs(htout=htout,pdf=splot.df,xvar=xvar,aggvar=aggvar,sgn=sss)
					if(htout=="n"){
						res.lst<-c(res.lst,res.lst.tmp)
					}else{
						res<-paste(res,res.lst.tmp)
					}			
				}
			}
		}else if(observation.groups.name!=""){
			ogg<-unique(plot.df[,observation.groups.name])
			for(ooo in ogg){
				osplot.df<-subset(plot.df,plot.df[,observation.groups.name]==ooo)
				res.lst.tmp<-createBirdAbundGraphs(htout=htout,pdf=osplot.df,xvar=xvar,aggvar=aggvar,ogn=ooo)
				if(htout=="n"){
					res.lst<-c(res.lst,res.lst.tmp)
				}else{
					res<-paste(res,res.lst.tmp)
				}
			}	
		}else{
			res.lst.tmp<-createBirdAbundGraphs(htout=htout,pdf=plot.df,xvar=xvar,aggvar=aggvar)
			if(htout=="n"){
				res.lst<-res.lst.tmp
			}else{
				res<-res.lst.tmp
			}
		}
		
		if(htout=="n"){res<-createTextResult(res.lst)}
		
	}
	
	if(class(res)=="character" & NROW(res)>1){res<-paste(res,collapse=" ")}
	return(res)
	#then return df or plot: e.g., frequency vs. date, a line per taxon (max 10, different colors), 
	# but facet.wrap/facet.grid by spatial.groups and observation.groups OJO!!!
	
}

getSummaries<-function(dat,agg.space="PlotName",agg.time="ObservationDate",taxon.groups.name,spatial.groups.name,observation.groups.name){
	if(agg.space=="Locations"){
		dat$Locations<-"All Sites and Units"
	}
	fml.t<-paste("ObservationCount~",agg.space,"+",agg.time,sep="")
	fml.m<-paste("SurveyDurationMinutes~",agg.space,"+",agg.time,sep="")
	fml.a<-paste("PlotAreaSqMeters~",agg.space,"+",agg.time,sep="")
	agg.space.name<-ifelse(agg.space=="PlotName","Unit",ifelse(agg.space=="StudyArea","Site","Locations"))
	res.nam<-c(agg.space.name,agg.time)
	if(taxon.groups.name!=""){
		fml.t<-paste(fml.t,"+TaxonGroup",sep="")
		res.nam<-c(res.nam,taxon.groups.name)	#Or just use "Guild" here?
	}else{
		fml.t<-paste(fml.t,"+CommonName",sep="")
		res.nam<-c(res.nam,"Species")
	}
	if(spatial.groups.name!=""){
		fml.t<-paste(fml.t,"+SpatialGroup",sep="")
		res.nam<-c(res.nam,spatial.groups.name)
	}
	if(observation.groups.name!=""){
		fml.t<-paste(fml.t,"+ObservationsGroup",sep="")
		res.nam<-c(res.nam,observation.groups.name)
	}
	grandtotal<-sum(dat$ObservationCount,na.rm=TRUE)
	counts<-aggregate(as.formula(fml.t),data=dat,FUN=sum,na.rm=TRUE)	#this is totalCount
	
	names(counts)<-c(res.nam,"Count")
	counts$Frequency<-round(counts$Count/grandtotal,digits=4)						#this is frequency
	
	avg.count<-aggregate(as.formula(fml.t),data=dat,FUN=mean,na.rm=TRUE) #this is average count
	names(avg.count)<-c(res.nam,"avgCount")
	avg.count$avgCount<-round(avg.count$avgCount,digits=3)
	countavg<-merge(counts,avg.count,by=res.nam,all.x=TRUE)
	
	max.count<-aggregate(as.formula(fml.t),data=dat,FUN=max,na.rm=TRUE) #this is max count
	names(max.count)<-c(res.nam,"maxCount")
	countavgmax<-merge(countavg,max.count,by=res.nam,all.x=TRUE)
	
	dat$SurveyDurationMinutes<-ifelse(is.na(dat$SurveyDurationMinutes),0,dat$SurveyDurationMinutes)
	total.survey.mins<-aggregate(as.formula(fml.m),data=dat,FUN=sum,na.rm=TRUE)
	names(total.survey.mins)<-c(agg.space.name,agg.time,"SurveyDurationMinutes")
	countavgmaxtime<-merge(countavgmax,total.survey.mins,by=c(agg.space.name,agg.time),all.x=TRUE)
	countavgmaxtime$SurveyDurationHours<-round(countavgmaxtime$SurveyDurationMinutes/60,digits=4)
	countavgmaxtime$BirdsPerHour<-round(countavgmaxtime$Count/countavgmaxtime$SurveyDurationHours,digits=0)	#this is birds per hour
	
	dat$PlotAreaSqMeters<-ifelse(is.na(dat$PlotAreaSqMeters),0,dat$PlotAreaSqMeters)
	total.survey.area<-aggregate(as.formula(fml.a),data=dat,FUN=sum,na.rm=TRUE)
	names(total.survey.area)<-c(agg.space.name,agg.time,"PlotAreaSqMeters")
	countavgmaxta<-merge(countavgmaxtime,total.survey.area,by=c(agg.space.name,agg.time),all.x=TRUE)
	countavgmaxta$SurveyAreaHectares<-round(countavgmaxta$PlotAreaSqMeters/10000,digits=2)
	countavgmaxta$BirdsPerHectare<-ifelse(countavgmaxta$SurveyAreaHectares==0,NA,round(countavgmaxta$Count/countavgmaxta$SurveyAreaHectares,digits=2))	#this is avgAbundance
	countavgmaxta<-countavgmaxta[,c(names(countavgmax),"BirdsPerHour","BirdsPerHectare")]
	countavgmaxta<-countavgmaxta[order(countavgmaxta[,res.nam[1]],countavgmaxta[,res.nam[2]],countavgmaxta[,res.nam[3]]),]
	return(countavgmaxta)
	
}

createTextResult<-function(res.lst){
	#grep for error. If there is one, report and skip all this
	if(class(res.lst)=="list"){
		titlePlots<-"Bird Observations Report"
		
		#res.txt<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
		#		"<script src=\"http://code.highcharts.com/highcharts.js\"></script>\n  ",sep="")
		res.txt<-""
		divdeclarations<-character()
		for(pp in 1:(NROW(res.lst))){
			plt<-res.lst[[pp]]
			if(class(plt)=="Highcharts"){
				idpl<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
				if(class(plt)=="Highcharts"){
					p1<-plt$html(idpl)
					pw1<-paste(substr(p1,1,regexpr("chart ",p1)-1),paste("chart_",idpl," ",sep=""),substr(p1,regexpr("chart ",p1)+6,nchar(p1)),sep="")
					res.txt<-paste(res.txt,pw1,sep="")
					divval1<-paste("<div id=\"",idpl,"\"></div>\n ",sep="")
					divdeclarations<-c(divdeclarations,divval1)
				}
			}
		}
		tail<-paste(divdeclarations,sep="")
		res.txt<-paste(res.txt,tail,sep="")
		return(res.txt)
	}
}

makePivot<-function(df,agg.space,xvar){
	if(agg.space=="PlotName"){
		prep<-df[,c("Unit","YearCollected",xvar,"Count")]
		#must reshape by unit.year and cbind...
		prep$UnitYear<-paste(prep$Unit,prep$YearCollected,sep="")
		pivot.df<-as.data.frame(unique(prep[,c(xvar)]));names(pivot.df)<-xvar
		for(uu in unique(prep$Unit)){
			subp<-subset(prep,Unit==uu)
			tpvt<-reshape(subp[c(xvar,"UnitYear","Count")],v.names="Count",idvar=c(xvar),timevar="UnitYear",direction="wide")
			pivot<-merge(pivot.df,tpvt,by=c(xvar),all.x=TRUE)
		}
	}else if(agg.space=="ProjectName"){
		prep<-df[,c("Site","YearCollected",xvar,"Count")]
		#must reshape by unit.year and cbind...
		prep$SiteYear<-paste(prep$Site,prep$YearCollected,sep="")
		pivot.df<-unique(prep[,c(xvar)])
		for(ss in unique(prep$Site)){
			subp<-subset(prep,Site==ss)
			tpvt<-reshape(subp[c(xvar,"SiteYear","Count")],v.names="Count",idvar=c(xvar),timevar="SiteYear",direction="wide")
			pivot.df<-merge(pivot.df,tpvt,by=c(xvar),all.x=TRUE)
		}
	}else{
		prep<-df[,c("YearCollected",xvar,"Count")]
		pivot.df<-reshape(prep,v.names="Count",idvar=c(xvar),timevar="YearCollected",direction="wide")
	}
	return(pivot.df)
}

createBirdAbundGraphs<-function(htout,pdf,xvar,aggvar,ogn="",sgn=""){	
	aggvttl<-substr(aggvar,1,regexpr("Year",aggvar,fixed=TRUE)-1)
	capt1<-paste("Average detections by",aggvttl,"and Year")
	capt2<-paste("Maximum detections by",aggvttl,"and Year")
	if(sgn!=""){
		capt1<-paste(capt1,"for",sgn)
		capt2<-paste(capt2,"for",sgn)
		if(ogn!=""){
			capt1<-paste(capt1,"and",ogn)
			capt2<-paste(capt2,"and",ogn)
		}
	}else if(ogn!=""){
		capt1<-paste(capt1,"for",ogn)
		capt2<-paste(capt2,"for",ogn)
	}else{}
	
	if(htout=="n"){ 	#in javascript - Highcharts
		#A list object with the following elements: df (data.frame), x (x-axis parameter), y (y-axis parameter), 
		# 		type (character vector with the plot types: line, bubble, scatter, spline - see highcharts for more detail), group (grouping parameter, deterimining the number and colors of lines, etc.),
		# 		size (parameter altering the size of bubbles, if using bubbles or other scalable icons). This is all for now, until package is better developed.
		# 		title (string with title)
		pldata<-list(
				df=pdf,
				x=xvar,
				y="avgCount",
				type="scatter",
				group=aggvar,
				size=2,
				title=capt1)
		pp<-try(create.HighchartGraph(pldata),silent=TRUE)
		if(!inherits(pp,"try-error")){
			#p2 is "protected" by pp - if pp works, p2 will too
			pldata$y<-"maxCount"
			pldata$title<-capt2
			
			p2<-create.HighchartGraph(pldata)
			
			res.lst.tmp<-list(pp,p2)
			
		}else{
			pp<-"Error creating graph"
			res.lst.tmp<-list(pp)
		}
		
	}else{	#base64 encoded png
		assign("aggvar",aggvar,envir=.GlobalEnv)
		assign("xvar",xvar,envir=.GlobalEnv)
		#x can be taxon.group
		p1<-ggplot(data=pdf,aes_string(x=xvar,y="avgCount")) + geom_point(aes(colour=get(aggvar)),size=2.5) + labs(y="Average Count", x="", colour=aggvar) +
				theme(axis.text.x=element_text(size=10)) + coord_flip()
		p2<-ggplot(data=pdf,aes_string(x=xvar,y="maxCount")) + geom_point(aes(colour=get(aggvar)),size=2.5) + labs(y="Max. Count", x="", colour=aggvar) +
				theme(axis.text.x=element_text(size=10)) + coord_flip()
		plot1<-makeHTMLplot(p1,capt=capt1,wdt=500, hgt=600)
		plot2<-makeHTMLplot(p2,capt=capt2,wdt=500, hgt=600)
		res.lst.tmp<-paste(plot1,plot2)
	}
	return(res.lst.tmp)
}


########################################################################################################################
###									BirdUseDays
########################################################################################################################

# Function to generate the Bird-use-days estimate: the total number of birds of a taxon/guild observed in a defined period of time
# 
# Function to generate the Bird-use-days estimate: the total number of birds of a taxon/guild observed in a defined period of time
# 
# @param iwmmObject An IWMMData object
# @param taxon.groups.name String providing the name (i.e., column name) of the taxon/guild grouping variable
# @param spatial.groups.name String providing the name (i.e., column name) of the spatial grouping variable
# @param observation.groups.name String providing the name (i.e., column name) of the observation grouping variable
# @param htout Should output be in html format? Defaults to n (return javascript)
# @param ... other parameters passed to the generation function (for now this is not implemented - it's a placeholder for extensions)
# @author Leo Salas \email{lsalas@@prbo.org}
BirdUseDays<-function(iwmmObject, taxon.groups.name="", spatial.groups.name="", observation.groups.name="",htout="n",...){
	#being called from Report, we know the object must be an IWMM data object and must have data, so...
	
	#need a table with date, species/taxon.group, and count
	#if submitting spatial.groups or observation.groups, then must serially graph these
	#merge the data
	library(splines)
	data<-as.data.frame(iwmmObject,by="merged")
	data$StudyArea<-data$ProjectName
	data<-subset(data,!is.na(CommonName))
	data<-subset(data,!is.na(ObservationDate))
	data$PlotAreaSqMeters<-ifelse(is.null(data$PlotAreaSqMeters)|is.na(data$PlotAreaSqMeters),1200,data$PlotAreaSqMeters)
	data$PlotAreaHa<-data$PlotAreaSqMeters/10000
	#use CountByArea instead of plain old ObservationCount
	data$CountByArea<-data$ObservationCount/data$PlotAreaHa
	
	if(nrow(data)==0){
		err<-"Error: no data, or species identified in the selection"; class(err)<-"try-error"
		return(err)
	}
	
	taxon.name<-"Species"; t.name<-"CommonName"
	if(taxon.groups.name!=""){
		taxon.name<-taxon.groups.name
		t.name<-"TaxonGroup"
	}
	utn<-as.character(unique(data[,t.name]))
	
	#if a taxon group aggregation or a spatial group aggregation is requested, we need to average the data for these...
	#If data from more than one project are selected, we must aggregate at project level too, otherwise, aggregate at site (plot) level
	if(NROW(unique(data$ProjectName))>1){
		spatial.name<-"ProjectName";s.name<-"ProjectName"
	}else{
		spatial.name<-"PlotName";s.name<-"PlotName"
	}
	if(spatial.groups.name!=""){
		spatial.name<-spatial.groups.name
		s.name<-"SpatialGroup"
	}
	
	fml<-paste("CountByArea ~ ObservationDate +",t.name,"+",s.name)
	if(observation.groups.name!=""){
		fml<-paste(fml,"+ ObservationsGroup")
	}
	data<-aggregate(as.formula(fml),data=data,FUN=mean)
	
	dat.fields<-c(t.name,s.name,"CountByArea","ObservationDate")
	
	res.table<-data.frame()
	
	#cycle through taxa and spatial groups and calculate bud's, append to res.table
	for(gg in utn){
		datag<-subset(data,data[,t.name]==gg)
		usn<-as.character(unique(datag[,s.name]))
		for(ss in usn){
			datags<-subset(datag,datag[,s.name]==ss)
			if(observation.groups.name!=""){
				for(oo in unique(datags$ObservationsGroup)){
					datagso<-subset(datags,ObservationsGroup==oo)
					if(nrow(datagso)>2){
						df<-datagso[,dat.fields]; names(df)<-c(taxon.name,"Location","Count","ObservationDate")
						res.df<-estimateTrapezoids(df) 
						res.df$Taxon<-gg
						res.df$Location<-ss
						res.df[,observation.groups.name]<-oo
						res.df<-res.df[,c("Taxon","Location",observation.groups.name,"StartDate","EndDate","BUD","Corrected_BUD","Var","glmVar","Ndays")]
					}else{#not enough dates...
						res.df<-unique(datagso[,c(t.name,s.name,"ObservationsGroup")]);names(res.df)<-c(taxon.name,"Location",observation.groups.name)
						res.df$StartDate<-min(datagso$ObservationDate);res.df$EndDate<-max(datagso$ObservationDate);res.df$BUD<-NA
						res.df$Corrected_BUD<-NA;res.df$Var<-NA;res.df$glmVar<-NA;res.df$Ndays<-NROW(datagso)
					}
					names(res.df)<-c(taxon.name,"Location",observation.groups.name,"StartDate","EndDate","BUD(birds/ha)","Corrected_BUD","Var","glmVar","Ndays")
					res.table<-rbind(res.table,res.df)
				}
			}else{ #no obs groups
				if(nrow(datags)>2){
					df<-datags[,dat.fields]; names(df)<-c(taxon.name,"Location","Count","ObservationDate")
					res.df<-estimateTrapezoids(df) 
					res.df$Taxon<-gg
					res.df$Location<-ss
					res.df<-res.df[,c("Taxon","Location","StartDate","EndDate","BUD","Corrected_BUD","Var","glmVar","Ndays")]
				}else{# no obs group and not enough dates
					res.df<-unique(datags[,c(t.name,s.name)]);names(res.df)<-c(taxon.name,"Location")
					res.df$StartDate<-min(datags$ObservationDate);res.df$EndDate<-max(datags$ObservationDate);res.df$BUD<-NA
					res.df$Corrected_BUD<-NA;res.df$Var<-NA;res.df$glmVar<-NA;res.df$Nrecs<-NROW(datags)
				}
				names(res.df)<-c(taxon.name,"Location","StartDate","EndDate","BUD(birds/ha)","Corrected_BUD","Var","glmVar","Ndays")
				res.table<-rbind(res.table,res.df)
			}
		}
	}
	
	id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
	capt<-paste("<h3>","Bird-use-days by",taxon.name,"</h3>")
	tb1<-makeIWMMtable(df=res.table,fmt="html",capt=capt,idval=id1)
	
	if(htout=="n"){	#adding the javascript suffix...
		#jsid1<-paste("\n  <script type=\"text/javascript\">\n  $(document).ready(function() {\n  $('#",idval1,"').DataTable();\n  } );\n  </script>\n  ",sep="")
		#nothing to do
		tb1<-paste(tb1)
	}
	
	return(tb1)
}

estimateTrapezoids<-function(df){
	df<-df[order(df$ObservationDate),]
	lng<-nrow(df)
	c<-df$Count
	if(class(df$ObservationDate)!="Date"){
		df$ObservationDate<-as.Date(as.character(df$ObservationDate))
	}
	t<-df$ObservationDate
	stdate<-min(df$ObservationDate);eddate<-max(df$ObservationDate)
	
	sdc<-sd(c);varc<-sdc^2
	sc<-numeric();vc<-numeric();diff.t<-numeric()
	
	for(xx in 2:(lng)){
		dift<-as.numeric(t[xx]-t[xx-1])
		smc<-(dift)*(c[xx]+c[xx-1])*0.5
		vmc<-(dift^2)*c[xx]*0.25*varc
		sc<-c(sc,smc);vc<-c(vc,vmc);diff.t<-c(diff.t,dift)
	}
	#simple BUD from trapezoid method, and simple variance under assumption that samples are IID.
	tauc<-sum(sc)
	vtauc<-sum(vc)
	avg.t<-floor(mean(diff.t)); if(avg.t==0){avg.t<-1}
	
	#calculating the Bue correction for non-zero start or end counts, but using average days between samples instead of life expectancy of spawners
	cb1<-0;cbn<-0
	if(c[1]!=0){
		cb1<-c[1]*avg.t/2
	}
	if(c[lng]!=0){
		cbn<-c[lng]*avg.t/2
	}
	buetauc<-tauc+cb1+cbn
	
	## calculating variance assuming non-independence in counts, using a spline curve approximation with no a priori modality assumptions (no knots)
	## need to calculate phi = (1/(n-3))*sum(((c-c_hat)^2)/c_hat)
	## So, need c_hat estimates, from glm splines 
	gdf<-data.frame(x=t,y=c)
	sgm<-glm(as.formula("y~bs(x,degree=3)"),data=gdf,family="quasipoisson")
	gdf$spred<-predict(sgm,se.fit=FALSE);gdf$phi_s<-((as.numeric(gdf$x-gdf$spred))^2)/gdf$spred
	mlt<-1/(lng-3)
	
	s_phi<-mlt*sum(gdf$phi_s)
	nvs<-numeric()
	for(xx in 2:(lng-1)){
		vs<-((as.numeric(t[xx+1]-t[xx-1]))^2)*gdf$spred[xx];nvs<-c(nvs,vs)
	}
	vtaucs<-0.25*s_phi*sum(nvs)
	
	res.df<-data.frame(StartDate=stdate,EndDate=eddate,BUD=tauc,Corrected_BUD=buetauc,Var=vtauc,glmVar=vtaucs,Ndays=lng)
	return(res.df)
}


toOrdinalDate<-function(dates){
	#dates is a POSIXct array
	#this function should convert these dates to ordinal numbers, but properly spaced
}


########################################################################################################################
###									HabitatReport
########################################################################################################################
# Function to generate the bird migration curve report: the total counts per date
# 
# Function to generate the bird migration curve report: the total counts per date
# 
# @param iwmmObject An IWMMData object
# @param spatial.groups.name String providing the name (i.e., column name) of the spatial grouping variable
# @param htout A string with the value in the POST, specifying whether to return html, highchart javascript, or json ("html", "high", "json")
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
Habitat<-function(iwmmObject, spatial.groups.name="", htout="n",...){
	#Report can be table or graph
	#This needs to report on: salinity, water gauge reading, water depth classes, habitat cover classes, vegheight classes
	#This needs to report: min, max, average, median, and stdev
	#REVIEW!!!
	
	#Report is always by plot (unit) and date???. If requested for several projects, then 
	
	#Here are the variables to summarize:
	#"HabitatCoverWater","HabitatCoverForest","HabitatCoverEmergent","HabitatCoverBareGround","HabitatCoverScrubShrub",
	#"VegetationHeightPercent3To6M","VegetationHeightPercentOver6M",
	#"VegetationHeightPercent15To30Cm","VegetationHeightPercent30To60Cm","VegetationHeightPercent60CmTo3M",
	#"VegetationHeightPercent2_5To15Cm","VegetationHeightPercentLessThan2_5Cm","WaterDepthPercentDry","WaterDepthPercent0To5CM","WaterDepthPercent5To15CM",
	#"WaterDepthPercent15To25CM","WaterDepthPercentOver25CM","WaterDepthPercentSaturatedMud",
	#"Wind","Visibility","StartTemperature","WaterGaugeReading","WaterGaugeReadingUnits","WaterSalinityMeasureTaken","WaterMeasuredSalinityLevel"
	
	#so, first get the data
	eff<-unique(EffortData(iwmmObject))
	
	#Don't need these, but jic
	eff$PlotAreaSqMeters<-ifelse(is.null(eff$PlotAreaSqMeters)|is.na(eff$PlotAreaSqMeters),1200,eff$PlotAreaSqMeters)
	eff$PlotAreaHa<-eff$PlotAreaSqMeters/10000
	
	spatial.name<-"PlotName";s.name<-"PlotName"
	if(NROW(unique(eff$ProjectName))>1){
		spatial.name<-"ProjectName";s.name<-"ProjectName"
	}
	if(spatial.groups.name!=""){
		spatial.name<-spatial.groups.name;s.name<-"SpatialGroup"
	}
	
	#then something like this...
	#for(fff in habfields){
	#	aggfml<-as.formula(paste(fff,"~",s.name,"+ SurveyYear"))
	#	aggdf<-aggregate(aggfml,data=eff,FUN=mean)
	#	aggdfsd<-aggregate(aggfml,data=eff,FUN=sd)
	#}
	
	#but for now faking it...
	####################################
	#Synthetic data
	effFields<-c("ProjectName","PlotName","PlotAreaSqMeters","YearCollected","ObservationDate")
	habfields<-c("HabitatCoverWater","HabitatCoverForest","HabitatCoverEmergent","HabitatCoverBareGround","HabitatCoverScrubShrub",
			"VegetationHeightPercent3To6M","VegetationHeightPercentOver6M","VegetationHeightPercent15To30Cm","VegetationHeightPercent30To60Cm",
			"VegetationHeightPercent60CmTo3M","VegetationHeightPercent2_5To15Cm","VegetationHeightPercentLessThan2_5Cm","WaterDepthPercentDry",
			"WaterDepthPercent0To5CM","WaterDepthPercent5To15CM","WaterDepthPercent15To25CM","WaterDepthPercentOver25CM",
			"WaterDepthPercentSaturatedMud","Wind","Visibility","StartTemperature")
	types<-c("p","p","p","p","p","p","p","p","p","p","p","p","p","p","p","p","p","p","d","d","n")
	meanvals<-c(0.3,0.2,0.05,0.05,0.4,0.15,0.1,0.25,0.25,0.2,0.05,0.05,0.1,0.5,0.1,0.1,0.1,0.1,3,5,70)
	hcv.df<-data.frame(habfield=habfields,type=types,meanval=meanvals)
	
	agg.df<-aggregate(as.formula(paste("PlotAreaHa ~",s.name,"+ SurveyYear")),data=eff,FUN=sum)
	
	res.df<-data.frame()
	for(ii in 1:NROW(agg.df)){
		hdat<-as.data.frame(hcv.df$"habfield");names(hdat)<-"HabitatParameter"
		#synthmean<-apply(hcv.df,1,FUN="genSyntheticData","mean")
		#synthsd<-apply(hcv.df,1,FUN="genSyntheticData","sd")
		hdat$MeanValue<-apply(hcv.df,1,FUN="genSyntheticData","mean")
		hdat$StErr<-apply(hcv.df,1,FUN="genSyntheticData","sd")
		hdat[,s.name]<-agg.df[ii,s.name];
		hdat$SurveyYear<-agg.df[ii,"SurveyYear"]
		hdat$PlotAreaHa<-agg.df[ii,"PlotAreaHa"]
		hdat<-hdat[,c(s.name,"SurveyYear","PlotAreaHa","HabitatParameter","MeanValue","StErr")]
		names(hdat)<-c(spatial.name,"SurveyYear","PlotAreaHa","HabitatParameter","MeanValue","StErr")
		res.df<-rbind(res.df,hdat)
	}
	
	#have table of results, now plot if more than one value of s.name in agg.df
	#else, just pass the table
	if(NROW(unique(agg.df[,s.name]))==1){
		#make the html table from res.df
		plot.nam<-unique(agg.df[,s.name])
		id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
		capt<-paste("<h3> Habitat covariate values for",plot.nam,"</h3>")
		tb1<-makeIWMMtable(df=res.df,fmt="html",capt=capt,id1)
		
		if(htout=="html" | htout=="high"){	
			#nothing to do
		}else if (htout=="json"){
			tb1<-substr(tb1,1,nchar(tb1)-1)
			tb1<-paste("{\"RavianResults\":{\"tables\":[",tb1,"]}}")
		}else{}
		
		return(tb1)
	}else{
		#subset by each variable and create a series of tables
		tbl.lst<-list();i<-0
		for(vv in hcv.df$habfield){
			i<-i+1
			tbl.df<-subset(res.df,HabitatParameter==vv)
			id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			capt<-paste("<h3> Habitat covariate values for",plot.nam,"</h3>")
			tbres<-makeIWMMtable(df=res.table,fmt="html",capt=capt,id1)
			tbl.lst[[i]]<-tbres
		}
		restb<-paste(tbl.lst,collapse=" ")
		return(restb)
	}
}


########################################################################################################################
###									VegetationReport
########################################################################################################################
#By unit or collection of units
#Selecting start and end dates
#whether metrics associated with bird counts or the annual habitat metrics. The former is the HaibitatReport and this is the VegetationReport.
#This vegetation report must report on: 
#	Relative percent cover by annual and perennial vegetation, (table if one unit or group, table & graph if more than 1 - stacked bars, one per unit)
#	List of dominant plant species based on relative cover of individual plant species (table with species as row, and unit/group as colum, cell is %cover)
#	Seed production index values based on seed head size, seed head density, and percent cover estimates for individual plant species (same as above)

# Function to generate all outputs for vegetation report
# 
# Function to generate all outputs for vegetation report
# 
# @param iwmmObject An IWMMVegData object
# @param outType String specifying the output requested - only "table" or "graph" allowed. Defaults to table.
# @param outputFormat String indicating the specific table or graph requested. Allowed values: pctCover, domPlants, seedProd. Defaults to pctCover.
# @param taxon.groups.name String providing the name (i.e., column name) of the taxon/guild grouping variable
# @param spatial.groups.name String providing the name (i.e., column name) of the spatial grouping variable
# @param observation.groups.name String providing the name (i.e., column name) of the observation grouping variable
# @param htout String indicating the format of the output. If "y" (default), output is html. Else it is javascript (highcharts for graph, jquery table for tables)
# @param ... other parameters passed to the graph or table generation functions (e.g., graph size)
# @author Leo Salas \email{lsalas@@prbo.org}
VegetationReport<-function(iwmmObject, outType="table", outputFormat="pctCover", taxon.groups.name="", spatial.groups.name="", 
		observation.groups.name="",htout="y",...){
	#being called from Report, we know the object must be an IWMM data object and must have data, so...
	
	#who converts tables to html/js, plots to js or ggplot?
	
	#This supposedly happens once/year, keep that in mind
	if(outputFormat=="domPlants"){
		captval<-"Dominant Plant Species Report"
		dat<-as.data.frame(iwmmObject,by="obs")
		dat<-dat[,c("ProjectCode","PlotName","ObservationDate","ScientificName","PlantPct")]
		pdat<-aggregate(as.formula("PlantPct~ProjectCode+PlotName+ObservationDate+ScientificName"),data=dat,FUN=mean,na.rm=TRUE)	#OJO: Can't use CommonName because there are too many NA's
		pdat<-pdat[order(pdat$ProjectCode,pdat$PlotName,pdat$ObservationDate),]
		id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
		res<-makeIWMMtable(df=pdat,fmt="html",capt=captval,idval=id1)
	}else if(outputFormat=="seedProd"){
		#plant.pct is the percent of all vegetated area that is due to the plant.
		#For SPI calculation, this percentage needs to be adjusted (multiplied) by the total vegetated area
		captval<-"Seed Production Index Report"
		dat<-as.data.frame(iwmmObject,by="obs")
		dat<-dat[,c("ProjectCode","PlotName","ObservationDate","ScientificName","PlantPct","SeedHeadSizeCd","SeedHeadSizeDensityCd")]
		dat<-subset(dat,!is.na(PlantPct) & !is.null(PlantPct))  #This should be warehouse design
		#SeedHeadSizeDensityCd: H-M-L,NA/NULL, SeedHeadSizeCd:L-A-S,NA/NULL 
		dat$hdhs<-paste(toupper(dat$SeedHeadSizeDensityCd),toupper(dat$SeedHeadSizeCd),sep="")
		dat$QualityScore<-ifelse(is.na(dat$SeedHeadSizeDensityCd)||dat$SeedHeadSizeDensityCd=="NA",0,
				ifelse(is.null(dat$SeedHeadSizeDensityCd)||dat$SeedHeadSizeDensityCd=="NULL",0,
						ifelse(is.na(dat$SeedHeadSizeCd)||dat$SeedHeadSizeCd=="NA",0,
								ifelse(is.null(dat$SeedHeadSizeCd)||dat$SeedHeadSizeCd=="NULL",0,
										ifelse(dat$hdhs %in% c("HL","HA"),4,
												ifelse(dat$hdhs %in% c("ML","MA"),3,
														ifelse(dat$hdhs %in% c("HS","MS","LL"),2,1)))))))
		dat$SeedProductionIndex<-dat$PlantPct*dat$QualityScore/100
		dat<-dat[,c("ProjectCode","PlotName","ObservationDate","ScientificName","PlantPct","SeedHeadSizeCd","SeedHeadSizeDensityCd","QualityScore","SeedProductionIndex")]
		dat<-dat[order(dat$ProjectCode,dat$PlotName,dat$ObservationDate),]
		id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
		res<-makeIWMMtable(df=dat,fmt="html",capt=captval,idval=id1)
	}else if(outputFormat=="pctAnnPer"){
		captval<-"Relative Percent Cover Annuals/Perennials Report"
		dat<-as.data.frame(iwmmObject,by="obs")
		dat<-dat[,c("ProjectCode","PlotName","YearCollected","ScientificName","PlantPct","LifeStrategy")]
		pdat<-aggregate(as.formula("PlantPct~ProjectCode+PlotName+YearCollected+ScientificName+LifeStrategy"),data=dat,FUN=mean,na.rm=TRUE)
		pdat$Strategy<-ifelse(grepl("Annual",pdat$LifeStrategy,fixed=TRUE),"Annuals","Non-annuals")
		pap<-aggregate(as.formula("PlantPct~ProjectCode+YearCollected+PlotName+Strategy"),data=pdat,FUN=sum)
		names(pap)<-c("ProjectCode","YearCollected","PlotName","Strategy","StrategyPercentCover")
		pap.support<-aggregate(as.formula("PlantPct~ProjectCode+YearCollected+PlotName"),data=pdat,FUN=sum)
		names(pap.support)<-c("ProjectCode","YearCollected","PlotName","TotalPercentCover")
		pap.res<-merge(pap,pap.support,by=c("ProjectCode","YearCollected","PlotName"),all.x=TRUE)
		pap.res$RelativePercentCover<-pap.res$StrategyPercentCover/pap.res$TotalPercentCover
		pldat<-pap.res[,c("ProjectCode","YearCollected","PlotName","Strategy","RelativePercentCover")]
		pldat<-pldat[order(pldat$ProjectCode,pldat$PlotName,pldat$YearCollected),]
		#now decide if plotting or reporting table
		if(outType=="table"){
			restbl<-reshape(pldat,idvar=c("ProjectCode","YearCollected","PlotName"),timevar="Strategy",direction="w")
			names(restbl)<-c("ProjectCode","YearCollected","PlotName","%Annuals","%non-Annuals")
			id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			res<-makeIWMMtable(df=restbl,fmt="html",capt=captval,idval=id1)
		}else{
			pldat$PlotYear<-paste(pldat$PlotName,pldat$YearCollected,sep="-")
			plt<-ggplot(data=pldat,aes(x=PlotYear,y=RelativePercentCover,fill=Strategy)) + geom_bar(stat="identity",position="stack")+
					coord_flip() + theme_bw() + labs(x="Plot & Year",y="Relative proportion of emergent cover",fill="Plant type")
			if(NROW(unique(pldat$ProjectCode))>1){
				pldat$ProjectPlotYear<-paste(pldat$ProjectCode,pldat$PlotName,pldat$YearCollected,sep="-")
				plt<-ggplot(data=pldat,aes(x=ProjectPlotYear,y=RelativePercentCover,fill=Strategy)) + geom_bar(stat="identity",position="stack")+
						coord_flip() + theme_bw() + labs(x="Project & Plot & Year",y="Relative proportion of emergent cover",fill="Plant type")
			}
			res<-makeHTMLplot(plobj=plt,capt=captval)
		}
	}else{	#default: relative Percent Cover (relPctCov)
		#first verify that there is only one survey per unit per year. If there is more than one, then report the range: min-max
		# of "NearTallEdgePct","EmergentPct","VisibilityPct","EstimationMethodCd"
		dat<-as.data.frame(iwmmObject,by="eff")
		dat$AreaSurveyed<-ifelse(is.null(dat$AreaSurveyed) || dat$AreaSurveyed==0,1200,dat$AreaSurveyed)
		dat$EstimationMethodCd<-ifelse(is.null(dat$EstimationMethodCd),"Visual",
				ifelse(is.na(dat$EstimationMethodCd),"Visual",
						ifelse(dat$EstimationMethodCd=="\\N","Visual",dat$EstimationMethodCd)))
		captval<-"Relative Percent Cover Report"
		if(nrow(unique(dat[,c("ProjectCode","SamplingUnitId","YearCollected")]))<nrow(unique(dat[,c("ProjectCode","SamplingUnitId","YearCollected","ObservationDate")]))){
			#here report the range of values
			minNTE<-aggregate(as.formula("NearTallEdgePct~ProjectCode+ProtocolCode+PlotName+YearCollected"),data=dat,FUN=min,na.rm=TRUE)
			names(minNTE)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","ymin")
			maxNTE<-aggregate(as.formula("NearTallEdgePct~ProjectCode+ProtocolCode+PlotName+YearCollected"),data=dat,FUN=max,na.rm=TRUE)
			names(maxNTE)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","ymax")
			dd<-merge(minNTE,maxNTE);dd$Variable<-"%NearTallEdge"
			minEPC<-aggregate(as.formula("EmergentPct~ProjectCode+ProtocolCode+PlotName+YearCollected"),data=dat,FUN=min,na.rm=TRUE)
			names(minEPC)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","ymin")
			maxEPC<-aggregate(as.formula("EmergentPct~ProjectCode+ProtocolCode+PlotName+YearCollected"),data=dat,FUN=max,na.rm=TRUE)
			names(maxEPC)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","ymax")
			d2<-merge(minEPC,maxEPC);d2$Variable<-"%Emergent"
			minVPC<-aggregate(as.formula("VisibilityPct~ProjectCode+ProtocolCode+PlotName+YearCollected"),data=dat,FUN=min,na.rm=TRUE)
			names(minVPC)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","ymin")
			maxVPC<-aggregate(as.formula("VisibilityPct~ProjectCode+ProtocolCode+PlotName+YearCollected"),data=dat,FUN=max,na.rm=TRUE)
			names(maxVPC)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","ymax")
			d3<-merge(minVPC,maxVPC);d3$Variable<-"%Visibility"
			pdat<-nrow(dd,d2,d3);
			#If table, return pdat, but rename columns
			if(outType=="table"){
				pdat<-pdat[,c("ProjectCode","ProtocolCode","PlotName","YearCollected","Variable","ymin","ymax")]
				names(pdat)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","Variable","Minimum","Maximum")
				pdat<-pdat[order(pdat$ProjectCode,pdat$PlotName,pdat$YearCollected,pdat$Variable),]
				id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
				res<-makeIWMMtable(df=pdat,fmt="html",capt=captval,idval=id1)
			}else{
				pdat<-pdat[,c("ProjectCode","PlotName","YearCollected","Variable","ymin","ymax")]
				plt<-ggplot(data=pdat,aes(x=PlotName,group=YearCollected)) + geom_linerange(aes(ymin=ymin,ymax=ymax,color=YearCollected),size=2,position="dodge") +
						coord_flip() + theme_bw() 
				if(NROW(unique(pdat$ProjectCode))>1){
					plt<-plt + facet_grid(ProjectCode~Variable)
				}else{
					plt<-plt + facet_wrap(~Variable,ncol=3)
				}
				res<-makeHTMLplot(plobj=plt,capt=captval)
			}
		}else{	#single value prt location per year
			pdat<-dat[,c("ProjectCode","ProtocolCode","PlotName","YearCollected","NearTallEdgePct","EmergentPct","VisibilityPct","EstimationMethodCd")]
			if(outType=="table"){ #If table, return pdat
				names(pdat)<-c("ProjectCode","ProtocolCode","PlotName","YearCollected","%NearTallEdge","%Emergent","%Visibility","EstimationMethod")
				pdat<-pdat[order(pdat$ProjectCode,pdat$PlotName,pdat$YearCollected),]
				id1<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
				res<-makeIWMMtable(df=pdat,fmt="html",capt=captval,idval=id1)
			}else{
				pdat<-pdat[,c("ProjectCode","PlotName","YearCollected","NearTallEdgePct","EmergentPct","VisibilityPct","EstimationMethodCd")]
				pdat<-melt(pdat,id.vars=c("ProjectCode","PlotName","YearCollected","EstimationMethodCd"))
				plt<-ggplot(data=pdat,aes(x=PlotName,y=value,color=as.character(YearCollected),shape=EstimationMethodCd)) + geom_point(size=2) +
						coord_flip() + theme_bw() + labs(x="Plot",y="Estimated value (%)",color= "Year",shape="Est. method") + facet_wrap(~variable,ncol=3)
				if(NROW(unique(pdat$ProjectCode))>1){
					pdat$ProjectPlot<-paste(pdat$ProjectCode,pdat$PlotName,sep="-")
					plt<-ggplot(data=pdat,aes(x=ProjectPlot,y=value,color=as.character(YearCollected),shape=EstimationMethodCd)) + geom_point(size=2) +
							coord_flip() + theme_bw() + labs(x="Project & Plot",y="Estimated value (%)",color= "Year",shape="Est. method") + facet_wrap(~variable,ncol=3)
				}
				res<-makeHTMLplot(plobj=plt,capt=captval)
			}
		}
	}
	
	return(res)
	
}
