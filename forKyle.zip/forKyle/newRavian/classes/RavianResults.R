# TODO: Add comment
# 
# Author: Leo Salas 
# Contact: lsalas@pointblue.org
# Creation Date: March 8, 2016
###############################################################################

###############################################################################
#' Abstract class for RavianResults
#' 
#' Abstract class for RavianResults
#' 
#' @param ResultTitle Character string that names the result object (e.g., table title, graph title, error prompt)
#' @param ResultNotes Character string with any notes about the object
#' @param ResultType A string, one of "Error", "Warning", "Table", or "Graph"
#' @param EncodedResult A string with the resulting encoded (as html, json or javascript) result
#' @exportClass RavianResults
setClass("RavianResults", representation(
				ResultTitle = "character",
				ResultNotes = "character",
				ResultType = "character",
				EncodedResult = "character"
				))

#############################
#' Set generic to  method that sets ResultTitle slot of RavianResults object.
#' 
#' @name setResultTitle
#' @param object An RavianResults object
#' @param value String to put into ResultTitle slot.
		setGeneric("ResultTitle<-", 
				function(object, value)	standardGeneric("ResultTitle<-"))
		
#' Set ResultTitle slot of RavianResults object.
#' 
#' @name setResultTitle
#' @param object An RavianResults object
#' @param value String to put into ResultTitle slot.
		setReplaceMethod("ResultTitle",signature(object="RavianResults"),
				function(object,value) {
					slot(object,"ResultTitle")<-value
					validObject(object)
					object
				})
		
#' Set generic to  method that retrieves ResultTitle slot value of RavianResults object.
#' 
#' @name ResultTitle
#' @param object An RavianResults object
		setGeneric("ResultTitle", 
				function(object) standardGeneric("ResultTitle"))
		
#' Retrieve ResultTitle slot value of RavianResults object.
#' 
#' @name ResultTitle
#' @param object An RavianResults object
		setMethod("ResultTitle", signature(object="RavianResults"),
				function(object) slot(object,"ResultTitle"))
		
#############################
#' Set generic to  method that sets ResultNotes slot of RavianResults object.
#' 
#' @name setResultNotes
#' @param object An RavianResults object
#' @param value String to put into ResultNotes slot.
		setGeneric("ResultNotes<-", 
				function(object, value)	standardGeneric("ResultNotes<-"))
		
#' Set ResultNotes slot of RavianResults object.
#' 
#' @name setResultNotes
#' @param object An RavianResults object
#' @param value String to put into ResultNotes slot.
		setReplaceMethod("ResultNotes", signature(object="RavianResults"),
				function(object,value){
					slot(object,"ResultNotes")<-value
					validObject(object)
					object
				})
		
#' Set generic to  method that retrieves ResultNotes slot value of RavianResults object.
#' 
#' @name ResultNotes
#' @param object An RavianResults object
		setGeneric("ResultNotes",
				function(object)	standardGeneric("ResultNotes"))
		
#' Retrieve ResultNotes slot value of RavianResults object.
#' 
#' @name ResultNotes
#' @param object An RavianResults object
		setMethod("ResultNotes", signature(object="RavianResults"),
				function(object) slot(object,"ResultNotes"))
		
#############################
#' Set generic to  method that sets ResultType slot of RavianResults object.
#' 
#' @name setResultType
#' @param object An RavianResults object
#' @param value String to put into ResultType slot.
		setGeneric("ResultType<-", 
				function(object, value)	standardGeneric("ResultType<-"))
		
#' Set ResultType slot of RavianResults object.
#' 
#' @name setResultType
#' @param object An RavianResults object
#' @param value String to put into ResultType slot.
		setReplaceMethod("ResultType",signature(object="RavianResults"),
				function(object,value) {
					slot(object,"ResultType")<-value
					validObject(object)
					object
				})
		
#' Set generic to  method that retrieves ResultType slot value of RavianResults object.
#' 
#' @name ResultType
#' @param object An RavianResults object
		setGeneric("ResultType", 
				function(object) standardGeneric("ResultType"))
		
#' Retrieve ResultType slot value of RavianResults object.
#' 
#' @name ResultType
#' @param object An RavianResults object
		setMethod("ResultType", signature(object="RavianResults"),
				function(object) slot(object,"ResultType"))
		
#############################
#' Set generic to  method that sets the EncodedResult slot of RavianResults object.
#' 
#' @name setEncodedResult
#' @param object An RavianResults object
#' @param value String to put into EncodedResult slot.
		setGeneric("EncodedResult<-", 
				function(object, value)	standardGeneric("EncodedResult<-"))
		
#' Set EncodedResult slot of RavianResults object.
#' 
#' @name setEncodedResult
#' @param object An RavianResults object
#' @param value String to put into EncodedResult slot.
		setReplaceMethod("EncodedResult",signature(object="RavianResults"),
				function(object,value) {
					slot(object,"EncodedResult")<-value
					validObject(object)
					object
				})
		
#' Set generic to  method that retrieves EncodedResult slot value of RavianResults object.
#' 
#' @name EncodedResult
#' @param object An RavianResults object
		setGeneric("EncodedResult", 
				function(object) standardGeneric("EncodedResult"))
		
#' Retrieve EncodedResult slot value of RavianResults object.
#' 
#' @name EncodedResult
#' @param object An RavianResults object
		setMethod("EncodedResult", signature(object="RavianResults"),
				function(object) slot(object,"EncodedResult"))
		
		
############################## Initialize RavianResults object
#' Instantiate a new RavianResults object
#' 
#' @name initialize
		setMethod("initialize",
				signature(.Object = "RavianResults"),
				function (.Object, ...) 
				{
					.Object@ResultTitle 		<- character()
					.Object@ResultNotes 		<- character()
					.Object@ResultType			<- character()
					.Object@EncodedResult 		<- character()
					.Object
				}
		)
		
###########################################################################

# Setting the generic for the results encoding methods
##################################### encodeRavianResultObject
#' Set generic to  method that requests encoding of results for a RavianResults sub-class object. 
#' 
#' @name encodeRavianResultObject
#' @param object An object of a valid subclass of RavianResults: RavianResultError, RavianResultTable, RavianResultGraph. 
#' @param outtype A string indicating the type of encoding requested: html, json or javascript
setGeneric("encodeRavianResultObject",
		function(object, outtype, ...) standardGeneric("encodeRavianResultObject"))

		
################################################################################################
## Sub-classes
################################################################################################

#' RavianResultError class - subclass of RavianResult Class
#' 
#' @param ResultTitle Character string that names the result object (e.g., table title, graph title, error prompt)
#' @param ResultNotes Character string with any notes about the object
#' @param ResultType A string, always "Error"
#' @param EncodedResult A string with the resulting encoded (as html, json or javascript) result
#' @param ErrorDescription A string with a simple description of the error, to be passed to the client
#' @param SinkObjects A list with objects to be saved for debugging
#' @param ErrorDate A string with a date stamp for when the error was generated
#' @exportClass RavianResultError
		setClass("RavianResultError",contains=c("RavianResults"),
				prototype=prototype(ResultType="Error"), 
				representation(
						ResultTitle = "character",
						ResultNotes = "character",
						ResultType = "character",
						EncodedResult = "character",
						ErrorDescription = "character",
						SinkObjects = "list",
						ErrorDate = "character"
		))

#############################
#' Set generic to  method that sets the ErrorDescription slot of RavianResultError object.
#' 
#' @name setErrorDescription
#' @param object An RavianResultError object
#' @param value String to put into ErrorDescription slot.
setGeneric("ErrorDescription<-", 
		function(object, value)	standardGeneric("ErrorDescription<-"))

#' Set ErrorDescription slot of RavianResultError object.
#' 
#' @name setErrorDescription
#' @param object An RavianResultError object
#' @param value String to put into ErrorDescription slot.
setReplaceMethod("ErrorDescription", signature(object="RavianResultError"),
		function(object,value){
			slot(object,"ErrorDescription")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ErrorDescription slot value of RavianResultError object.
#' 
#' @name ErrorDescription
#' @param object An RavianResultError object
setGeneric("ErrorDescription",
		function(object)	standardGeneric("ErrorDescription"))

#' Retrieve ErrorDescription slot value of RavianResultError object.
#' 
#' @name ErrorDescription
#' @param object An RavianResultError object
setMethod("ErrorDescription", signature(object="RavianResultError"),
		function(object) slot(object,"ErrorDescription"))

#############################
#' Set generic to  method that sets the SinkObjects slot of RavianResultError object.
#' 
#' @name setSinkObjects
#' @param object An RavianResultError object
#' @param value List of objects to put into SinkObjects slot.
setGeneric("SinkObjects<-", 
		function(object, value)	standardGeneric("SinkObjects<-"))

#' Set SinkObjects slot of RavianResultError object.
#' 
#' @name setSinkObjects
#' @param object An RavianResultError object
#' @param value List of objects to put into SinkObjects slot.
setReplaceMethod("SinkObjects",signature(object="RavianResultError"),
		function(object,value) {
			slot(object,"SinkObjects")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves the SinkObjects slot value of RavianResultError object.
#' 
#' @name SinkObjects
#' @param object An RavianResultError object
setGeneric("SinkObjects", 
		function(object) standardGeneric("SinkObjects"))

#' Retrieve SinkObjects slot value of RavianResultError object.
#' 
#' @name SinkObjects
#' @param object An RavianResultError object
setMethod("SinkObjects", signature(object="RavianResultError"),
		function(object) slot(object,"SinkObjects"))

#############################
#' Set generic to  method that sets the ErrorDate slot of RavianResultError object.
#' 
#' @name setErrorDate
#' @param object An RavianResultError object
#' @param value String to put into ErrorDate slot.
setGeneric("ErrorDate<-", 
		function(object, value)	standardGeneric("ErrorDate<-"))

#' Set ErrorDate slot of RavianResultError object.
#' 
#' @name setErrorDate
#' @param object An RavianResultError object
#' @param value String to put into ErrorDate slot.
setReplaceMethod("ErrorDate", signature(object="RavianResultError"),
		function(object,value){
			slot(object,"ErrorDate")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ErrorDate slot value of RavianResultError object.
#' 
#' @name ErrorDate
#' @param object An RavianResultError object
setGeneric("ErrorDate",
		function(object)	standardGeneric("ErrorDate"))

#' Retrieve ErrorDate slot value of RavianResultError object.
#' 
#' @name ErrorDate
#' @param object An RavianResultError object
setMethod("ErrorDate", signature(object="RavianResultError"),
		function(object) slot(object,"ErrorDate"))

############################## Initialize RavianResultError object
#' Instantiate a new RavianResultError object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "RavianResultError"),
		function (.Object, ...) 
		{
			.Object@ResultTitle 		<- character()
			.Object@ResultNotes 		<- character()
			.Object@ResultType			<- character()
			.Object@EncodedResult 		<- character()
			.Object@ErrorDescription	<- character()
			.Object@SinkObjects 		<- list()
			.Object@ErrorDate	 		<- character()
			.Object
		}
)

##############################################
## Method to encode RavianResultError objects
#' Requests ecoding of results for a RavianResultError object.
#' 
#' @param object A RavianResultError object.
#' @param outtype A string indicating the type of encoding: html, json, javascript
#' @param ... Other parameters to be passed to the method, such as additional message contents or naming of error log file (unsupported presently)
setMethod("encodeRavianResultObject", signature(object = "RavianResultError", outtype = "character"),
		function(object,outtype="html", ...){
			resout<-""
			errttl<-ResultTitle(object)
			errmsg<-ErrorDescription(object)
			errobj<-SinkObjects(object)
			errdate<-ErrorDate(object)
			
			#get the support address:
			log.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianLogRegistry.yaml",sep="")),silent=TRUE)
			supportAddress<-log.registry[["general"]][["supportAddress"]]
			urlHelp<-log.registry[["general"]][["urlHelp"]]
			
			idv<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			
			snk<-addRavianLog(logobj=errobj, logdir="general", idv=idv)	#addRavianLogs is in the utilsRavianR file What is the log ID???
			errorsupport<-paste("Please contact us at",supportAddress,"for additional help.")
			
			#encode the message
			if(outtype=="html" || outtype=="javascript"){
				errmsg<-paste(errdate,"<br />",errmsg, "<br />", errorsupport, "<br /> Error log ID:", snk)
				resout<-errmsg
			}else{
				pref<-substr(errmsg,1,7)
				if(casefold(pref)=="error: "){
					errmsg<-substr(errmsg,8,nchar(errmsg))
				}
				errmsg<-paste(errmsg,errorsupport)
				##EncodedResult(resObj) should return...
				#{\"resultType\":\"e.g.,Table\",\"resultTitle\":\"My first table name\",\"resultContents\":[\"table as json\"],\"resultID\":\"Ravian3098683\"}
				#make sure to escape any quotes in errmsg
				errmsg<-gsub('"','',errmsg)
				resout<-paste("{\"resultType\":\"Error\",\"resultTitle\":\"",errttl,"\",\"resultContents\":\"",errmsg,"\",\"resultID\":\"",snk,"\"}",sep="")
			}
			EncodedResult(object)<-resout
			return(object)
		}
)


################################################################################################

#' RavianResultWarning class - subclass of RavianResult Class
#' 
#' @param ResultTitle Character string that names the result object (e.g., table title, graph title, error prompt)
#' @param ResultNotes Character string with any notes about the object
#' @param ResultType A string, always "Warning"
#' @param EncodedResult A string with the resulting encoded (as html, json or javascript) result
#' @param WarningDescription A string with a simple description of the warning, to be passed to the client
#' @exportClass RavianResultWarning
setClass("RavianResultWarning",contains=c("RavianResults"),
		prototype=prototype(ResultType="Warning"), 
		representation(
				ResultTitle = "character",
				ResultNotes = "character",
				ResultType = "character",
				EncodedResult = "character",
				WarningDescription = "character"
		))

#############################
#' Set generic to  method that sets the WarningDescription slot of RavianResultWarning object.
#' 
#' @name setWarningDescription
#' @param object An RavianResultWarning object
#' @param value String to put into WarningDescription slot.
setGeneric("WarningDescription<-", 
		function(object, value)	standardGeneric("WarningDescription<-"))

#' Set WarningDescription slot of RavianResultWarning object.
#' 
#' @name setWarningDescription
#' @param object An RavianResultWarning object
#' @param value String to put into WarningDescription slot.
setReplaceMethod("WarningDescription", signature(object="RavianResultWarning"),
		function(object,value){
			slot(object,"WarningDescription")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves WarningDescription slot value of RavianResultWarning object.
#' 
#' @name WarningDescription
#' @param object An RavianResultWarning object
setGeneric("WarningDescription",
		function(object)	standardGeneric("WarningDescription"))

#' Retrieve WarningDescription slot value of RavianResultWarning object.
#' 
#' @name WarningDescription
#' @param object An RavianResultWarning object
setMethod("WarningDescription", signature(object="RavianResultWarning"),
		function(object) slot(object,"WarningDescription"))

############################## Initialize RavianResultWarning object
#' Instantiate a new RavianResultWarning object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "RavianResultWarning"),
		function (.Object, ...) 
		{
			.Object@ResultTitle 		<- character()
			.Object@ResultNotes 		<- character()
			.Object@ResultType			<- character()
			.Object@EncodedResult 		<- character()
			.Object@WarningDescription	<- character()
			.Object
		}
)

##############################################
## Method to encode RavianResultWarning objects
#' Requests ecoding of results for a RavianResultWarning object.
#' 
#' @param object A RavianResultWarning object.
setMethod("encodeRavianResultObject", signature(object = "RavianResultWarning", outtype = "character"),
		function(object,outtype="html", ...){
			resout<-""
			wrnttl<-ResultTitle(object)
			wrnmsg<-WarningDescription(object)
			
			#get the support address:
			log.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianLogRegistry.yaml",sep="")),silent=TRUE)
			supportAddress<-log.registry[["general"]][["supportAddress"]]
			urlHelp<-log.registry[["general"]][["urlHelp"]]
			
			warnsupport<-paste("Please review your selections and try again. If you need help with this application, please contact us at",supportAddress)
			idv<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			
			#encode the message
			if(outtype=="html" || outtype=="javascript"){
				wrnmsg<-paste(wrnmsg, "<br />", warnsupport)
				resout<-wrnmsg
			}else{
				pref<-substr(wrnmsg,1,7)
				if(casefold(pref)=="error: "){
					wrnmsg<-substr(wrnmsg,8,nchar(wrnmsg))
				}
				wrnmsg<-paste(wrnmsg,warnsupport)
				resout<-paste("{\"resultType\":\"Warning\",\"resultTitle\":\"",wrnttl,"\",\"resultContents\":\"",wrnmsg,"\",\"resultID\":\"",idv,"\"}",sep="")
			}
			EncodedResult(object)<-resout
			return(object)
		}
)


################################################################################################

#' RavianResultTable - subclass of RavianResult Class
#' @param ResultTitle Character string that names the result object (e.g., table title, graph title, error prompt)
#' @param ResultNotes Character string with any notes about the object
#' @param ResultType A string, always "Table"
#' @param EncodedResult A string with the resulting encoded (as html, json or javascript) result
#' @param ResultTable A data.frame object with the table's data
#' @exportClass RavianResultTable
setClass("RavianResultTable",contains=c("RavianResults"),
		prototype=prototype(ResultType="Table"), 
		representation(
				ResultTitle = "character",
				ResultNotes = "character",
				ResultType = "character",
				EncodedResult = "character",
				ResultTable = "data.frame"
		))
				
#############################
#' Set generic to  method that sets the ResultTable slot of RavianResultTable object.
#' 
#' @name setResultTable
#' @param object An RavianResultTable object
#' @param value Data frame to put into ResultTable slot.
setGeneric("ResultTable<-", 
		function(object, value)	standardGeneric("ResultTable<-"))

#' Set ResultTable slot of RavianResultTable object.
#' 
#' @name setResultTable
#' @param object An RavianResultTable object
#' @param value Data.frame to put into ResultTable slot.
setReplaceMethod("ResultTable", signature(object="RavianResultTable"),
		function(object,value){
			slot(object,"ResultTable")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ResultTable slot value of RavianResultTable object.
#' 
#' @name ResultTable
#' @param object An RavianResultTable object
setGeneric("ResultTable",
		function(object)	standardGeneric("ResultTable"))

#' Retrieve ResultTable slot value of RavianResultTable object.
#' 
#' @name ResultTable
#' @param object An RavianResultTable object
setMethod("ResultTable", signature(object="RavianResultTable"),
		function(object) slot(object,"ResultTable"))

############################## Initialize RavianResultTable object
#' Instantiate a new RavianResultTable object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "RavianResultTable"),
		function (.Object, ...) 
		{
			.Object@ResultTitle 		<- character()
			.Object@ResultNotes 		<- character()
			.Object@ResultType			<- character()
			.Object@EncodedResult 		<- character()
			.Object@ResultTable	 		<- data.frame()
			.Object
		}
)

################################################################################################
## Method to encode RavianResultTable objects
#' Requests ecoding of results for a RavianResultTable object.
#' 
#' @param object A RavianResultTable object.
setMethod("encodeRavianResultObject", signature(object = "RavianResultTable", outtype = "character"),
		function(object,outtype="html", ...){
			title<-ResultTitle(object)
			df<-ResultTable(object)
			notes<-ResultNotes(object)
			
			tbl<-""
			capt<-"Result Table"
			if(NROW(title)==1){
				capt<-title
			}
			#encode the table
			idv<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			if(outtype=="html"){
				tbl<-as.character(kable(x=df,format="html",row.names=FALSE,table.attr=paste("caption=\"",capt,"\" id=\"",idv,"\"",sep="")))	
			}else if(outtype=="javascript"){
				tbl<-kable(x=df,format="html",row.names=FALSE,table.attr=paste("caption=\"",capt,"\" id=\"",idv,"\"",sep=""))
				jsid<-paste("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>\n ",
						"\n  <script type=\"text/javascript\">\n  $(document).ready(function() {\n  $('#",idv,"').DataTable();\n  } );\n  </script>\n ",sep="")
				tbl<-paste(tbl, jsid)
			}else{
				#resout<-paste("{\"resultType\":\"Warning\",\"resultTitle\":\"",wrnttl,"\",\"resultContents\":\"",wrnmsg,"\",\"resultID\":\"",idv,"\"}",sep="")
				for(cc in ncol(df)){
					df[,cc]<-as.character(df[,cc])
				}
				tbl<-paste("{\"resultType\":\"Table\",\"resultTitle\":\"",capt,"\",\"resultContents\":[",as.character(toJSON(df,na="string")),"],\"resultID\":\"",idv,"\"}",sep="")
			}
			EncodedResult(object)<-tbl
			return(object)
		}
)

################################################################################################

#' RavianResultGraph - subclass of RavianResult Class
#' @param ResultTitle Character string that names the result object (e.g., table title, graph title, error prompt)
#' @param ResultNotes Character string with any notes about the object
#' @param ResultType A string, always "Graph"
#' @param EncodedResult A string with the resulting encoded (as html, json or javascript) result
#' @param ResultGraphPltFunction A string naming the plotting function that contains the ggplot generating function - a function defined by the pluggin file
#' @param ResultGraphArgs A list object with the arguments used by the ggplot generating function
#' @exportClass RavianResultGraph
setClass("RavianResultGraph",contains=c("RavianResults"),
		prototype=prototype(ResultType="Graph"), 
		representation(
				ResultTitle = "character",
				ResultNotes = "character",
				ResultType = "character",
				EncodedResult = "character",
				ResultGraphPltFunction = "character",
				ResultGraphArgs = "list"
		))

#############################
#' Set generic to  method that sets the ResultGraphPltFunction slot of RavianResultGraph object.
#' 
#' @name setResultGraphPltFunction
#' @param object An RavianResultGraph object
#' @param value A string naming the plotting function, to put into ResultGraphPltFunction slot
setGeneric("ResultGraphPltFunction<-", 
		function(object, value)	standardGeneric("ResultGraphPltFunction<-"))

#' Set ResultGraphPltFunction slot of RavianResultGraph object.
#' 
#' @name setResultGraphPltFunction
#' @param object An RavianResultGraph object
#' @param value A string naming the plotting function, to put into ResultGraphPltFunction slot
setReplaceMethod("ResultGraphPltFunction", signature(object="RavianResultGraph"),
		function(object,value){
			slot(object,"ResultGraphPltFunction")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ResultGraphPltFunction slot value of RavianResultGraph object.
#' 
#' @name ResultGraphPltFunction
#' @param object An RavianResultGraph object
setGeneric("ResultGraphPltFunction",
		function(object)	standardGeneric("ResultGraphPltFunction"))

#' Retrieve ResultGraphPltFunction slot value of RavianResultGraph object.
#' 
#' @name ResultGraphPltFunction
#' @param object An RavianResultGraph object
setMethod("ResultGraphPltFunction", signature(object="RavianResultGraph"),
		function(object) slot(object,"ResultGraphPltFunction"))

#############################
#' Set generic to  method that sets the ResultGraphArgs slot of RavianResultGraph object.
#' 
#' @name setResultGraphArgs
#' @param object An RavianResultGraph object
#' @param value A list to put into ResultGraphArgs slot
setGeneric("ResultGraphArgs<-", 
		function(object, value)	standardGeneric("ResultGraphArgs<-"))

#' Set ResultGraphArgs slot of RavianResultGraph object.
#' 
#' @name setResultGraphArgs
#' @param object An RavianResultGraph object
#' @param value A list object to put into ResultGraphArgs slot
setReplaceMethod("ResultGraphArgs", signature(object="RavianResultGraph"),
		function(object,value){
			slot(object,"ResultGraphArgs")<-value
			validObject(object)
			object
		})

#' Set generic to  method that retrieves ResultGraphArgs slot value of RavianResultGraph object.
#' 
#' @name ResultGraphArgs
#' @param object An RavianResultGraph object
setGeneric("ResultGraphArgs",
		function(object)	standardGeneric("ResultGraphArgs"))

#' Retrieve ResultGraphArgs slot value of RavianResultGraph object.
#' 
#' @name ResultGraphArgs
#' @param object An RavianResultGraph object
setMethod("ResultGraphArgs", signature(object="RavianResultGraph"),
		function(object) slot(object,"ResultGraphArgs"))

############################## Initialize RavianResultGraph object
#' Instantiate a new RavianResultGraph object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "RavianResultGraph"),
		function (.Object, ...) 
		{
			.Object@ResultTitle 		<- character()
			.Object@ResultNotes 		<- character()
			.Object@ResultType			<- character()
			.Object@EncodedResult 		<- character()
			.Object@ResultGraphPltFunction	<- character()
			.Object@ResultGraphArgs		<- list()
			.Object
		}
)

################################################################################################
## Method to encode RavianResultGraph objects
#' Requests ecoding of results for a RavianResultGraph object.
#' 
#' @param object A RavianResultGraph object.
#' @param outtype A character string specifying the type of output requested: html, javascript, json
#' @param tooltip Only applicable for ggplotly outputs: the aesthetic to display in the tooltip. Defaults to all.
setMethod("encodeRavianResultObject", signature(object = "RavianResultGraph", outtype = "character"),
		function(object,outtype="html", tooltip="all", ...){
			#generate the ggplot2 object
			argsLst<-ResultGraphArgs(object)
			grphFnct<-ResultGraphPltFunction(object)
			graphttl<-ResultTitle(object)
			for(nn in names(argsLst)){ #making sure the ggplot function can find the args, because its binding envir is not env or the envir of the pluggin's function
				.GlobalEnv[[nn]]<-nn
			}
			
			idv<-substr(tempfile(pattern="Ravian", tmpdir=""),2,20)
			
			plt<-try(do.call(what=grphFnct,args=argsLst,envir=.GlobalEnv),silent=TRUE)
			if(inherits(plt,"try-error")){
				resout<-""
				errttl<-graphttl
				errmsg<-"Error: Ravian failed to generate the ggplot object."
				errobj<-object
				errdate<-Sys.time()
				
				#get the support address:
				log.registry<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianLogRegistry.yaml",sep="")),silent=TRUE)
				supportAddress<-log.registry[["general"]][["supportAddress"]]
				urlHelp<-log.registry[["general"]][["urlHelp"]]
				
				snk<-addRavianLog(logobj=errobj, logdir="general", idv=idv)	#addRavianLogs is in the utilsRavianR file What is the log ID???
				errorsupport<-paste("Please contact us at",supportAddress,"for additional help.")
				
				#encode the message
				if(outtype=="html" || outtype=="javascript"){
					errmsg<-paste(errdate,"<br />",errmsg, "<br />", errorsupport, "<br /> Error log ID:", snk)
					resout<-errmsg
				}else{
					pref<-substr(errmsg,1,7)
					if(casefold(pref)=="error: "){
						errmsg<-substr(errmsg,8,nchar(errmsg))
					}
					errmsg<-paste(errmsg,errorsupport)
					##EncodedResult(resObj) should return...
					#{\"resultType\":\"e.g.,Table\",\"resultTitle\":\"My first table name\",\"resultContents\":[\"table as json\"],\"resultID\":\"Ravian3098683\"}
					resout<-paste("{\"resultType\":\"Error\",\"resultTitle\":\"",errttl,"\",\"resultContents\":\"",errmsg,"\",\"resultID\":\"",snk,"\"}",sep="")
				}
				
			}else{
				#now generate the encoding...
				if(outtype=="html"){ 	#html is the encoded plot
					htgrph<-create.EncodeGraph(plobj=plt,...)
					resout<-paste('<figure caption="',graphttl,'"  id="',idv,'">\n  <img src="data:image/png;base64,',htgrph,'" alt="Ravian plot" />\n </figure>',sep="")
				}else if(outtype=="png"){
					htgrph<-create.EncodeGraph(plobj=plt,...)
					resout<-htgrph
				}else if(outtype=="json"){ #json is just the json in plotly object
					#plotly first creates a plotly list object with q<-gg2list(p)
					#all we need is to convert the list to json, so...
					assign("plt",plt,envir=.GlobalEnv)	#make it discoverable by other functions' bindings...
					resjson<-createJSONforPlotly(plt, tooltip=tooltip)
					#add the following to each:
					resout<-paste("{\"resultType\":\"Graph\",\"resultTitle\":\"",graphttl,"\",\"resultContents\":",resjson,"}",sep="")
				}else if(outtype=="javascript"){#javascript is the full plotly code
					#this requires that we generate the widget object first
					#put this in a utils function, and use a yaml to configure the location of the plotly js libraries!
					resout<-createHTMLforPlotly(plobj=plt, tooltip=tooltip)
				}
			}
			EncodedResult(object)<-resout
			return(object)
		})
