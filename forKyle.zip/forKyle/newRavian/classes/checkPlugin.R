# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This class uses information passed to it by dispatchRavian to return a plugin file (i.e., file to source) with signatures being the warehouse name and the analysis requested
## to return the object of the class checkPlugin with the name of the plugin file, if one is found in the Ravian plugin registry

################################## Object def
#' Abstract class for checkPlugin
#' 
#' Abstract class for checkPlugin
#' 
#' @param FormData A json string with the GET/POST request as it was passed to checkPlugin
#' @param RegistryData A list object with the contents of Ravian plugin registry, as rad from the YAML file by dispatchRavian
#' @param PluginName A string naming the file to source 
#' @param AnalysisTitle A string with the title for the analysis that generated the results. This should be described in the yaml entry for the plugin used.
#' @param ErrorReport A string vector to store any error reports
setClass("checkPlugin", representation(
				FormData = "character",
				RegistryData = "list",
				PluginName = "character",
				AnalysisTitle = "character",
				ErrorReport = "character"
		)
)

############################### class operation methods ############################################################

############################## FormData
#Generic set by speciesKeys.R

#' Set FormData slot of checkPlugin object.
#' 
#' @name setFormData
#' @param object A checkPlugin object
#' @param value A json string to put into the FormData slot, which includes the parameters of the POST.
setReplaceMethod("FormData",signature(object="checkPlugin"),
		function(object,value) {
			slot(object,"FormData")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the FormData slot of the checkPlugin object.
#' 
#' @name FormData
#' @param object A checkPlugin object
setMethod("FormData", signature(object="checkPlugin"),
		function(object) slot(object,"FormData"))

############################## RegistryData
#' Set generic to  method that sets the RegistryData slot of checkPlugin object.
#' 
#' @name setRegistryData
#' @param object A checkPlugin object
#' @param value A list with the Ravian plugin registry, to put into the RegistryData slot.
setGeneric("RegistryData<-", 
		function(object, value)	standardGeneric("RegistryData<-"))

#' Set RegistryData slot of checkPlugin object.
#' 
#' @name setRegistryData
#' @param object A checkPlugin object
#' @param value A list with the Ravian plugin registry, to put into the RegistryData slot.
setReplaceMethod("RegistryData",signature(object="checkPlugin"),
		function(object,value) {
			slot(object,"RegistryData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the RegistryData slot of the checkPlugin object.
#' 
#' @name RegistryData
#' @param object A checkPlugin object
setGeneric("RegistryData", 
		function(object) standardGeneric("RegistryData"))

#' Retrieve the contents of the RegistryData slot of the checkPlugin object.
#' 
#' @name RegistryData
#' @param object A checkPlugin object
setMethod("RegistryData", signature(object="checkPlugin"),
		function(object) slot(object,"RegistryData"))

############################## PluginName
#' Set generic to  method that sets the PluginName slot of checkPlugin object.
#' 
#' @name setPluginName
#' @param object A checkPlugin object
#' @param value A string naming the file to source for the application requested
setGeneric("PluginName<-", 
		function(object, value)	standardGeneric("PluginName<-"))

#' Set PluginName slot of checkPlugin object.
#' 
#' @name setPluginName
#' @param object A checkPlugin object
#' @param value A string naming the file to source for the application requested
setReplaceMethod("PluginName",signature(object="checkPlugin"),
		function(object,value) {
			slot(object,"PluginName")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the PluginName slot of the checkPlugin object.
#' 
#' @name PluginName
#' @param object A checkPlugin object
setGeneric("PluginName", 
		function(object) standardGeneric("PluginName"))

#' Retrieve the contents of the PluginName slot of the checkPlugin object.
#' 
#' @name PluginName
#' @param object A checkPlugin object
setMethod("PluginName", signature(object="checkPlugin"),
		function(object) slot(object,"PluginName"))

############################## AnalysisTitle
#' Set generic to  method that sets the AnalysisTitle slot of checkPlugin object.
#' 
#' @name setAnalysisTitle
#' @param object A checkPlugin object
#' @param value A string specifying the type of output requested: html, json, javascript
setGeneric("AnalysisTitle<-", 
		function(object, value)	standardGeneric("AnalysisTitle<-"))

#' Set AnalysisTitle slot of checkPlugin object.
#' 
#' @name setAnalysisTitle
#' @param object A checkPlugin object
#' @param value A string specifying the type of output requested: html, json, javascript
setReplaceMethod("AnalysisTitle",signature(object="checkPlugin"),
		function(object,value) {
			slot(object,"AnalysisTitle")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the AnalysisTitle slot of the checkPlugin object.
#' 
#' @name AnalysisTitle
#' @param object A checkPlugin object
setGeneric("AnalysisTitle", 
		function(object) standardGeneric("AnalysisTitle"))

#' Retrieve the contents of the ResultHandle slot of the checkPlugin object.
#' 
#' @name AnalysisTitle
#' @param object A checkPlugin object
setMethod("AnalysisTitle", signature(object="checkPlugin"),
		function(object) slot(object,"AnalysisTitle"))


############################## ErrorReport
#Generic set by validateRavianDomain.R

#' Set ErrorReport slot of checkPlugin object.
#' 
#' @name setErrorReport
#' @param object A checkPlugin object
#' @param value A string to put into the ErrorReport slot
setReplaceMethod("ErrorReport",signature(object="checkPlugin"),
		function(object,value) {
			slot(object,"ErrorReport")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ErrorReport slot of the checkPlugin object.
#' 
#' @name ErrorReport
#' @param object A checkPlugin object
setMethod("ErrorReport", signature(object="checkPlugin"),
		function(object) slot(object,"ErrorReport"))


############################## Initialize
#' Instantiate a new checkPlugin object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "checkPlugin"),
		function (.Object, ...) 
		{
			.Object@FormData 		<- character()
			.Object@RegistryData 	<- list()
			.Object@PluginName 		<- character()
			.Object@AnalysisTitle	<- character()
			.Object@ErrorReport		<- character()
			.Object
		}
)


##################################### getPluginName

#' Set generic to  method that gets the analysis function name from the warehouse name and function, using the Ravian plugin registry
#' 
#' @name getPluginName
#' @param object A checkPlugin object. 
setGeneric("getPluginName",
		function(object) standardGeneric("getPluginName"))

#' Get the analysis function name from the warehouse name and function, using the Ravian plugin registry
#' 
#' @param object A checkPlugin object.
setMethod("getPluginName", signature(object = "checkPlugin"),
		function(object) {
				
			fd<-fromJSON(FormData(object))
			fda<-fd$analysisName
			fdwn<-fd$warehouseName
			if(NROW(fda)==0 || nchar(fda)==0 || NROW(fdwn)==0 || nchar(fdwn)==0){
				ErrorReport(object)<-"Error: Ravian cannot determine the plugin to request of analyses."
			}else{
				reg<-RegistryData(object)
				whd<-reg[[fdwn]]
				pgn<-character();anattl<-character()
				for(ii in 1:NROW(whd)){
					bb<-names(whd[[ii]]$analyses)
					if(TRUE %in% grepl(fda,bb)){
						anattl<-c(anattl,whd[[ii]][[2]][[1]])
						pgn<-c(pgn,whd[[ii]]$plugin[[1]])
					}
				}
				if(NROW(pgn)==1){
					PluginName(object)<-pgn
					AnalysisTitle(object)<-anattl
					regpath<-try(yaml.load_file(paste(Sys.getenv("R_SHARE_DIR"),"/RavianConfig/RavianPluginRegistry.yaml",sep="")),silent=TRUE)
					if(inherits(regpath,"try-error")){
						ErrorReport(object)<-"Error: Ravian cannot read the plugin registry file."
					}else{
						srcpth<-paste(regpath$sourcepath,pgn,sep="")
						if(!file.exists(srcpth)){
							ErrorReport(object)<-paste("Error: though it is named in the plugin registry, Ravian cannot find the plugin",pgn,"in the sources folder. Maybe it has not been pulled into the server.")
						}
					}
				}else if(NROW(pgn)>1){
					ErrorReport(object)<-"Error: Ravian found more than one plugin registered under the same warehouse and application name."
				}else{
					ErrorReport(object)<-"Error: Ravian found no plugin registered under the provided warehouse and application name."
				}
			}
			return(object)
		}
)



