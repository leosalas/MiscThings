#' @include connectRavian.R

# TODO: Add comment
# 
# Author: lsalas
###############################################################################


## This class uses information passed to it by dispatchRavian to locate the FieldBirdId keys identifying all species in a guild or set of guilds
## to return the object of the class speciesKeys with a list where each element is a vector of keys, and its name is the name of the guild
## The request may contain no guild keys, in which case the list is of size 0

################################## Object def
#' Abstract class for speciesKeys
#' 
#' Abstract class for speciesKeys
#' 
#' @param FormData A json string with the GET/POST request as it was passed to speciesKeys
#' @param ConnectHandle A connectRavian object with the connection handle to resolve the request
#' @param ResultKeys A list whose each element is a numeric list of FieldBirdId keys identifying the component species of a guild
#' 			and the name of the list element is the name of the guild. Alternatively, if species were selected instead of guilds,
#' 			the list includes only one element, named "SelectedSpecies", with the species keys in the post. If no guild information is provided, 
#' 			the result list is of size 0. 
#' @param ErrorReport A string vector to store any error reports
setClass("speciesKeys", representation(
				FormData = "character",
				ConnectHandle = "connectRavian",
				ResultKeys = "data.frame",
				ErrorReport = "character"
		)
)

############################### class operation methods ############################################################

############################## FormData
#' Set generic to  method that sets the FormData slot of speciesKeys object.
#' 
#' @name setFormData
#' @param object A speciesKeys object
#' @param value A json string to put into the FormData slot, which includes the parameters of the POST.
setGeneric("FormData<-", 
		function(object, value)	standardGeneric("FormData<-"))

#' Set FormData slot of speciesKeys object.
#' 
#' @name setFormData
#' @param object A speciesKeys object
#' @param value A json string to put into the FormData slot, which includes the parameters of the POST.
setReplaceMethod("FormData",signature(object="speciesKeys"),
		function(object,value) {
			slot(object,"FormData")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the FormData slot of the speciesKeys object.
#' 
#' @name FormData
#' @param object A speciesKeys object
setGeneric("FormData", 
		function(object) standardGeneric("FormData"))

#' Retrieve the contents of the FormData slot of the speciesKeys object.
#' 
#' @name FormData
#' @param object A speciesKeys object
setMethod("FormData", signature(object="speciesKeys"),
		function(object) slot(object,"FormData"))

############################## ConnectHandle
#' Set generic to  method that sets the ConnectHandle slot of speciesKeys object.
#' 
#' @name setConnectHandle
#' @param object A speciesKeys object
#' @param value A connectRavian object to put into the ConnectHandle slot.
setGeneric("ConnectHandle<-", 
		function(object, value)	standardGeneric("ConnectHandle<-"))

#' Set ConnectHandle slot of speciesKeys object.
#' 
#' @name setConnectHandle
#' @param object A speciesKeys object
#' @param value A connectRavian object to put into the ConnectHandle slot.
setReplaceMethod("ConnectHandle",signature(object="speciesKeys"),
		function(object,value) {
			slot(object,"ConnectHandle")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the ConnectHandle slot of the speciesKeys object.
#' 
#' @name ConnectHandle
#' @param object A speciesKeys object
setGeneric("ConnectHandle", 
		function(object) standardGeneric("ConnectHandle"))

#' Retrieve the contents of the ConnectHandle slot of the speciesKeys object.
#' 
#' @name ConnectHandle
#' @param object A speciesKeys object
setMethod("ConnectHandle", signature(object="speciesKeys"),
		function(object) slot(object,"ConnectHandle"))

############################## ResultKeys
#' Set generic to  method that sets the ResultKeys slot of speciesKeys object.
#' 
#' @name setResultKeys
#' @param object A speciesKeys object
#' @param value A data.frame to put into the ResultKeys slot, whose each element is a numeric vector describing each guild in the request, or an error evaluating the guild
setGeneric("ResultKeys<-", 
		function(object, value)	standardGeneric("ResultKeys<-"))

#' Set ResultKeys slot of speciesKeys object.
#' 
#' @name setResultKeys
#' @param object A speciesKeys object
#' @param value A data.frame to put into the ResultKeys slot, whose each element is a numeric vector describing each guild in the request, or an error evaluating the guild
setReplaceMethod("ResultKeys",signature(object="speciesKeys"),
		function(object,value) {
			slot(object,"ResultKeys")<-value
			validObject(object)
			object
		})

#' Set generic to the method that retrieves the contents of the ResultKeys slot of the speciesKeys object.
#' 
#' @name ResultKeys
#' @param object A speciesKeys object
setGeneric("ResultKeys", 
		function(object) standardGeneric("ResultKeys"))

#' Retrieve the contents of the ResultKeys slot of the speciesKeys object.
#' 
#' @name ResultKeys
#' @param object A speciesKeys object
setMethod("ResultKeys", signature(object="speciesKeys"),
		function(object) slot(object,"ResultKeys"))

############################## ErrorReport
#Generic set by validateRavianDomain.R

#' Set ErrorReport slot of speciesKeys object.
#' 
#' @name setErrorReport
#' @param object A speciesKeys object
#' @param value A string to put into the ErrorReport slot
setReplaceMethod("ErrorReport",signature(object="speciesKeys"),
		function(object,value) {
			slot(object,"ErrorReport")<-value
			validObject(object)
			object
		})

#' Retrieve the contents of the ErrorReport slot of the speciesKeys object.
#' 
#' @name ErrorReport
#' @param object A speciesKeys object
setMethod("ErrorReport", signature(object="speciesKeys"),
		function(object) slot(object,"ErrorReport"))


############################## Initialize
#' Instantiate a new speciesKeys object
#' 
#' @name initialize
setMethod("initialize",
		signature(.Object = "speciesKeys"),
		function (.Object, ...) 
		{
			.Object@FormData 		<- character()
			.Object@ConnectHandle 	<- new("connectRavian")
			.Object@ResultKeys 		<- data.frame()
			.Object@ErrorReport		<- character()
			.Object
		}
)



##################################### evaluateSpeciesKeys
#returns a list of vectors with FieldBirdId keys, one for each guild key
#' Set generic to  method that gets FieldBirdId keys from the FormData slot in the object
#' 
#' @name evaluateSpeciesKeys
#' @param object An speciesKeys object. 
setGeneric("evaluateSpeciesKeys",
		function(object) standardGeneric("evaluateSpeciesKeys"))

#' Get FieldBirdId keys from the FormData slot in the object
#' 
#' @param object A speciesKeys object.
setMethod("evaluateSpeciesKeys", signature(object = "speciesKeys"),
		function(object) {
			#decode and evaluate FormData
			res<-ResultKeys(object)
			fd<-fromJSON(FormData(object))
			if(NROW(fd$guilds)==0){	
				#no guild info
				#check for species keys
				if(NROW(fd$species)==0){	
					#no species info, return object as is
				}else{	
					#the contents are species codes and need to translate to FieldBirdIs
					connObj<-ConnectHandle(object)
					HandleType(connObj)<-"support"
					conn<-ResultHandle(getRavianHandle(connObj))[[1]]
					
					#evaluate the handle for an error
					if(inherits(conn,"try-error")){
						ErrorReport(object)<-as.character(conn)
					}else{
						#have connection handle, make sql request
						#get the species codes from fd
						sppCodes<-paste("('",paste(fd$species,collapse="','"),"')",sep="")
						res<-data.frame()
						sqltxt<-paste("select BirdCd,FieldBirdId from PRBOdb.FieldBird_v2 where BirdCd in ",sppCodes,sep="")
						gdf<-try(sqlQuery(conn,sqltxt,rows_at_time=1),silent=TRUE)
						if(inherits(gdf,"try-error") || (TRUE %in% grepl("ERROR",gdf))){
							ErrorReport(object)<-"Error: an error occurred when Ravian attempted to obtain species Id keys"
						}else{
							if(nrow(gdf)==0){
								ErrorReport(object)<-"Error: Ravian did not find definitions for the species requested"
							}else{
								names(gdf)<-c("SpeciesCode","TaxonId")
								res<-gdf
							}
						}
					}
				}
			}else{
				#guild keys were passed - need to resolve...
				#NOT assuming the POST includes the species keys
				#fd$guilds shoud be an array of arrays guildnames
				
				connObj<-ConnectHandle(object)
				HandleType(connObj)<-"support"
				conn<-ResultHandle(getRavianHandle(connObj))[[1]]
				
				#evaluate the handle for an error
				if(inherits(conn,"try-error")){
					ErrorReport(object)<-as.character(conn)
				}else{
					#have connection handle, make sql request
					#get the guild category and guild keys from fd
					guildCat<-names(fd$guilds)
					guildnames<-fd$guilds[[guildCat]]
					res<-data.frame()
					for(ggg in guildnames){
						sqltxt<-paste("select FieldBirdId from PRBOdb.FieldBirdGuild where GuildCategory='",guildCat,"' and GuildName='",ggg,"'",sep="")
						gdf<-try(sqlQuery(conn,sqltxt,rows_at_time=1),silent=TRUE)
						if(inherits(gdf,"try-error") || (TRUE %in% grepl("ERROR",gdf))){
							ErrorReport(object)<-"Error: an error occurred when Ravian attempted to obtain species guild definitions"
						}else{
							if(nrow(gdf)==0){
								ErrorReport(object)<-"Error: Ravian did not find definitions for the species guilds requested"
							}else{
								tdf<-data.frame(Guild=ggg,TaxonId=gdf$FieldBirdId)
								res<-rbind(res,tdf)
							}
						}
					}
					
				}
##############################################
			}
			ResultKeys(object)<-res
			return(object)
		}
)


