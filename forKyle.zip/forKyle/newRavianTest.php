<?php

$reqpath=$_SERVER['DOCUMENT_ROOT'];

require_once("$reqpath/lib/rserve-php/Connection.php");

        ob_start();
        try
	{
        	$cnx = new Rserve_Connection('localhost',6311,array('debug'=>FALSE));
		$cnx->evalString('library(IWMMAnalyst)');

		$requestBodyRaw = file_get_contents('php://input');
		$requestBody = json_decode($requestBodyRaw);

		//create the requestParameters json object from the call
	        $cnarr = 'requestParameters <- "' . addslashes( $requestBodyRaw ) . '"';
//                file_put_contents('request_contents.txt', $requestBody);
	        $cnx->evalString($cnarr);
       		$cnx->evalString('w<-passToDispatch(requestParameters=requestParameters)');
                $resulttbl = $cnx->evalString('print(w)');
		ob_clean();	//remove warnings from the buffer
		echo $resulttbl;
		$cnx->close();
	}
	catch (Exception $e)
	{
		error_log($e);
        	echo $e->getMessage();
		ob_end_flush();
		exit();
        }

	if($requestBody->outputFormat == 'json')
        {
        	header("Content-Type:application/json");
		ob_end_flush();
	}
	elseif($requestBody->outputFormat == 'pdf')
	{
		$pdfFilePath = ob_get_contents();
		ob_end_clean();
		header("Content-type:application/pdf");
		header("Content-Disposition:inline");
		readfile($pdfFilePath);
	}
	else
	{
		ob_end_flush();
	}
