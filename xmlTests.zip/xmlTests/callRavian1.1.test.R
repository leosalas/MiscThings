# TODO: Add comment
# 
# Author: lsalas
###############################################################################
options(Hverbose=FALSE,verbose=FALSE,warn=FALSE)
require(Ravian, quietly=TRUE, warn.conflicts=FALSE)
require(XML, quietly=TRUE, warn.conflicts=FALSE)
require(moments, quietly=TRUE, warn.conflicts=FALSE)
source("/var/www/RavianWeb/CADC.R")
source("/var/www/RavianWeb/RavianWeb1.1/crossTabulate.R")
source("/var/www/RavianWeb/RavianWeb1.1/describeVariable.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianResults1.1.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianWebOut1.0.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianWeb.Utils1.0.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianWeb.Output1.1.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianWeb.Abundance1.1.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianWeb.CrossTab1.0.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianWeb.DescribeVar1.0.R")
source("/var/www/RavianWeb/RavianWeb1.1/RavianWeb.Richness1.1.R")
source("/var/www/RavianWeb/RavianWeb1.1/checkRavianWebErrors1.1.R")

results<-list()
results.out<-""

ifelse(is.null(GET)==FALSE, formData<-GET, formData<-POST)
error<-checkRavianWebErrors(formData)	
if (error != "" ) { # there are errors in the post
	error.message.pref<-"The following error(s) have occurred prior to any RavianWeb estimation routines: <br />"
	results[[1]]<-error.report.gen(error.message.pref, error, formData, res.ordinal="1")
} else {
	if(is.null(formData$obsSQL)==TRUE) formData$obsSQL <- ""
	results.tmp<-try(do.call(paste("RavianWeb.",formData$Process,sep=""),args=list(formData)),silent=TRUE)
	if (inherits(results.tmp,"try-error")) { # handle any errors that came from the attempt to call a function 
		error.message.pref<-paste("The &call to",formData$Process,"returned the following error(s) <br />")
		error<-results.tmp	#this is sunk in the log file
		results[[1]]<-error.report.gen(error.message.pref, error, formData, res.ordinal="1")
	} else {
		results<-results.tmp	#if the wrapper executed, its return is a list of the right type - can contain error messages as graphs!
	}
}	

#have a results list with RWO objects
results.out<-try(RavianWeb.Output(results), silent=TRUE)
#How to handle an error in call to the xml wrapper?? Pass a canned XML with an error msg
if (inherits(results.out,"try-error")){
	temp.file<-basename(tempfile(pattern=""))
	error.msg<-paste("The &call to RavianWeb.Output returned the following error(s) <br />",
			paste(results.out,collapse=" <br /> "),
			"<br /> Please report the following error to developers: ", temp.file)
	save(results.out, formData, results, error.msg, file=paste("/var/www/RavianWeb/tmp/",temp.file,".RData",sep=""))
	xmlgen.part1<-"<?xml version='1.0'?><RavianResults><RavianResultSet><RavianResult><RavianResultInfo><RavianResultOrdinal>1</RavianResultOrdinal><RavianResultType>Error</RavianResultType><RavianResultTitle>RavianWeb error message</RavianResultTitle><RavianErrorLogNumber>"
	xmlgen.part2<-"</RavianErrorNumber></RavianResultInfo><RavianResultMessage>"
	xmlgen.part3<-"</RavianResultMessage></RavianResult></RavianResultSet></RavianResults>"
	results.out<-paste(xmlgen.part1,temp.file,xmlgen.part2,error.msg,xmlgen.part3, sep="")	
}
cat(results.out)

DONE