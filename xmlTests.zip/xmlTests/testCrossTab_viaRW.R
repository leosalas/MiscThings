# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 22, 2009
###############################################################################


library(Ravian)

#setwd("C:/users/mherzog/code/workspace/Ravian/devel/")
parent.dir<-"C:/Documents and Settings/lsalas/workspace"
w.dir<-paste(parent.dir,"/RavianWeb/RavianWeb1.1/test/", sep="")
setwd(w.dir)

source(paste(parent.dir,"/RavianVault/test/CADC.R",sep=""))
source(paste(parent.dir,"/RavianVault/build/BandData.R", sep=""))	#my current build is not up to date (but the server's is!)
source(paste(parent.dir,"/RavianVault/build/DataStore.R", sep=""))	#only because my Ravian version currently does not load it (??)
source(paste(parent.dir,"/RavianVault/devel/crossTabulate.R", sep=""))
source(paste(parent.dir,"/RavianWeb/RavianWeb1.1/RavianChanges/RavianResults1.1.R", sep=""))
source(paste(parent.dir,"/RavianWeb/RavianWeb1.1/devel/RavianWebOut1.0.R", sep=""))
source(paste(parent.dir,"/RavianWeb/RavianWeb1.1/devel/RavianWeb.Utils1.0.R", sep=""))

do.test<-new("BandData")
DataDefn(do.test)<-CADC("Band")
FilterList(do.test)<- list(obsSQL="CommonName='Golden-Crowned Sparrow'",
		eventSQL="ProjectCode='PALO' AND ProtocolCode='PALO_BAND' AND YearCollected < 2005"
)

rwo.list<-list()

tv<-array(dim=c(9,4))	#thus will generate 9+ crosstables
###Note: we are doing it this way so that data are harvested only once - faster
#species x year ~ Abundance/NH
tv[1,]<-c("CommonName","YearCollected","ObservationCount",NA)	#1 table; if a species selected, then table has 1 row
tv[2,]<-c("YearCollected","YearCollected","NetHours",NA)	#1 table
#species x month ~ Abundance/NH
tv[3,]<-c("CommonName","MonthCollected","ObservationCount",NA) #1 table; if a species selected, then table has 1 row
tv[4,]<-c("MonthCollected","MonthCollected","NetHours",NA)	#1 table
#station x year ~ Abundance/NH
tv[5,]<-c("StationCode","YearCollected","ObservationCount",NA)	#1 table
tv[6,]<-c("YearCollected","YearCollected","NetHours","StationCode")	#as many tables as stations in selection
#age x sex ~ Abundance by year	- meaningful only if one species selected... but who cares what user asks for?
tv[7,]<-c("LifeStage","Sex","ObservationCount",NA)	#1 table
tv[8,]<-c("LifeStage","Sex","ObservationCount","YearCollected")	#as many tables as years in selection
tv[9,]<-c("LifeStage","Sex","ObservationCount","MonthCollected") #as many tables as months in selection

tvm<-as.matrix(tv)
fun.list<-as.vector(c("sum"))

test.ct<-try(crossTabulate(object = do.test,
				table.vars= tvm,
				fun.list=fun.list))

if (inherits(test.ct,"try-error")) {
	error.message.pref = "The &call to the Ravian method to crosstabulate produced the following errors: <br />"
	rwo.list[[1]]<-error.report.gen(error.message.pref, error=test.ct, formData, data.obj=do.test)
} else {	#we have crosstables in a list that need to be parsed into RWO objects
	res.tables<-Results(test.ct)
	for(i in 1:NROW(res.tables)){
		res.tbl<-res.tables[[i]][[2]]
		if(!is.na(ncol(res.tbl))){
			class(res.tbl)<-"matrix"
			rwo.list[[i]]<-populate.RWOXTable(ordinal=i, title=res.tables[[i]][[1]], table.obj=res.tbl)
		} else {
			res.tbl<-as.data.frame(res.tbl)
			tit.tbl<-res.tables[[i]][[1]]
			colnames(res.tbl)[2]<-substr(tit.tbl,1, regexpr(" ~ ",tit.tbl)-1)
			rwo.list[[i]]<-populate.RWOTable(ordinal=i, title=res.tables[[i]][[1]], table.obj=res.tbl)
		}
	}
}

