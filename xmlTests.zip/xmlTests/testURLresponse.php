<?php
//Single url testing script
//This file should always be run from data.prbo.org
			$url_req = "http://10.10.250.42/RavianWeb/callRavian1.1.R?Process=Abundance&OutputType=XML&DataType=Band&obsSQL=CommonName='Golden-Crowned%20Sparrow'&eventSQL=ProjectCode='PALO'%20AND%20ProtocolCode='PALO_BAND'%20AND%20YearCollected<2005";
			$xml_res = file_get_contents($url_req);

//Loading result into DOM document
			$xml_doc = new DOMDocument();
			$xml_doc ->loadXML( $xml_res );

//checking the DOM
			$warn_str = "  WARNING!";

			$results = $xml_doc->getElementsByTagName("RavianResult");

			foreach($results as $result){
				$result_types = $result->getElementsByTagName("RavianResultType");
				$res_type = $result_types->item(0)->nodeValue;
				$iii = $iii+1;
				$out_str = "Result #$iii is $res_type"; 
				if(preg_match("/Error/",$res_type)) {
					$out_str = $out_str . $warn_str;
				}
				$out_str = $out_str . "<br>";
				echo $out_str;
			}

//Done!
echo "Done";
?>


<?php 
//Testing urls loaded from a text file
//This file should always be run from data.prbo.org

//Reading URLs file into array
			$url_array = file('c:\\LeoTemp\\url_list.txt', FILE_SKIP_EMPTY_LINES);
			foreach($url_array as $url_test){
				$jjj = $jjj+1;
				$iii = 0;
				echo "Begin testing $jjj <br>";
				$xml_res = file_get_contents($url_test);

//Loading result into DOM document
				$xml_doc = new DOMDocument();
				$xml_doc ->loadXML( $xml_res );

//checking the DOM
				$warn_str = "  WARNING!";

				$results = $xml_doc->getElementsByTagName("RavianResult");
				foreach($results as $result){
					$result_types = $result->getElementsByTagName("RavianResultType");
					$res_type = $result_types->item(0)->nodeValue;
					$iii = $iii+1;
					$out_str = "Result $jjj::$iii is $res_type"; 
					if(preg_match("/Error/",$res_type)) {
						$out_str = $out_str . $warn_str;
					}
					$out_str = $out_str . "<br>";
					echo $out_str;
				}
				
				echo "Done testing $jjj <br><br>";
			}
echo "Done"
?>


<?php 
//Testing a random set of urls loaded from a text file
//This file should always be run from data.prbo.org

//getting the GET info to determine the number of random tests to perform
			$_nt = $_GET["ntests"];
			if(is_null($_nt) || $_nt == "" || $_nt > 20) $_nt = 20;
			echo "Number of tests requested: $_nt <br>";

//Reading URLs file into array to count the number of tests in pool
			$url_array = file('c:\\LeoTemp\\url_list.txt', FILE_SKIP_EMPTY_LINES);
			$kkk = count($url_array);
			echo "Number of tests in pool: $kkk <br>";
			if($_nt > $kkk) $_nt = $kkk;
			echo "Number of tests to perform: $_nt <br>";

//Generating array of random tests
			if($_nt == $kkk) $url_rand = array_keys($url_array);
			else $url_rand = array_rand($url_array,$_nt);
		//Report which tests were selected
			$sel_test = "";
			foreach($url_rand as $key => $value){
				$sel_test = $sel_test . $value . ", ";
			}
			unset($value);
			$sel_test = rtrim($sel_test, ", ");
			echo "The following are the keys of the tests being performed: <br>";
			echo "$sel_test <br><br>";
			
//Testing the Analyst using the random set of tests
			echo "Beginning tests...<br><br>";
			foreach($url_rand as $url_test){
				echo "Testing key $url_test --- <br>";
				$iii = 0;
			//make url request to Analyst and get result xml
				$xml_res = file_get_contents($url_array[$url_test]);
				$xml_doc = new DOMDocument();
				$xml_doc ->loadXML( $xml_res );

			//checking the DOM of the returned xml and reporting what is found in title of object
				$warn_str = "  WARNING!";
				$results = $xml_doc->getElementsByTagName("RavianResult");
				foreach($results as $result){
					$result_types = $result->getElementsByTagName("RavianResultType");
					$res_type = $result_types->item(0)->nodeValue;
					$iii = $iii+1;
					$out_str = "Result for key $url_test::$iii is $res_type"; 
					if(preg_match("/Error/",$res_type) && !preg_match("/User Error/",$res_type)) {
						$out_str = $out_str . $warn_str;
					}
					$out_str = $out_str . "<br>";
					echo $out_str;
				}
				
				echo "Done testing key $url_test <br><br>";
			}
echo "Done"
?>