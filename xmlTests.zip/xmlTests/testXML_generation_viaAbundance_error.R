# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 22, 2009
###############################################################################


library(Ravian)
library(XML)

#setwd("C:/users/mherzog/code/workspace/Ravian/devel/")
parent.dir<-"C:/Documents and Settings/lsalas/workspace"
w.dir<-paste(parent.dir,"/RavianWeb/test/", sep="")
setwd(w.dir)

source(paste(parent.dir,"/RavianVault/test/CADC.R",sep=""))
source(paste(parent.dir,"/RavianVault/build/BandData.R", sep=""))	#my current build is not up to date (but the server's is!)
source(paste(parent.dir,"/RavianVault/build/PointCountData.R", sep=""))	#my current build is not up to date (but the server's is!)
source(paste(parent.dir,"/RavianVault/build/AreaSearchData.R", sep=""))	#my current build is not up to date (but the server's is!)
source(paste(parent.dir,"/RavianVault/build/DataStore.R", sep=""))	#only because my Ravian version currently does not load it (??)
source(paste(parent.dir,"/RavianVault/build/RavianResults1.1.R", sep=""))
source(paste(parent.dir,"/RavianWeb/build/R/RavianWebOut.R", sep=""))
source(paste(parent.dir,"/RavianWeb/build/R/RavianWeb.Utils.R", sep=""))
source(paste(parent.dir,"/RavianWeb/build/R/RavianWeb.Output.R", sep=""))
source(paste(parent.dir,"/RavianWeb/build/R/RavianWeb.Abundance.R", sep=""))

formData<-list()
formData[["Process"]]<-"Abundance"
formData[["OutputType"]]<-"XML"
formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-"SpeciesCode in ('COYE') AND DistanceFromObserver <= 50 AND Flyover != 'FlyOver'"

#User error
formData[["eventSQL"]]<-"ProjectCode IN ('XXXX') AND SamplingUnitId IN (68055,33369,33370,33371,33372,33944,33373,33374,33376,33943,33375,34028,34027,34026,34607,34608,34609,34610,34023,34024,34025,34611,34612,34613,34614,34615,34020,34021,34017,34018,34019,34022,34029) AND YearCollected >= 1900 AND YearCollected <= 2100 AND MonthCollected >= 02 AND MonthCollected <= 08"

#System error
#formData[["eventSQL"]]<-"ProjectAgua IN ('TIMA') AND SamplingUnitId IN (68055,33369,33370,33371,33372,33944,33373,33374,33376,33943,33375,34028,34027,34026,34607,34608,34609,34610,34023,34024,34025,34611,34612,34613,34614,34615,34020,34021,34017,34018,34019,34022,34029) AND YearCollected >= 1900 AND YearCollected <= 2100 AND MonthCollected >= 02 AND MonthCollected <= 08"

ggg<-RavianWeb.Abundance(formData)
NROW(ggg)

#pass the results to RWO and check the returning xml
tst.xml<-RavianWeb.Output(ggg)
sink(file="C:/LeoTemp/errors/system_error.xml")
cat(tst.xml)
sink()