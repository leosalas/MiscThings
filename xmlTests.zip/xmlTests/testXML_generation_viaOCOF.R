# TODO: Add comment
# 
# Author: lsalas
###############################################################################


#Test to see if XML generation works for crosstab calls
library(Ravian)
library(RavianWeb)

w.dir<-"/var/www/html";setwd(w.dir)

source(paste(w.dir,"/CADCocof.R",sep=""))

#Process is the name of the wrapper.  In this case RavianWeb.Summary.OCOF.R
#DataType is the name of the data object.  In this case OCOFData.R
#GeoLinkParVals1 contains the names of rasters (tables in postgis), a string of names (format??)
#GeoLinkParVals2 contains a list of WKT vectors to intersect on the rasters
#As json???


##NEED to modify GeoDataStore.R to add a method to GetOCOFData using a GeoDatStore object
##NEED a way to know which query to use based on queryType
##NEED to know how to handle different projection and datum data (EPSG code)

ww<-data.frame("schema1"=c("table1","table2","table3"))
wj<-toJSON(ww)
formData<-list(Process="Summary.OCOF",OutputType="XML",DataType="OCOFgeo",eventSQL="line",
		obsSQL="",collTables=wj,geoDbName="test2",wkt="this is a wkt",geoType="flood_depth",queryType="line")


ggg<-RavianWeb.Summary.OCOF(formData)

