# TODO: Add comment
# 
# Author: lsalas
# Date created: Apr 8, 2010
###############################################################################


#Test to see if XML generation works for crosstab calls
library(Ravian)
library(RavianWeb)


w.dir<-"C:/Documents and Settings/lsalas/workspace"
cadc.loc<-paste(w.dir,"/RavianVault/test/CADC.R",sep="")
if(Sys.info()[1]=="Linux"){
	w.dir<-"/home/lsalas/tests"
	cadc.loc<-paste(w.dir,"/CADC.R",sep="")
}
source(cadc.loc)
###USE THIS to test in rh production
#setwd("/var/www/RavianWeb/")
#source("/var/www/RavianWeb/CADC.R")
#source(paste(w.dir,"/RavianVault/devel/plotPhenology.R",sep=""))
#source("/var/www/RavianWeb/test/RavianWeb.Multimap.R")

#sourcing the RWMultimap file
 
formData<-list()
#formData[["Process"]]<-"Multimap"
#formData[["OutputType"]]<-"XML"
#formData[["level"]]<-"b"
#formData[["DataType"]]<-"AreaSearch"
#formData[["obsSQL"]]<-"SpeciesCode = 'AMAV' AND Flyover != 'FlyOver'" 
#formData[["eventSQL"]]<-"ProjectCode = 'PFLY01' AND Plot LIKE 'PFLY01:LE'"
formData<-list(Process="Multimap",OutputType="XML",DataType="BBS",
		eventSQL="ProjectCode = 'bbs' AND Transect LIKE 'Rgn14Rte015'",
		obsSQL="SpeciesCode	= 'CALT'",level="b",
		TaxonGroups="",TaxonGroupsName="",SpatialGroups="",
		SpatialGroupsName="",ObservationGroups="",ObservationGroupsName="")
#the following is done by callRavian
if(is.null(formData$obsSQL)) formData[["obsSQL"]] <- ""
if(is.null(formData$TaxonGroups)){
	formData$TaxonGroups<-""
	formData$TaxonGroupsName<-""
}
if(is.null(formData$SpatialGroups)){
	formData$SpatialGroups<-""
	formData$SpatialGroupsName<-""
}
if(is.null(formData$ObservationGroups)){
	formData$ObservationGroups<-""
	formData$ObservationGroupsName<-""
}

#ggg<-RavianWeb.Abundance.SNMIS(formData)
ggg<-RavianWeb.Multimap(formData)
NROW(ggg)

#pass the results to RWO and check the returning xml
tst.xml<-RavianWeb.Output(ggg)
sink(file="C:/LeoTemp/XMLtests/Multimap.xml")
cat(tst.xml)
sink()


#####################################
#AreaSearch - works on-line, not here - why???
formData[["DataType"]]<-"AreaSearch"
formData[["obsSQL"]]<-"Flyover != 'FlyOver'" 
formData[["eventSQL"]]<-"ProjectCode = 'PFLY01' AND Plot LIKE 'PFLY01:LE'"

#PointCount
formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-"DistanceFromObserver	<= 50 AND Flyover != 'FlyOver'"
formData[["eventSQL"]]<-"ProjectCode = 'CNPSM' AND Transect LIKE 'PRHS'"

#Banding - this works
formData[["DataType"]]<-"Band"
formData[["obsSQL"]]<-"SpeciesCode IN ('RCKI')"
formData[["eventSQL"]]<-"ProjectCode='SODS' AND StationCode IN ('HO')"

#BBS - this works
formData[["DataType"]]<-"BBS"
formData[["obsSQL"]]<-""
formData[["eventSQL"]]<-"ProjectCode = 'bbs' AND Transect LIKE 'Rgn14Rte186'"
