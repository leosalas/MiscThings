# TODO: Add comment
# 
# Author: lsalas
# Date created: Mar 7, 2011
###############################################################################


library(Ravian)
library(RavianWeb)

w.dir<-"C:/Documents and Settings/lsalas/workspace"
cadc.loc<-"/RavianVault/test/CADC.R"
if(Sys.info()[1]=="Linux"){
	w.dir<-"/home/lsalas"
	cadc.loc<-"/UnitTests/CADC.R"
}
setwd(w.dir)
source(paste(w.dir,cadc.loc,sep=""))
#source(paste(w.dir,"/RavianVault/devel/AvianData.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/PointCountData.R",sep=""))
#source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Occupancy.R",sep=""))
source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Occupancy.SNMIS.R",sep=""))
#source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Abundance.R",sep=""))
#source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Abundance.SNMIS.R",sep=""))

### Clear contents of temp folder
unlink("C:/LeoTemp/tmpRavian/RavianWeb*")

formData<-list(Process="Occupancy.SNMIS",OutputType="XML",DataType="PointCount",eventSQL="ProjectCode in ('LABLOA', 'PLAS') AND SamplingUnitId IN (65544,65588,65589,65696,65600,65646,65607,65687,65684,65683,65682,65707,65579,65569,66772,66771,66770,65548,66769,66768,66599,65559,65673,65717,65681,65680,65664,65663,65662,65661,65660,65635,65658,65657,65656,65655,65667,65670,65627,65659,65617,65679,65678,65677,65676,65675,65674,65672,65671,65654,66775,71321,71319,71320,65524,71322,71323,65535,65514,65494,66779,65495,66778,66777,66776) AND ((YearCollected >= 2009 AND YearCollected <= 2009) OR 'all' = 'all')",obsSQL="DetectionCue IN ('C','S','D') AND Flyover != 'FlyOver'  AND SpeciesCode IN ('FOSP','HAWO','MOUQ','YWAR')",level="0",TaxonGroups='{"Indicator species":["FOSP","HAWO","MOUQ","YWAR"]}',TaxonGroupsName="Indicator species",SpatialGroups='{"CB":["65544","65588","65589","65696","65600","65646","65607","65687","65684","65683","65682","65707","65579","65569","66772","66771","66770","65548","66769","66768","66599","65559","65673","65717","65681","65680","65664","65663","65662","65661","65660","65635","65658","65657","65656","65655","65667","65670","65627","65659","65617","65679","65678","65677","65676","65675","65674","65672","65671","65654","66775","71321","71319","71320","65524","71322","71323","65535","65514","65494","66779","65495","66778","66777","66776"]}',SpatialGroupsName="Forests",ObservationGroups="",ObservationGroupsName="")

#the following is done by callRavian
if(is.null(formData$obsSQL)) formData$obsSQL <- ""
if(is.null(formData$level)) formData$level <- ""
if(is.null(formData$TaxonGroups)){
	formData$TaxonGroups<-""
	formData$TaxonGroupsName<-""
}
if(is.null(formData$SpatialGroups)){
	formData$SpatialGroups<-""
	formData$SpatialGroupsName<-""
}
if(is.null(formData$ObservationGroups)){
	formData$ObservationGroups<-""
	formData$ObservationGroupsName<-""
}

ggg<-RavianWeb.Occupancy.SNMIS(formData)
#ggg<-RavianWeb.Occupancy(formData)
NROW(ggg)

#pass the results to RWO and check the returning xml
tst.xml<-RavianWeb.Output(ggg)
sink(file="C:/LeoTemp/XMLtests/Occupancy.xml")
cat(tst.xml)
sink()

