# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 23, 2009
###############################################################################

library(Ravian)
library(RavianWeb)

w.dir<-"C:/Documents and Settings/lsalas/workspace"
cadc.loc<-"/RavianVault/test/CADC.R"
if(Sys.info()[1]=="Linux"){
	w.dir<-"/home/lsalas/UnitTests"
	cadc.loc<-"/CADC.R"
}
setwd(w.dir)
source(paste(w.dir,cadc.loc,sep=""))
#source(paste(w.dir,"/RavianVault/devel/AvianData.R",sep=""))
#source(paste(w.dir,"/RavianVault/devel/PointCountData.R",sep=""))
#source(paste(w.dir,"/RavianVault/devel/AreaSearchData.R",sep=""))
#source(paste(w.dir,"/RavianVault/devel/BandData.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/ShoreBirdData.R",sep=""))
source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Richness.PFSS.R",sep=""))
#source(paste(w.dir,"/RavianWeb/devel/checkRavianWebErrors.R",sep=""))

formData<-list(Process="Richness.PFSS",OutputType="XML",DataType="ShoreBird",
		eventSQL="ProjectCode in ('SFSS','HBSS','BHSS','TBSS','BLWB','ESSS','MBSS','CVSS','SBSS','KRSS') AND SamplingUnitId IN 
				(72658,72659,72660,72661,72662,72663,72664,72665,72666,72667,75358,75359,75360,75361,75362,75363,75364,75365,75366,75367,75368,
				75369,75370,75371,75372,75373,75374,75375,75376,75377,75378,75379,75380,75381,75382,75383,75384,75385,75386,75387,75388,75389,
				75390,75391,75392,75393,75394,75395,72637,72638,72639,72640,72641,72642,72643,72644,72645,72646,72647,72648,72649,72650,72651,89065) AND 
				((YearCollected >= 1971 AND YearCollected <= 1971) OR 'all' = 'all')",
		obsSQL="",level="b",TaxonGroups="",TaxonGroupsName="",
		SpatialGroups='{"Elkhorn Slough":["72658","72659","72660","72661","72662","72663","72664","72665","72666","72667"],
				"Kern National Wildlife Refuge":["75358","75359","75360","75361","75362","75363","75364","75365","75366","75367","75368","75369",
				"75370","75371","75372","75373","75374","75375","75376","75377","75378","75379","75380","75381","75382","75383","75384","75385",
				"75386","75387","75388","75389","75390","75391","75392","75393","75394","75395"],"Morro Bay":["72637","72638","72639","72640",
				"72641","72642","72643","72644","72645","72646","72647","72648","72649","72650","72651","89065"]}',
		SpatialGroupsName="Site",ObservationGroups="",ObservationGroupsName="")

#the following is done by callRavian
if(is.null(formData$obsSQL)) formData$obsSQL <- ""
if(is.null(formData$TaxonGroups)){
	formData$TaxonGroups<-""
	formData$TaxonGroupsName<-""
}
if(is.null(formData$SpatialGroups)){
	formData$SpatialGroups<-""
	formData$SpatialGroupsName<-""
}
if(is.null(formData$ObservationGroups)){
	formData$ObservationGroups<-""
	formData$ObservationGroupsName<-""
}


#ggg<-RavianWeb.Richness.SNMIS(formData)
ggg<-RavianWeb.Richness.PFSS(formData)
#ggg<-RavianWeb.Richness(formData)
NROW(ggg)

#pass the results to RWO and check the returning xml
tst.xml<-RavianWeb.Output(ggg)
sink(file="C:/LeoTemp/XMLtests/Richness.xml")
cat(tst.xml)
sink()

###############################################
#PC
formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-"SpeciesCode IN ('COYE','AMGO','AMRO','WREN','GCSP','SOSP') AND Flyover != 'FlyOver'"
formData[["eventSQL"]]<-"ProjectCode IN ('TIMA') AND SamplingUnitId IN (33369,33370,33371,33372,33373,33374,33375,33376,33943,34021,34023,34607,34608,34609,
		34610,34611,34613,34614,34615,33384,33444,33445,33446,33447,33448,33449,33450,33451,33452,33453,33472,33603,33604,33605,33637,
		33638,33639,33640,33793,33794,33795,33796,33797,33798,33799,33800,33801,33802,33803,34434,34435,34436,34437,34438,34439)
		AND YearCollected >= 1900 AND YearCollected <= 2100 AND MonthCollected >= 02 AND MonthCollected <= 08"

ss<-list("Nice transects" = c(33369,33370,33371,33372,33373,33374,33375,33376,33943,34021,34023,34607,34608,34609,34610,34611,
				34613,34614,34615,33384,33444,33445,33446,33447,33448,33449,33450,33451,33452,33453,33472,33603,33604,33605,33637,
				33638,33639,33640),
		"Bad transects" = c(33793,33794,33795,33796,33797,33798,33799,33800,33801,33802,33803,34434,34435,34436,34437,34438,34439))
ssj<-toJSON(ss)
formData[["SpatialGroups"]]<-ssj
formData[["SpatialGroupsName"]]<-"TypeOfTransect"

############################################
#Band
formData[["DataType"]]<-"Band"
formData[["obsSQL"]]<-""
formData[["eventSQL"]]<-"ProjectCode='PALO' AND ProtocolCode='PALO_BAND' AND StationCode = 'PN' AND YearCollected < 2007 AND MonthCollected = 6"


#SpeciesCode IN ('COYE','AMGO','AMRO','WREN','GCSP','SOSP') 

###########################################
#AS
formData[["DataType"]]<-"AreaSearch"
formData[["obsSQL"]]<-"FlyOver != 'Flyover'"
formData[["eventSQL"]]<-"ProjectCode='PALO' AND SamplingUnitId IN (30004,30042,30044,30040) AND YearCollected<'2008'"

ss<-list("Nice plots" = c(30004,30042),
		"Bad plots" = c(30044,30040))
ssj<-toJSON(ss)
formData[["SpatialGroups"]]<-ssj
formData[["SpatialGroupsName"]]<-"Type_of_Plot"



#########################################
#SNMIS
formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-"DistanceFromObserver<=50"
formData[["eventSQL"]]<-"ProjectCode IN ('SNMIS') AND SamplingUnitId IN (61626,61627,61628,61629,61630,61631,61632,61633,61634,61635,
		61636,61637,61638,61639,61640,61641,61642,61643,61644,61645,61646,61647,61648,61649,61650,61651,61652,61653,
		61654,61655,61656,61657,61658,61659,61660,61661,61662,61663,61664,61665,61666,61667,61668,61669,61670,61671,
		61672,61673,61674,61675,61676,61677,61678,61679,61680,61681,61682,61683,61684,61685,61686,61687,61688,61689,
		61690,61691,61692,61693,61694,61695,61696,61697,61698,61699,61700,61701,61702,61703,61704,61705,61706,61707,
		61708,61709,61710,61711,61712,61713,61714,61715,61716,61717,61718,61719,61720,61721,61722,61723,61724,61725,
		61726,61727,61728,61729,61730,61731,61732,61733,61734,61735,61736,61737,61738,61739,61740,61741,61742,61743,
		61744,61745,61746,61747,61748,61749,61750,61751,61752,61753,61754,61755,61756,61757,61758,61759,61760,61761,
		61762,61763,61764,61765,61766,61767,61768,61769,61770,61771,61772,61773,61774,61775,61776,61777,61778,61779,
		61780,61781,61782,61783,61784,61785,61786,61787,61788,61789,61790,61791,61792,61793,61794,61795) 
		AND YearCollected >= 1900 AND YearCollected <= 2100 AND MonthCollected >= 02 AND MonthCollected <= 08"

#formData[["TaxonGroupsName"]]<-"Pesky Birds"

ss<-list("Good Points" = c(61626,61627,61628,61629,61630,61631,61632,61633,61634,61635,61636,61637,61638,61639,61640,61641,61642,61643,61644,61645,61646,61647,61648,61649,61650),
		"SoSo Points" = c(61651,61652,61653,61654,61655,61656,61657,61658,61659,61660,61661,61662,61663,61664,61665,61666,61667,61668,61669,61670,61671,61672,61673,61674,61675,61676,61677,61678,61679,61680,61681,61682,61683,61684,61685,61686,61687,61688,61689,61690,61691,61692,61693,61694,61695,61696,61697,61698,61699,61700,61701,61702,61703,61704,61705,61706,61707,61708,61709,61710,61711,61712,61713,61714,61715,61716,61717,61718,61719,61720),
		"Bad Points" = c(61721,61722,61723,61724,61725,61726,61727,61728,61729,61730,61731,61732,61733,61734,61735,61736,61737,61738,61739,61740,61741,61742,61743,61744,61745,61746,61747,61748,61749,61750,61751,61752,61753,61754,61755,61756,61757,61758,61759,61760,61761,61762,61763,61764,61765,61766,61767,61768,61769,61770,61771,61772,61773,61774,61775,61776,61777,61778,61779,61780,61781,61782,61783,61784,61785,61786,61787,61788,61789,61790,61791,61792,61793,61794,61795))
ssj<-toJSON(ss)
formData[["SpatialGroups"]]<-ssj
formData[["SpatialGroupsName"]]<-"Type_of_Point"

##PFSS
formData<-list(Process="Richness.PFSS",OutputType="XML",DataType="ShoreBird",eventSQL="ProjectCode IN ('BLWB') AND SamplingUnitId IN (67092,67094,
				67095,67096,67097,67589,67590,67591,67593,67594,67595,67596,67597,67598,67599,67600,67601,67602,67603,67604,67605,67606,68276) 
				AND MonthCollected >= 01 AND MonthCollected <= 12",
		obsSQL="(SpeciesCode IN ('allspecies') OR 'allspecies' = 'allspecies') AND NoObservations = 0", 
		level="b",TaxonGroups="",TaxonGroupsName="",SpatialGroups="",
		SpatialGroupsName="",ObservationGroups="",ObservationGroupsName="")

#source(paste(parent.dir,"/RavianVault/devel/AvianData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/BandData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/AreaSearchData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/PointCountData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/DataStore.R", sep=""))	
#source(paste(parent.dir,"/RavianVault/devel/RavianUtils.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/RavianResults.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/build/R/RavianWebOut.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/devel/RavianWeb.Utils.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/build/R/RavianWeb.Output.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/devel/RavianWeb.Summary.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/devel/RavianWeb.Richness.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/devel/RavianWeb.Richness.SNMIS.R", sep=""))