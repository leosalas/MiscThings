# TODO: Add comment
# 
# Author: lsalas
# Date created: Nov 3, 2009
###############################################################################
library(Ravian)
library(RavianWeb)
#library(foreach)

w.dir<-"C:/users/lsalas/workspace"
cadc.loc<-"/Ravian/test/CADC.R"
if(Sys.info()[1]=="Linux"){
	w.dir<-"/var/www/html"
	cadc.loc<-"/CADC.R"
}
setwd(w.dir)
source(paste(w.dir,cadc.loc,sep=""))
#source(paste(w.dir,"/RavianVault/devel/AvianData.R",sep=""))
#source(paste(w.dir,"/RavianVault/devel/ISBAdbData.R",sep=""))
#source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Summary.ISBAdb.R",sep=""))

formData<-list(Process="Summary",OutputType="XML",DataType="PointCount",eventSQL="ProjectCode = 'SNMIS'",
		obsSQL="", 
		level="0",TaxonGroups="",TaxonGroupsName="",SpatialGroups="",
		SpatialGroupsName="",ObservationGroups="",ObservationGroupsName="")

#formData<-list(Process="Summary.ISBAdb",OutputType="XML",DataType="ISBAdb",eventSQL="ProjectCode in ('ISBADB') AND SamplingUnitId IN ('68613','68628') AND (YearCollected >= 2000 AND YearCollected <= 2005) ",obsSQL="SpeciesCode IN ('AMAV','GRYE')",level="b",TaxonGroups="",TaxonGroupsName="",SpatialGroups="",SpatialGroupsName="",ObservationGroups="",ObservationGroupsName="")

#the following is done by callRavian
if(is.null(formData$obsSQL)) formData$obsSQL <- ""
if(is.null(formData$TaxonGroups)){
	formData$TaxonGroups<-""
	formData$TaxonGroupsName<-""
}
if(is.null(formData$SpatialGroups)){
	formData$SpatialGroups<-""
	formData$SpatialGroupsName<-""
}
if(is.null(formData$ObservationGroups)){
	formData$ObservationGroups<-""
	formData$ObservationGroupsName<-""
}
#ptm <- proc.time()
#ggg<-RavianWeb.Summary.ISBAdb(formData)
#proc.time() - ptm
#ggg<-RavianWeb.Summary.PFSS(formData)
#ggg<-RavianWeb.Summary.SNMIS(formData)
ggg<-RavianWeb.Summary(formData)
NROW(ggg)


#pass the results to RWO and check the returning xml
tst.xml<-RavianWeb.Output(ggg)
sink(file="C:/LeoTemp/XMLtests/Summary.xml")
cat(tst.xml)
sink()

############################################
#Band data 
formData[["DataType"]]<-"Band"
#formData[["obsSQL"]]<-"SpeciesCode = 'AMRO'"
formData[["eventSQL"]]<-"ProjectCode='PALO' AND ProtocolCode='PALO_BAND' AND YearCollected < 2005"
#SpeciesCode IN ('WIWA')

############################################
#PC 
#formData[["DataType"]]<-"PointCount"
#formData[["obsSQL"]]<-"DistanceFromObserver<=50"
#formData[["eventSQL"]]<-"ProjectCode IN ('TIMA') AND SamplingUnitId IN (68055,33369,33370,33371,33372,33944,33373,33374,33376,33943,33375,34028,34027,34026,34607,34608,34609,34610,34023,34024,34025,34611,34612,34613,34614,34615,34020,34021,34017,34018,34019,34022,34029) AND YearCollected >= 1900 AND YearCollected <= 2100 AND MonthCollected >= 02 AND MonthCollected <= 08"
#SpeciesCode IN ('COYE','AMGO','AMRO') AND 

formData[["Process"]]<-"Summary"
formData[["OutputType"]]<-"XML"
formData[["level"]]<-"0"

formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-""
formData[["eventSQL"]]<-"ProjectCode='TIMA' AND Transect='ALA' AND MonthCollected IN ('03','04','05','06','07','08')"

############################################
#AS 
#formData[["DataType"]]<-"AreaSearch"
#formData[["obsSQL"]]<-"SpeciesCode IN ('COYE','AMGO','AMRO')"
#formData[["eventSQL"]]<-"ProjectCode='PALO' AND Plot='PALO:LACR_A' AND YearCollected<>'2007'" #AS

##########################################
#ISBAdb
formData<-list(Process="Summary.ISBAdb",OutputType="XML",DataType="ISBAdb",eventSQL="SamplingUnitId IN (68625,68626,68627,68628,68629,68630) 
				AND YearCollected >= 2003 AND YearCollected <= 2006 AND MonthCollected >= 01 AND MonthCollected <= 12",
		obsSQL="(SpeciesCode IN ('allspecies') OR 'allspecies' = 'allspecies')", 
		level="0",TaxonGroups="",TaxonGroupsName="",SpatialGroups="",
		SpatialGroupsName="",ObservationGroups="",ObservationGroupsName="")

############################################
#PFSS
formData<-list(Process="Summary.PFSS",OutputType="XML",DataType="ShoreBird",eventSQL="ProjectCode IN ('BLWB') AND SamplingUnitId IN (67092,67094,
				67095,67096,67097,67589,67590,67591,67593,67594,67595,67596,67597,67598,67599,67600,67601,67602,67603,67604,67605,67606,68276) 
				AND YearCollected >= 2003 AND YearCollected <= 2004 AND MonthCollected >= 01 AND MonthCollected <= 12",
		obsSQL="(SpeciesCode IN ('allspecies') OR 'allspecies' = 'allspecies')", 
		level="0",TaxonGroups="",TaxonGroupsName="",SpatialGroups='{"East_Side":["67092","67094","67095","67096","67097"],
				"Kent_Island":["67589","67590","67591","67593","67594","67595","67596","67597","67598","67599"],
				"Pine_Gulch":["67600","67601","67602","67603","67604","67605","67606","68276"]}',
		SpatialGroupsName="Study_Areas",ObservationGroups="",ObservationGroupsName="")


############################################
#SNMIS
formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-"DistanceFromObserver<=50"
formData[["eventSQL"]]<-"ProjectCode IN ('SNMIS') AND SamplingUnitId IN (61626,61627,61628,61629,61630,61631,61632,61633,61634,61635,61636,
							61637,61638,61639,61640,61641,61642,61643,61644,61645,61646,61647,61648,61649,61650,61651,61652,61653,61654,
							61655,61656,61657,61658,61659,61660,61661,61662,61663,61664,61665,61666,61667,61668,61669,61670,61671,61672,
							61673,61674,61675,61676,61677,61678,61679,61680,61681,61682,61683,61684,61685,61686,61687,61688,61689,61690,
							61691,61692,61693,61694,61695,61696,61697,61698,61699,61700,61701,61702,61703,61704,61705,61706,61707,61708,
							61709,61710,61711,61712,61713,61714,61715,61716,61717,61718,61719,61720,61721,61722,61723,61724,61725,61726,
							61727,61728,61729,61730,61731,61732,61733,61734,61735,61736,61737,61738,61739,61740,61741,61742,61743,61744,
							61745,61746,61747,61748,61749,61750,61751,61752,61753,61754,61755,61756,61757,61758,61759,61760,61761,61762,
							61763,61764,61765,61766,61767,61768,61769,61770,61771,61772,61773,61774,61775,61776,61777,61778,61779,61780,
							61781,61782,61783,61784,61785,61786,61787,61788,61789,61790,61791,61792,61793,61794,61795) 
							AND YearCollected >= 1900 AND YearCollected <= 2100 AND MonthCollected >= 02 AND MonthCollected <= 08"
#SpeciesCode IN ('COYE','AMGO','AMRO') AND


#source(paste(parent.dir,"/RavianVault/devel/AvianData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/BandData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/AreaSearchData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/PointCountData.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/crossTabulate.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/crossTabulate.SNMIS.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/describeVariable.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/RavianResults.R", sep=""))
#source(paste(parent.dir,"/RavianVault/devel/RavianUtils.R", sep=""))
#source(paste(parent.dir,"/RavianVault/build/DataStore.R", sep=""))	
#source(paste(parent.dir,"/RavianWeb/devel/RavianWeb.Summary.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/build/R/RavianWebOut.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/devel/RavianWeb.Utils.R", sep=""))
#source(paste(parent.dir,"/RavianWeb/build/R/RavianWeb.Output.R", sep=""))


formData<-list(Process="Summary.SNMIS",OutputType="XML",DataType="PointCount",
		eventSQL="ProjectCode = 'SNMIS' AND SamplingUnitId IN (61676,61654,61653,61652,61651,61650,61649,61648,61647,61646,61635,61634,61655,61666,
				66067,61675,61674,61673,61672,61671,65984,61670,61669,61668,61667,61633,61632,61631,63133,63132,63131,63130,63129,63128,63127,63126,61725,
				61724,61723,63134,63135,61630,61629,61628,61627,61626,63203,63202,63201,63200,63198,63196,61722,61677,63205,63173,63172,63171,66719,63170,
				63169,63168,63167,63166,63165,63164,63174,63175,63204,63199,63197,66013,66011,66010,66012,66014,63180,63178,63176,63163,63162,63161,61699,
				61698,61697,61696,61685,61684,61683,61682,61681,61680,61679,61700,61701,66035,64086,63160,63159,63158,63157,63156,61705,61704,61703,61702,
				61678,61713,61689,61688,61687,61686,61665,61664,61663,61662,61661,66033,61660,61690,61691,61712,61711,61710,61709,61708,61707,61706,61695,
				61694,61693,61692,61659,61658,61657,64228,64210,64174,66032,64192,64156,66071,64226,64208,64172,64190,61636,61637,61656,66066,66065,61645,
				61644,61643,61642,61641,61640,61639,61638,64154,61714,61721,64243,64225,64189,64207,64171,63155,63154,63153,63152,63151,65985,64170,64206,
				65986,61720,61719,61718,61717,61716,66720,66068,64242,64224,64188,63150,63149,61715,64213,64177,64195,64159,63185,63184,63183,63182,63181,
				63179,63177,64231,64155,63148,63147,63146,64241,64223,64187,64205,64191,64173,64209,64227,64169,61742,61743,61744,61745,61766,61767,61768,
				61769,61770,61771,61741,61740,66575,66576,61735,66572,66573,66574,61736,61737,61738,61739,61772,61773,63216,63217,63218,63219,63220,63221,
				63222,63223,63224,61805,61804,61803,61774,61775,61796,61797,61798,61799,61800,61801,61802,63225,61751,61763,61764,61765,61776,61777,61778,
				61779,61780,61781,61762,61761,61760,61752,61753,61754,61755,66170,61756,61757,61758,61759,61782,61783,61795,61726,61727,61728,61729,61730,
				61731,61732,61733,61734,61794,61793,61784,61785,61786,61787,61788,61789,61790,66034,61791,61792) AND ((YearCollected >= 2009 AND YearCollected <= 2009) OR 'all' = 'all')",
		obsSQL="DetectionCue IN ('C','S','D') AND DistanceFromObserver <= 100 AND Flyover != 'FlyOver'  AND SpeciesCode IN ('FOSP','HAWO','MOUQ','YWAR')",
		level="0",TaxonGroups="",TaxonGroupsName="",
		SpatialGroups='{"Eldorado":["61676","61654","61653","61652","61651","61650","61649","61648","61647","61646","61635","61634","61655","61666",
				"66067","61675","61674","61673","61672","61671","65984","61670","61669","61668","61667","61633","61632","61631","63133","63132","63131",
				"63130","63129","63128","63127","63126","61725","61724","61723","63134","63135","61630","61629","61628","61627","61626","63203","63202",
				"63201","63200","63198","63196","61722","61677","63205","63173","63172","63171","66719","63170","63169","63168","63167","63166","63165",
				"63164","63174","63175","63204","63199","63197","66013","66011","66010","66012","66014","63180","63178","63176","63163","63162","63161",
				"61699","61698","61697","61696","61685","61684","61683","61682","61681","61680","61679","61700","61701","66035","64086","63160","63159",
				"63158","63157","63156","61705","61704","61703","61702","61678","61713","61689","61688","61687","61686","61665","61664","61663","61662",
				"61661","66033","61660","61690","61691","61712","61711","61710","61709","61708","61707","61706","61695","61694","61693","61692","61659",
				"61658","61657","64228","64210","64174","66032","64192","64156","66071","64226","64208","64172","64190","61636","61637","61656","66066",
				"66065","61645","61644","61643","61642","61641","61640","61639","61638","64154","61714","61721","64243","64225","64189","64207","64171",
				"63155","63154","63153","63152","63151","65985","64170","64206","65986","61720","61719","61718","61717","61716","66720","66068","64242",
				"64224","64188","63150","63149","61715","64213","64177","64195","64159","63185","63184","63183","63182","63181","63179","63177","64231",
				"64155","63148","63147","63146","64241","64223","64187","64205","64191","64173","64209","64227","64169"],"Inyo":["61742","61743","61744",
				"61745","61766","61767","61768","61769","61770","61771","61741","61740","66575","66576","61735","66572","66573","66574","61736","61737",
				"61738","61739","61772","61773","63216","63217","63218","63219","63220","63221","63222","63223","63224","61805","61804","61803","61774",
				"61775","61796","61797","61798","61799","61800","61801","61802","63225","61751","61763","61764","61765","61776","61777","61778","61779",
				"61780","61781","61762","61761","61760","61752","61753","61754","61755","66170","61756","61757","61758","61759","61782","61783","61795",
				"61726","61727","61728","61729","61730","61731","61732","61733","61734","61794","61793","61784","61785","61786","61787","61788","61789",
				"61790","66034","61791","61792"]}',SpatialGroupsName="Forests",ObservationGroups="",ObservationGroupsName="")

