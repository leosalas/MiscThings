# TODO: Add comment
# 
# Author: lsalas
# Date created: Oct 28, 2010
###############################################################################


library(Ravian)
library(RavianWeb)
library(unmarked)
library(gam)

w.dir<-"C:/Documents and Settings/lsalas/workspace"
cadc.loc<-"/RavianVault/test/CADC.R"
if(Sys.info()[1]=="Linux"){
	w.dir<-"/home/lsalas/tests"
	cadc.loc<-"/CADC.R"
}
setwd(w.dir)
source(paste(w.dir,cadc.loc,sep=""))
source(paste(w.dir,"/RavianVault/devel/PointCountData.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/RavianSummaryTable.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/RavianSampleSummaryTable.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/AvianData.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/DataStore.R",sep=""))
source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Abundance.R",sep=""))

formData<-list()
formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-"SpeciesCode IN ('AMRO','RWBL','HOFI','AMGO') AND DistanceFromObserver<=50"
formData[["eventSQL"]]<-"ProjectCode IN ('TIMA') AND Transect = 'ELSL'"


gg<-list("Good birds" = c("RWBL","HOFI"),
		"Bad birds" = c("AMRO","AMGO"))
ggj<-toJSON(gg)
formData[["TaxonGroups"]]<-ggj
formData[["TaxonGroupsName"]]<-"TypeOfBird"

#ss<-list("Good Points" = c(31358,31352,31349,31359),
#		"SoSo Points" = c(31353,31354,31350,31355),
#		"Bad Points" = c(31356,31360,31357,31351,68057))
#ssj<-toJSON(ss)
#formData[["SpatialGroups"]]<-ssj
#formData[["SpatialGroupsName"]]<-"Type_of_Point"

#hh<-list("HabitatType"=list("Good habitat" = c("U","L"),
#		"Bad habitat" = c("AG","B")))
#hhj<-toJSON(hh)
#formData[["ObservationGroups"]]<-hhj
#formData[["ObservationGroupsName"]]<-"TypeOfHabitat"


#the following is done by callRavian
if(is.null(formData$obsSQL)) formData$obsSQL <- ""
if(is.null(formData$level)) formData$level <- ""
if(is.null(formData$TaxonGroups)){
	formData$TaxonGroups<-""
	formData$TaxonGroupsName<-""
}
if(is.null(formData$SpatialGroups)){
	formData$SpatialGroups<-""
	formData$SpatialGroupsName<-""
}
if(is.null(formData$ObservationGroups)){
	formData$ObservationGroups<-""
	formData$ObservationGroupsName<-""
}

#ggg<-RavianWeb.Abundance.SNMIS(formData)
ggg<-RavianWeb.Abundance(formData)
NROW(ggg)

