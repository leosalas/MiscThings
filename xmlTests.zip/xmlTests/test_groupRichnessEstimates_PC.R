# TODO: Add comment
# 
# Author: lsalas
# Date created: Nov 2, 2010
###############################################################################


library(Ravian)
library(RavianWeb)

w.dir<-"C:/Documents and Settings/lsalas/workspace"
cadc.loc<-"/RavianVault/test/CADC.R"
if(Sys.info()[1]=="Linux"){
	w.dir<-"/home/lsalas/tests"
	cadc.loc<-"/CADC.R"
}
setwd(w.dir)
source(paste(w.dir,cadc.loc,sep=""))
source(paste(w.dir,"/RavianVault/devel/PointCountData.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/RavianSummaryTable.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/RavianSampleSummaryTable.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/AvianData.R",sep=""))
source(paste(w.dir,"/RavianVault/devel/DataStore.R",sep=""))
source(paste(w.dir,"/RavianWeb/devel/RavianWeb.Abundance.R",sep=""))

formData<-list()
formData[["DataType"]]<-"PointCount"
formData[["obsSQL"]]<-"SpeciesCode IN ('COYE','AMGO','AMRO','WREN','GCSP','SOSP') AND Flyover != 'FlyOver'"
formData[["eventSQL"]]<-"ProjectCode IN ('TIMA') AND SamplingUnitId IN (33369,33370,33371,33372,33373,33374,33375,33376,33943,34021,34023,34607,34608,34609,
		34610,34611,34613,34614,34615,33384,33444,33445,33446,33447,33448,33449,33450,33451,33452,33453,33472,33603,33604,33605,33637,
		33638,33639,33640,33793,33794,33795,33796,33797,33798,33799,33800,33801,33802,33803,34434,34435,34436,34437,34438,34439)
		AND YearCollected >= 1900 AND YearCollected <= 2100 AND MonthCollected >= 02 AND MonthCollected <= 08"

ss<-list("Nice transects" = c(33369,33370,33371,33372,33373,33374,33375,33376,33943,34021,34023,34607,34608,34609,34610,34611,
				34613,34614,34615,33384,33444,33445,33446,33447,33448,33449,33450,33451,33452,33453,33472,33603,33604,33605,33637,
				33638,33639,33640),
		"Bad transects" = c(33793,33794,33795,33796,33797,33798,33799,33800,33801,33802,33803,34434,34435,34436,34437,34438,34439))
ssj<-toJSON(ss)
formData[["SpatialGroups"]]<-ssj
formData[["SpatialGroupsName"]]<-"TypeOfTransect"
formData[["level"]]<-3

#the following is done by callRavian
if(is.null(formData$obsSQL)) formData$obsSQL <- ""
if(is.null(formData$TaxonGroups)){
	formData$TaxonGroups<-""
	formData$TaxonGroupsName<-""
}
if(is.null(formData$SpatialGroups)){
	formData$SpatialGroups<-""
	formData$SpatialGroupsName<-""
}
if(is.null(formData$ObservationGroups)){
	formData$ObservationGroups<-""
	formData$ObservationGroupsName<-""
}


ggg<-RavianWeb.Richness.SNMIS(formData)
#ggg<-RavianWeb.Richness(formData)
NROW(ggg)

